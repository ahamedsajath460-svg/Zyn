# Built-in API keys (GitHub Secrets)

The app works right after the first open without the user adding a key. The keys are added at build time by `.github/workflows/release-apk.yml` (step "Add built-in API keys from secrets") and are never stored in the repository.

GitHub repo → Settings → Secrets and variables → Actions → New repository secret. Create ONE secret named `AI_API` and paste every key into it, one per line as `provider:key`:

```
pollinations:sk_xxxxxxxx
openrouter:sk-or-v1-xxxxxxxx
gemini:AIzaxxxxxxxx
groq:gsk_xxxxxxxx
tavily:tvly-xxxxxxxx
youtube:AIzaxxxxxxxx
```

- Providers: `pollinations`, `openrouter`, `gemini`, `groq`, `tavily`, `youtube`.
- Line order = fallback order; the first text provider is the primary one.
- Always write the `provider:` prefix (YouTube and Tavily keys cannot be recognised without it).
- Empty lines and lines starting with `#` are ignored. The old `AI_KEYS` secret still works and is added after `AI_API`.

How the app uses them:
- Every Pollinations key becomes a TEXT provider only (never used for image or video; users add their own Pollinations key for that); every Gemini key becomes a Gemini provider. If one key hits a limit, the next one answers automatically (existing fallback order). The user's own providers stay first.
- YouTube keys are used in turn (round-robin) by the YouTube tools.
- Tavily keys are tried in turn (rotating start); if one fails or is out of quota, the next is used, then DuckDuckGo/Wikipedia.
- The floating assistant and the AI agent use the same providers.
- Built-in keys are left out of backups and replaced by `[redacted key]` when a chat is shared.

Note: keys inside an APK can be extracted by someone who tears the APK apart. Use keys with usage limits.

## Who can see the built-in keys (v21)
- The built-in keys (from GitHub Secrets) are shown **only** when the signed-in account is the admin e-mail (`ZADMIN` in `a2z.html`, currently ahamedsajath160@gmail.com) and that e-mail is verified (Google sign-in is always verified).
- Every other account: the app still works with the built-in keys, but they are never listed or shown anywhere: not in AI providers, My API Keys, Test all, Billing, provider pickers, "copy key from another provider", the title menu, the line under the app name, or under the messages (the floating panel too). They only see a neutral "Zyn Ai".
- Keys a user adds themselves are always shown to that user (header, under messages, providers).
- Change the admin e-mail in two places: `ZADMIN` in `a2z.html` and the Firestore rules (ADMIN_PANEL_SETUP.md).
