# Ask card: 4 question types + when-to-ask rules (a2z.html)

Chat now asks questions like Claude does, always as a tappable card at the end of the reply:
- single: pick one (+ "Something else" field)
- multi: pick several (+ "Something else" field)
- rank: drag the handle (or tap the arrows) to put options in priority order
- text: free typing with a placeholder, no options

Rules sent to the AI (ASK_RULE): check the chat first, 1 question where possible (max 3), 2-4 short options,
same language/script as the user, no yes/no plain-text questions, and do NOT ask for A-or-B questions, venting,
opinions, factual questions, reviews/translations, or prompts that already have constraints.
The Settings toggle "Ask a clarifying question when my request is unclear" also uses the card now.
Files: app/src/main/assets/a2z.html (ASK_RULE, parseAsk, build, showAsk, .askc CSS).

## Work-time questions (Code Writer + Project Agent)
If the AI hits a real doubt while coding or editing, it now STOPS and shows the same ask card (single / multi / rank / text)
inside the tool, waits for the answer, then continues with it. Skip = the AI picks a sensible default.
- Code Writer (cwTool, io.ask): any step (plan, write part, review, edit) can reply with an ```ask block. Answers are saved
  in the job (J.qa) and sent back as "DECISIONS ALREADY MADE" so it never asks the same thing twice (also after Resume).
- Project Agent: new action `@@ask` + JSON + `@@end`. The answer returns as the action result; decisions are repeated in every step prompt.
- The Stop button also closes a waiting card.
Helpers: askCard(), askBlocking(), ASK_WORK_RULE, askDecisions() in a2z.html.

## Everywhere else (tools, floating panel, screen agent)
- Tools page AI tools (everything that calls ask()): wrapped in a2z.html. On a real doubt the tool pauses, shows the card
  (in the tool page, or above the chat box when run from chat), then continues with the answer.
- Floating panel (zyn_float_panel.html): ask card renderer (single/multi/rank/text); FloatingPanelController.systemPrompt
  now includes FLOAT_ASK so the floating chat asks with the card. The answer is sent as the next message.
- Screen agent (AgentRunner.kt): "clarify" now carries an "ask" object -> shown as the card; ACT_SYS has a DOUBT rule:
  in the middle of a task the agent stops with {"explain","ask"} (no action), the card is shown, and the answer continues the
  task through the existing pendingTask follow-up. AUTO mode stays silent on purpose (the user authorised the whole task).
  The raw ```ask block is never read aloud.
NOT tested on a device or compiled here (no Gradle/Android in this sandbox): build with the GitHub Action and test.
- Screen-share tools (ai() in a2z.html: Describe, Transcribe, Translate, Summarise) also pause and ask with the card on a real doubt.

## Greeting (empty chat)
Added Claude-style greetings: day of the week (Happy Tuesday), friendly openers (all English; name = profile name, else Full name, else Google account name), mixed with the time-of-day ones (a2z.html, pool()).
