# Auto tools in chat (a2z.html, v19)

> v21 below (Code Writer, Website builder, QR code, Code explainer, Project Agent run by words) is replaced: see MANUAL_TOOLS_MENU_CHANGES.md. They now start only from + > Create with tools.

- YouTube channel by name: "<name> channel link kodu", "<name> youtube link", "@handle subscribers evvalavu" -> channel search (top 4 matches with @handle link and subscriber count). Needs a YouTube Data API key; without a key the chat falls back to a web search ("<name> YouTube channel").
- Place lookup: "<place> map link", "location of <place>", "<place> enga irukku" -> OpenStreetMap (free, no key) + a Google Maps link.
- The AI is told that a tool result is given and to finish the job from it.
- Unchanged: web search, weather (Open-Meteo), calendar, YouTube video links/search/comments. Image/video/voice/API tools stay manual (Tools page).

## v20: developer tools in chat
Exact helpers run by themselves when the message asks for them (result is given to the AI as-is):
- GitHub: github.com link, owner/repo or "github <user>" -> profile, repo info, latest commits, issues, readme (api.github.com, no token, 60 requests/hour).
- UUID, SHA-1/256/384/512, Base64 encode/decode, URL encode/decode, JSON validate/format/minify, regex test (/pattern/flags + text), colour HEX/RGB/HSL with shades, HTTP status check of a link.
- Not in chat (stay in Tools > Developer): WebSocket tester, REST client with headers/body, Markdown editor.

## v21: Code Writer, Website builder, QR code, Code explainer, Project Agent run by themselves in chat
Plus-menu switch "Dev tools in chat" (ON by default). Light requests in English, Tamil or Tanglish start the tool and the result stays in the chat:
- Code Writer: "todo app pannu", "snake game build pannu", "python script ezhuthu", "kotlin android app ..." -> plan, write in parts, review, file cards, live phone preview (web apps), Download all (.zip). Short script/function asks use Quick mode. Default language is a single-file HTML app (so the preview works); Python, Node, Kotlin, Java, C/C++, PHP, SQL, Bash, YAML are picked from the words. After a build, a follow-up like "add dark mode" or "fix the button" updates the same project.
- Website builder: "website venum", "landing page for my gym" -> same builder as Tools, live preview and Copy code / Download in the chat. The HTML is also saved in the message.
- QR code: "qr code for https://..." or "qr code kodu: text" -> QR image with Save image in the chat. Needs internet for the QR library (cdnjs).
- Code explainer: paste code (or attach a code file) and write explain / vilakku / step by step -> the AI explains in simple words in your language, with bugs and improvements.
- Project Agent: attach a .zip with the + button (no need to switch Project Agent ON) and write the task -> updated ZIP in the chat. Writing "project agent" alone tells how to use it.
Questions such as "how to make an app" or "what is a QR code" still go to the AI as text. Turn the switch OFF to send everything to the AI as text.
Code changes: cwTool(w,X) embed mode (own storage key per chat result), website builder 'wbdone' event, Project Agent auto-ZIP, new script v21 at the end of a2z.html.
