# Calendar: real tools for the AI (Zen AI)

Works like a real calendar assistant. Needs Calendar = "Read & Write" on the Permissions page.

## What the AI can do now
- Reads the live phone calendar: 30 days back to 120 days ahead, all calendars, with event ids (was only 14 days).
- Add event: title, date/time, all-day, location, notes, reminders (default 10 min before), repeat (daily/weekly/monthly/yearly or full rule), attendees, choose calendar. Saved right away, card shows Undo.
- Edit event: rename, move/reschedule, change place/notes/reminders/repeat. Saved right away.
- Delete event: asks Delete / Keep first (repeating events delete the whole series).
- Several actions in one message are fine. If calendar permission is missing, Android asks for it.
- Understands English, Tanglish and Tamil triggers (naalaikku, reminder podu, etc.).

## Files
- MainActivity.kt: calListJson, calSearchJson, calCreateJson, calUpdateJson, calDeleteJson + bridge calList / calSearch / calCreate / calUpdate / calDelete (old calEvents / calAdd kept).
- a2z.html: calendar block near "Location + Calendar features" (calCtx, CALINSTR, runAct, afterAnswer); Permissions text updated.
- AndroidManifest.xml: no change (READ_CALENDAR / WRITE_CALENDAR were already there).
