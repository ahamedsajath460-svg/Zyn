# Capabilities page: every setting now does something

Already working before: Generate memory from chats, Include sensitive topics in memory, Memory files, Web search (section at the bottom of the page).

Now wired (a2z.html, `capPage` + `<script id="zyn-capabilities-js">` + `<style id="zyn-viz">`):

- Inline visualizations: the AI is told it may answer with ```chart (JSON), ```mermaid, ```svg or ```widget blocks. Charts are drawn as SVG (bar, line, area, pie, doughnut), Mermaid diagrams load from cdnjs on first use (needs internet), SVG is shown as an image, widgets run in a sandboxed iframe. Each block has Code and Copy buttons. Off: normal code blocks, and the AI is told not to use them.
- Code execution and file creation: off removes file cards, Download and Preview buttons (code stays in plain blocks with Copy), removes the code/file rules from the AI prompt and blocks the Create with tools button with a message.
- Artifacts: locked on while Code execution is on; when Code execution is off it becomes a real switch (Preview button for HTML, SVG and Markdown code).
- Switch models when a message is flagged: on = next provider is tried (as before). Off = the chat pauses with a clear message and Retry when a provider's safety filter flags the message (`__zFlag` in the send loop).
- Tool access: controls when the extra tool instructions are added to the prompt. Auto = when the message or recent chat needs them, On demand = only on clear requests (least data), Always available = every message.
- Toggling these redraws the chat so old messages follow the setting. In-app help text updated.

## Web search section shows only while web search is on

- In Settings > Capabilities only the "Enable web search" switch is always visible. Search automatically, Search engine, Search preferences, Search result settings and the Tavily key row appear when it is on and hide when it is off (updates instantly when you flip the switch).

## Fix: Think deeper was blocked when Code execution was off
- The guard for "Create with tools" pointed at `#tk`, which is the Think deeper button. It now checks the + sheet button whose label is "Create with tools".
