# Chat inside Capabilities
- Settings > Capabilities now ends with a Chat row (Replies, behavior, follow-ups, memory) right below the Web search block. It opens the same Chat page as the Chat row on the Settings home (which is still there).
- Update: the Chat row was removed from the Settings home; Chat now lives only in Capabilities.
