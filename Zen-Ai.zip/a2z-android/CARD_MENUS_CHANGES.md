# Claude-style cards (header 3-dot menu + long-press on a message)

- Header 3-dot card (`#hm`): Claude look - dimmed page behind, white rounded card in the top-right corner, grey chat title, Material outlined icons (Pin, Share, Rename, Add to project, Add to home, Delete in red).
- Long-press on a chat message: a small card (`#mm`) opens above the finger with only two buttons: Select and Memory. Copy, Read aloud, Edit, Download .md / .txt and Delete are removed from this menu.
- Select: the message becomes selectable and the app asks Android (`A2ZNative.selectAt`, new in `MainActivity.kt`) to do a real long press on it, so you get the normal handles and the Copy / Select all / Share toolbar. In a plain browser (no native bridge) the whole message is highlighted instead, and a normal long press works on it.
- Memory: saves the message to memory (same as the old "Remember this").
- Code: `<style id="zyn-claude-cards">` and `<script id="zyn-claude-cards-js">` at the end of `a2z.html`; the in-app help line about long-press was updated.

- Update: long-press only works when the finger is on real text (empty space, padding, buttons and icons do nothing). Select now makes only the pressed paragraph / list item / code block selectable. Card icons are clean stroke icons (text-with-caret for Select, bookmark for Memory).
