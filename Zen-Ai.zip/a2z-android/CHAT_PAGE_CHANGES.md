# Settings: Chat page (chat behavior only here)
- New Settings: a "Chat" button right below Capabilities opens its own page (back arrow on top).
- The Chat page holds all chat behavior: follow-ups, AI chat titles, creativity, memory depth, file reading limit, remember other chats, open links, image quality, data saver, memory notes, extra instructions, plus Chat preferences (response style, length, streaming, auto continue) and AI behavior (emoji, formatting, clarifying question, think step by step).
- Removed from the old places: the old Settings dialog no longer shows a Chat tab; Agent Control no longer shows Chat preferences / AI behavior (it keeps Personalities). Duplicate Creativity and Custom instructions boxes removed (same settings, shown once).
- File: app/src/main/assets/a2z.html (chatSheet, agentUI, openSettings, Settings home).
