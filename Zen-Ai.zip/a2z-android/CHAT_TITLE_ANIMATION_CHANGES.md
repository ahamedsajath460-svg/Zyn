# Chat title rename animation

File changed: `app/src/main/assets/a2z.html` (only this file)

## Naming flow (already in the app, verified)
1. First message is a greeting ("Hi", "Hello", "Vanakkam"...) -> chat is named **Greeting**.
2. Further small talk ("epdi irukinga", "how are you") keeps the name **Greeting**.
3. The first message that has a real topic (2nd, 3rd ... up to the 7th exchange) -> the AI reads the chat and renames it
   (for example "iPhone 17 Price Details"). A chat the user renamed by hand is never changed.

## New: animation when the name changes
- Top bar: the old name is erased, the new name types in with a Material "auto_awesome" sparkle and a caret, then a soft pop.
- Sidebar: the renamed chat row flashes with the accent colour and its text types in.
- Opening or switching chats does not animate; only a rename inside the open chat does.
- Respects "reduce motion" (no animation, name changes instantly).

## Code
- `zyn-titles` script: `done()` now fires a `zt-title` event ({id, from, to}).
- Header `sync()` calls `window.__ztAnim(b, title, cur)` before writing the title.
- New `<style id="zyn-title-anim">` and `<script id="zyn-title-anim-js">` at the end of the file.

## Chat name centred in the top bar
- The name is centred on the screen, not just in the free space between the buttons. A small script measures the left and right button groups
  and gives both sides the same space (`--ttl`), so it stays centred even when a button is added or hidden. Long names get "..." at the end.
- Code: `<style id="zyn-title-center">` and `<script id="zyn-title-center-js">` at the end of `a2z.html`.
