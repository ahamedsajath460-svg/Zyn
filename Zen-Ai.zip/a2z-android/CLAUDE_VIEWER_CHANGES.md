# Claude-style file viewer (Preview / Code + ⋮ menu)

Files changed
- `app/src/main/assets/a2z.html`: new `zyn-claude-viewer` CSS + script at the end; `viewFile()` (file cards) now calls `window.zenViewFile`.
- `app/src/main/java/com/a2z/ai/MainActivity.kt`: two new bridge methods, `printHtml(html, title)` (Android print dialog, Save as PDF) and `shareFile(name, mime, b64)` (share sheet via the existing FileProvider).

Behaviour
- Tap any file card or code block -> full-screen viewer: X, file name, ⋮ menu.
- ⋮ menu: Preview / Code (when the type can be previewed), Share, Copy, Download, Save as PDF, Share as PDF, Print.
- Preview works for html, svg, md, csv, tsv (new table preview), Word / Excel / PowerPoint / PDF / images / media (existing converters). All other languages open as code.
- Code blocks (unnamed, short) get an "Open" button; tapping a block's file name opens the viewer too.
- Save/Share as PDF = PDF of the source text (ZenGen). Print = what is on screen (rendered page in Preview, highlighted code in Code).
