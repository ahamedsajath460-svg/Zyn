# Cleanup of old first-start code

Checked: boot gate (`a2z-boot`, `a2z-boot-css`), sign-in page (`#authgate` CSS, markup, `zyn-login-js`, Firebase script), guest mode, welcome greeting, Android launch theme and manifest. Every class, id, keyframe and function in these was still referenced, so they were kept.

Removed (not used any more):
- `<style id="fba-css">`: styles for the old sidebar sign-in box (`#acct`). That box no longer exists in the markup or the JS (sign-in lives only on the first-open sign-in page), so the CSS did nothing. Its leftover selector in the pure-white override was removed too.
