# Cloud Studio keeps working when you leave the tool, open Chat, or close the app

**Problem:** work started in Zen AI Cloud Studio (build, AI App Creator, AI auto-fix) stopped or was lost when you left the tool, went to Chat or closed the app.

**Root cause (main bug):** every time the tool was opened, `CS.init()` reloaded the database. A build that was still being followed kept its own record objects, which were no longer part of the reloaded database, so its progress and final result were saved to nowhere.

## What changed
**Page (`cloudstudio-core.js`, `-gen.js`, `-ui.js`, `a2z.html`)**
- `CS.init()` loads once per account (the bug above).
- Builds, the AI App Creator and the AI fix loop are saved background jobs (`CS.build`, `CS.jobs`). Screens only subscribe (`CS.on`); leaving a screen does not stop anything, and opening Build Center / AI App Creator again re-attaches to the running work.
- Creator creates the project itself when done (no screen needed) and can continue from the files already written after an interruption.
- Fix loop writes every step down; a fix that needs approval waits ("Review pending fix" button) instead of being lost.
- On app start (and when the app becomes visible) `CS.resumeAll()` re-attaches to unfinished builds and jobs and applies results the native watcher collected.
- While Cloud Studio works it holds the existing keep-alive service (`window.__zynCsHold`, renewed every 4 minutes), whichever screen is open.
- Notification when a job ends while you are away.

**Phone (Kotlin)**
- `CloudWatchService` (+ `CloudWatchLogic`, `CloudWatchStore`): foreground service with `stopWithTask="false"`. Follows the GitHub run even if the app is closed from Recents, saves the APK to Downloads/Zen Ai/Cloud Studio, and notifies you. Stops itself when nothing is watched.
- `CloudBridge`: new `watchStart / watchStop / watchTake`. Token handling moved to `CloudVault`, APK saving to `CloudFiles` (same behavior).
- `MainActivity.onBackPressed`: while a tool or cloud build works, Back moves the app to the background instead of closing it (closing destroyed the page and all jobs in it).
- `KeepAliveService`: every start renews the wake lock and the 30 minute safety timer.

## Second pass: bug found by checking the whole path (AI generate -> APK)
- **The page's `ask()` returns an object `{text, think, sources, queries, trunc}`, not a string.** Cloud Studio treated it as a string, so with a real AI provider the App Creator, auto-fix and AI edit got "[object Object]" (JSON not found / garbage files). The tests only used string stubs, so this was hidden. `CS.askFn()` now returns plain text, reports a cut-off reply (`trunc`) and an empty reply with a clear message.
- The AI is told never to ask questions (the page's ask wrapper can otherwise stop and wait for an answer while you are away).
- A failed App Creator job shows "Continue where it stopped" (it keeps the files already written).
- Starting a build with no repository set no longer leaves a stuck build / keep-alive.
- New tests: 5 with real-shaped AI replies (fenced code, cut-off, empty, fix loop), and `tools/cloud/tests/ui-bg-test.js` which drives the real a2z.html: generate with AI, leave the tool for Chat, build, come back.

## What is and is not possible
- Leave the tool / Chat / other app / lock screen / Back button: everything continues, including AI writing and the fix loop.
- Swipe the app away from Recents: the GitHub build is followed natively and the APK is saved. The AI parts (writing an app, fixing errors) need the page and the AI keys, so they continue the next time the app opens (state is saved, nothing is lost).
- Force stop in Android settings stops everything until the app is opened again.
- Android 15 limits "data sync" foreground services to about 6 hours per day, far above a build.

## Tests
- `node tools/cloud/tests/run-tests.js`: 33 pass (11 new).
- `node tools/cloud/tests/ui-test.js`: real a2z.html in headless Chromium, passes.
- `tools/cloud/run-watch-tests.sh`: 8 Kotlin tests for the watcher logic against a fake GitHub, pass.
- Android-bound Kotlin was type-checked against API stubs only (no errors); still not compiled with the real Android SDK here: CloudWatchService, CloudVault, CloudBridge, MainActivity edits. GitHub Actions build will show any compile error.

---

## v3 — Import your own ZIP / files / code and build an APK

New file: `app/src/main/assets/cloudstudio-import.js` (loaded after `cloudstudio-gen.js` in `a2z.html`).

Where in the app
- Cloud Studio → **My Projects → Choose ZIP or files** (new project)
- Cloud Studio → **AI App Creator → Import my own ZIP / code / files**
- Cloud Studio → **Code Workspace → Add files** (add to the open project)

What it accepts
1. **Android Studio project ZIP** (has `settings.gradle(.kts)`, any folder depth): used as it is, with your own Gradle files.
2. **ZIP of sources only** (has `AndroidManifest.xml`, no Gradle): Zen AI adds its tested Gradle files around your code.
3. **Loose files** (`.kt .java .xml .png .ttf …`): each goes to the folder Android expects (Kotlin by `package`, layouts, drawables, values, menu, font, raw, assets). You can edit every target path before it is added. A starter manifest/theme/icon is added only if you did not supply them.

Safety rules (never uploaded): keystores/certs, `local.properties`, Gradle wrapper, `.github`/YAML, `build/`, `.idea`, `.git`, `*.apk/*.jar/*.so`, unsafe paths (`..`, absolute), password-protected entries, files > 5 MB, ZIPs > 80 MB unpacked or > 5000 entries. A "not imported" list with reasons is shown.

Images / fonts / sounds are kept as binary resources (`CS.bin`, separate store) and pushed to GitHub as base64 blobs next to the text files (limits: 1.5 MB each, 12 MB total). ZIP reading is offline (browser `DecompressionStream`); needs Android System WebView 80+.

Tests: `run-tests.js` 44 pass (11 new import tests incl. zip → push → build → APK and byte-exact PNG round trip), new `ui-import-test.js` (real a2z.html, file chooser → plan dialog → build; Add files), `ui-test.js`, `ui-bg-test.js`, JVM watch tests all pass.
Not tested: real Android phone file picker, real GitHub Actions/Gradle compile of an imported project, WebView older than 80.

---

## v3.1 — every download goes to Downloads/Zen Ai

- New `DownloadsSaver.kt`: the single place user-facing files are saved (Downloads/Zen Ai[/sub]). No fallback to app-private folders (the old Android 6–9 fallback saved into `Android/data/...`, now removed).
- `Bridge.saveFile` (images, exports, documents) and `CloudFiles.saveToDownloads` (APKs, also from the background watcher) use it.
- WebView `DownloadListener`: http/https downloads → system DownloadManager → Downloads/Zen Ai.
- a2z.html: every `<a download>` with a blob:/data: link (detached or clicked, from any tool) is routed to `saveFile` instead of being silently dropped by the WebView.
- Manifest: `WRITE_EXTERNAL_STORAGE` with `maxSdkVersion=28` (Android 6–9 only; asked when the first download happens).
- Test: `tools/cloud/tests/dl-test.js` (real a2z.html). Not compiled with the real Android SDK / not tried on a phone.
