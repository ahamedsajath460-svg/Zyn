# Zen AI – Creative Design Studio (10 tools + hub)

## What was added (Creative category)
Existing tools kept untouched: AI Image Generator, AI Video Generator, Image & Video to Link.
New: **Creative Design Studio** hub + Logo Studio, Poster Maker, Thumbnail Maker, Banner Designer, Presentation Designer, Infographic Maker, UI Mockup Generator, Color Palette Generator, Icon Studio, Brand Kit Generator.

No image-generation API is used anywhere. Everything is drawn locally (SVG / HTML / CSS / Canvas). AI is optional and uses the existing Zen AI text provider (`ask`) – no new key system, no hardcoded keys. Every tool works without AI (templates, editing, export).

## Per-tool summary (own theme, workspace, settings, export, history)
| Tool | Theme | Notes | Exports |
|---|---|---|---|
| Logo Studio | black + gold | templates, symbol library, text/fonts, palettes | PNG, SVG, PDF |
| Poster Maker | vibrant editorial | event/business/festival/sale templates, free canvas | PNG, JPG, PDF, SVG |
| Thumbnail Maker | dark creator | 16:9, YouTube styles, photo import | PNG, JPG |
| Banner Designer | modern marketing | web/social/YouTube/ad sizes | PNG, JPG, PDF, SVG |
| Presentation Designer | elegant corporate | outline → slides, themes, charts, notes | **editable PPTX**, PDF, slide PNG |
| Infographic Maker | data visualisation | timeline, process, stats, bar/line/pie charts | PNG, PDF, SVG |
| UI Mockup Generator | developer dark | components → real HTML/CSS, phone/tablet/web, multi-screen, code tab | HTML, CSS, SVG, PNG |
| Color Palette Generator | colour laboratory | 7 harmonies, gradients, WCAG contrast, palette from photo (k-means, on device), history | CSS vars, JSON, SCSS, HEX list, PNG, gradient SVG |
| Icon Studio | minimal vector | symbol library (line/solid/duotone), geometric generator, collections, AI path icons | SVG, PNG, PDF, ZIP, SVG sprite |
| Brand Kit Generator | luxury branding | one identity drives 12 assets: logo (dark/light), card front/back, social profile/post/cover, letterhead, 4 guideline pages | per-asset PNG/JPG/PDF/SVG, ZIP of everything + colors.json/css, guidelines PDF |
| Hub | – | tool grid, search, favourites, recent projects, import | – |

Shared engine (`studio-core.js`): select, drag, resize, rotate, text/font/colour/background, shapes, delete, duplicate, undo/redo, layers, zoom, snapping, save. Projects (`studio-io.js`): save, rename, duplicate, delete, recent, 1.5 s autosave, up to 8 restorable versions, `.zenstudio.json` export/import.

## New files (app/src/main/assets)
studio-core.js, studio-io.js, studio-ui.js, studio-logo.js, studio-a.js, studio-b.js, studio-c.js, studio-d.js
Tests: tools/studio-tests/ (all.js = per-tool functional run in the real a2z.html, page.js = open every Creative tool, t1.js = engine/export, shot.js = screenshots).
## Modified files
a2z.html – only 8 `<script src="studio-*.js">` tags added before `webimages.js`. No Kotlin, manifest, package or auth code changed.

## Verification (what was actually run)
- Real `a2z.html` in headless Chromium (412×860): all 14 Creative tools register and render, 0 JS errors.
- Each tool opened and exported; files checked: all PDFs pass `qpdf --check`, PPTX opens in python-pptx (4 slides, text/shapes as editable objects) and renders in LibreOffice, SVGs parse as XML, PNG/JPG sizes correct.
- AI paths tested with a stubbed `ask` for UI Mockup and Palette; project autosave → hub "Recent" → reopen in the right tool; hub opens tools; 12 brand assets validate.
- Bug found and fixed in testing: mockup PNG export (invalid XML in SVG), hub navigation (`tool` must be an id).

## Honest limits
- **Not built or run on Android.** No Gradle/SDK/device here; only Chromium. Android WebView download/share of the exported files uses the app's existing `dlBlob` path and still needs a real-device check. Run the GitHub Actions build and try each export on a phone.
- PDF export is a high-resolution picture (JPEG), not vector/selectable text.
- PPTX charts are exported as editable shapes, not native PowerPoint charts.
- Real AI output (live provider) was not tested; only stubbed responses. Bad AI replies show an error instead of changing the design.
- The Creative category is behind the app's existing sign-in gate for "big tools" (same as AI Image Generator).
- Kotlin JVM harness was not re-run for this change (no Kotlin was touched; last result 177/177).

## Removal of chat-message image/video auto-creation (requested)
Words like "image", "video", "padam", "generate", "create" in a chat message no longer start any image or video creation.
- Page (`a2z.html`): removed `genIntent` (both versions) and its word lists, the "how-to" wrapper script, the brain-image hook, the "Create image / Create video" buttons that appeared under text answers, and the "Auto-make images and videos" settings (2 places) + `S.autogen`.
- Native (`Brain.kt`, `BrainAgents.kt`, `BrainBridge.kt`, `AgentRoles.kt`, `FloatingPanelController.kt`): removed IMAGE and VIDEO intents + their regexes, `ImageGen` (Pollinations call), `ImageAgent`, the `image.generate` tool and `Role.IMAGE`.
- Still available, only by the user's own action: the "Create image / Create video" mode button in the composer, the Start-screen buttons, and the AI Image / AI Video / Design Studio tools.
- Tests updated (image/video words classify as normal chat). JVM harness: 174 tests OK (3 image-specific tests removed). Page test: sending "create an image of a cat" calls the image generator 0 times.

## Code Writer fix
With the default settings (Advanced mode) the tool first asks the AI for a JSON plan. If that plan failed (some models, e.g. Groq gpt-oss, return no valid JSON or refuse "thinking"), the build stopped with an error and the user had to switch Mode to Quick by hand. Now, if planning fails for any reason (except the user pressing Stop), Code Writer automatically writes the code in one go (Quick path) instead. Tested with a stubbed AI that returns garbage for the plan: code is still produced with all defaults untouched. Normal plan path still works.

## Pollinations: text only from the secret
- The Pollinations key in the GitHub secret `AI_API` now makes a TEXT provider only. The extra "Pollinations Image" provider it used to create is removed.
- The free no-key Pollinations image provider (built-in list + catalog) and the free no-key Pollinations video entry are removed; the old image tool that called `image.pollinations.ai` directly is deleted.
- Pollinations image and video now need the user's own key (`need: key`); the runners also refuse providers marked built-in (`def`) or without a key.
- Verified in the page with a fake `default-keys.json` (pollinations + groq): image providers = none, video providers = none; after adding an own Pollinations image provider with a key it appears. Workflow `.github/workflows/release-apk.yml` comment and `API_KEYS_SECRETS.md` updated.
