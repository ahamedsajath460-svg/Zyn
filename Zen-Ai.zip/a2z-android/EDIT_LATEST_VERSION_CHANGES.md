# Follow-ups build on the latest version

File changed: `app/src/main/assets/a2z.html` (v21 dev-tools block, `forced()`)

- Create with tools > Website builder: if you attach an HTML file, that file is the base. Otherwise the newest website the tool made in this chat is the base. The AI gets the CURRENT HTML plus your change request and returns the complete updated page (nothing is rebuilt from scratch). Say "new" / "from scratch" / "another" in the message to start a new site instead.
- Create with tools > Code writer: if you attach file(s), they become the project (`seedProject`) and only the needed files are changed. Otherwise the newest Code writer project of this chat is changed; if its saved copy is gone, it is rebuilt from the files in the last answer. Same "new / from scratch" rule.
- A change request with no text and an attached file means "review, fix and improve this".
