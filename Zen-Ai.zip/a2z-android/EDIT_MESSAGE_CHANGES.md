# Edit a sent message (Claude-style)

- Long-press on YOUR message: the card now shows Select, Memory and **Edit** (Edit only on user messages).
- Edit: the full message text goes into the chat box and an "Editing message" bar with an **X** appears above it, with the line "Editing this message will restart the conversation from this point." Nothing is deleted yet.
- X: cancels. The bar disappears, the chat box goes back to what it was before (your earlier draft or empty) and the chat is exactly as before.
- Send (while editing): the old message and every message after it are replaced by the edited one and the AI answers again from that point. If no new file/photo is added, the pictures/files of the old message are kept.
- Editing is also dropped if you switch chat or the message disappears. While a reply is being written, Edit says "Stop the reply first".
- Code: `zyn-claude-cards-js` (Edit button + icon) and new `<style id="zyn-edit-msg">` / `<script id="zyn-edit-msg-js">` at the end of `app/src/main/assets/a2z.html`. Only that one file changed.
