# Explore Providers / My API Keys (change)

- Explore Providers is now a clean catalog: no saved keys, no ready/setup lights, no "Added" providers, no custom providers.
- Every tap in Explore Providers creates a NEW provider with a BLANK API key box (even if the same provider was saved before).
- After you type a key and press Done/Back, the provider is saved and the page jumps to My API Keys, in that provider's category chip.
- If no key was typed (empty draft) nothing is saved.
- My API Keys lists every provider with a key (your own keys; built-in GitHub-secret keys only for the admin, as before).
- The AI providers page now always opens on My API Keys, and closing a provider form opened from Explore Providers (saved or not) returns to My API Keys.
- Code: `provPage()` in `app/src/main/assets/a2z.html`.
- Any REST API form shows only the important fields: Name, API key, Method, Endpoint, Key is sent as. Header name appears only for Custom header; POST body only for POST. Category note and Copy key from another provider are hidden for REST.
- Any REST API form has a Model box. Write {model} in the Endpoint or POST body and the model name is put there when the request is sent.
- Every category now has a "Custom REST API" in Explore Providers: Text, Image, Video (two), Voice (new, answers with an audio file), Data, Web search (new, {q} in the Endpoint).
- All provider forms: removed the "Category: ..." note, the "Tap the eye..." hint under the API key and the "Copy the key from another provider" box. "Header name" shows only when "Key is sent as" = Custom header.
- Custom REST API forms (Data, Web search, Voice, Video any provider) show only Name, API key, Endpoint, Model. Everything else is under an "Advanced options" button.
- Any REST API with API key + Endpoint + Model works by itself: it is sent as an AI chat request (POST, Authorization: Bearer key, model + message). A base URL such as https://api.groq.com/openai/v1 gets /chat/completions added automatically. "Key is sent as" defaults to Automatic (Bearer key, or {key} inside the URL).
- Custom REST speech API: key + endpoint + model works by itself (/audio/speech is added to a /v1 base URL).
- Cleanup: removed 18 old copies of functions that a newer version already replaced (old openSettings, speak, callAI, sysPrompt, build, fill, refreshHead, answer, suggest, send, drawSide, shrink, frames, addFiles, drawAtt, mic, msgMenu, chatMenu), the old first openProvider, and the unused helper in provPage. About 20 KB less code in a2z.html, same behaviour.
