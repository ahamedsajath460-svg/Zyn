# Smart file generation (Word, Excel, PowerPoint, PDF, PNG)

Zen Ai can now hand over **real** `.docx`, `.xlsx`, `.pptx`, `.pdf`, `.png` and `.jpg` files, and it chooses the right type for the request.
Nothing needs the internet and no library is downloaded: everything is built on the device.

## How it works
1. The model answers with ONE fenced block per file, named with the right extension, for example ```` ```docx title="Resume.docx" ````.
2. The block holds plain text (Markdown, CSV or SVG). The app shows it as a file card (Word / Excel / PowerPoint / PDF / PNG icon and label).
3. **Download**, **Share**, **Download all (.zip)** and the "Files in this chat" list turn that text into the real binary file at that moment (`ZenGen.build`) and save it through the existing `A2ZNative.saveFile` (Downloads/Zen Ai) with the correct MIME type.

| File | Model writes | Built as |
|---|---|---|
| `.docx` | Markdown (headings, lists, **bold**, tables, quotes, code, `---`) | Word document, A4, real heading / list / table styles, Tamil safe |
| `.xlsx` | CSV (first row = headers), `## Sheet: Name` for more sheets, `=SUM(..)` formulas | Excel workbook, header style, frozen row, auto column widths, formulas recalculated when opened |
| `.pptx` | Markdown, slides split by a line `---` (`# Title` first, then `## Slide title` + bullets or a table) | 16:9 deck, cover slide, title + content slides, tables, long lists split into "(cont.)" slides |
| `.pdf` | Markdown (same as docx) | A4 PDF, many pages, page numbers; text is drawn as images so Tamil / Sinhala / Hindi always display correctly (text in the PDF is not selectable) |
| `.png` `.jpg` | One complete SVG | Raster image (up to 2400 px) |

Other text files (`.ics` calendar, `.vcf` contact, `.csv`, `.tsv`, `.json`, `.html`, code ...) were already plain text and now also get the correct MIME type and file-card label.

## Choosing the type ("which file for which request")
`FILE_RULE` (appended to the system prompt in `a2z.html`, next to `CODE_RULE`) tells the model to:
- use exactly the format / file name the user names;
- otherwise choose by purpose: letter, resume, report, essay, notes = Word; final copy to print / send, forms, invoices, certificates = PDF; tables, budgets, trackers, timetables, anything with calculations = Excel; slides / seminar / pitch = PowerPoint; web page / game / tool = HTML; calendar event = .ics; contact = .vcf; logo / image = SVG or PNG;
- when two formats are both right, make the main one and offer the other in one short line, without asking first.

## Files changed
- **New** `app/src/main/assets/filegen.js` (the generator, exposes `window.ZenGen`).
- Every named file (code, HTML, JSON, CSV, TXT, ICS ...) now uses the same card: page icon with a coloured type badge, name, and type label.
- `app/src/main/assets/a2z.html`:
  - `<script src="filegen.js">` next to `datasave.js`;
  - `dlText` builds binary files; new `zipDl` used by the three "Download all (.zip)" places;
  - `MIMEX`, `LNAME`, `FX` know the new extensions;
  - file cards: document icon + label, binary blocks always become cards, Preview button (Markdown view for docx / pdf / pptx, table view for xlsx, image for png), `shareFile` shares the real file;
  - `FILE_RULE` added to `sysPrompt`.
- No Kotlin, manifest or Gradle change.

## Tested (desktop Chromium + LibreOffice + python-docx / openpyxl / python-pptx)
- `.docx`, `.xlsx`, `.pptx` open with python-docx, openpyxl, python-pptx and convert with LibreOffice; Tamil text, tables, nested and restarted numbered lists, formulas (`=SUM`) all correct.
- `.pdf` is valid (`pdfinfo`), multi-page, Tamil wrapped correctly; `.png` / `.jpg` valid.
- In the real `a2z.html`: card -> Download for every type sends the right bytes and MIME to `A2ZNative.saveFile`; ZIP with mixed real files opens; no page errors.

## Not tested
- Never run on an Android device / the Android WebView (no device here). Things to check there: Tamil / Sinhala font fallback inside PDFs (uses Noto Sans Tamil / Sinhala / system fallback) and Share sheet with binary files (falls back to saving when `navigator.share` has no file support).
- Opening the files in Microsoft Word / Excel / PowerPoint themselves (only LibreOffice and the python libraries were available).
- The model must actually follow `FILE_RULE`; weaker models may still write the wrong extension or put HTML inside a docx block.
- The floating panel (`zyn_float_panel.html`) is not changed.
