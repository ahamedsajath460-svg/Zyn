# Chat speed (Gemini and others)

File changed: `app/src/main/assets/a2z.html`

Causes found
1. Auto-think turned deep thinking on for almost every Tamil / Tanglish message (any Tamil script text over 25 characters or with "?", words like enna / epdi / ethu, any message over 120 characters, any attachment, common words like how / why / explain / code / plan / translate). Gemini then thinks at "medium" before it starts to answer.
2. Every message sent up to 400 000 characters of earlier chat (a one-time migration had raised it), so replies got slower as chats grew.

Changes
- `ZT.need`: auto-think only for real problems (maths, logic, debugging, algorithms, code fences, very long messages over 700 characters).
- Auto-think uses level Low. Your own "Think deeper" switch still uses the level you chose (Low / Medium / High).
- One-time migration (`S.mig4`): memory depth set to 60 000 characters. Change it in Settings > Memory depth (Normal / Long / Maximum / Huge).
