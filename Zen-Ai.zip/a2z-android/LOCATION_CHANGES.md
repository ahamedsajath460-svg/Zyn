# Location: real position for the AI

- New native read: `A2ZNative.locRequest(id)` takes the newest last-known fix (under 2 min old) or one fresh fix (network first, then GPS). It answers through `window.__locDone(id, json)`. If it fails, the page falls back to the WebView's `navigator.geolocation`.
- When Location is not allowed in Android, the app asks for it first (Android's own dialog), then reads the position.
- The AI gets the real latitude/longitude, accuracy and a readable place (road, area, city, state, country from OpenStreetMap) and is told to answer "where am I", weather, nearby places and distance from it.
- If it cannot be read (not allowed, phone Location switch off, timeout), the AI is told the real reason and tells the user what to switch on, instead of guessing.
- Wider triggers: where am I / naan enga irukken, my city, weather, nearest, hospital near me, etc. (English, Tanglish, Tamil).
- Permissions page "Never" still blocks it; "Ask"/"Always" behave as before ("Always" reuses the fix for 10 min).
