# New login page

- Old Google-centric login gate (`#authgate`) removed: its HTML, CSS (`zyn-login`, `zyn-login-anim`, gate rules) and form JS (`zyn-login-js`).
- New design added in `app/src/main/assets/a2z.html`: animated gradient background, glass card, floating labels, show/hide password eye, sign in / create account / forgot password views (all in one card), success check animation.
- Still uses your existing Firebase code: `A2ZAuth.emailSignIn`, `emailSignUp`, `resetPassword`, and the `#ag-btn` Continue with Google button (same ids, so the Google/native flow is untouched).
- Kept ids used by the main script: `ag-btn`, `ag-msg`, `ag-last`. Logout dialog (`#lodlg`) is unchanged.
- Gate CSS lives in <head> so the login page never flashes unstyled while the app loads.
- Password rule: at least 8 characters on sign up. Name is optional.

## Black and white login + Agree + 15 s Skip
- Login page recoloured to black and white only (light = white page / black button, dark mode = black page / white button). Google icon keeps its original colours.
- Skip button is smaller; the word "Skip" is visible from the start and a border line fills round it over 15 seconds. It can be tapped only after the line completes (every time the sign-in page opens).
- Create account now shows an "I agree to Zen Ai's terms and privacy policy" checkbox. Sign up (and Continue with Google while on the Create account view) is blocked until it is ticked.
- Firebase sign-in, sign-up and reset code is unchanged.

## Guest (Skip) uses its own clean data
- Tapping **Skip** no longer opens the last signed-in account's chats. Guest has its own private data space.
- First time as guest (or after another account was used) guest starts clean, like a fresh install. The account's data is archived untouched and comes back when that account signs in again.
- If guest was used before, Skip continues from the guest's own chats and settings.
- Signing in from guest saves the guest data first, then loads the account's data.
- Switching to guest shows "Opening guest mode…" and reloads the page once, then goes straight into the app (no second Skip tap).
- Code: `window.__zGuestEnter` in `#a2z-acct`, the Skip handler in `#zyn-guest`, `zguest_go` / `__zGuestOn` in `#a2z-boot` and `gate()`.
- Not tested on a device (no build here); syntax-checked only.

## Login page no longer flashes before the chat opens
- Cause: the start-up check only looked for Firebase's own saved-session key. When Firebase restored the session a moment later (2 to 3 seconds, it loads from the network) the sign-in page was already on screen and then jumped to the chat.
- Fix: when Firebase reports a signed-in user the app now also saves a small marker (`zen.sess`) in localStorage. At the next start that marker keeps the sign-in page hidden, so a signed-in user goes straight to the chat. It is removed when Firebase reports no user (logout or an expired session), and the sign-in page shows again.
- It is not an `a2z*` key, so account switching and guest data do not touch it.
- First start after installing this update: the marker does not exist yet, so a signed-in user can still see the sign-in page once for 2 to 3 seconds. After that it is gone.
- Not tested on a device; syntax-checked only.

## Top bar: buttons on the right, chat name in the centre
- Menu button stays on the left. The ghost (incognito) button on an empty chat, and the new-chat and 3-dot buttons once the chat has messages, now sit at the right end of the top bar.
- The chat name stays in the exact middle of the screen (it is centred by the same measuring script, now with buttons on both sides).
- Cause: the name had been taken out of the layout flow to centre it, so the right-hand buttons were packing next to the menu button on the left. Fix: `#mb{margin-right:auto}` in `<style id="zyn-title-center">`.
- Not tested on a device (no build here).

## Chat name exactly in the centre (second fix)
- The name was still sitting left of the middle (it was placed with left/right insets that depend on a measured value). It is now placed with `left:50%` + `translate(-50%,-50%)` and `width:max-content`, so it is always on the middle of the top bar, whatever the buttons are. The measured side space only limits the width of a long name (it then ends with "...").
- Code: `<style id="zyn-title-center">` in `a2z.html`.
- Not tested on a device (no build here).

## "+" menu opens and closes smoothly
- The "Add to chat" sheet now slides up with a soft ease-out, slides back down when it closes (before, it just disappeared), and the dimmed background fades in and out instead of popping.
- Drag the handle or the "Add to chat" title downwards to close it; a short fast flick also closes it, a small drag snaps back.
- Tiles and rows get a small press effect. "Reduce motion" is respected.
- Code: `<style id="zen-plus-smooth">` and `<script id="zen-plus-smooth-js">` at the end of `a2z.html`. The existing open/close code (`am.hidden = true/false`) is unchanged; only the CSS now animates the hidden state.
- Not tested on a device (no build here).
