# Tools start only from the + menu (no word triggers)

File changed: `app/src/main/assets/a2z.html` (only this file)

## Rule now
Typing words in chat (website, app, QR code, explain, PDF, "link for this photo" ...) never starts a tool.
A tool runs only when you pick it in the + menu, and the pick lasts for one message.

## + menu
- Create image and Create video: unchanged, own buttons (they were already manual).
- NEW **Create with tools** button, opens a bottom sheet with everything else:
  Website builder, Code writer, QR code, Code explainer, Project Agent (ZIP), File maker (Word, Excel, PowerPoint, PDF), Photo link.
- After a pick a chip appears above the message box (tap x to cancel) and the box hint changes (for example "Describe the website you want").
  Picking Create image / Create video drops a tool pick and the other way round.
- Project Agent: picking it switches the agent on for one message and opens the file picker for the ZIP. The old Project Agent switch and the
  "Dev tools in chat" switch are removed from the + menu. A ZIP you attach is no longer taken by the agent on its own.

## What changed in the code
- v21 dev tools: word detection is not used any more; `forced()` builds the job from the picked tool (`message.mk`).
- Brain wrapper: photo/video-to-link only for the Photo link pick; words alone go to normal chat.
- File maker rules (Word/Excel/PPT/PDF smart types) are added to the AI prompt only for a File maker message.
- The pick is stored on the message (`mk`), so a reply that waits for the internet still runs the same tool.

## Left as before (they only look things up or answer, they do not build anything)
Web search, weather, maps/places, YouTube links, GitHub info, and the small exact helpers (UUID, hash, Base64, URL, JSON, regex, colour).
