# Claude-style memory (a2z.html, v18)

- Memory is now filed by category. Each line in S.mem starts with its file: `[profile]`, `[preferences]`, `[areas/<slug>]` (projects), `[people/<slug>]`, `[topics/<slug>]`. Old lines without a tag still work (always sent).
- Use: profile + preferences are always sent; areas/people/topics are sent only when the message is about them (keyword match), the rest appear as a one-line list. Sensitive files (topics/health, finance, identity, politics) show only when the message is about them or the user asks "what do you know about me". The prompt tells the AI to use notes silently and never say "I remember".
- Save: the auto-extractor saves only facts the user STATED (no guesses or AI advice), durable only, replaces changed facts with history ("now X (previously Y)"), max 150 lines. Wider trigger words (projects, plans, decisions, Tanglish "venum/pannanum"). "remember that ..." saves at once, then files it into the right category in the background.
- Never saved: passwords, keys, OTP, card/bank/ID numbers, immigration, minors, abuse, self-harm, crime, and instructions like "always agree / flatter me / act as my partner". Sensitive topics follow Capabilities > "Include sensitive topics in memory".
- Floating panel: gets the same filed notes, and its chats are learned from after they sync into the app.
- Memory page and Settings textarea show/edit the tagged lines. Backup/restore unchanged (still S.mem).
