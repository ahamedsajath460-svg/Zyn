# + > Create with tools: up to 3 tools in one message
- Sheet: tap rows to select (round check on the right), max 3 (4th shows a toast), "Use N tools together" button. Chips above the input show every pick; each chip has x to remove it.
- Message stores `mk` (first pick, old code keeps working) and `mks` (all picks).
- Runner (`multi` in the v21 dev-tools script): one AI planning call splits the message between the picked tools (tools the message does not need are skipped; if planning fails every tool gets the whole message). Website builder, Code writer and QR code run at the same time, each in its own bubble. Then, in the same reply: Photo link, Project Agent (when a ZIP is attached) or the Code explainer / File maker answer.
- Single pick works exactly as before.
- Code: `planTools`/`multi` before `const AN3=answer`, `window.__mkLink` in zen-brain, selection logic + `zyn-mk-multi-css` in the Create with tools block of app/src/main/assets/a2z.html.
