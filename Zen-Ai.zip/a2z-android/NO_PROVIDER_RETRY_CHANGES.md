
# No provider: Retry
- Sending a message with no ready provider shows the "No provider is ready" card with a Settings button. Once a provider is added, the button turns into Retry; tapping it removes the card and sends the same message again (answer()).
