# Offline-safe chat (no error when the internet drops)

File changed: `app/src/main/assets/a2z.html` (only this file)

## What happens now
- Internet cut / airplane mode / wifi with no real internet while sending (text or voice conversation):
  no error card, no "Switching provider" toasts. The message stays saved in the chat (`chat.wait`),
  and a calm card "Waiting for internet" is shown (Material cloud-off icon, "Send now" button).
- If the connection dies while a reply is streaming, the half reply is dropped and the whole task is re-run when data is back
  (it is NOT saved as a "cut off" reply).
- Back online (the `online` event, a 3 s check, or opening the app): a real reachability probe runs, then the same task is answered
  automatically and the reply appears in the chat (spoken too if the voice conversation is on).
- Several messages sent while offline are answered together when data returns.
- Survives closing the app: the waiting flag is saved with the chat, so it is sent on the next start once online.
- Voice conversation: a network speech-recognition error no longer ends the conversation; it waits for the internet and listens again.
- Pressing Stop is still a real stop.

## Code
- `answer()` core: network failures are detected (`__off.is`), provider switching stops when offline, the failure branch calls `__off.hold()`.
- New `<style id="zyn-offline-css">` and `<script id="zyn-offline-js">` at the end of the file: outer `answer()` layer (covers tools, images, agent),
  waiting card, resume loop, `__off.when()` callbacks.
- `a2z-live` voice module: `err()` handles the `network` kind, new `__liveResume()`.

## Limits
- A waiting message in a chat that is not open is sent when you open that chat (the answer path works on the open chat).
- The floating panel chat is not changed in this version.
