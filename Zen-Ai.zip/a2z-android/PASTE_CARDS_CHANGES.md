# Paste cards + drag-drop (chat box)
File: app/src/main/assets/a2z.html
- Long pasted text (over 25000 characters or over 350 lines) no longer fills the message box. It becomes a "PASTED" card above the text (first lines preview, round X to remove), like Claude. Short text pastes normally.
- On send, the pasted text goes to the AI as an attachment ("Pasted text"), and the sent message shows the same PASTED card (tap to open full text).
- Zip and other files show as cards (ZIP / PDF / DOCX ...) in the box and in the sent message.
- Drag and drop on the chat box: files become cards, long dragged text becomes a PASTED card; the box highlights while dragging.
- Max 100000 characters per pasted card. Several pastes make "Pasted text 2", "Pasted text 3".

# Message time on long-press
- Long-press on a message you sent: the card now starts with the date and time it was sent (e.g. 23 Nov 2026, 4:10 am), then a divider, then Select and Memory. Older messages saved without a time show the card as before.

# Paste card fix (Android keyboard paste)
File: app/src/main/assets/a2z.html
- On Android, pasting with the keyboard clipboard chip (Gboard) or some long-press menus did not send a paste event, so long text went into the box as normal text. Now the box also watches for one big insert (over 25000 characters or over 350 lines) and turns it into the PASTED card, whichever way it was pasted.

# Paste card limit changed
- A paste becomes the PASTED card only when it is over 25000 characters (spaces included) or over 350 lines. Anything smaller pastes normally into the box.

# Paste card look + speed
- The PASTED card is now a neat square box (108 x 108): PASTED tag top-left, X top-right (no longer covers the text), first lines of the text below with a soft fade at the bottom.
- Faster paste: only the first 600 characters are used for the preview, the long/short check stops early, and the keyboard-paste fallback no longer re-fires every input listener.
