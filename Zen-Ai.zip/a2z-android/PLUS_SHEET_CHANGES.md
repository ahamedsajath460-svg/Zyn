# + menu in the "Add to chat" style

File changed: `app/src/main/assets/a2z.html` (only this file)

- Tap + : a bottom sheet slides up at about half the screen (dim background). Drag it up to open it fully, pull it down to go back to half,
  pull down again (or tap the dim area / X) to close. Tapping the handle also switches half / full.
  When the sheet is fully open and scrolled, dragging only scrolls the list; the pull-down works from the top of the list or from the handle and title.
- Look: white cards in the light theme (dark cards in the dark theme), thin outline icons in round badges, chevrons and switches, groups with gaps.
- "Create with tools" sheet uses the same look (X, centred title, one white card with round icon badges).
- Fixed: a hidden row (the old Project Agent switch) no longer breaks the rounded corners / gap of the next group.
- Code: `<style id="zyn-sheet-css">` and `<script id="zyn-sheet-js">` at the end of `a2z.html`; the Create with tools sheet is in `zyn-mk-css` / `zyn-mk-js`.

## Fix: double icons in the + sheet

- Bug: every row/tile in the "Add to chat" sheet (Camera, Photos, Files, Video, Web search, Think deeper) showed two icons.
- Cause: the sheet script drew its own icon at page load, then the app's startup code (after `loadAll()`) added the default icon to the same buttons, so each button ended up with two.
- Fix (`a2z.html`, `zyn-sheet-js`): `skin()` now keeps exactly one icon per button and removes extras, and it watches the buttons too (`subtree:true`), so an icon added later is cleaned up.

## Smooth + sheet (open / swipe / scroll)

- Cause of the jerk: two scripts both handled the touch drag, and an older CSS rule (higher specificity) cancelled the slide transition, so the sheet popped open/closed and animated `height` (slow layout work).
- Now: one motion engine in `zyn-sheet-js`; the old `zen-plus-smooth-js` is removed. The sheet has a fixed height and only moves with `transform` (GPU), three snap points (half / full / closed), flick velocity, rubber band at the top, the dim background fades with the drag, and you can catch it mid-animation.
- Half height fits the whole menu on most phones (up to 76% of the screen); only a taller menu has a half/full stage. Full state scrolls natively (`overscroll-behavior:contain`); pulling down at the top of the list closes it.
- CSS: `<style id="zen-plus-smooth">`.

## + sheet opens at about half height

- The + sheet now first opens to about 49% of the screen height (just below the greeting text, with "Create with tools" peeking at the bottom). Drag it up for the full sheet, drag down to close.
- `measure()` in `zyn-sheet-js`: `HALF = max(49% of screen, 340px)`, capped by the full height.
