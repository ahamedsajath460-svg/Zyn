# Pure white theme

- Light theme is now pure white everywhere: page, header, chat, side drawer, settings pages, sheets, dialogs, cards (`<style id="zyn-pure-white">` at the end of a2z.html).
- Because tints are gone, cards, chips, user bubbles, selected rows, settings rows and the + sheet tiles are separated by a thin light-grey line (inset 1px) instead of a grey fill. The side drawer gets a soft shadow.
- Android: launch window and WebView default background are white (`MainActivity.kt`, `res/values*/colors.xml`); the app also reports the white `--nbg0` to Android as the boot colour.
- Dark theme is unchanged.
