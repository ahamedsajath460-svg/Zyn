# Preview viewer = Claude app artifact sheet
- Console bar and the "Fix with AI" error button removed from the HTML preview.
- Viewer dialog restyled from a Claude screen recording: dimmed page behind, rounded top sheet (38px), off-white header (close, file name, 3 dots), flat full-width content with soft left edge shadow.
- 3-dot menu: Preview (check), Code | Publish (share), Copy, Download | Save as HTML (Save as PDF for non-HTML files). Share as PDF and Print were removed from the menu.
- Code: style `zyn-claude-sheet-css` and `addBar` (now empty) in app/src/main/assets/a2z.html; menu in script `zyn-claude-viewer`.
- Update: a red error card (message + dismiss) now appears at the bottom of the HTML preview ONLY when the page reports a console/runtime error; it is hidden the rest of the time. No Fix button. Style `zyn-err-css`, `addBar` in script `zyn-cw-chat-js`.
