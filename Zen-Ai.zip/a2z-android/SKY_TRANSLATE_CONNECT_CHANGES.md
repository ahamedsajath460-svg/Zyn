# Sky Translate connected to Zen Ai (Tools > Translate)

Removed from Tools (AI Writing): "Translator" and "Tanglish -> Any language" (a2z.html, list AT). The Advanced Vision "Translate" tab (screen OCR) is a different feature and was left alone.
Added: one tool card "Translate" (first in AI Writing). Tapping it calls `A2ZNative.openSkyTranslate()`, which opens Sky Translate full screen. Back returns to Zen Ai.

Sky Translate itself is unchanged (no UI/UX change): translate2.html, native-speech.js, ai-keys.js copied as-is.

Files
- assets/sky/translate2.html, native-speech.js, ai-keys.js (placeholder, filled at build time)
- java/com/a2z/ai/sky/: SkyTranslateActivity (was MainActivity), OcrBridge, OcrService, SpeechBridge, ClipBridge (package renamed only)
- res: layout/activity_sky_translate.xml, values/sky_translate.xml, values-night/sky_translate.xml
- AndroidManifest.xml: activity .sky.SkyTranslateActivity (CAMERA, RECORD_AUDIO and speech/TTS queries already existed)
- app/build.gradle.kts: ML Kit Chinese, Japanese, Korean OCR added (Latin and Devanagari already there)
- MainActivity.kt: bridge methods skyTranslate(), openSkyTranslate()
- .github/workflows/release-apk.yml: NOT changed (your original). Sky Translate gets its keys at runtime: SkyTranslateActivity builds ai-keys.js from assets/default-keys.json, i.e. the same AI_API secret and the same line order as the Zen Ai chat.
- a2z.html: tools list + the app's own help text

Own web origin (sky.appassets.androidplatform.net), so Sky's history/settings never mix with Zen Ai's storage.
Not built or run on a device here (no Android SDK).
