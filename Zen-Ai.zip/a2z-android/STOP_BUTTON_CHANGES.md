# Stop button (copied from the Claude app screen recording)
- While the AI is answering, the send button becomes a stop button: light grey filled circle (#EDEDEA, same size as the mic), thin outlined rounded square inside (dark), about 15px gap before it from the mic. Dark theme uses a soft tint of the text colour.
- Files: a2z.html (setBusy icon + style block "zyn-stop-claude" at the end).
