# Create with tools: only the result shows in chat

File changed: `app/src/main/assets/a2z.html` (v21 dev-tools block)

- Website builder, Code writer and QR code still run the real tool, but its screen (prompt box, 70vh preview, plan / progress panel) is kept out of sight (`hideTool`). The chat shows only a small progress line ("Website builder...", "Writing your code...") while it works.
- When finished, the message is rendered in the normal way (`sayo` -> `fill`):
  - Website builder: one file card (`<page-title>.html`) with the code; tap it to Preview / Code / Download.
  - Code writer: one file card per file (several files become the usual ZIP card). The old "tool shown under this message" panel is gone (limit 300 000 characters).
  - QR code: only the QR image and Save image.
- Failures and "Stopped" are normal chat messages too.
