# Create with tools: faster

File changed: `app/src/main/assets/a2z.html`

Code writer (was: deep-think plan -> many 200-line parts -> deep-think review that re-wrote every file)
- Single-file HTML apps and games are now written in ONE go (Quick mode). Other languages / multi-file projects still get a plan.
- The plan no longer uses the slow deep-thinking mode; parts are about 450 lines instead of 200, so far fewer AI calls.
- The AI review of every file is gone. `cwCheck()` checks each file on the phone (JS syntax, JSON, HTML cut-off) and only a file with a real problem is sent back for one repair call.
- "Which files change" in project edits no longer uses deep thinking.

Website builder
- The prompt asks for a compact page (about 350 to 600 lines), so it finishes sooner. The repair passes still only run when the page has a script error.
