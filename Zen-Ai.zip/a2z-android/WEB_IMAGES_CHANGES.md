# Web image search + inline images (v22)
Real website photos only. No AI image generation is called by this feature (Pollinations code untouched).

## Files
- NEW `app/src/main/assets/webimages.js` (the whole feature)
- MODIFIED `app/src/main/assets/a2z.html` (one line: `<script src="webimages.js"></script>` before `</body>`)
- NEW `docs/web-image-proxy/index.js` (optional key-protecting Cloud Function, UNTESTED)
- NEW `tools/web-images-tests/` (headless-Chrome test scripts with mocked APIs)
- No Kotlin, manifest, Gradle, package name or permission change.

## How it works
answer() is wrapped: the text is shown first, then enrich() decides (decide), plans where images go (plan), searches
(search: cache -> providers in order -> probe each image -> dedupe), saves `m.wimg` on that assistant message, and draws
figures between the paragraphs. fill() is wrapped so reopening a chat redraws them from `m.wimg`.
- Skips: greetings, small talk, code/translation/maths/writing tasks, error answers, short answers, image-generation requests.
- Layouts: figure after the paragraph under a heading; list items get a thumbnail beside them; "show me A and B" gives a horizontal group.
- Provider order (default): Pexels, Unsplash (keys already in Settings > AI providers > Data; skipped if no key), Openverse, Wikimedia Commons (free, no key).
- "+" menu: "Web images in answers" (ON/OFF) and "Web image sources" (providers on/off, clear cache).
- Attribution kept per image: title, site, creator, licence, licence URL, source page, original image URL. Tap image = full screen with "Open original website" and "View licence". Nothing is labelled copyright-free.
- Safety: https only; credentials, localhost/IP, svg/exe/html/pdf URLs rejected; metadata stripped of HTML and inserted with textContent; no-referrer image loads.
- Caching: results 24 h (empty 10 min); 429/quota pauses a provider 15 min and the next one is used; 9 s API timeout, 8 s image timeout; images load lazily (WebView HTTP cache keeps the files).
- Nothing found = normal text answer. No generation fallback.

## Setup
No key required (Openverse + Commons work without one). For better photos add a Pexels and/or Unsplash key in Settings > AI providers > Data.
Keys inside the app can be read by someone who unpacks the APK (same as existing keys). For real protection deploy docs/web-image-proxy and set cfg.proxy.

## Tested (headless Chrome, mocked APIs) / NOT tested
Tested: intent rules (EN, Tamil, Tanglish), inline placement, list thumbnails, group, history reopen, message buttons, cache, 429 fallback, all-fail = text only, URL safety, real answer() hook with a mock provider.
NOT tested: real device/emulator, Android 8.0 WebView, Gradle build (no SDK or network here), live Pexels/Unsplash/Openverse/Commons calls, slow real networks, floating assistant panel (unchanged, shows no images).
