# Zen AI 6.0: one brain, one chat

## What was found (audit)
- **Main chat** = `assets/a2z.html` (WebView). It already had streaming, web search with sources, key rotation and provider fallback in JavaScript.
- **Native team (5.x)** = `Coordinator`, `AgentRuntime` (registry + messages + timeouts + retry), `AgentRoles`, `AgentImpls` (5 agents), `TaskManager`, `TaskQueue`, `ProviderRouter`, `KeyPool`, `AgentController/Runner/Policy/Actions/Vision`, `FloatingPanelController`.
- The two sides did not talk to each other, image/voice/memory/provider/task were not agents or tools, and there was no tool registry, no shared context between chats and agents, and no dependency/parallel planning.

## What 6.0 adds (extends, nothing removed)
| Required part | Where / how |
|---|---|
| MasterOrchestrator | `Brain.kt` `MasterOrchestrator` (classify, plan, check permissions, run, recover, aggregate, compose) |
| AgentRegistry + AgentCommunicationManager | existing `AgentRuntime` (reused). Now 14 roles registered |
| AgentCoordinator | existing `Coordinator` (reused) for phone tasks: checkpoints, resume, AgentPolicy |
| AgentRouter / TaskPlanner | `IntentClassifier` + `TaskPlanner` (dependency graph, waves) |
| TaskScheduler | waves: independent steps in parallel (`A vs B` research), dependent steps in order; `TaskQueue` now runs every queued task through the brain |
| ToolRegistry / ToolExecutor | `Brain.kt`: unique id, capabilities, input/output schema, status, timeout, structured `ToolResult`; 14 real tools in `BrainAgents.kt` |
| SharedContextManager | per chat/account session: turns, last results, tool results; "compare the first two" resolves to the real earlier items |
| ResultAggregator / ResponseComposer | one final text; honest "Not fully verified", "Live search was unavailable" and "Not completed" notes |
| ErrorRecoveryManager | search down -> answer from general knowledge, clearly marked; image/screen/phone failures are reported, never faked |
| ExecutionMonitor | plain progress lines (Understanding request, Planning, Searching, Collaborating, Analyzing, Verifying, Preparing response) |
| PermissionManager | screen share / accessibility / agent switch checked BEFORE anything runs; AgentPolicy and confirmations still guard every phone action |

New agents (all registered in the same runtime): Image, Voice, Memory, Task, Provider, Analysis, Verification. Verification is rule based (citations must exist in the real sources), so it costs no AI call.

## Chat integration (updated: every working tool category is reachable from chat)
The brain classifies each message instantly (no AI call). Plain conversation (greetings, Tamil/Tanglish chat) uses no tool and keeps the chat's streaming path. Everything else goes to the brain and the answer lands in the same chat:

| You say | Tool / agent that runs |
|---|---|
| research / latest info / compare / "A vs B" / follow-up "compare the first two" | Research -> Verification (-> Analysis -> Conversation) agents; A vs B researched in parallel |
| code questions | Coding agent |
| "give me links for ..." | `web.search` tool |
| "translate / summarize <text>" | `ai.chat` tool |
| "generate an image of ..." | `image.generate` (your image providers first, then built-in service) |
| "what is on my screen?" | `vision.screen` (screen share on) or read-only accessibility explain |
| "read the text on my screen" | `vision.ocr` |
| "is screen sharing on?" | `screen.share.status` |
| "start / stop screen share" | `screen.share.start` / `screen.share.stop` (Android's own dialog still needs your tap) |
| "open the floating assistant" | `floating.open` (Android may ask for the overlay permission) |
| "open Settings and ..." | phone agent (`screen.act`), AgentPolicy + confirmations |
| "add a task ..." / "task status" | `task.queue` / `task.status` |
| "read it aloud" | `voice.speak` |
| "what did we talk about ..." | `memory.recall` |
| "which provider are you using?" | `provider.status` (never shows keys) |

- Research, code, links and translate **fall back automatically** to the chat's own pipeline if the brain cannot finish (nothing wrong is shown). To keep them on the old streaming pipeline set `localStorage.zenBrainAll = '0'` in the page. Screen, phone, image and tool actions never fall back.
- Main chat: script `#zen-brain` at the end of `a2z.html`. Floating panel: `sendChat` -> same brain. Account switch resets all brain sessions.
- Trade-off: research/code answers routed through the brain show a progress line instead of token-by-token streaming.

## Tests (run here on the JVM with the project's own harness: `tools/jvm-harness/run.sh`)
- **176 tests, 176 pass** (re-run twice). 57 are new: `Zyn6BrainTest` (pure, also runs under Gradle `testDebugUnitTest`), `BrainIntegrationTest` (real agents + real registry + real runtime + real ProviderRouter/KeyPool/TaskQueue with fake provider/search/screen), `BrainBridgeTest`.
- Covered: greetings (English/Tamil/Tanglish) use zero tools; search, image, screen, phone and compare examples from the spec; follow-up "compare the first two"; account/chat isolation; parallel research; recovery and partial success; permission denials; cancel; duplicate request; provider fallback; key never leaked; image bytes validated.
- Old suites (queue, keys, OCR/health, runtime, coordinator, router, task manager ...) still pass. One regression found and fixed on the way: queued tasks were sharing chat context, so every task now gets its own isolated session.

## NOT verified / honest gaps
1. **No Gradle/Android build was possible here** (no network, no Android SDK). `MainActivity.kt`, `FloatingPanelController.kt` and the `a2z.html` script were edited but not compiled or run on a device. `Brain.kt`, `BrainAgents.kt`, `BrainBridge.kt`, `AgentImpls.kt`, `TaskQueue.kt` were compiled and tested on the JVM. The JS has a syntax check only. **Run your GitHub Actions build and send me any error.**
2. Image fallback uses Pollinations' free public endpoint (not your configured image provider, which only the page knows). The floating panel cannot display pictures: it says the image is saved.
3. Still NOT connected, because no real backend exists for the brain: **file processing** (attachments are handled by the page; a message with files/images skips the brain on purpose) and **speech recognition** (the mic fills the chat box; agents cannot call it).
4. `research.deep` is the same code as the Research agent (the agent is what the plan runs); `vision.screen` likewise equals the Vision agent. Tools are also callable one by one through `MasterOrchestrator.callTool`.
5. Memory recall covers the current chat and the panel chats; the page's saved "Claude-style memories" are page-side only.
6. Verification is citation-based only (no second AI fact-check).

## Addendum: Creative category (3 tools)

| Tool | Connected to chat | How |
|---|---|---|
| AI Image Generator | Yes | The page's existing image pipeline (`genIntent`/`genAnswer`) handles draw/edit/reference requests; the brain's native image tool (Pollinations) is only the fallback for other image requests. |
| AI Video Generator | Yes (page only) | The brain classifies `VIDEO`; the chat page runs it with your video providers via the existing `genIntent`/`genAnswer`. Floating panel / task queue cannot make video and say so (nothing is faked). |
| Image & Video to Link | Yes for photos | `LINK_UPLOAD` intent; new `window.__l2lUpload` reuses the tool's host, compression, size limits, short link and history. Photos attached to the chat are uploaded and the links are returned in the reply. |

Honest gaps: chat attaches only photos (videos become frames), so a video link still needs Tools > Image & Video to Link. The new page code (`__l2lUpload`, `linkUpload`) is syntax-checked but not run on a device. JVM suite: 177/177 pass (new test `creativeToolsAreRoutedToThePage`).
