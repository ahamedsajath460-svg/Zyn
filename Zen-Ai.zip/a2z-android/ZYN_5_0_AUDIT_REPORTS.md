# Zyn AI 5.0: Audit Reports 1-3 (pre-implementation)

Basis: the supplied ZIP was extracted and the files below were read. Nothing was modified. Nothing was compiled or run.
Report 4 (implementation and testing) does not exist yet, because no implementation has been done.

## Environment limits (read first)
- This workspace has no Android SDK, no Kotlin compiler and no network, so Gradle cannot run here. `gradle` itself is present, but it cannot download the Android plugin or dependencies.
- No APK can be built here. Your GitHub workflow (`release-apk.yml`) is the real compile step, and it needs your secrets.
- All earlier reports in the repo (AGENT_4_REPORT.md, AUTONOMOUS_ASSISTANT_CHANGES.md) say the same: Kotlin written but never compiled, tests never run, nothing run on a device. So the existing code is also unverified.
- Not read in full: `a2z.html` (8,491 lines, 1.1 MB), `FloatingPanelController.kt`, `MainActivity.kt`, and `zyn_float_panel.html`. I only searched them for the topics below.

## Project shape
- Hybrid app: a WebView UI (`assets/a2z.html`, plain JS) plus native Kotlin (38 files, about 6.8k lines) in `com.a2z.ai`. Package name must stay `com.a2z.ai` (the workflow checks it).
- The WebView owns the providers, API keys, chat history and the main chat. Kotlin gets providers from the page through `FloatStore.applySync`, and holds keys in memory only.
- Build config: minSdk 26, targetSdk 34, compileSdk 34, Java 17, Kotlin JVM 17, Gradle 8.7, no Compose. Dependencies: core-ktx, appcompat, webkit, play-services-tasks, ML Kit text-recognition (Latin and Devanagari), play-services-auth. Unit tests: JUnit and org.json, one test file with 21 tests.

---

## REPORT 1: Existing code audit

Status key: FI = Fully implemented, PI = Partially implemented, INC = Incomplete, NI = Not implemented, BRK = Broken. "Unverified" means I found no evidence of a compile or device run.

| System | File / symbol | Status | What exists | What is missing | Action |
|---|---|---|---|---|---|
| Agent control (state) | `AgentController.kt`: object `AgentController` | FI (unverified) | Modes (readonly, manual, supervised, trusted, auto), pause, resume, `hardStop`, progress queue, voice stop phrases (English, Tamil, Tanglish), event emit to the WebView and the floating panel | State names are `idle/planning/waiting/running/paused`. There is no Understanding, Agent Selection, Verifying, Completed, Failed or Cancelled | Extend |
| Agent loop | `AgentRunner.kt`: `start`, `run`, `callAi`, `execute`, `verify` | FI (unverified) | Plan, observe, act, verify loop. Retries transient AI errors twice, 90 s timeout, loop guard, recovery hints, confirmation card | Single agent only. The user's task is carried out one UI action at a time by one AI call. No task queue persisted across restarts, no resume after interruption, no step-level retry controls | Extend |
| Action parsing | `AgentActions.kt` | FI | Normalises many provider JSON shapes into one action | None | Reuse |
| Safety policy | `AgentPolicy.kt` | FI | Action allowlist, password-field protection, protected installer and permission screens, secret redaction. The model can only propose actions; policy decides | None found | Reuse |
| Gestures | `AgentGestures.kt`, `AIAccessibilityService.kt` | FI (unverified) | Tap, double tap, long press, swipe, drag, scroll via `dispatchGesture`. `canPerformGestures` is set in the accessibility XML | Never run on a device | Reuse |
| Touch indicator | `TouchIndicator.kt` | FI (unverified) | Visible touch markers | None | Reuse |
| Agent history | `AgentHistory.kt` | PI | Redacted history of finished tasks | No separate failed-task list or retry action | Extend |
| Overlay | `AgentOverlay.kt` | FI | Thin wrapper. Real UI lives in `FloatingPanelController` | None | Reuse |
| Vision link | `AgentVision.kt`, `FrameStore.kt`, `ScreenOcr.kt`, `HighlightOverlay.kt`, `FloatVision.kt` | FI (unverified) | Frame plus OCR observation, change detection (`settle`, `visualVerdict`), `tap_text`, recovery hints, vision-capability check by model name, privacy mode | OCR only for Latin and Devanagari scripts (Tamil screens will not be read by OCR). Change detection is hash/pixel based, not semantic | Reuse and extend |
| Screen share | `ScreenCaptureService.kt`, `CaptureRequestActivity.kt` | FI (unverified) | Foreground service type mediaProjection, `registerCallback` before `createVirtualDisplay`, notification with Pause and Stop, full cleanup in `onDestroy` (display, reader, projection, handler thread, frame store) | No orientation-change handling found in the lines I read. No network-interruption handling in this service (it does not use the network) | Reuse; verify orientation |
| Floating assistant | `FloatingAssistantService.kt`, `FloatingPanelController.kt` (1,208 lines), `zyn_float_panel.html`, `FloatTileService.kt`, `ZynWidget.kt` | FI (unverified) | Bubble and panel, chat, providers, search, voice, agent status, confirm card, Quick Settings tile, widget | One large controller class | Reuse. Do not add a second panel |
| Native AI client | `FloatAi.kt` | FI | Streaming client for OpenAI-style, Claude and Gemini formats, friendly errors | No retry or provider switching inside it | Reuse |
| Native provider list | `FloatStore.kt`: `ordered()` | PI | Providers synced from the page, selected provider first | Agent loop uses only the first one. See Report 2 | Extend |
| Native search | `FloatSearch.kt`, `FloatSources.kt`, `FloatSmart.kt` | PI (not read in detail) | Search-need decision and sources | Not audited in depth | Read before touching |
| Chat, history, auth, settings | `a2z.html`, `MainActivity.kt`, `datasave.js`, `firebase-config.js` | Present (not audited in depth) | Web chat, Firebase sign-in, settings, history | Out of scope for the audit so far | Preserve |
| Multi-agent architecture (7 agents) | none | NI | Nothing named Research, Coding, Vision, Screen Interaction, Planning, Conversation or Task Execution agents exists. Vision, screen interaction and planning behaviour is already inside `AgentRunner` | Everything in section 1 of the prompt | New code |
| Adaptive intelligence engine (native) | `FloatSmart.kt` only decides web search | NI (for routing) | See Report 2 | Complexity detection, intent routing, health tracking, quota handling | New code |
| Autonomous planner | `AgentRunner.run` (plan step), `progressQueue` | PI | A short plan and a step queue per task | No structured plan objects, priorities, persistence, pause-and-resume across process death | Extend |
| Task manager UI | WebView Agent Control page, floating panel | PI | Progress with completed and failed lists (last 20), Stop, Pause | Retry controls, a queue of several tasks, duplicate-task prevention across tasks | Extend |

Duplicates and risks found:
- Two copies of `release-apk.yml` exist (`.github/workflows/` in the ZIP and the one you attached). I did not diff them.
- Provider logic exists twice: JavaScript (`a2z.html`) and Kotlin (`FloatStore` plus `FloatAi`). New routing logic must live in one place or it will drift.
- `AgentController.maxSteps` is documented as 3 to 15 in a comment and clamped to 3 to 30 in `config()`. Minor.
- The manifest permission list includes a note that `MODIFY_AUDIO_SETTINGS` may be removable.
- The release workflow bakes API keys into `assets/default-keys.json` inside the APK. Anyone can extract those keys from the APK. This is a security risk for any key with billing or quota value.

---

## REPORT 2: API routing and provider integration

| Capability | Expected (your prompt) | What the code does | Status | Gap |
|---|---|---|---|---|
| Text chat | Pollinations | Pollinations is one entry among others (`gen.pollinations.ai/v1`, and `text.pollinations.ai/openai` as a keyless entry). Order is set by the user's provider list, so Pollinations is primary only if the list or the first key line puts it first | PI | The route is not tied to the task type |
| Image generation | Pollinations | `img-pollinations` provider (flux, turbo, gptimage) used by the Image Generator. Other image providers also supported | FI (JS) | None |
| Screen vision | Gemini | Not routed by task. The agent uses `FloatStore.ordered().first()` and only strips images if that model looks text-only (`FloatVision.support`). If the first provider is text-only, the agent runs without images and does not switch to Gemini | PI | No capability-based provider choice. This is the biggest routing gap |
| Web search and research | Tavily | Tavily keys are used first when present (`__tavKeys`, rotation across built-in keys), with other search engines and Wikipedia as fallback | FI (JS) | Native floating panel has its own search path (`FloatSearch`), not verified here |
| Other providers | OpenAI, Claude, DeepSeek, Groq, OpenRouter, Mistral, Together, custom | All present as templates (`E('text', ...)`), plus NVIDIA and a custom OpenAI-style endpoint. Types: openai, anthropic, gemini | FI (JS) | None |
| Key storage | existing | Keys in WebView storage; Kotlin holds them in memory only (by design) | FI | Built-in keys shipped in the APK (see Report 1) |
| Key rotation | existing keys | Only Tavily built-in keys rotate (`__tavN`). I found no rotation across several keys of the same text provider | PI | Missing for text and vision providers |
| Provider fallback | automatic | The web chat says "Order = fallback order. If a provider fails or reaches its limit, the next one answers" (settings text, lines 1649 and 1967). The native agent and floating panel do not fall back: one provider, 2 retries on transient errors | PI | Native fallback missing |
| Quota and rate limits | handled | A 429 gives a friendly message in `FloatAi.friendly`. The agent retries. No cooldown, no quota counters, no health score | PI | Missing |
| Capability check | verified, not assumed | `FloatVision.support` guesses vision support from the model name. Its own comment says no provider offers a reliable capability API | PI | Acceptable, but results can be wrong. Marked "unknown" in the UI |
| Sensitive screen data routing | never route to an unrelated provider | Agent sends frames to whichever provider is first. Frames are redacted and privacy mode exists, but there is no rule saying frames may only go to the user's vision-capable provider | PI | Needs an explicit rule |

Things I have not verified (do not claim them): that any listed model name is currently valid at its provider, and Pollinations' current API terms and model list. The Gemini model constant is `gemini-3.6-flash`; I did not check that it exists.

Required changes (proposed):
1. One native `ProviderRouter` that takes a task kind (chat, vision, research, code, image) and picks from `FloatStore.providers`, with per-provider health (last error, cooldown on 429, latency). It must reuse `FloatAi` and `FProvider`, not add a new HTTP client.
2. Vision tasks only go to providers `FloatVision.support` marks YES, preferring Gemini type. If none qualify, text-only fallback with a clear message. Never send frames to a provider the user did not configure.
3. Fallback loop around `AgentRunner.callOnce` using the router.
4. Same-provider multi-key rotation only where the user has entered several keys for it.

---

## REPORT 3: Android compatibility (Android 8.0 / API 26 and up)

| Item | Finding | Verdict |
|---|---|---|
| minSdk, targetSdk, compileSdk | 26 / 34 / 34 | OK for Android 8.0 and up. targetSdk 34 means Android 15 and 16 run in compatibility behaviour. Not a problem for sideloaded APKs |
| Java and Kotlin | Java 17, jvmTarget 17. Kotlin plugin version is in the root `build.gradle.kts` (not read) | Needs a check against Gradle 8.7. Likely fine, unverified |
| Gradle | wrapper and workflow both use 8.7, JDK 17 | OK |
| Accessibility gestures | `dispatchGesture` and `canPerformGestures` need API 24 | OK on API 26 |
| Accessibility settings screen text | The service reads the UI tree only. Some apps (banking, password managers) block it by design | Limitation. Keep the existing "protected screen" handling |
| MediaProjection | Needs a foreground service. Foreground service type `mediaProjection` is required from API 29. The code branches on SDK 29 correctly. On Android 14 (API 34), the user consent must come before `startForeground`, and the projection token can be used once. The service registers the stop callback before creating the display, which Android 14 requires | OK in design. Unverified on a device |
| Foreground service types | `mediaProjection`, `dataSync`, `specialUse`. Declared in the manifest. `FOREGROUND_SERVICE_SPECIAL_USE` needs the declared subtype property, which exists | OK |
| Android 15 and later | `dataSync` foreground services have a time limit (about 6 hours per 24 h) from Android 15. `KeepAliveService` stops itself after 30 minutes, so this is fine | OK |
| Notification permission | `POST_NOTIFICATIONS` is requested only on API 33 and up (MainActivity line 128 and 314) | OK |
| Overlay | `SYSTEM_ALERT_WINDOW`. `FloatPerm.has` handles a known Android 8.0 `canDrawOverlays()` bug | OK |
| Runtime permissions | Microphone, camera, location, calendar are asked when used | OK |
| Background restrictions | Phone makers (Xiaomi, Oppo, Vivo, Samsung and others) may kill services. The app has `KeepAliveService`. There is no battery-optimisation prompt that I found | Limitation, document it |
| Blur | Glass blur only on API 31 and up (guarded) | OK |
| Camera as a live vision source | Camera permission exists. Live camera vision needs a visible indicator in the app | Not verified |
| Storage | `FileProvider` is used. No broad storage permission | OK |
| Lifecycle | `MainActivity` handles configuration changes itself (no recreate on rotation) | OK for WebView. Screen-capture orientation change not verified |
| Local network | `usesCleartextTraffic="false"`. Only https endpoints | OK. Local or self-hosted http providers will not work |
| Release hardening | `isMinifyEnabled = false` | Works, larger APK, easier to read. A choice, not an error |

Not possible or limited, with the supported alternative:
- Accessibility cannot touch secure windows (lock screen, password fields, some payment screens). Alternative: the agent stops and asks the user.
- Silent screen capture is not possible. MediaProjection always shows the system consent dialog. This is correct and must stay.
- Android 8.0 and 8.1 cannot use APIs added later (for example `takeScreenshot`, API 30). The existing capture uses MediaProjection, which works from API 21. Anything added for 5.0 must stay on API 26 level calls or be guarded.

---

## What I propose next (plan, nothing built yet)
Because the base already has a safe single agent, I would add the 5.0 layer as thin Kotlin objects on top, not replace anything:
1. `ProviderRouter` (health, cooldown, vision-only-to-vision-provider rule, fallback) used by `AgentRunner.callOnce`.
2. `TaskState` with the 11 states in your prompt, mapped onto `AgentController.state`, plus a persisted task record so a task can be resumed or retried.
3. `Agents` registry: the seven agents as roles with a prompt, allowed actions and boundaries. Planning, Vision and Screen Interaction are mostly the existing runner split into roles. Research and Coding call the router with the matching task kind.
4. Minimal UI: extra fields in the existing Agent Control page and floating status line. No new pages.
5. Unit tests for the router and state machine (JVM, no Android). These can only be proven by your GitHub build.

Risk: every Kotlin line written here is uncompiled. A single compile error fails your release workflow. I would keep changes small and test-friendly.

Open questions for you:
1. Do you want me to go ahead on that scope, or something smaller (router and fallback only)?
2. Should Pollinations always be the default chat provider, or only when the user lists it first?
3. Are you OK with the built-in-keys-in-APK risk, or should I leave the workflow alone?


---
## Addendum (after the completion upgrade)
See `ZYN_5_0_COMPLETION_REPORT.md`. Changes to the findings above: the native agent now falls back between providers and has a task queue, real agent runtime, native research through the existing Tavily search, and capture orientation handling. Still true: nothing was built with Gradle, the WebView chat routing and key rotation across keys of one provider were not changed, and Tamil/Sinhala OCR is not supported.
