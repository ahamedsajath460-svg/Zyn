# Zyn AI 5.1: Audit report (state before the 5.1 changes)

Method: reading the 5.0 project source. No Android SDK or network was available, so nothing was built or run on a device.

| Area | What already existed | Gap for 5.1 |
|---|---|---|
| Keys per provider | `FProvider` has ONE `key`. The page stores providers and keys in the WebView (`P`, `saveCore`) and sends them to native with `snap()` -> `FloatStore.applySync`. Only Tavily web search had key rotation (`__tavKeys`). | No rotation, no per-key state, no cooldown per key. |
| Provider health | `ProviderRouter` (5.0): cooldown per provider, fails, ok count, last latency, in memory, not shown in the UI. | No health states, no history, no success rate, no check, no UI. |
| Reasoning | `FloatAi.thinkCfg`: fixed "low" for Gemini 3 and budget 0 for Gemini 2.5 Flash, with a retry when the model rejects it. | No depth setting, no per-agent setting. |
| Usage | None. `FloatAi` ignored usage blocks. | Everything. |
| Frame dedup | `ScreenOcr.aHash` (16x16) used only for the OCR cache. `FrameStore.add` stored every frame. | No dedup before storing frames. |
| Network | `NetInfo.metered()` only. | No connectivity monitoring or recovery state. |
| Camera | Only the CAMERA permission and the system camera / WebView `getUserMedia`. No CameraX. | Not present. |
| OCR | ML Kit Latin + Devanagari in `ScreenOcr`. To my knowledge ML Kit's on-device recognizer has no Tamil or Sinhala model (not verified here, no network). | No Tamil / Sinhala engine. |
| Release | `release-apk.yml` writes the `AI_API` secret into `assets/default-keys.json` inside the APK (extractable). | Not changed in 5.1 (see 5.0 report). |

Reuse decisions: extend `ProviderRouter`, `FloatAi`, `FloatStore`/`FProvider`, `AiGateway`, `AgentRunner.callProvider`, `ScreenCaptureService`, `FrameStore`, `a2z.html` (provider editor, `snap()`, settings list). New classes only where no existing class owns the job (see implementation report).
