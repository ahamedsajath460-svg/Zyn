# Zyn AI 5.1: Test report

## Environment
No Android SDK and no network, so **no Gradle build, no APK, no device test.** Tests ran on the JVM with the Kotlin compiler from Gradle 8.14.3 + JUnit 4.13.2 (`tools/jvm-harness/run.sh`). The harness compiles the REAL source of the pure and mostly-pure classes and uses stand-ins for `org.json`, `Context`, `FloatAi`, `FloatStore`, `FloatSearch`, `AgentVision`, `AgentController`, `AgentRunner`. Stand-ins copy signatures but are not the real classes.

## Result: 121 of 121 passed
| Group | Tests |
|---|---|
| 5.0 regression (ProviderRouter 5, TaskManager 8, Orchestrator 4, AgentRuntime 15, Coordinator 7, PlanParser 3, TaskQueue 13, QueueIntegration 13) | 68 |
| KeyPool (rotation, 429 recovery, invalid keys, all-cooling, disabled, manual mode, stats kept, no key in status, `call` rotation, each key tried once) | 12 |
| Health states (unknown, available, rate / auth / degraded / unavailable, slow, offline, history bound, checks) | 6 |
| ReasoningPolicy (real controls only, mapping, legacy, priority) | 4 |
| UsageTracker (no invented tokens, price needed for cost, periods, time zone, budgets, CSV, save/load) | 6 |
| FrameDedup (hash, first/same/changed, local text change, text signature, rotation, refresh, threshold) | 5 |
| NetRecovery (backoff, recovery, give up, never restart projection, stale frames) | 5 |
| OcrLang (script detection, consent gate, prompt and wrong-script check) | 3 |
| AiConfig | 2 |
| CameraGate (throttle, pause drops frame, one request at a time, Live rules, flip / stop) | 4 |
| Integration, harness only: gateway key rotation, all-keys-rejected fallback, unreported usage | 3 |
| Integration, harness only: no frame without consent, Tamil read + wrong script rejected, health probe | 3 |

Gradle test sources (`app/src/test`): 102 tests (`Zyn5Test` 17, `Zyn5RuntimeTest` 38, `Zyn51Test` 47). The 19 integration tests run only in the harness. The older `AgentActionsTest` was not run.
Regression rule: the full suite was re-run after wiring the key pool into the gateway and runner (121/121); no earlier test changed except the harness stand-ins.

## Not tested (do not assume it works)
- `./gradlew testDebugUnitTest`, `assembleDebug`, `assembleRelease`: not run.
- Edits in `AgentRunner.kt`, `FloatAi.kt` (usage parsing), `FloatStore.kt`, `ScreenCaptureService.kt`, `FrameStore.kt`, `MainActivity.kt`, `CameraVisionActivity.kt`, manifest and Gradle change: not compiled. Possible compile errors; the first GitHub build is the real check.
- `a2z.html`: `node --check` only (0 syntax errors). The rotation wrapper, the More keys box and the AI Intelligence page were never opened in a WebView.
- Real providers (429 / 401 behaviour, usage blocks), real Tamil / Sinhala images, screen rotation, network loss, dedup quality on real screens, battery cost: not tested.
- Camera: only the pure `CameraGate` rules are tested. `CameraVisionActivity` (CameraX binding, permission, YUV to JPEG, banner, Live loop) is not compiled and not run; the CameraX dependency was never resolved.
