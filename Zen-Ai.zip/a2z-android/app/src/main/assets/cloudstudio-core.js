/* Zen AI Cloud Studio - core: storage, GitHub client (through the native bridge), project store, commits, builds, usage.
 * Nothing in this file holds a GitHub token. The token lives in the Android Keystore; JavaScript only asks the native
 * bridge A2ZCloud to run an allow-listed GitHub call. Pure logic, no DOM: it is also tested in Node (tools/cloud/tests).
 */
(function (W) {
  'use strict';
  if (W.CloudStudio && W.CloudStudio.core) return;
  var CS = W.CloudStudio = W.CloudStudio || {}; CS.core = 1; CS.version = 1;

  /* ---------------- small helpers ---------------- */
  var U = CS.u = {};
  U.esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (m) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m]; }); };
  U.rid = function (p) { var a = 'abcdefghijklmnopqrstuvwxyz0123456789', s = ''; for (var i = 0; i < 9; i++) s += a[Math.floor(Math.random() * a.length)]; return (p || 'x') + s; };
  U.sleep = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };
  U.slug = function (s) { s = String(s || '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 40); return s.length >= 3 ? s : (s + '-app').replace(/^-/, '').slice(0, 40); };
  U.utf8b64 = function (t) { var b = new TextEncoder().encode(t), s = ''; for (var i = 0; i < b.length; i += 0x8000) s += String.fromCharCode.apply(null, b.subarray(i, i + 0x8000)); return btoa(s); };
  U.b64utf8 = function (b) { var s = atob(String(b).replace(/\s/g, '')), a = new Uint8Array(s.length); for (var i = 0; i < s.length; i++) a[i] = s.charCodeAt(i); return new TextDecoder().decode(a); };
  U.hash = function (t) { var h = 5381; t = String(t); for (var i = 0; i < t.length; i++) h = ((h << 5) + h + t.charCodeAt(i)) | 0; return (h >>> 0).toString(36); };
  U.bytes = function (n) { n = +n || 0; return n < 1024 ? n + ' B' : n < 1048576 ? (n / 1024).toFixed(1) + ' KB' : n < 1073741824 ? (n / 1048576).toFixed(1) + ' MB' : (n / 1073741824).toFixed(2) + ' GB'; };
  U.clone = function (o) { return JSON.parse(JSON.stringify(o)); };
  CS.Err = function (msg, code, extra) { var e = new Error(msg); e.code = code || 'error'; if (extra) e.extra = extra; return e; };

  /* ---------------- storage: IndexedDB through the page helpers when present, else localStorage, else memory ----------------
   * Keys start with "a2z." so the page's per-account data separation (a2z-a.js "Each account keeps its own data") covers them. */
  var mem = {}, PFX = 'a2z.cloud.';
  var st = CS.store = {
    get: function (k, d) {
      return new Promise(function (res) {
        var fin = function (v) { res(v == null ? d : v); };
        try { if (typeof W.idbG === 'function') { W.idbG(PFX + k).then(function (v) { if (v != null) return fin(v); fin(lsGet(k)); }); return; } } catch (e) { }
        fin(lsGet(k));
      });
    },
    set: function (k, v) {
      mem[k] = v; var ok = false;
      try { if (typeof W.idbS === 'function') { W.idbS(PFX + k, v); ok = true; } } catch (e) { }
      if (!ok || JSON.stringify(v).length < 200000) { try { W.localStorage.setItem(PFX + k, JSON.stringify(v)); } catch (e) { } }
      return Promise.resolve();
    },
    del: function (k) { delete mem[k]; try { if (typeof W.idbS === 'function') W.idbS(PFX + k, null); } catch (e) { } try { W.localStorage.removeItem(PFX + k); } catch (e) { } return Promise.resolve(); }
  };
  function lsGet(k) { try { var t = W.localStorage.getItem(PFX + k); if (t) return JSON.parse(t); } catch (e) { } return mem[k] == null ? null : mem[k]; }

  /* ---------------- native bridge (token never visible here) ---------------- */
  var seq = 0, wait = {};
  W.__cloudCb = function (id, status, body) { var w = wait[id]; if (!w) return; delete wait[id]; clearTimeout(w.t); w.res({ status: status, text: body }); };
  CS.nativeOk = function () { return !!(W.A2ZCloud && typeof W.A2ZCloud.gh === 'function'); };
  CS.ns = function () { try { var u = W.A2ZAuth && W.A2ZAuth.user && W.A2ZAuth.user(); var id = (u && (u.uid || u.email)) || 'local'; return String(id).replace(/[^A-Za-z0-9]/g, '').slice(0, 40) || 'local'; } catch (e) { return 'local'; } };
  function call(fn) {   // runs fn(id) which starts a native async call; resolves with {status,text}
    return new Promise(function (res) {
      var id = 'c' + (++seq) + '_' + Math.random().toString(36).slice(2, 7);
      wait[id] = { res: res, t: setTimeout(function () { delete wait[id]; res({ status: 0, text: '{"message":"The phone did not answer in time."}' }); }, 120000) };
      try { fn(id); } catch (e) { delete wait[id]; res({ status: 0, text: JSON.stringify({ message: 'Cloud bridge error: ' + e.message }) }); }
    });
  }
  function parse(t) { try { return JSON.parse(t); } catch (e) { return null; } }

  /** One allow-listed GitHub REST call. Resolves {status, ok, data, text}; never throws for HTTP errors. */
  CS.gh = function (method, path, body) {
    if (!CS.nativeOk()) return Promise.resolve({ status: 0, ok: false, data: { message: 'Cloud Studio needs the Zen AI app (native bridge not found).' }, text: '' });
    return call(function (id) { W.A2ZCloud.gh(id, CS.ns(), method, path, body == null ? '' : JSON.stringify(body)); }).then(function (r) {
      var d = parse(r.text); return { status: r.status, ok: r.status >= 200 && r.status < 300, data: d, text: r.text };
    });
  };
  CS.explain = function (r) {   // friendly message for a failed call
    var m = (r.data && r.data.message) || r.text || ('HTTP ' + r.status);
    if (r.status === 0) return m;
    if (r.status === 401) return 'GitHub did not accept the saved token. Open Cloud Settings and connect again.';
    if (r.status === 403 && /rate limit/i.test(m)) return 'GitHub API rate limit reached. Wait a few minutes.';
    if (r.status === 403 || (r.status === 404 && /Not Found/i.test(m))) return 'GitHub says no access (' + m + '). The token needs access to this repository: Contents (read and write), Actions (read and write), Metadata (read).';
    if (r.status === 422) return 'GitHub refused the request: ' + m + (r.data && r.data.errors ? ' ' + JSON.stringify(r.data.errors).slice(0, 200) : '');
    return 'GitHub error ' + r.status + ': ' + m;
  };
  function must(r, what) { if (!r.ok) throw CS.Err((what ? what + ': ' : '') + CS.explain(r), 'http' + r.status, r); return r.data; }
  CS.ghJson = function (method, path, body, what) { return CS.gh(method, path, body).then(function (r) { return must(r, what); }); };

  /* ---------------- settings ---------------- */
  var DEF = { repo: '', branchPrefix: 'cloud/', gradleVersion: '8.7', retentionDays: 7, retryLimit: 3, maxActive: 1, monthlyMinutes: 2000, storageLimitMB: 500, autoApplyMinor: true, emulatorApi: '34', uiEvents: 300, externalEmulatorUrl: '' };
  CS.cfg = { v: Object.assign({}, DEF), load: function () { return st.get('cfg:' + CS.ns(), null).then(function (c) { CS.cfg.v = Object.assign({}, DEF, c || {}); return CS.cfg.v; }); },
    save: function (patch) { var v = CS.cfg.v; Object.keys(patch || {}).forEach(function (k) { if (k in DEF) v[k] = patch[k]; }); v.retryLimit = Math.max(0, Math.min(6, +v.retryLimit | 0)); v.maxActive = Math.max(1, Math.min(3, +v.maxActive | 0)); v.retentionDays = Math.max(1, Math.min(30, +v.retentionDays | 0 || 7)); return st.set('cfg:' + CS.ns(), v).then(function () { return v; }); } };
  CS.repoParts = function () { var m = /^([A-Za-z0-9_.-]{1,100})\/([A-Za-z0-9_.-]{1,100})$/.exec(String(CS.cfg.v.repo || '').trim()); return m ? { owner: m[1], name: m[2], path: '/repos/' + m[1] + '/' + m[2] } : null; };
  function R() { var p = CS.repoParts(); if (!p) throw CS.Err('Choose your GitHub repository in Cloud Settings first (owner/name).', 'setup'); return p; }

  /* ---------------- token (stored natively) ---------------- */
  CS.token = {
    has: function () { try { return !!(CS.nativeOk() && W.A2ZCloud.hasToken(CS.ns())); } catch (e) { return false; } },
    set: function (t) { if (!CS.nativeOk()) return Promise.reject(CS.Err('Needs the Zen AI app', 'setup')); var r = W.A2ZCloud.setToken(CS.ns(), String(t || '').trim()); if (r !== 'ok') return Promise.reject(CS.Err(r === 'bad' ? 'That does not look like a GitHub token (it starts with github_pat_ or ghp_).' : 'Could not store the token securely on this phone.', 'token'));
      return CS.gh('GET', '/user').then(function (x) { if (!x.ok) { W.A2ZCloud.clearToken(CS.ns()); throw CS.Err(CS.explain(x), 'token'); } return x.data; }); },
    clear: function () { try { W.A2ZCloud.clearToken(CS.ns()); } catch (e) { } }
  };

  /* ---------------- on-device database (same model as cloud-backend/schema.sql); every query is scoped to the signed-in user ---------------- */
  var db = CS.db = { d: { users: [], projects: [], builds: [], artifacts: [] },
    load: function () { return st.get('db:' + CS.ns(), null).then(function (d) { db.d = Object.assign({ users: [], projects: [], builds: [], artifacts: [] }, d || {}); var uid = CS.ns(); if (!db.d.users.find(function (u) { return u.user_id === uid; })) db.d.users.push({ user_id: uid, account_status: 'active', created_at: Date.now() }); return db.d; }); },
    save: function () { return st.set('db:' + CS.ns(), db.d); },
    mine: function (t) { var uid = CS.ns(); return db.d[t].filter(function (x) { return x.user_id === uid; }); }
  };
  db.projects = {
    list: function () { return db.mine('projects').sort(function (a, b) { return b.updated_at - a.updated_at; }); },
    get: function (id) { return db.mine('projects').find(function (p) { return p.project_id === id; }) || null; },
    create: function (o) { var p = { project_id: U.rid('p'), user_id: CS.ns(), project_name: o.name, package_name: o.pkg, project_type: o.type || 'android-kotlin', slug: o.slug, created_at: Date.now(), updated_at: Date.now(), dirty: true, lastCommit: '', branch: (CS.cfg.v.branchPrefix || 'cloud/') + o.slug }; db.d.projects.push(p); return p; },
    touch: function (p) { p.updated_at = Date.now(); },
    remove: function (id) { var p = db.projects.get(id); if (!p) return; db.d.projects = db.d.projects.filter(function (x) { return x !== p; }); var bs = db.d.builds.filter(function (b) { return b.project_id === id; }).map(function (b) { return b.build_id; }); db.d.builds = db.d.builds.filter(function (b) { return b.project_id !== id; }); db.d.artifacts = db.d.artifacts.filter(function (a) { return bs.indexOf(a.build_id) < 0; }); }
  };
  db.builds = {
    list: function (pid) { return db.mine('builds').filter(function (b) { return !pid || b.project_id === pid; }).sort(function (a, b) { return b.started_at - a.started_at; }); },
    get: function (id) { return db.mine('builds').find(function (b) { return b.build_id === id; }) || null; },
    create: function (o) { var b = Object.assign({ build_id: U.rid('b'), user_id: CS.ns(), build_status: 'queued', started_at: Date.now(), completed_at: 0, run_id: 0, html_url: '', progress: { done: 0, total: 0, step: '' }, summary: '' }, o); db.d.builds.push(b); if (db.d.builds.length > 300) db.d.builds.splice(0, db.d.builds.length - 300); return b; }
  };
  db.artifacts = {
    forBuild: function (bid) { return db.mine('artifacts').filter(function (a) { return a.build_id === bid; }); },
    list: function () { return db.mine('artifacts').sort(function (a, b) { return b.created_at - a.created_at; }); },
    upsert: function (a) { var old = db.d.artifacts.find(function (x) { return x.user_id === CS.ns() && x.gh_id === a.gh_id; }); if (old) return Object.assign(old, a); var n = Object.assign({ artifact_id: U.rid('a'), user_id: CS.ns(), checksum: '', storage_location: '', created_at: Date.now() }, a); db.d.artifacts.push(n); return n; }
  };
  /* project files (text) live in their own record so the metadata stays small */
  CS.files = {
    get: function (pid) { return st.get('files:' + CS.ns() + ':' + pid, {}); },
    set: function (pid, files) { return st.set('files:' + CS.ns() + ':' + pid, files); },
    snaps: function (pid) { return st.get('snaps:' + CS.ns() + ':' + pid, []); },
    snap: function (pid, label, files) { return CS.files.snaps(pid).then(function (s) { s.unshift({ id: U.rid('s'), t: Date.now(), label: label, files: files }); s = s.slice(0, 20); return st.set('snaps:' + CS.ns() + ':' + pid, s).then(function () { return s[0]; }); }); }
  };
  CS.logs = { get: function (bid) { return st.get('log:' + CS.ns() + ':' + bid, ''); }, set: function (bid, t) { return st.set('log:' + CS.ns() + ':' + bid, String(t).slice(-400000)); } };

  /* ---------------- path rules for everything the app writes to GitHub ---------------- */
  var EXT = /\.(kt|java|xml|json|gradle|kts|properties|html|css|js|txt|md|pro|toml|svg)$/i;   // yml is deliberately absent: no workflow files
  CS.okRel = function (rel) {
    rel = String(rel || '');
    if (!rel || rel.length > 200 || rel[0] === '/' || /(^|\/)\.\.?(\/|$)/.test(rel) || /\/\//.test(rel) || /[^A-Za-z0-9_.\-\/]/.test(rel)) return false;
    if (/(^|\/)\.(git|github)(\/|$)/i.test(rel)) return false;
    if (/(^|\/)gradle-wrapper\.jar$/.test(rel)) return false;
    return EXT.test(rel) || /(^|\/)(gradlew|\.gitignore|proguard-rules\.pro)$/.test(rel);
  };
  CS.repoPath = function (p, rel) { if (!CS.okRel(rel)) throw CS.Err('Path not allowed: ' + rel, 'path'); return 'cloud-projects/' + p.slug + '/' + rel; };
  CS.LIMITS = { file: 400000, files: 400 };

  /* ---------------- GitHub: repository, branches, files, commits ---------------- */
  var git = CS.git = {
    repo: function () { var r = R(); return CS.ghJson('GET', r.path, null, 'Repository'); },
    defaultBranch: function () { return git.repo().then(function (d) { return d.default_branch || 'main'; }); },
    branches: function () { var r = R(); return CS.ghJson('GET', r.path + '/branches?per_page=100', null, 'Branches').then(function (a) { return a.map(function (b) { return b.name; }); }); },
    refSha: function (branch) { var r = R(); return CS.gh('GET', r.path + '/git/ref/heads/' + branch).then(function (x) { return x.ok ? x.data.object.sha : (x.status === 404 ? null : must(x, 'Branch')); }); },
    ensureBranch: function (branch) {
      return git.refSha(branch).then(function (sha) {
        if (sha) return sha;
        var r = R();
        return git.defaultBranch().then(function (d) { return git.refSha(d); }).then(function (base) { return CS.ghJson('POST', r.path + '/git/refs', { ref: 'refs/heads/' + branch, sha: base }, 'Create branch').then(function () { return base; }); });
      });
    },
    deleteBranch: function (branch) { var r = R(); if (!/^cloud\//.test(branch)) return Promise.reject(CS.Err('Only cloud/* branches can be deleted here.', 'path')); return CS.gh('DELETE', r.path + '/git/refs/heads/' + branch).then(function (x) { if (!x.ok && x.status !== 404 && x.status !== 422) must(x); return true; }); },
    tree: function (branch) { var r = R(); return CS.ghJson('GET', r.path + '/git/trees/' + branch + '?recursive=1', null, 'File list').then(function (d) { return (d.tree || []).filter(function (t) { return t.type === 'blob'; }); }); },
    readBlob: function (sha) { var r = R(); return CS.ghJson('GET', r.path + '/git/blobs/' + sha, null, 'Read file').then(function (b) { return b.encoding === 'base64' ? U.b64utf8(b.content) : b.content; }); },
    /** Pull a project's files from its branch. */
    pull: function (p) {
      var prefix = 'cloud-projects/' + p.slug + '/';
      return git.tree(p.branch).then(function (t) {
        var items = t.filter(function (x) { return x.path.indexOf(prefix) === 0 && CS.okRel(x.path.slice(prefix.length)) && (x.size || 0) <= CS.LIMITS.file; }).slice(0, CS.LIMITS.files);
        var out = {}; var i = 0;
        function next() { if (i >= items.length) return Promise.resolve(out); var it = items[i++]; return git.readBlob(it.sha).then(function (txt) { out[it.path.slice(prefix.length)] = txt; return next(); }); }
        return next();
      });
    },
    /** One atomic commit of many files: changes = { relPath: "text" | null (delete) }. Returns the new commit sha. */
    commit: function (p, message, changes) {
      return Promise.resolve().then(function () { return git.commit1(p, message, changes); });
    },
    commit1: function (p, message, changes) {
      var r = R(), keys = Object.keys(changes);
      if (!keys.length) return Promise.resolve(p.lastCommit);
      var paths = {}; keys.forEach(function (k) { paths[k] = CS.repoPath(p, k); if (changes[k] != null && String(changes[k]).length > CS.LIMITS.file) throw CS.Err('File too large (400 KB max): ' + k, 'path'); });
      var head, baseTree, entries = [];
      return git.ensureBranch(p.branch).then(function () { return git.refSha(p.branch); }).then(function (sha) { head = sha; return CS.ghJson('GET', r.path + '/git/commits/' + sha, null, 'Read branch'); })
        .then(function (c) { baseTree = c.tree.sha; var i = 0;
          function nxt() { if (i >= keys.length) return Promise.resolve(); var k = keys[i++];
            if (changes[k] == null) { entries.push({ path: paths[k], mode: '100644', type: 'blob', sha: null }); return nxt(); }
            return CS.ghJson('POST', r.path + '/git/blobs', { content: U.utf8b64(String(changes[k])), encoding: 'base64' }, 'Upload ' + k).then(function (b) { entries.push({ path: paths[k], mode: '100644', type: 'blob', sha: b.sha }); return nxt(); }); }
          return nxt(); })
        .then(function () { return CS.ghJson('POST', r.path + '/git/trees', { base_tree: baseTree, tree: entries }, 'Create tree'); })
        .then(function (t) { return CS.ghJson('POST', r.path + '/git/commits', { message: String(message || 'Zen AI Cloud Studio').slice(0, 200), tree: t.sha, parents: [head] }, 'Create commit'); })
        .then(function (c) { return CS.ghJson('PATCH', r.path + '/git/refs/heads/' + p.branch, { sha: c.sha, force: false }, 'Update branch').then(function () { p.lastCommit = c.sha; return c.sha; }); });
    },
    /** Push the whole local working copy (diff against what the branch holds). */
    push: function (p, files, message, force) {
      return git.refSha(p.branch).then(function (sha) {
        var remote = sha ? git.pull(p).catch(function () { return {}; }) : Promise.resolve({});
        return remote.then(function (rem) {
          var ch = {}; Object.keys(files).forEach(function (k) { if (rem[k] !== files[k]) ch[k] = files[k]; }); Object.keys(rem).forEach(function (k) { if (!(k in files)) ch[k] = null; });
          return git.commit(p, message, ch).then(function (c) { p.dirty = false; return { commit: c, changed: Object.keys(ch).length }; });
        });
      });
    }
  };

  /* ---------------- builds ---------------- */
  var WF = { debug: 'cloud-android-debug.yml', release: 'cloud-android-release.yml', test: 'cloud-android-test.yml' };
  CS.workflows = WF;
  var runs = CS.runs = {
    list: function (q) { var r = R(); return CS.ghJson('GET', r.path + '/actions/runs?per_page=100' + (q || ''), null, 'Runs').then(function (d) { return (d.workflow_runs || []).filter(function (x) { return /^Cloud Android/.test(x.name || ''); }); }); },
    active: function () { return runs.list('&status=in_progress').then(function (a) { return runs.list('&status=queued').then(function (b) { return a.concat(b).filter(function (x) { return !/Cleanup/.test(x.name); }); }); }); },
    jobs: function (id) { var r = R(); return CS.ghJson('GET', r.path + '/actions/runs/' + id + '/jobs?per_page=30', null, 'Jobs').then(function (d) { return d.jobs || []; }); },
    jobLog: function (jobId) { var r = R(); return CS.gh('GET', r.path + '/actions/jobs/' + jobId + '/logs').then(function (x) { return x.ok ? x.text : ''; }); },
    annotations: function (jobId) { var r = R(); return CS.gh('GET', r.path + '/check-runs/' + jobId + '/annotations?per_page=50').then(function (x) { return x.ok && Array.isArray(x.data) ? x.data : []; }); },
    artifacts: function (id) { var r = R(); return CS.ghJson('GET', r.path + '/actions/runs/' + id + '/artifacts?per_page=30', null, 'Artifacts').then(function (d) { return d.artifacts || []; }); },
    cancel: function (id) { var r = R(); return CS.gh('POST', r.path + '/actions/runs/' + id + '/cancel').then(function (x) { if (!x.ok && x.status !== 409) must(x, 'Cancel'); return true; }); }
  };
  CS.TIMEOUT_MS = 50 * 60 * 1000;
  CS.poll = { find: 3000, start: 4000, step: 1000, max: 15000 };   // tests make these tiny

  /** Usage limits and messages. minutes are an ESTIMATE from run durations (GitHub has no simple per-repo billing API). */
  CS.usage = {
    get: function () {
      var r = R(), since = new Date(); since = new Date(Date.UTC(since.getUTCFullYear(), since.getUTCMonth(), 1)).toISOString().slice(0, 10);
      return CS.ghJson('GET', r.path, null, 'Repository').then(function (repo) {
        return runs.list('&created=%3E%3D' + since).then(function (rs) {
          var mins = 0; rs.forEach(function (x) { if (x.run_started_at && x.updated_at) mins += Math.max(1, Math.ceil((Date.parse(x.updated_at) - Date.parse(x.run_started_at)) / 60000)) + 1; });
          return CS.ghJson('GET', r.path + '/actions/artifacts?per_page=100', null, 'Artifacts').then(function (a) {
            var bytes = 0, n = 0; (a.artifacts || []).forEach(function (x) { if (!x.expired) { bytes += x.size_in_bytes || 0; n++; } });
            var priv = !!repo.private, lim = CS.cfg.v.monthlyMinutes;
            return { private: priv, runs: rs.length, minutes: priv ? mins : 0, rawMinutes: mins, limit: lim, storageBytes: bytes, storageLimit: CS.cfg.v.storageLimitMB * 1048576, artifactCount: n,
              note: priv ? 'Private repository: GitHub Free includes about 2000 Actions minutes and 500 MB of artifact storage per month. These numbers are estimates from run durations; GitHub\'s billing page is the real source.' : 'Public repository: standard GitHub-hosted runners are free. Artifact storage still has a limit.' };
          });
        });
      });
    },
    /** Throws a clear message when a new build must not start. */
    guard: function () {
      return runs.active().then(function (act) {
        var max = CS.cfg.v.maxActive;
        if (act.length >= max) throw CS.Err('Concurrency limit: ' + act.length + ' cloud build' + (act.length > 1 ? 's are' : ' is') + ' already running (limit ' + max + '). Wait for it, cancel it in Build Center, or raise the limit in Cloud Settings.', 'quota');
        return CS.usage.get().then(function (u) {
          if (u.private && u.minutes >= u.limit) throw CS.Err('Monthly Actions limit reached: about ' + u.minutes + ' of ' + u.limit + ' minutes used. Builds would be billed or refused by GitHub. Raise the limit in Cloud Settings only if your plan allows it.', 'quota');
          var warn = u.private && u.minutes >= u.limit * 0.8 ? 'About ' + u.minutes + ' of ' + u.limit + ' monthly minutes used.' : '';
          if (u.storageBytes >= u.storageLimit) throw CS.Err('Artifact storage is full (' + U.bytes(u.storageBytes) + ' of ' + U.bytes(u.storageLimit) + '). Run "Clean up" in Build History or delete old artifacts.', 'quota');
          return { warn: warn, usage: u };
        }).catch(function (e) { if (e.code === 'quota') throw e; return { warn: 'Usage could not be checked (' + e.message + ').', usage: null }; });
      });
    }
  };

  /** Start a cloud build and follow it. opts: {kind:'debug'|'release'|'test', onUpdate(build), force:boolean}. Resolves the finished build record. */
  CS.build = {
    handles: {},
    start: function (p, opts) {
      opts = opts || {}; var kind = opts.kind || 'debug', wf = WF[kind], r = R(), cfg = CS.cfg.v;
      if (!wf) return Promise.reject(CS.Err('Unknown build type', 'arg'));
      var b = db.builds.create({ project_id: p.project_id, build_type: kind, retry_of: opts.retryOf || '', attempt: opts.attempt || 1, fix_chain: opts.fixChain || [] }), ctl = { cancelled: false, run: 0 };
      CS.build.handles[b.build_id] = ctl; var upd = function () { db.save(); try { opts.onUpdate && opts.onUpdate(b); } catch (e) { } };
      function fail(e) { b.build_status = 'failed'; b.completed_at = Date.now(); b.summary = e.message; b.error_code = e.code; delete CS.build.handles[b.build_id]; upd(); throw e; }
      return CS.usage.guard().then(function (g) {
        b.guard = g.warn; b.build_status = 'preparing'; b.progress.step = 'Saving project to GitHub'; upd();
        return CS.files.get(p.project_id).then(function (files) {
          if (!Object.keys(files).length) throw CS.Err('This project has no files.', 'arg');
          return git.push(p, files, 'Zen AI Cloud Studio: ' + kind + ' build ' + b.build_id);
        });
      }).then(function (pr) {
        b.commit = p.lastCommit; db.projects.touch(p); b.progress.step = 'Starting workflow'; upd();
        var inputs = { build_id: b.build_id, project_dir: 'cloud-projects/' + p.slug, gradle_version: String(cfg.gradleVersion), retention_days: String(cfg.retentionDays) };
        if (kind === 'test') { inputs.api_level = String(cfg.emulatorApi); inputs.ui_events = String(cfg.uiEvents); }
        if (opts.sdkPackages) inputs.sdk_packages = opts.sdkPackages;
        return CS.gh('POST', r.path + '/actions/workflows/' + wf + '/dispatches', { ref: p.branch, inputs: inputs }).then(function (x) {
          if (!x.ok) { if (x.status === 404) throw CS.Err('Workflow ' + wf + ' was not found on branch ' + p.branch + '. Upload the files from .github/workflows/ to your repository first (see Setup).', 'setup'); throw CS.Err('Could not start the workflow: ' + CS.explain(x), 'dispatch'); }
        });
      }).then(function () { b.build_status = 'queued'; b.progress.step = 'Waiting for a GitHub runner'; upd(); return follow(p, b, ctl, opts, upd); }).catch(function (e) { if (b.build_status === 'failed') throw e; return fail(e); });
    },
    cancel: function (bid) { var b = db.builds.get(bid), c = CS.build.handles[bid]; if (c) c.cancelled = true; if (b && b.run_id) return runs.cancel(b.run_id); return Promise.resolve(); }
  };
  function follow(p, b, ctl, opts, upd) {
    var r = R(), t0 = Date.now(), delay = CS.poll.start;
    function findRun() {
      return CS.ghJson('GET', r.path + '/actions/runs?event=workflow_dispatch&per_page=20&branch=' + encodeURIComponent(p.branch), null, 'Find run').then(function (d) {
        var m = (d.workflow_runs || []).find(function (x) { return String(x.display_title || x.name || '').indexOf(b.build_id) >= 0; });
        if (m) { b.run_id = m.id; b.html_url = m.html_url; upd(); return m; }
        if (ctl.cancelled) throw CS.Err('Cancelled', 'cancelled'); if (Date.now() - t0 > 120000) throw CS.Err('GitHub did not start the build within 2 minutes. Check the Actions tab of your repository.', 'timeout');
        return U.sleep(CS.poll.find).then(findRun);
      });
    }
    function tick() {
      return CS.ghJson('GET', r.path + '/actions/runs/' + b.run_id, null, 'Run status').then(function (run) {
        return runs.jobs(run.id).then(function (jobs) {
          var steps = []; jobs.forEach(function (j) { (j.steps || []).forEach(function (s) { steps.push(s); }); });
          var done = steps.filter(function (s) { return s.status === 'completed'; }).length, cur = steps.find(function (s) { return s.status === 'in_progress'; });
          b.progress = { done: done, total: steps.length, step: cur ? cur.name : (run.status === 'completed' ? 'Finished' : 'Waiting') };
          b.build_status = run.status === 'completed' ? (run.conclusion === 'success' ? 'success' : run.conclusion === 'cancelled' ? 'cancelled' : 'failed') : (run.status === 'in_progress' ? 'running' : 'queued');
          upd();
          if (run.status === 'completed') return finish(run, jobs);
          if (ctl.cancelled) { runs.cancel(run.id).catch(function () { }); ctl.cancelled = false; }
          if (Date.now() - t0 > CS.TIMEOUT_MS) { runs.cancel(run.id).catch(function () { }); throw CS.Err('Build timed out after 50 minutes and was cancelled.', 'timeout'); }
          delay = Math.min(CS.poll.max, delay + CS.poll.step); return U.sleep(delay).then(tick);
        });
      });
    }
    function finish(run, jobs) {
      b.completed_at = Date.now(); b.duration = Math.round((Date.parse(run.updated_at) - Date.parse(run.run_started_at || run.created_at)) / 1000);
      var bad = jobs.find(function (j) { return j.conclusion === 'failure'; }) || jobs[jobs.length - 1];
      var work = [];
      work.push(runs.artifacts(run.id).then(function (as) { b.artifacts = as.map(function (a) { return a.id; }); as.forEach(function (a) { db.artifacts.upsert({ gh_id: a.id, build_id: b.build_id, file_name: a.name, file_size: a.size_in_bytes, expiration_time: a.expires_at ? Date.parse(a.expires_at) : 0, created_at: Date.parse(a.created_at) || Date.now(), kind: /^cloud-signed/.test(a.name) ? 'release' : /^cloud-apk/.test(a.name) ? (b.build_type === 'release' ? 'unsigned' : 'debug') : /^cloud-emu/.test(a.name) ? 'emulator' : /^cloud-log/.test(a.name) ? 'log' : 'other' }); }); }).catch(function () { }));
      if (bad) { work.push(runs.jobLog(bad.id).then(function (t) { return CS.logs.set(b.build_id, t); })); work.push(runs.annotations(bad.id).then(function (a) { b.annotations = a.slice(0, 20).map(function (x) { return { path: x.path, line: x.start_line, level: x.annotation_level, message: String(x.message || '').slice(0, 400) }; }); })); }
      return Promise.all(work).then(function () {
        if (b.build_status === 'failed') { return CS.logs.get(b.build_id).then(function (log) { var c = CS.classify ? CS.classify(log, b.annotations) : null; if (c) { b.error = c; b.summary = c.title + ': ' + c.summary; } else b.summary = 'Build failed'; delete CS.build.handles[b.build_id]; upd(); return b; }); }
        b.summary = b.build_status === 'success' ? 'Build succeeded' : 'Build ' + b.build_status; delete CS.build.handles[b.build_id]; upd(); return b;
      });
    }
    return (b.run_id ? Promise.resolve() : findRun()).then(tick).catch(function (e) { b.build_status = e.code === 'cancelled' ? 'cancelled' : 'failed'; b.completed_at = Date.now(); b.summary = e.message; delete CS.build.handles[b.build_id]; upd(); throw e; });
  }

  /* ---------------- artifacts / APKs (download happens natively; the page only gets metadata) ---------------- */
  CS.apk = {
    download: function (art) {
      var r = R();
      if (!CS.nativeOk()) return Promise.reject(CS.Err('Needs the Zen AI app', 'setup'));
      return call(function (id) { W.A2ZCloud.downloadApk(id, CS.ns(), r.owner, r.name, String(art.gh_id)); }).then(function (x) {
        var d = parse(x.text); if (x.status !== 200 || !d) throw CS.Err((d && d.message) || 'Download failed', 'download');
        art.checksum = d.sha256; art.file_name = d.name; art.file_size = d.size; art.storage_location = d.where; art.package = d.package || ''; art.versionName = d.versionName || ''; art.versionCode = d.versionCode || 0; art.certSha256 = d.certSha256 || ''; art.downloaded_at = Date.now(); db.save(); return art;
      });
    },
    reports: function (art) {
      var r = R();
      return call(function (id) { W.A2ZCloud.downloadReports(id, CS.ns(), r.owner, r.name, String(art.gh_id)); }).then(function (x) { var d = parse(x.text); if (x.status !== 200 || !d) throw CS.Err((d && d.message) || 'Download failed', 'download'); return d.files || []; });
    },
    share: function (art) { return W.A2ZCloud.shareApk(art.file_name); },
    remove: function (art) { var r = R(); return CS.gh('DELETE', r.path + '/actions/artifacts/' + art.gh_id).then(function () { db.d.artifacts = db.d.artifacts.filter(function (a) { return a !== art; }); db.save(); }); }
  };
  CS.cleanup = function () {   // delete expired / old cloud artifacts from the phone-side list + GitHub
    var r = R(), cut = Date.now() - CS.cfg.v.retentionDays * 86400000, n = 0;
    return CS.ghJson('GET', r.path + '/actions/artifacts?per_page=100', null, 'Artifacts').then(function (a) {
      var old = (a.artifacts || []).filter(function (x) { return /^cloud-/.test(x.name) && Date.parse(x.created_at) < cut; }), i = 0;
      function nx() { if (i >= old.length) return Promise.resolve(n); var x = old[i++]; return CS.gh('DELETE', r.path + '/actions/artifacts/' + x.id).then(function (q) { if (q.ok) n++; return nx(); }); }
      return nx();
    }).then(function (c) { db.d.artifacts = db.d.artifacts.filter(function (a) { return !a.expiration_time || a.expiration_time > Date.now(); }); return db.save().then(function () { return c; }); });
  };

  CS.init = function () { return CS.cfg.load().then(function () { return db.load(); }); };
})(typeof window !== 'undefined' ? window : globalThis);
