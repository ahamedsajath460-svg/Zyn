/* Zen AI Cloud Studio - generation: project scaffold, AI App Creator, static lint, build-error classifier,
 * automatic fix engine (propose -> review -> apply -> rebuild, with snapshots and rollback), XML/HTML previews.
 * Pure logic; the AI is the page's existing provider router (global ask). Tested in Node with a stubbed AI. */
(function (W) {
  'use strict';
  var CS = W.CloudStudio; if (!CS || !CS.core || CS.gen) return; CS.gen = 1;
  var U = CS.u, db = CS.db;

  /* ======================= scaffold (known-good Gradle files; the AI only writes app code and resources) ======================= */
  var AGP = '8.5.2', KOTLIN = '1.9.24';
  CS.LIBS = {   // vetted versions; the AI picks keys, never versions
    recyclerview: { deps: ['androidx.recyclerview:recyclerview:1.3.2'], about: 'lists' },
    lifecycle: { deps: ['androidx.lifecycle:lifecycle-viewmodel-ktx:2.8.4', 'androidx.lifecycle:lifecycle-livedata-ktx:2.8.4', 'androidx.activity:activity-ktx:1.9.1'], about: 'ViewModel / LiveData' },
    navigation: { deps: ['androidx.navigation:navigation-fragment-ktx:2.7.7', 'androidx.navigation:navigation-ui-ktx:2.7.7'], about: 'fragment navigation' },
    room: { deps: ['androidx.room:room-runtime:2.6.1', 'androidx.room:room-ktx:2.6.1'], kapt: ['androidx.room:room-compiler:2.6.1'], about: 'SQLite database', needsKapt: true },
    retrofit: { deps: ['com.squareup.retrofit2:retrofit:2.11.0', 'com.squareup.retrofit2:converter-gson:2.11.0', 'com.squareup.okhttp3:okhttp:4.12.0'], about: 'HTTP API client', internet: true },
    gson: { deps: ['com.google.code.gson:gson:2.10.1'], about: 'JSON' },
    coroutines: { deps: ['org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1'], about: 'async work' },
    coil: { deps: ['io.coil-kt:coil:2.6.0'], about: 'image loading', internet: true }
  };
  var RESERVED = ['in', 'is', 'as', 'do', 'if', 'for', 'fun', 'val', 'var', 'new', 'int', 'long', 'void', 'class', 'null', 'true', 'false', 'try', 'object', 'package', 'import', 'return', 'when', 'while', 'this', 'super', 'static', 'public', 'private', 'default', 'switch', 'case', 'enum', 'final', 'throw', 'throws'];
  CS.okPackage = function (p) { return /^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$/.test(p) && p.split('.').every(function (s) { return RESERVED.indexOf(s) < 0; }); };
  CS.guessPackage = function (name) { var s = String(name || 'app').toLowerCase().replace(/[^a-z0-9]/g, '').replace(/^[0-9]+/, ''); if (!s || RESERVED.indexOf(s) >= 0) s = 'app' + s; return 'com.zenai.' + s.slice(0, 24); };
  var L = function () { return [].slice.call(arguments).join('\n') + '\n'; };
  var xml = function (s) { return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, "\\'"); };

  /** Complete, buildable starter project: AppCompat + Material 3 + one Activity with a counter button. */
  CS.scaffold = function (o) {
    var name = String(o.name || 'My App').slice(0, 40), pkg = o.pkg || CS.guessPackage(name), libs = (o.libs || []).filter(function (k) { return CS.LIBS[k]; }), dir = pkg.replace(/\./g, '/');
    if (!CS.okPackage(pkg)) throw CS.Err('Invalid package name: ' + pkg, 'arg');
    var kapt = libs.some(function (k) { return CS.LIBS[k].needsKapt; }), net = libs.some(function (k) { return CS.LIBS[k].internet; });
    var deps = ['androidx.core:core-ktx:1.13.1', 'androidx.appcompat:appcompat:1.7.0', 'com.google.android.material:material:1.12.0', 'androidx.constraintlayout:constraintlayout:2.1.4'], kd = [];
    libs.forEach(function (k) { deps = deps.concat(CS.LIBS[k].deps); kd = kd.concat(CS.LIBS[k].kapt || []); });
    var f = {};
    f['settings.gradle.kts'] = L('pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } }', 'dependencyResolutionManagement { repositories { google(); mavenCentral() } }', 'rootProject.name = "' + name.replace(/[^A-Za-z0-9 _-]/g, '') + '"', 'include(":app")');
    f['build.gradle.kts'] = L('plugins {', '    id("com.android.application") version "' + AGP + '" apply false', '    id("org.jetbrains.kotlin.android") version "' + KOTLIN + '" apply false', '}');
    f['gradle.properties'] = L('org.gradle.jvmargs=-Xmx2g -Dfile.encoding=UTF-8', 'android.useAndroidX=true', 'android.nonTransitiveRClass=true', 'kotlin.code.style=official');
    f['.gitignore'] = L('build/', '.gradle/', 'local.properties', '*.iml', '.idea/');
    f['app/build.gradle.kts'] = L('plugins {', '    id("com.android.application")', '    id("org.jetbrains.kotlin.android")', kapt ? '    id("org.jetbrains.kotlin.kapt")' : null, '}', '',
      'android {', '    namespace = "' + pkg + '"', '    compileSdk = 34', '    defaultConfig {', '        applicationId = "' + pkg + '"', '        minSdk = 26', '        targetSdk = 34', '        versionCode = 1', '        versionName = "1.0"', '    }',
      '    buildTypes { release { isMinifyEnabled = false } }', '    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }', '    kotlinOptions { jvmTarget = "17" }', '}', '',
      'dependencies {', deps.map(function (d) { return '    implementation("' + d + '")'; }).join('\n'), kd.map(function (d) { return '    kapt("' + d + '")'; }).join('\n'), '}').replace(/\n\n\n+/g, '\n\n').replace(/\n\s*\n}\n$/, '\n}\n');
    f['app/src/main/AndroidManifest.xml'] = L('<?xml version="1.0" encoding="utf-8"?>', '<manifest xmlns:android="http://schemas.android.com/apk/res/android">', net ? '    <uses-permission android:name="android.permission.INTERNET" />' : null,
      '    <application', '        android:allowBackup="true"', '        android:icon="@mipmap/ic_launcher"', '        android:roundIcon="@mipmap/ic_launcher"', '        android:label="@string/app_name"', '        android:supportsRtl="true"', '        android:theme="@style/Theme.App">',
      '        <activity android:name=".MainActivity" android:exported="true">', '            <intent-filter>', '                <action android:name="android.intent.action.MAIN" />', '                <category android:name="android.intent.category.LAUNCHER" />', '            </intent-filter>', '        </activity>', '    </application>', '</manifest>');
    f['app/src/main/java/' + dir + '/MainActivity.kt'] = L('package ' + pkg, '', 'import android.os.Bundle', 'import android.widget.Button', 'import android.widget.TextView', 'import androidx.appcompat.app.AppCompatActivity', '',
      'class MainActivity : AppCompatActivity() {', '    private var count = 0', '', '    override fun onCreate(savedInstanceState: Bundle?) {', '        super.onCreate(savedInstanceState)', '        setContentView(R.layout.activity_main)',
      '        val label = findViewById<TextView>(R.id.label)', '        findViewById<Button>(R.id.button).setOnClickListener {', '            count++', '            label.text = getString(R.string.clicked, count)', '        }', '    }', '}');
    f['app/src/main/res/layout/activity_main.xml'] = L('<?xml version="1.0" encoding="utf-8"?>', '<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"', '    android:layout_width="match_parent"', '    android:layout_height="match_parent"', '    android:gravity="center"',
      '    android:orientation="vertical"', '    android:padding="24dp">', '', '    <TextView', '        android:id="@+id/label"', '        android:layout_width="wrap_content"', '        android:layout_height="wrap_content"', '        android:text="@string/hello"', '        android:textSize="24sp" />', '',
      '    <Button', '        android:id="@+id/button"', '        android:layout_width="wrap_content"', '        android:layout_height="wrap_content"', '        android:layout_marginTop="16dp"', '        android:text="@string/tap_me" />', '</LinearLayout>');
    f['app/src/main/res/values/strings.xml'] = L('<resources>', '    <string name="app_name">' + xml(name) + '</string>', '    <string name="hello">Hello from Zen AI Cloud Studio</string>', '    <string name="tap_me">Tap me</string>', '    <string name="clicked">Clicked %1$d times</string>', '</resources>');
    f['app/src/main/res/values/colors.xml'] = L('<resources>', '    <color name="brand">#6750A4</color>', '    <color name="icon_bg">#6750A4</color>', '</resources>');
    f['app/src/main/res/values/themes.xml'] = L('<resources>', '    <style name="Theme.App" parent="Theme.Material3.DayNight.NoActionBar">', '        <item name="colorPrimary">@color/brand</item>', '    </style>', '</resources>');
    f['app/src/main/res/mipmap-anydpi/ic_launcher.xml'] = L('<?xml version="1.0" encoding="utf-8"?>', '<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">', '    <background android:drawable="@color/icon_bg" />', '    <foreground android:drawable="@drawable/ic_launcher_fg" />', '</adaptive-icon>');
    f['app/src/main/res/drawable/ic_launcher_fg.xml'] = L('<?xml version="1.0" encoding="utf-8"?>', '<vector xmlns:android="http://schemas.android.com/apk/res/android"', '    android:width="108dp"', '    android:height="108dp"', '    android:viewportWidth="108"', '    android:viewportHeight="108">',
      '    <path android:fillColor="#FFFFFF" android:pathData="M54,30 L72,78 L36,78 Z" />', '</vector>');
    Object.keys(f).forEach(function (k) { f[k] = f[k].replace(/^null\n/gm, ''); });
    return f;
  };

  /* ======================= static lint (offline; also drives error highlighting) ======================= */
  CS.lint = function (files) {
    var out = [], add = function (path, line, msg, level) { out.push({ path: path, line: line || 1, message: msg, level: level || 'error' }); };
    var parseXml = function (t) { if (typeof DOMParser === 'undefined') return null; var d = new DOMParser().parseFromString(t, 'application/xml'); var e = d.getElementsByTagName('parsererror')[0]; return e ? { err: e.textContent } : { doc: d }; };
    var layouts = {}, strings = {}, ids = {}, colors = {};
    Object.keys(files).forEach(function (p) {
      var t = files[p];
      if (/\.xml$/.test(p)) {
        var r = parseXml(t); if (r && r.err) { var m = /line\s+(\d+)/i.exec(r.err); add(p, m ? +m[1] : 1, 'XML is not well-formed: ' + r.err.split('\n')[0].slice(0, 160)); }
        var lm = /\/res\/layout[^/]*\/([^/]+)\.xml$/.exec(p); if (lm) layouts[lm[1]] = 1;
        if (/\/res\/values[^/]*\//.test(p)) { t.replace(/<string\s+name="([^"]+)"/g, function (_, n) { strings[n] = 1; }); t.replace(/<color\s+name="([^"]+)"/g, function (_, n) { colors[n] = 1; }); }
        t.replace(/@\+?id\/([A-Za-z0-9_]+)/g, function (_, n) { ids[n] = 1; });
      }
      if (/\.(kt|java)$/.test(p)) {
        var o = 0, c = 0, q = t.replace(/\/\/.*$/gm, '').replace(/\/\*[\s\S]*?\*\//g, '').replace(/"(?:\\.|[^"\\\n])*"/g, '""').replace(/'(?:\\.|[^'\\\n])'/g, "''");
        for (var i = 0; i < q.length; i++) { if (q[i] === '{') o++; else if (q[i] === '}') c++; }
        if (o !== c) add(p, 1, 'Unbalanced braces: ' + o + ' "{" and ' + c + ' "}"');
        var pk = /^\s*package\s+([\w.]+)/m.exec(t), dm = /src\/main\/(?:java|kotlin)\/(.+)\/[^/]+$/.exec(p);
        if (pk && dm && pk[1] !== dm[1].replace(/\//g, '.')) add(p, 1, 'package ' + pk[1] + ' does not match the folder ' + dm[1].replace(/\//g, '.'), 'warning');
      }
    });
    Object.keys(files).forEach(function (p) {
      var t = files[p];
      if (/\.(kt|java)$/.test(p)) {
        t.split('\n').forEach(function (ln, i) {
          var m, re = /R\.layout\.([A-Za-z0-9_]+)/g; while ((m = re.exec(ln))) if (!layouts[m[1]]) add(p, i + 1, 'Layout "' + m[1] + '" does not exist (res/layout/' + m[1] + '.xml)');
          re = /R\.string\.([A-Za-z0-9_]+)/g; while ((m = re.exec(ln))) if (!strings[m[1]]) add(p, i + 1, 'String "' + m[1] + '" is not defined in res/values/strings.xml');
          re = /R\.id\.([A-Za-z0-9_]+)/g; while ((m = re.exec(ln))) if (!ids[m[1]]) add(p, i + 1, 'View id "' + m[1] + '" is not defined in any layout');
        });
      }
      if (/AndroidManifest\.xml$/.test(p)) {
        var pkg = /namespace\s*=\s*"([\w.]+)"/.exec(files['app/build.gradle.kts'] || ''); pkg = pkg && pkg[1];
        t.replace(/<activity[^>]*android:name="([^"]+)"/g, function (_, n) {
          var cls = n.charAt(0) === '.' ? (pkg || '') + n : (n.indexOf('.') < 0 ? (pkg || '') + '.' + n : n), path = cls.replace(/\./g, '/');
          if (pkg && !Object.keys(files).some(function (k) { return k.indexOf(path + '.kt') > 0 || k.indexOf(path + '.java') > 0; })) add(p, 1, 'Activity class ' + cls + ' was not found in the project');
        });
        if (!/android\.intent\.category\.LAUNCHER/.test(t)) add(p, 1, 'No launcher activity: the app cannot be opened from the home screen', 'warning');
      }
      if (/\.xml$/.test(p) && /\/res\//.test(p)) { t.split('\n').forEach(function (ln, i) { var m, re = /@color\/([A-Za-z0-9_]+)/g; while ((m = re.exec(ln))) if (!colors[m[1]] && !/^(white|black|transparent|holo_)/.test(m[1])) add(p, i + 1, 'Color "' + m[1] + '" is not defined in res/values/colors.xml', 'warning'); }); }
    });
    return out;
  };

  /* ======================= build error classifier ======================= */
  var CATS = [
    ['kotlin', /^e: (?:file:\/\/)?\S+\.kt:\d+/m, 'Kotlin compile error'], ['java', /\.java:\d+: error:/m, 'Java compile error'],
    ['resource', /(AAPT|aapt2)|error: resource .* not found|Android resource linking failed|resource (?:string|layout|color|style|drawable|id)\/\S+ not found/i, 'Android resource error'],
    ['manifest', /Manifest merger failed|AndroidManifest\.xml.*error|Attribute .* is also present|android:exported/i, 'AndroidManifest error'],
    ['dependency', /Could not (?:resolve|find|get) |Could not GET|No matching variant|Failed to resolve:|Unable to resolve dependency/i, 'Dependency could not be resolved'],
    ['plugin', /Plugin .* was not found|Plugin \[id: .*\] was not found|Could not find com\.android\.tools\.build|requires Java|Unsupported class file major version|incompatible with.*Gradle|Minimum supported Gradle version/i, 'Gradle / plugin version problem'],
    ['dsl', /Script compilation error|Build file '.*' line: \d+|Unresolved reference.*\.kts|A problem occurred evaluating (?:root )?project|Could not (?:get|set) unknown property/i, 'Gradle script error'],
    ['sdk', /SDK location not found|Failed to find (?:target with hash|Build Tools|Platform)|license for package|Failed to install the following Android SDK packages/i, 'Android SDK component missing'],
    ['memory', /OutOfMemoryError|GC overhead limit|Java heap space|Metaspace/i, 'Out of memory'], ['signing', /keystore|Failed to read key|signing|zipalign|apksigner/i, 'Signing problem'],
    ['network', /Connection (?:reset|timed out)|UnknownHostException|SocketTimeoutException|Read timed out/i, 'Network problem during build'], ['test', /Tests? failed|There were failing tests/i, 'Test failure'], ['lint', /Lint found errors|lint-results/i, 'Lint error']];
  CS.classify = function (log, anns) {
    log = String(log || '').replace(/\u001b\[[0-9;]*m/g, '').replace(/^\d{4}-\d\d-\d\dT[\d:.]+Z /gm, '');
    var cat = 'unknown', title = 'Build failed', file = '', line = 0, lines = log.split('\n');
    for (var i = 0; i < CATS.length; i++) if (CATS[i][1].test(log)) { cat = CATS[i][0]; title = CATS[i][2]; break; }
    var m = /^e: (?:file:\/\/)?(\S+?):(\d+):(\d+)\s+(.*)$/m.exec(log), sum = '';
    if (m) { file = m[1]; line = +m[2]; sum = m[4]; }
    if (!m) { m = /^(\S+\.(?:java|kt|xml)):(\d+)(?::\d+)?: (?:AAPT: )?error: (.*)$/m.exec(log); if (m) { file = m[1]; line = +m[2]; sum = m[3]; } }
    if (!sum) { var w = /\* What went wrong:\n([^\n]+(?:\n(?!\*)[^\n]+)?)/.exec(log); if (w) sum = w[1].replace(/\n/g, ' ').trim(); }
    if (!sum) { var c = /> (Could not [^\n]+)/.exec(log) || /(Execution failed for task [^\n]+)/.exec(log); if (c) sum = c[1]; }
    if (!sum && anns && anns.length) { var a = anns.find(function (x) { return x.level === 'failure' || x.level === 'error'; }) || anns[0]; sum = a.message; if (a.path && !file) { file = a.path; line = a.line || 0; } }
    if (!sum) sum = 'See the build log for details.';
    file = file.replace(/^.*?cloud-projects\/[^/]+\//, '').replace(/^\/+/, '');
    var fi = lines.findIndex(function (x) { return /FAILURE: Build failed|^e: |error:|What went wrong/.test(x); }), from = Math.max(0, (fi < 0 ? lines.length - 40 : fi) - 6);
    var excerpt = lines.slice(from, from + 60).join('\n').slice(0, 6000);
    var sig = cat + '|' + file + '|' + line + '|' + sum.replace(/\d+/g, '#').slice(0, 120);
    return { category: cat, title: title, summary: sum.slice(0, 300), file: file, line: line, excerpt: excerpt, signature: sig, fixable: ['kotlin', 'java', 'resource', 'manifest', 'dependency', 'dsl', 'plugin', 'unknown'].indexOf(cat) >= 0 };
  };

  /* ======================= AI helpers ======================= */
  CS.askFn = function () { if (typeof W.ask === 'function') return W.ask; throw CS.Err('No AI provider is ready. Open Settings in Chat and add a provider.', 'ai'); };
  CS.jsonFrom = function (txt) {
    var t = String(txt || '').replace(/```(?:json)?/gi, '').trim(), s = t.indexOf('{'); if (s < 0) throw CS.Err('The AI did not return JSON.', 'ai');
    var d = 0, inS = false, esc = false;
    for (var i = s; i < t.length; i++) { var ch = t[i]; if (inS) { if (esc) esc = false; else if (ch === '\\') esc = true; else if (ch === '"') inS = false; } else if (ch === '"') inS = true; else if (ch === '{') d++; else if (ch === '}') { d--; if (d === 0) { try { return JSON.parse(t.slice(s, i + 1)); } catch (e) { throw CS.Err('The AI returned broken JSON.', 'ai'); } } } }
    throw CS.Err('The AI reply was cut off.', 'ai');
  };
  CS.stripFence = function (t) { t = String(t || '').trim(); var m = /^```[\w-]*\n([\s\S]*?)\n```\s*$/.exec(t); if (m) return m[1]; t = t.replace(/^```[\w-]*\n/, '').replace(/\n```\s*$/, ''); return t; };
  var SYS_BASE = 'You are the code generator of Zen AI Cloud Studio. You write Android apps in Kotlin using classic Views and XML layouts, AppCompat and Material 3 (Theme.Material3.DayNight.NoActionBar), minSdk 26, compileSdk 34, no Jetpack Compose, no ViewBinding (use findViewById), no third-party library that is not in the allowed list. Never invent API keys or secrets. Never write files outside app/src/main. Reply with exactly what is asked and nothing else.';

  /* ======================= AI App Creator ======================= */
  CS.creator = {
    /** prompt -> analysis -> file plan -> every file -> lint -> one repair round. Returns {name,pkg,libs,files,analysis,issues}. */
    generate: function (o) {
      var ask = CS.askFn(), step = function (m) { try { o.onStep && o.onStep(m); } catch (e) { } }, name, pkg, libs, plan;
      step('Understanding your idea');
      var sys1 = SYS_BASE + ' Allowed library keys: ' + Object.keys(CS.LIBS).map(function (k) { return k + ' (' + CS.LIBS[k].about + ')'; }).join(', ') + '. Reply with ONE JSON object only: {"appName":"...","summary":"...","screens":["..."],"features":["..."],"architecture":"...","libs":["key",...],"files":[{"path":"app/src/main/...","purpose":"..."}]}. ' +
        'The file list must contain at most 12 files, all under app/src/main/ (Kotlin in app/src/main/java/<package path>/, XML in res/), must include MainActivity.kt, the layouts it uses, and values/strings.xml. Do NOT list gradle files, AndroidManifest.xml (only if you add activities), icons or themes.xml: they exist already.';
      return ask(sys1, 'App idea: ' + String(o.prompt).slice(0, 2000) + (o.name ? '\nApp name: ' + o.name : '') + (o.pkg ? '\nPackage: ' + o.pkg : '')).then(function (t) {
        plan = CS.jsonFrom(t); name = String(o.name || plan.appName || 'My App').slice(0, 40); pkg = o.pkg || CS.guessPackage(name); if (!CS.okPackage(pkg)) pkg = CS.guessPackage(name);
        libs = (plan.libs || []).filter(function (k) { return CS.LIBS[k]; });
        var base = CS.scaffold({ name: name, pkg: pkg, libs: libs }), dir = 'app/src/main/java/' + pkg.replace(/\./g, '/') + '/', files = Object.assign({}, base);
        var list = (plan.files || []).map(function (f) { return { path: String(f.path || '').replace(/^\/+/, ''), purpose: String(f.purpose || '') }; }).filter(function (f) { return /^app\/src\/main\//.test(f.path) && CS.okRel(f.path) && !/\/themes\.xml$/.test(f.path); }).slice(0, 12);
        if (!list.some(function (f) { return /MainActivity\.kt$/.test(f.path); })) list.unshift({ path: dir + 'MainActivity.kt', purpose: 'Main screen' });
        var i = 0;
        function nxt() {
          if (i >= list.length) return Promise.resolve();
          var f = list[i++]; step('Writing ' + f.path.replace('app/src/main/', '') + ' (' + i + '/' + list.length + ')');
          var ctx = 'Package: ' + pkg + '\nApp: ' + name + '\nSummary: ' + (plan.summary || '') + '\nArchitecture: ' + (plan.architecture || '') + '\nScreens: ' + (plan.screens || []).join('; ') + '\nAll files of the app: ' + list.map(function (x) { return x.path; }).join(', ') + '\nLibraries available: ' + libs.join(', ') + '\n' +
            'Existing strings.xml:\n' + (files['app/src/main/res/values/strings.xml'] || '') + '\nExisting colors.xml:\n' + (files['app/src/main/res/values/colors.xml'] || '');
          return ask(SYS_BASE + ' Output ONLY the complete content of the requested file, no explanation, no markdown fence. Kotlin files start with "package ' + pkg + '".', ctx + '\n\nWrite the file ' + f.path + '. Purpose: ' + f.purpose).then(function (c) { files[f.path] = CS.stripFence(c) + '\n'; return nxt(); });
        }
        return nxt().then(function () {
          if (!files['app/src/main/res/values/strings.xml'] || !/name="app_name"/.test(files['app/src/main/res/values/strings.xml'])) files['app/src/main/res/values/strings.xml'] = base['app/src/main/res/values/strings.xml'];
          var issues = CS.lint(files).filter(function (x) { return x.level === 'error'; });
          if (!issues.length) return { name: name, pkg: pkg, libs: libs, files: files, analysis: plan, issues: [] };
          step('Fixing ' + issues.length + ' problem' + (issues.length > 1 ? 's' : '') + ' found by the checker');
          var byFile = {}; issues.forEach(function (x) { (byFile[x.path] = byFile[x.path] || []).push('line ' + x.line + ': ' + x.message); });
          var fl = Object.keys(byFile).slice(0, 4), j = 0;
          function rep() { if (j >= fl.length) return Promise.resolve(); var p = fl[j++]; return ask(SYS_BASE + ' Output ONLY the corrected complete file content, no markdown fence.', 'File ' + p + ' has these problems:\n' + byFile[p].join('\n') + '\n\nCurrent content:\n' + files[p].slice(0, 12000) + '\n\nOther files in the project: ' + Object.keys(files).join(', ')).then(function (c) { files[p] = CS.stripFence(c) + '\n'; return rep(); }); }
          return rep().then(function () { return { name: name, pkg: pkg, libs: libs, files: files, analysis: plan, issues: CS.lint(files).filter(function (x) { return x.level === 'error'; }) }; });
        });
      });
    }
  };

  /* ======================= automatic fix engine ======================= */
  var BUILD_FILES = /(^|\/)(build\.gradle(\.kts)?|settings\.gradle(\.kts)?|gradle\.properties|AndroidManifest\.xml|proguard-rules\.pro)$/;
  var fix = CS.fix = {
    /** Ask the AI for a minimal correction. Returns a proposal {summary, risk, edits:[{path, find, replace}|{path, content}], reasons[]} or throws. */
    propose: function (p, files, err, attempt, previous) {
      var ask = CS.askFn(), c = err, ctxFiles = {};
      var add = function (path) { if (path && files[path] && Object.keys(ctxFiles).length < 3) ctxFiles[path] = files[path].slice(0, 9000); };
      add(c.file); if (c.category === 'dependency' || c.category === 'plugin' || c.category === 'dsl') { add('app/build.gradle.kts'); add('build.gradle.kts'); add('settings.gradle.kts'); } if (c.category === 'manifest') add('app/src/main/AndroidManifest.xml');
      if (!Object.keys(ctxFiles).length) add('app/build.gradle.kts');
      var sys = SYS_BASE + ' You repair build failures with the SMALLEST possible change. Reply with ONE JSON object: {"summary":"one sentence","risk":"minor"|"major","edits":[{"path":"...","find":"exact text that occurs once in the file","replace":"new text"}]}. ' +
        'Use "find"/"replace" for existing files. To create a missing file use {"path":"...","content":"..."}. Edit at most 3 files, never delete files, never touch anything unrelated to the error, never edit .github. Use "major" if you change the Gradle plugin versions, minSdk/compileSdk/targetSdk, add or remove many lines, or restructure the app.';
      var msg = 'Build error (' + c.title + '):\n' + c.summary + '\nFile: ' + (c.file || '(unknown)') + ' line ' + (c.line || '?') + '\n\nLog excerpt:\n' + c.excerpt + '\n\n' +
        Object.keys(ctxFiles).map(function (k) { return '--- ' + k + ' ---\n' + ctxFiles[k]; }).join('\n\n') + '\n\nAll project files: ' + Object.keys(files).join(', ') +
        (previous && previous.length ? '\n\nThese earlier fixes did not solve it (do not repeat them):\n' + previous.map(function (x) { return '- ' + x; }).join('\n') : '') + '\n\nAttempt ' + attempt + '.';
      return ask(sys, msg).then(function (t) { var pr = CS.jsonFrom(t); pr.edits = Array.isArray(pr.edits) ? pr.edits : []; return pr; });
    },
    /** Programmatic review: scope, uniqueness of "find", size, risk. Returns {ok, needsApproval, reasons[], changes:{path:newText}, diff:[...]} */
    review: function (files, err, pr) {
      var reasons = [], needs = pr.risk === 'major', changes = {}, diff = [], paths = {}, changed = 0;
      if (!pr.edits.length) return { ok: false, needsApproval: false, reasons: ['The AI proposed no change.'], changes: {}, diff: [] };
      if (pr.edits.length > 3) return { ok: false, needsApproval: false, reasons: ['The AI proposed too many edits (more than 3).'], changes: {}, diff: [] };
      for (var i = 0; i < pr.edits.length; i++) {
        var e = pr.edits[i], path = String(e.path || '');
        if (!CS.okRel(path)) return { ok: false, needsApproval: false, reasons: ['Path not allowed: ' + path], changes: {}, diff: [] };
        paths[path] = 1; var cur = files[path];
        var inScope = path === err.file || BUILD_FILES.test(path) || (err.excerpt || '').indexOf(path) >= 0 || (err.excerpt || '').indexOf(path.split('/').pop()) >= 0;
        if (!inScope) { needs = true; reasons.push('Touches a file the error does not mention: ' + path); }
        if (typeof e.content === 'string' && cur == null) { changes[path] = e.content; diff.push({ path: path, before: '', after: e.content, kind: 'new' }); changed += e.content.split('\n').length; needs = true; reasons.push('Creates a new file: ' + path); continue; }
        if (cur == null) return { ok: false, needsApproval: false, reasons: ['File does not exist: ' + path], changes: {}, diff: [] };
        if (typeof e.find !== 'string' || typeof e.replace !== 'string' || !e.find) return { ok: false, needsApproval: false, reasons: ['Malformed edit for ' + path], changes: {}, diff: [] };
        var base = changes[path] != null ? changes[path] : cur, n = base.split(e.find).length - 1;
        if (n !== 1) return { ok: false, needsApproval: false, reasons: ['Text to replace was found ' + n + ' times in ' + path + ' (must be exactly once).'], changes: {}, diff: [] };
        changes[path] = base.replace(e.find, function () { return e.replace; }); diff.push({ path: path, before: e.find, after: e.replace, kind: 'edit' }); changed += Math.max(e.find.split('\n').length, e.replace.split('\n').length);
        if (/(com\.android\.application|org\.jetbrains\.kotlin\.android)["']\)?\s*version|compileSdk|targetSdk|minSdk|distributionUrl/.test(e.find + e.replace)) { needs = true; reasons.push('Changes plugin or SDK versions'); }
      }
      if (changed > 40) { needs = true; reasons.push('Large change (' + changed + ' lines)'); }
      if (Object.keys(paths).length > 3) needs = true;
      Object.keys(changes).forEach(function (k) { if (changes[k].length > CS.LIMITS.file) { reasons.push('Result is too large: ' + k); } });
      var lintBefore = CS.lint(files).length, merged = Object.assign({}, files, changes), lintAfter = CS.lint(merged).filter(function (x) { return x.level === 'error'; });
      if (lintAfter.length > CS.lint(files).filter(function (x) { return x.level === 'error'; }).length) { return { ok: false, needsApproval: false, reasons: ['The change would add checker errors: ' + lintAfter[0].message], changes: {}, diff: [] }; }
      if (pr.risk === 'major') reasons.push('The AI marked this change as major');
      return { ok: true, needsApproval: needs, reasons: reasons, changes: changes, diff: diff };
    },
    /** Apply a reviewed proposal locally (after a restorable snapshot). */
    apply: function (p, files, rv, label) {
      return CS.files.snap(p.project_id, 'Before: ' + label, U.clone(files)).then(function (snap) { var nf = Object.assign({}, files, rv.changes); return CS.files.set(p.project_id, nf).then(function () { p.dirty = true; db.projects.touch(p); return db.save().then(function () { return { files: nf, snap: snap }; }); }); });
    },
    /** Put a snapshot back, locally and on GitHub. */
    rollback: function (p, snapId) {
      return Promise.all([CS.files.snaps(p.project_id), CS.files.get(p.project_id)]).then(function (a) {
        var sn = a[0].find(function (x) { return x.id === snapId; }); if (!sn) throw CS.Err('Snapshot not found', 'arg');
        return CS.files.snap(p.project_id, 'Before rollback', a[1]).then(function () { return CS.files.set(p.project_id, sn.files); }).then(function () { p.dirty = true; db.projects.touch(p); return db.save().then(function () { return sn.files; }); });
      });
    },
    /**
     * Build -> on failure classify -> propose -> review -> apply -> rebuild, up to cfg.retryLimit fixes.
     * ui = { onBuild(b), onProposal(rv, pr, err) -> Promise<boolean> (approval; called when needsApproval or autoApplyMinor is off), onStatus(msg) }
     */
    loop: function (p, kind, ui) {
      var limit = CS.cfg.v.retryLimit, tried = [], sigs = {}, attempt = 0, snaps = [];
      function run() {
        attempt++; ui.onStatus && ui.onStatus('Build attempt ' + attempt + ' of ' + (limit + 1));
        return CS.build.start(p, { kind: kind, attempt: attempt, fixChain: snaps.slice(), onUpdate: ui.onBuild }).then(function (b) {
          if (b.build_status === 'success') return { ok: true, build: b, attempts: attempt, snaps: snaps };
          var err = b.error || CS.classify('', b.annotations); if (b.build_status !== 'failed') return { ok: false, build: b, attempts: attempt, snaps: snaps, reason: 'Build ' + b.build_status };
          if (!err.fixable) return { ok: false, build: b, attempts: attempt, snaps: snaps, reason: err.title + ' cannot be fixed by changing code: ' + err.summary };
          if (attempt > limit) return { ok: false, build: b, attempts: attempt, snaps: snaps, reason: 'Retry limit reached (' + limit + ' fixes).' };
          if (sigs[err.signature]) return { ok: false, build: b, attempts: attempt, snaps: snaps, reason: 'The same error came back after the fix. Stopping so unrelated files are not changed.' };
          sigs[err.signature] = 1; ui.onStatus && ui.onStatus('Analyzing: ' + err.summary);
          return CS.files.get(p.project_id).then(function (files) {
            return fix.propose(p, files, err, attempt, tried).then(function (pr) {
              var rv = fix.review(files, err, pr);
              if (!rv.ok) { tried.push(pr.summary || 'invalid proposal'); return { ok: false, build: b, attempts: attempt, snaps: snaps, reason: 'Fix rejected by review: ' + rv.reasons.join('; ') }; }
              var ask = (rv.needsApproval || !CS.cfg.v.autoApplyMinor) ? (ui.onProposal ? ui.onProposal(rv, pr, err) : Promise.resolve(false)) : Promise.resolve(true);
              return ask.then(function (yes) {
                if (!yes) return { ok: false, build: b, attempts: attempt, snaps: snaps, reason: 'Fix not approved.' , proposal: { rv: rv, pr: pr } };
                tried.push(pr.summary || ''); ui.onStatus && ui.onStatus('Applying: ' + (pr.summary || 'fix'));
                return fix.apply(p, files, rv, pr.summary || 'AI fix').then(function (r) { snaps.push(r.snap.id); return run(); });
              });
            });
          });
        });
      }
      return run();
    }
  };

  /* ======================= previews ======================= */
  /** Combine an HTML entry with its css/js files into one document. Only returns text; it is run in the isolated native preview. */
  CS.preview = {
    htmlEntry: function (files) {
      var keys = Object.keys(files).filter(function (k) { return /\.html?$/i.test(k); });
      if (!keys.length) return null;
      var pref = ['index.html', 'web/index.html', 'app/src/main/assets/index.html', 'app/src/main/assets/www/index.html'], k = pref.find(function (x) { return files[x]; }) || keys[0];
      var dir = k.indexOf('/') >= 0 ? k.slice(0, k.lastIndexOf('/') + 1) : '', html = files[k], at = function (h) { h = String(h).replace(/^\.\//, ''); return files[dir + h] != null ? files[dir + h] : files[h]; };
      html = html.replace(/<link[^>]*href=["']([^"':]+\.css)["'][^>]*>/gi, function (m, h) { var c = at(h); return c != null ? '<style>' + c.replace(/<\/style/gi, '<\\/style') + '</style>' : m; });
      html = html.replace(/<script[^>]*src=["']([^"':]+\.js)["'][^>]*>\s*<\/script>/gi, function (m, h) { var c = at(h); return c != null ? '<script>' + c.replace(/<\/script/gi, '<\\/script') + '</script>' : m; });
      return { path: k, html: html };
    },
    /** Android layout XML -> static HTML approximation (NO scripts). A visual hint, not Android's renderer. */
    xmlToHtml: function (xmlText, files) {
      if (typeof DOMParser === 'undefined') return null; var d = new DOMParser().parseFromString(xmlText, 'application/xml'); if (d.getElementsByTagName('parsererror')[0]) return null;
      var res = {}; Object.keys(files || {}).forEach(function (k) { if (/res\/values[^/]*\/(strings|colors|dimens)\.xml$/.test(k)) files[k].replace(/<(string|color|dimen)\s+name="([^"]+)"[^>]*>([^<]*)</g, function (_, t, n, v) { res[t + '/' + n] = v; }); });
      var A = function (el, n) { return el.getAttributeNS('http://schemas.android.com/apk/res/android', n) || el.getAttribute('android:' + n) || ''; };
      var val = function (v) { v = String(v || ''); var m = /^@(string|color|dimen)\/(.+)$/.exec(v); return m ? (res[m[1] + '/' + m[2]] || '') : v; };
      var px = function (v) { v = val(v); var m = /^(-?[\d.]+)(dp|dip|sp|px)$/.exec(v); return m ? m[1] + 'px' : ''; };
      var sz = function (v, ax) { v = String(v || ''); return v === 'match_parent' || v === 'fill_parent' ? (ax === 'w' ? 'width:100%;' : 'height:100%;') : v === 'wrap_content' || !v ? '' : (px(v) ? (ax === 'w' ? 'width:' : 'height:') + px(v) + ';' : ''); };
      function node(el) {
        var t = el.localName, s = 'box-sizing:border-box;', kids = [].slice.call(el.children).map(node).join('');
        s += sz(A(el, 'layout_width'), 'w') + sz(A(el, 'layout_height'), 'h'); var pd = px(A(el, 'padding')); if (pd) s += 'padding:' + pd + ';'; var mg = px(A(el, 'layout_margin')); if (mg) s += 'margin:' + mg + ';';
        ['Top', 'Bottom', 'Start', 'End'].forEach(function (x) { var v = px(A(el, 'layout_margin' + x)); if (v) s += 'margin-' + ({ Top: 'top', Bottom: 'bottom', Start: 'left', End: 'right' })[x] + ':' + v + ';'; var q = px(A(el, 'padding' + x)); if (q) s += 'padding-' + ({ Top: 'top', Bottom: 'bottom', Start: 'left', End: 'right' })[x] + ':' + q + ';'; });
        var bg = val(A(el, 'background')); if (/^#[0-9a-f]{3,8}$/i.test(bg)) s += 'background:' + bg + ';'; var w = A(el, 'layout_weight'); if (w) s += 'flex:' + parseFloat(w) + ' 1 0;';
        var g = A(el, 'gravity'); if (/center_horizontal/.test(g)) s += 'align-items:center;'; if (/center_vertical/.test(g)) s += 'justify-content:center;'; if (g === 'center') s += 'align-items:center;justify-content:center;text-align:center;';
        var text = U.esc(val(A(el, 'text'))), hint = U.esc(val(A(el, 'hint'))), tc = val(A(el, 'textColor')), ts = px(A(el, 'textSize'));
        var tx = (/^#[0-9a-f]{3,8}$/i.test(tc) ? 'color:' + tc + ';' : '') + (ts ? 'font-size:' + ts + ';' : '') + (/bold/.test(A(el, 'textStyle')) ? 'font-weight:700;' : '');
        if (/LinearLayout$/.test(t)) return '<div style="display:flex;flex-direction:' + (A(el, 'orientation') === 'horizontal' ? 'row' : 'column') + ';' + s + '">' + kids + '</div>';
        if (/ScrollView$/.test(t)) return '<div style="overflow:auto;' + s + '">' + kids + '</div>';
        if (/(Constraint|Relative|Frame|Coordinator)Layout$/.test(t) || /^(androidx\.)?cardview|CardView$/.test(t)) { var card = /CardView$/.test(t); return '<div style="display:flex;flex-direction:column;gap:8px;' + s + (card ? 'border-radius:12px;box-shadow:0 1px 6px rgba(0,0,0,.25);background:#fff;' : '') + '">' + kids + '</div>'; }
        if (/Button$/.test(t)) return '<button style="' + s + tx + 'padding:8px 16px;border:0;border-radius:20px;background:#6750a4;color:#fff;font:inherit;">' + text + '</button>';
        if (/EditText$|TextInputEditText$/.test(t)) return '<input placeholder="' + hint + '" value="' + text + '" style="' + s + tx + 'border:0;border-bottom:1px solid #888;padding:8px;font:inherit;background:transparent;">';
        if (/ImageView$|ImageButton$/.test(t)) return '<div style="' + s + 'min-width:48px;min-height:48px;background:#c9c5d0;border-radius:6px;display:flex;align-items:center;justify-content:center;font-size:11px;color:#444;">image</div>';
        if (/CheckBox$|Switch$|RadioButton$|SwitchMaterial$/.test(t)) return '<label style="' + s + tx + '"><input type="' + (/Radio/.test(t) ? 'radio' : 'checkbox') + '"> ' + text + '</label>';
        if (/ProgressBar$/.test(t)) return '<progress style="' + s + '"></progress>';
        if (/RecyclerView$|ListView$/.test(t)) return '<div style="' + s + 'border:1px dashed #888;min-height:80px;padding:6px;font-size:12px;color:#666;">list (' + t + ')</div>';
        if (/TextView$/.test(t)) return '<div style="' + s + tx + '">' + text + '</div>';
        return '<div style="' + s + '">' + kids + '</div>';
      }
      var root = d.documentElement; if (!root) return null;
      return '<!doctype html><html><head><meta charset="utf-8"><meta http-equiv="Content-Security-Policy" content="default-src \'none\'; style-src \'unsafe-inline\'; img-src data:"><meta name="viewport" content="width=device-width,initial-scale=1"><style>html,body{margin:0;height:100%;font-family:Roboto,system-ui,sans-serif;background:#fff;color:#1c1b1f}body>div{min-height:100%}</style></head><body>' + node(root) + '</body></html>';
    }
  };

  /** The sample project is the starter scaffold, generated locally (no AI, no network). */
  CS.sampleProject = function () { return { name: 'Sample Hello', pkg: 'com.zenai.samplehello', files: CS.scaffold({ name: 'Sample Hello', pkg: 'com.zenai.samplehello' }) }; };

  /** Create a project record + working copy. */
  CS.newProject = function (o) {
    var slug = U.slug(o.name); if (db.mine('projects').some(function (x) { return x.slug === slug; })) slug = slug + '-' + U.rid('').slice(1, 4);
    var p = db.projects.create({ name: o.name, pkg: o.pkg, slug: slug, type: o.type || 'android-kotlin' });
    return CS.files.set(p.project_id, o.files).then(function () { return CS.files.snap(p.project_id, 'Created', U.clone(o.files)); }).then(function () { return db.save(); }).then(function () { return p; });
  };
})(typeof window !== 'undefined' ? window : globalThis);
