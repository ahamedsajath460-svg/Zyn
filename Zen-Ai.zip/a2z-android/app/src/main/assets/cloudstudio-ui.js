/* Zen AI Cloud Studio - interface (11 sections). Every button calls real code in cloudstudio-core.js / cloudstudio-gen.js
 * or shows exactly what setup is missing. Material 3 look, follows the page theme variables (light and dark). */
(function (W) {
  'use strict';
  var CS = W.CloudStudio; if (!CS || !CS.gen || CS.ui) return; CS.ui = 1;
  var U = CS.u, db = CS.db, esc = U.esc;
  var h = function (t, c, x) { var e = document.createElement(t); if (c) e.className = c; if (x != null) e.textContent = x; return e; };
  var say = function (m) { try { W.toast ? W.toast(m) : console.log(m); } catch (e) { } };

  var CSS = '.cs{--p:var(--acc,#6750a4);--op:var(--onacc,#fff);--s1:var(--side,#f3edf7);--tx:var(--ink,#1d1b20);--mu:var(--mut,#49454f);--ln:var(--line,#cac4d0);--bd:var(--bad,#b3261e);--ok:#2e7d32;font:14px/1.45 Roboto,system-ui,sans-serif;color:var(--tx);padding-bottom:40px}' +
    '@media(prefers-color-scheme:dark){.cs{--ok:#81c784}}[data-theme=dark] .cs{--ok:#81c784}[data-theme=light] .cs{--ok:#2e7d32}' +
    '.cs *{box-sizing:border-box}.cs h2{margin:0 0 4px;font-size:22px}.cs h3{margin:16px 0 8px;font-size:13px;letter-spacing:.08em;text-transform:uppercase;color:var(--mu)}.cs p{margin:6px 0}.cs small,.cs .mu{color:var(--mu)}' +
    '.cs-nav{display:flex;gap:6px;overflow-x:auto;padding:8px 0;margin:0 -2px;position:sticky;top:0;background:var(--bg,#fff);z-index:3;scrollbar-width:none}.cs-nav button{flex:none;border:1px solid var(--ln);background:transparent;color:var(--tx);border-radius:18px;padding:7px 13px;font:inherit;font-size:13px;cursor:pointer}.cs-nav button.on{background:var(--p);color:var(--op);border-color:var(--p)}' +
    '.cs-card{background:var(--s1);border:1px solid var(--ln);border-radius:16px;padding:14px;margin:10px 0}.cs-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:10px}.cs-tile{background:var(--s1);border:1px solid var(--ln);border-radius:14px;padding:12px}.cs-tile b{display:block;font-size:24px}.cs-tile span{color:var(--mu);font-size:12px}' +
    '.cs-b{border:0;background:var(--p);color:var(--op);border-radius:20px;padding:9px 16px;font:inherit;font-weight:500;cursor:pointer;margin:3px 4px 3px 0}.cs-b.o{background:transparent;color:var(--p);border:1px solid var(--ln)}.cs-b.d{background:var(--bd);color:#fff}.cs-b:disabled{opacity:.5}' +
    '.cs input,.cs textarea,.cs select{width:100%;background:var(--bg,#fff);color:var(--tx);border:1px solid var(--ln);border-radius:10px;padding:9px 11px;font:inherit;margin:4px 0 8px}.cs label{font-size:12px;color:var(--mu);display:block}.cs textarea{min-height:90px;resize:vertical}.cs input[type=checkbox]{width:auto;margin:0 8px 0 0}' +
    '.cs-bar{height:8px;border-radius:5px;background:var(--ln);overflow:hidden;margin:8px 0}.cs-bar i{display:block;height:100%;background:var(--p);transition:width .4s}' +
    '.cs-pill{display:inline-block;border-radius:10px;padding:1px 9px;font-size:12px;border:1px solid var(--ln)}.cs-pill.success{color:var(--ok);border-color:var(--ok)}.cs-pill.failed{color:var(--bd);border-color:var(--bd)}.cs-pill.running,.cs-pill.queued,.cs-pill.preparing{color:var(--p);border-color:var(--p)}' +
    '.cs-row{display:flex;gap:8px;align-items:center;flex-wrap:wrap}.cs-row>.g{flex:1;min-width:0}.cs-warn{border-left:4px solid #e6a100;background:rgba(230,161,0,.12);padding:8px 10px;border-radius:6px;margin:8px 0;font-size:13px}.cs-err{border-left:4px solid var(--bd);background:rgba(179,38,30,.1);padding:8px 10px;border-radius:6px;margin:8px 0;font-size:13px}' +
    '.cs pre.log{background:var(--code,#1e1e1e);color:var(--tx);border-radius:10px;padding:10px;font:11.5px/1.4 ui-monospace,Menlo,monospace;max-height:340px;overflow:auto;white-space:pre-wrap;word-break:break-word}' +
    '.cs-ed{display:flex;gap:8px}.cs-files{flex:0 0 38%;max-height:420px;overflow:auto;border:1px solid var(--ln);border-radius:10px;font-size:12px}.cs-files div{padding:6px 8px;cursor:pointer;border-bottom:1px solid var(--ln);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.cs-files div.on{background:var(--p);color:var(--op)}.cs-files div i{font-style:normal;color:var(--bd)}' +
    '.cs-ew{position:relative;flex:1;min-width:0;height:420px;border:1px solid var(--ln);border-radius:10px;overflow:hidden;background:var(--code,#1e1e1e)}.cs-ew pre,.cs-ew textarea,.cs-ew .mk{position:absolute;inset:0;margin:0;padding:8px 10px 8px 10px;font:12.5px/18px ui-monospace,Menlo,monospace;tab-size:4;white-space:pre;overflow:auto;border:0;border-radius:0;width:100%;height:100%}' +
    '.cs-ew pre{pointer-events:none;color:var(--tx);overflow:hidden}.cs-ew textarea{background:transparent;color:transparent;caret-color:var(--tx);resize:none;outline:0;min-height:0}.cs-ew .mk{pointer-events:none;overflow:hidden;padding:0}.cs-ew .mk div{position:absolute;left:0;right:0;height:18px;background:rgba(179,38,30,.28);border-left:3px solid var(--bd)}.cs-ew .mk div.w{background:rgba(230,161,0,.22);border-color:#e6a100}' +
    '.t-k{color:#c678dd}.t-s{color:#98c379}.t-c{color:#7f848e;font-style:italic}.t-n{color:#d19a66}.t-t{color:#e06c75}.t-a{color:#d19a66}.t-m{color:#61afef}' +
    '[data-theme=light] .t-k{color:#8e24aa}[data-theme=light] .t-s{color:#2e7d32}[data-theme=light] .t-c{color:#757575}[data-theme=light] .t-n{color:#b45309}[data-theme=light] .t-t{color:#c62828}[data-theme=light] .t-m{color:#1565c0}' +
    '.cs-dim{position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:9999;display:flex;align-items:flex-end;justify-content:center}.cs-md{background:var(--bg,#fff);color:var(--tx);width:min(560px,100%);max-height:88vh;overflow:auto;border-radius:22px 22px 0 0;padding:18px}.cs-df{font:11.5px/1.4 ui-monospace,monospace;white-space:pre-wrap;word-break:break-word;border-radius:8px;padding:8px;margin:4px 0}.cs-df.a{background:rgba(46,125,50,.16)}.cs-df.r{background:rgba(179,38,30,.16)}' +
    '@media(max-width:560px){.cs-ed{flex-direction:column}.cs-files{flex:none;max-height:130px}}' +
    '.cs-dev{margin:8px auto;border:10px solid #222;border-radius:26px;overflow:hidden;background:#fff}.cs-dev iframe{border:0;width:100%;height:100%;display:block}.cs-shots{display:flex;gap:8px;overflow-x:auto}.cs-shots img{height:260px;border-radius:10px;border:1px solid var(--ln)}';

  var KW = { kt: 'abstract|as|break|by|catch|class|companion|const|constructor|continue|data|do|else|enum|false|final|finally|for|fun|if|import|in|init|inline|interface|internal|is|lateinit|lazy|null|object|open|operator|out|override|package|private|protected|public|return|sealed|super|suspend|this|throw|true|try|typealias|val|var|when|while',
    java: 'abstract|boolean|break|byte|case|catch|char|class|continue|default|do|double|else|enum|extends|false|final|finally|float|for|if|implements|import|instanceof|int|interface|long|new|null|package|private|protected|public|return|short|static|super|switch|this|throw|throws|true|try|void|while', js: 'async|await|break|case|catch|class|const|continue|default|else|export|false|finally|for|function|if|import|in|let|new|null|return|switch|this|throw|true|try|typeof|var|while' };
  function lang(p) { var e = (/\.([a-z0-9]+)$/i.exec(p) || [])[1] || ''; e = e.toLowerCase(); return e === 'kts' || e === 'gradle' ? 'kt' : e === 'htm' ? 'html' : e === 'svg' ? 'xml' : e; }
  function hl(t, lg) {
    var rx;
    if (lg === 'xml' || lg === 'html') rx = /(<!--[\s\S]*?-->)|(<\/?[A-Za-z][\w:.-]*)|("[^"]*"|'[^']*')|([\w:.-]+(?==))|(\/?>)/g;
    else if (lg === 'json') rx = /("(?:\\.|[^"\\])*"(?=\s*:))|("(?:\\.|[^"\\])*")|(-?\d+\.?\d*(?:[eE][+-]?\d+)?)|(\btrue\b|\bfalse\b|\bnull\b)/g;
    else if (lg === 'css') rx = /(\/\*[\s\S]*?\*\/)|("[^"]*"|'[^']*')|([.#]?[\w-]+(?=\s*[{,]))|([\w-]+(?=\s*:))|(#[0-9a-fA-F]{3,8}\b|-?\d+\.?\d*(?:px|em|rem|%|vh|vw)?)/g;
    else { var kw = KW[lg] || KW.kt; rx = new RegExp('(\\/\\/[^\\n]*|\\/\\*[\\s\\S]*?\\*\\/)|("""[\\s\\S]*?"""|"(?:\\\\.|[^"\\\\\\n])*"|\'(?:\\\\.|[^\'\\\\\\n])*\'|`(?:\\\\.|[^`\\\\])*`)|(@\\w+)|\\b(' + kw + ')\\b|(\\b\\d+\\.?\\d*[fFLxX]?\\b)', 'g'); }
    var o = '', i = 0, m;
    while ((m = rx.exec(t))) {
      o += esc(t.slice(i, m.index)); var cls;
      if (lg === 'xml' || lg === 'html') cls = m[1] ? 't-c' : m[2] ? 't-t' : m[3] ? 't-s' : m[4] ? 't-a' : 't-t';
      else if (lg === 'json') cls = m[1] ? 't-t' : m[2] ? 't-s' : m[3] ? 't-n' : 't-k';
      else if (lg === 'css') cls = m[1] ? 't-c' : m[2] ? 't-s' : m[3] ? 't-t' : m[4] ? 't-a' : 't-n';
      else cls = m[1] ? 't-c' : m[2] ? 't-s' : m[3] ? 't-m' : m[4] ? 't-k' : 't-n';
      o += '<span class="' + cls + '">' + esc(m[0]) + '</span>'; i = m.index + m[0].length; if (m[0].length === 0) rx.lastIndex++;
    }
    return o + esc(t.slice(i)) + '\n';
  }
  CS.highlight = hl;

  function miniDiff(a, b) { a = String(a).split('\n'); b = String(b).split('\n'); var s = 0; while (s < a.length && s < b.length && a[s] === b[s]) s++; var e = 0; while (e < a.length - s && e < b.length - s && a[a.length - 1 - e] === b[b.length - 1 - e]) e++; return { del: a.slice(s, a.length - e).join('\n'), add: b.slice(s, b.length - e).join('\n'), at: s + 1 }; }
  function modal(title, body, btns) {   // btns: [[label, cls, fn]] ; returns close()
    var dim = h('div', 'cs-dim'), md = h('div', 'cs-md cs'); md.appendChild(h('h2', '', title)); if (typeof body === 'string') md.appendChild(h('p', '', body)); else md.appendChild(body);
    var r = h('div', 'cs-row'); (btns || []).forEach(function (b) { var x = h('button', 'cs-b ' + (b[1] || ''), b[0]); x.onclick = function () { dim.remove(); b[2] && b[2](); }; r.appendChild(x); }); md.appendChild(r); dim.appendChild(md); dim.onclick = function (e) { if (e.target === dim) dim.remove(); }; document.body.appendChild(dim); return function () { dim.remove(); };
  }
  function confirm(title, msg, yes, cls) { return new Promise(function (res) { modal(title, msg, [['Cancel', 'o', function () { res(false); }], [yes || 'OK', cls || '', function () { res(true); }]]); }); }
  function diffView(rv) { var box = h('div'); rv.diff.forEach(function (d) { box.appendChild(h('small', '', d.path)); if (d.before) box.appendChild(h('div', 'cs-df r', d.before.slice(0, 1500))); box.appendChild(h('div', 'cs-df a', d.after.slice(0, 2500))); }); return box; }
  function busy(b, fn) { if (b.disabled) return; var t = b.textContent; b.disabled = true; b.textContent = 'Working…'; return Promise.resolve().then(fn).catch(function (e) { say(e.message || String(e)); modal('Could not finish', e.message || String(e), [['OK']]); }).then(function () { b.disabled = false; b.textContent = t; }); }
  function field(label, el) { var d = h('div'); d.appendChild(h('label', '', label)); d.appendChild(el); return d; }
  function input(v, ph, type) { var i = h('input'); i.value = v == null ? '' : v; if (ph) i.placeholder = ph; if (type) i.type = type; return i; }
  function pill(s) { return h('span', 'cs-pill ' + s, s); }
  function ago(t) { if (!t) return ''; var s = Math.round((Date.now() - t) / 1000); return s < 90 ? s + 's ago' : s < 5400 ? Math.round(s / 60) + ' min ago' : s < 129600 ? Math.round(s / 3600) + ' h ago' : Math.round(s / 86400) + ' d ago'; }

  var SECS = [['overview', 'Overview'], ['creator', 'AI App Creator'], ['projects', 'My Projects'], ['workspace', 'Code Workspace'], ['sdk', 'Android SDK'], ['build', 'Build Center'], ['preview', 'Live Preview'], ['device', 'Virtual Device'], ['apk', 'APK Manager'], ['history', 'Build History'], ['settings', 'Cloud Settings']];

  function cloudTool(w) {
    if (!document.getElementById('cs-css')) { var st = h('style'); st.id = 'cs-css'; st.textContent = CSS; document.head.appendChild(st); }
    var root = h('div', 'cs'), nav = h('div', 'cs-nav'), box = h('div'), S = { sec: 'overview', pid: '', file: '', buildId: '' }, cleanups = [];
    root.append(h('h2', '', 'Zen AI Cloud Studio'), h('small', 'mu', 'AI writes the app. GitHub Actions builds it in the cloud. Nothing is compiled or run on this phone.'), nav, box); w.appendChild(root);
    SECS.forEach(function (s) { var b = h('button', '', s[1]); b.dataset.s = s[0]; b.onclick = function () { go(s[0]); }; nav.appendChild(b); });
    function go(s) { S.sec = s; cleanups.forEach(function (f) { try { f(); } catch (e) { } }); cleanups = []; [].forEach.call(nav.children, function (b) { b.classList.toggle('on', b.dataset.s === s); }); box.innerHTML = ''; try { VIEWS[s](box); } catch (e) { box.appendChild(h('div', 'cs-err', 'Screen error: ' + e.message)); } }
    var project = function () { return db.projects.get(S.pid) || db.projects.list()[0] || null; };
    function projectPicker(onChange) { var sel = h('select'); db.projects.list().forEach(function (p) { var o = h('option', '', p.project_name); o.value = p.project_id; sel.appendChild(o); }); var cur = project(); if (cur) sel.value = cur.project_id; S.pid = cur ? cur.project_id : ''; sel.onchange = function () { S.pid = sel.value; S.file = ''; onChange && onChange(); }; return sel; }
    function setupGate() {
      var msgs = []; if (!CS.nativeOk()) msgs.push('Cloud Studio needs the Zen AI Android app (this page is not running inside it).'); else { if (!CS.token.has()) msgs.push('GitHub token not saved.'); if (!CS.repoParts()) msgs.push('GitHub repository not chosen.'); }
      if (!msgs.length) return null; var c = h('div', 'cs-warn'); c.append(h('b', '', 'Setup required: '), document.createTextNode(msgs.join(' '))); var b = h('button', 'cs-b o', 'Open Cloud Settings'); b.onclick = function () { go('settings'); }; c.appendChild(b); return c;
    }
    function needProject(into) { if (project()) return true; into.appendChild(h('div', 'cs-card', 'No project yet. Create one in AI App Creator (or make the sample project).')); var b = h('button', 'cs-b', 'Go to AI App Creator'); b.onclick = function () { go('creator'); }; into.appendChild(b); return false; }

    var VIEWS = {};
    /* ---------- 1 Overview ---------- */
    VIEWS.overview = function (b) {
      var g = setupGate(); if (g) b.appendChild(g);
      var bs = db.builds.list(), ok = bs.filter(function (x) { return x.build_status === 'success'; }).length, bad = bs.filter(function (x) { return x.build_status === 'failed'; }).length, arts = db.artifacts.list().filter(function (a) { return /^(debug|release|unsigned)$/.test(a.kind); });
      var grid = h('div', 'cs-grid'); [[db.projects.list().length, 'Active projects'], [bs.length, 'Total builds'], [ok, 'Successful builds'], [bad, 'Failed builds'], [arts.length, 'Recent APKs']].forEach(function (t) { var d = h('div', 'cs-tile'); d.append(h('b', '', t[0]), h('span', '', t[1])); grid.appendChild(d); });
      var cloud = h('div', 'cs-tile'), cb = h('b', '', '…'); cloud.append(cb, h('span', '', 'Cloud build status')); grid.appendChild(cloud);
      var sto = h('div', 'cs-tile'), sb = h('b', '', '–'); sto.append(sb, h('span', '', 'Storage usage')); grid.appendChild(sto); var ac = h('div', 'cs-tile'), ab = h('b', '', '–'); ac.append(ab, h('span', '', 'GitHub Actions usage')); grid.appendChild(ac); b.appendChild(grid);
      var note = h('p', 'mu'); b.appendChild(note);
      if (!g) { CS.runs.active().then(function (a) { cb.textContent = a.length ? a.length + ' running' : 'Idle'; }).catch(function (e) { cb.textContent = 'Error'; note.textContent = e.message; });
        CS.usage.get().then(function (u) { sb.textContent = U.bytes(u.storageBytes); sto.lastChild.textContent = 'Storage of ' + U.bytes(u.storageLimit); ab.textContent = u.private ? u.minutes + ' / ' + u.limit + ' min' : 'Public: free'; note.textContent = u.note; }).catch(function (e) { ab.textContent = 'n/a'; note.textContent = 'Usage could not be read: ' + e.message; }); }
      b.appendChild(h('h3', '', 'Recent builds')); bs.slice(0, 5).forEach(function (x) { var r = h('div', 'cs-card cs-row'); var p = db.projects.get(x.project_id); r.append(h('span', 'g', (p ? p.project_name : '?') + ' · ' + x.build_type + ' · ' + ago(x.started_at)), pill(x.build_status)); r.onclick = function () { S.buildId = x.build_id; go('history'); }; b.appendChild(r); }); if (!bs.length) b.appendChild(h('p', 'mu', 'No builds yet.'));
    };

    /* ---------- 2 AI App Creator ---------- */
    VIEWS.creator = function (b) {
      var g = setupGate(); if (g) b.appendChild(g);
      var pr = h('textarea'); pr.placeholder = 'Describe the app, e.g. "A to-do list app with categories, saved offline, dark theme."'; var nm = input('', 'App name (optional)'), pk = input('', 'Package, e.g. com.me.todo (optional)'), log = h('div', 'mu');
      b.append(field('What should the app do?', pr), field('Name', nm), field('Package name', pk));
      var go1 = h('button', 'cs-b', 'Generate with AI'), go2 = h('button', 'cs-b o', 'Create sample project (no AI)'); b.append(go1, go2, log);
      b.appendChild(h('p', 'mu', 'The AI plans the app, then writes each Kotlin / XML file. Gradle files come from a tested template. A checker then looks for missing layouts, strings and broken XML. Nothing is built until you press Build.'));
      go1.onclick = function () { busy(go1, function () {
        if (pr.value.trim().length < 8) throw CS.Err('Describe the app in a few words first.');
        var steps = []; return CS.creator.generate({ prompt: pr.value, name: nm.value.trim(), pkg: pk.value.trim(), onStep: function (s) { steps.push(s); log.textContent = s + '…'; } }).then(function (o) {
          return CS.newProject({ name: o.name, pkg: o.pkg, files: o.files }).then(function (p) { S.pid = p.project_id; log.textContent = ''; if (o.issues.length) modal('Created, with warnings', 'The project was created but the checker still reports ' + o.issues.length + ' problem(s), e.g. ' + o.issues[0].message + '. Open it in Code Workspace to review.', [['Open workspace', '', function () { go('workspace'); }]]); else { say('Project created: ' + o.name); go('workspace'); } }); }); }); };
      go2.onclick = function () { busy(go2, function () { var s = CS.sampleProject(); return CS.newProject({ name: s.name, pkg: s.pkg, files: s.files }).then(function (p) { S.pid = p.project_id; say('Sample project created'); go('workspace'); }); }); };
    };

    /* ---------- 3 My Projects ---------- */
    VIEWS.projects = function (b) {
      var ps = db.projects.list(); if (!ps.length) b.appendChild(h('p', 'mu', 'No projects yet.'));
      ps.forEach(function (p) {
        var c = h('div', 'cs-card'); c.append(h('b', '', p.project_name), h('div', 'mu', p.package_name + ' · branch ' + p.branch + ' · ' + ago(p.updated_at) + (p.dirty ? ' · not pushed' : '')));
        var open = h('button', 'cs-b', 'Open'), bd = h('button', 'cs-b o', 'Build debug'), pull = h('button', 'cs-b o', 'Pull from GitHub'), del = h('button', 'cs-b d', 'Delete');
        open.onclick = function () { S.pid = p.project_id; go('workspace'); }; bd.onclick = function () { S.pid = p.project_id; go('build'); };
        pull.onclick = function () { busy(pull, function () { return CS.git.pull(p).then(function (f) { if (!Object.keys(f).length) throw CS.Err('Nothing found on branch ' + p.branch + ' under cloud-projects/' + p.slug + '/'); return CS.files.snap(p.project_id, 'Before pull', null).catch(function () { }).then(function () { return CS.files.set(p.project_id, f); }).then(function () { p.dirty = false; return db.save(); }).then(function () { say('Pulled ' + Object.keys(f).length + ' files'); }); }); }); };
        del.onclick = function () { confirm('Delete project?', 'Deletes "' + p.project_name + '" and its build records from this phone. Files on GitHub (branch ' + p.branch + ') stay until you delete the branch there.', 'Delete', 'd').then(function (y) { if (!y) return; db.projects.remove(p.project_id); CS.store.del('files:' + CS.ns() + ':' + p.project_id); db.save().then(function () { go('projects'); }); }); };
        c.append(open, bd, pull, del); b.appendChild(c);
      });
      b.appendChild(h('h3', '', 'Add an existing project from GitHub'));
      var sl = input('', 'folder name inside cloud-projects/'), br = input('', 'branch (default cloud/<folder>)'), add = h('button', 'cs-b o', 'Import'); b.append(sl, br, add);
      add.onclick = function () { busy(add, function () { var slug = sl.value.trim(); if (!/^[A-Za-z0-9._-]{3,60}$/.test(slug)) throw CS.Err('Enter the folder name under cloud-projects/.'); var p = db.projects.create({ name: slug, pkg: '', slug: slug }); if (br.value.trim()) p.branch = br.value.trim();
        return CS.git.pull(p).then(function (f) { if (!Object.keys(f).length) { db.d.projects = db.d.projects.filter(function (x) { return x !== p; }); throw CS.Err('No files found at cloud-projects/' + slug + ' on branch ' + p.branch); } var m = /namespace\s*=\s*"([\w.]+)"/.exec(f['app/build.gradle.kts'] || ''); p.package_name = m ? m[1] : ''; p.dirty = false; return CS.files.set(p.project_id, f).then(function () { return db.save(); }).then(function () { S.pid = p.project_id; say('Imported ' + Object.keys(f).length + ' files'); go('workspace'); }); }); }); };
    };

    /* ---------- 4 Code Workspace ---------- */
    VIEWS.workspace = function (b) {
      if (!needProject(b)) return; var pick = projectPicker(function () { go('workspace'); }); b.appendChild(pick); var p = project(), files = {}, cur = S.file, timer = 0, marks = [];
      var list = h('div', 'cs-files'), ew = h('div', 'cs-ew'), pre = h('pre'), mk = h('div', 'mk'), ta = h('textarea'), info = h('div', 'mu'), tb = h('div', 'cs-row'), ed = h('div', 'cs-ed'); ta.spellcheck = false; ta.setAttribute('autocapitalize', 'off'); ta.setAttribute('autocomplete', 'off'); ew.append(pre, mk, ta); ed.append(list, ew);
      function tbtn(l, fn, c) { var x = h('button', 'cs-b ' + (c || 'o'), l); x.onclick = function () { busy(x, fn); }; tb.appendChild(x); }
      var save = function () { return CS.files.set(p.project_id, files).then(function () { p.dirty = true; db.projects.touch(p); return db.save(); }); };
      var errLines = function () { var o = {}; var bs = db.builds.list(p.project_id)[0]; var all = CS.lint(files).slice(); if (bs && bs.build_status === 'failed') { if (bs.error && bs.error.file) all.push({ path: bs.error.file, line: bs.error.line || 1, message: bs.error.summary, level: 'error' }); (bs.annotations || []).forEach(function (a) { if (a.path) all.push({ path: a.path.replace(/^cloud-projects\/[^/]+\//, ''), line: a.line || 1, message: a.message, level: 'error' }); }); } all.forEach(function (x) { (o[x.path] = o[x.path] || []).push(x); }); return o; };
      function drawList() { list.innerHTML = ''; var er = errLines(); Object.keys(files).sort().forEach(function (k) { var d = h('div', cur === k ? 'on' : '', k.replace(/^app\/src\/main\//, '…/')); d.title = k; if (er[k]) d.appendChild(h('i', '', ' ●')); d.onclick = function () { open(k); }; list.appendChild(d); }); }
      function paint() { pre.innerHTML = hl(ta.value, lang(cur)); pre.scrollTop = ta.scrollTop; pre.scrollLeft = ta.scrollLeft; mk.innerHTML = ''; var er = (errLines()[cur] || []); er.forEach(function (x) { var d = h('div', x.level === 'warning' ? 'w' : ''); d.style.top = (8 + (x.line - 1) * 18 - ta.scrollTop) + 'px'; d.title = x.message; mk.appendChild(d); }); info.textContent = cur ? (cur + ' · ' + ta.value.split('\n').length + ' lines' + (er.length ? ' · ' + er[0].message : '')) : 'Choose a file'; }
      function open(k) { cur = S.file = k; ta.value = files[k] == null ? '' : files[k]; ta.disabled = false; drawList(); paint(); }
      ta.addEventListener('scroll', function () { pre.scrollTop = ta.scrollTop; pre.scrollLeft = ta.scrollLeft; paint(); });
      ta.addEventListener('keydown', function (e) { if (e.key === 'Tab') { e.preventDefault(); var s = ta.selectionStart; ta.value = ta.value.slice(0, s) + '    ' + ta.value.slice(ta.selectionEnd); ta.selectionStart = ta.selectionEnd = s + 4; ta.dispatchEvent(new Event('input')); } });
      ta.addEventListener('input', function () { if (!cur) return; files[cur] = ta.value; paint(); clearTimeout(timer); timer = setTimeout(save, 700); });
      cleanups.push(function () { clearTimeout(timer); if (cur && files[cur] != null) save(); });
      tbtn('New file', function () { var i = input('', 'path, e.g. app/src/main/res/layout/item.xml'); return new Promise(function (res) { modal('New file', field('Path inside the project', i), [['Cancel', 'o', res], ['Create', '', function () { var k = i.value.trim(); if (!CS.okRel(k)) { say('That path is not allowed.'); return res(); } if (files[k] != null) { say('File exists'); return res(); } files[k] = ''; save().then(function () { open(k); res(); }); }]]); }); });
      tbtn('Rename', function () { if (!cur) return; var i = input(cur); return new Promise(function (res) { modal('Rename file', field('New path', i), [['Cancel', 'o', res], ['Rename', '', function () { var k = i.value.trim(); if (!CS.okRel(k) || files[k] != null) { say('Path not allowed or already exists'); return res(); } files[k] = files[cur]; delete files[cur]; cur = S.file = k; save().then(function () { drawList(); paint(); res(); }); }]]); }); });
      tbtn('Delete', function () { if (!cur) return; return confirm('Delete file?', 'Delete ' + cur + '? You can restore it from History.', 'Delete', 'd').then(function (y) { if (!y) return; return CS.files.snap(p.project_id, 'Before deleting ' + cur, U.clone(files)).then(function () { delete files[cur]; cur = S.file = ''; ta.value = ''; return save(); }).then(function () { drawList(); paint(); }); }); });
      tbtn('Find / replace', function () { var f = input('', 'find'), r = input('', 'replace with'), out = h('div', 'mu'), box2 = h('div'); box2.append(field('Find', f), field('Replace', r), out); var run = function (all, doIt) { var q = f.value; if (!q) return 0; var n = 0, ks = all ? Object.keys(files) : [cur]; ks.forEach(function (k) { if (files[k] == null) return; var c = files[k].split(q).length - 1; if (c) { n += c; if (doIt) files[k] = files[k].split(q).join(r.value); } }); return n; };
        return new Promise(function (res) { modal('Find and replace', box2, [['Close', 'o', res], ['Count in project', 'o', function () { say(run(true, false) + ' matches in the project'); res(); }], ['Replace in file', '', function () { var n = run(false, true); if (cur) ta.value = files[cur]; save().then(function () { paint(); say(n + ' replaced'); res(); }); }], ['Replace in project', 'd', function () { var n = run(true, true); if (cur) ta.value = files[cur]; save().then(function () { paint(); drawList(); say(n + ' replaced'); res(); }); }]]); }); });
      tbtn('AI edit', function () { if (!cur) { say('Open a file first'); return; } var ins = h('textarea'); ins.placeholder = 'What should change in this file?'; return new Promise(function (res) { modal('AI code edit', field(cur, ins), [['Cancel', 'o', res], ['Ask AI', '', function () { var ask; try { ask = CS.askFn(); } catch (e) { say(e.message); return res(); } say('Asking AI…');
        ask('You edit one file of an Android project. Output ONLY the complete new content of the file, no explanation, no markdown fence. Keep everything that is not part of the request unchanged.', 'File: ' + cur + '\nRequest: ' + ins.value + '\n\nCurrent content:\n' + ta.value.slice(0, 30000) + '\n\nOther files: ' + Object.keys(files).join(', ')).then(function (t) { var nt = CS.stripFence(t) + '\n', d = miniDiff(ta.value, nt), v = h('div'); v.append(h('small', '', 'Changed from line ' + d.at), h('div', 'cs-df r', d.del.slice(0, 1500) || '(nothing removed)'), h('div', 'cs-df a', d.add.slice(0, 2500) || '(nothing added)'));
          modal('Apply this change?', v, [['Reject', 'o'], ['Apply', '', function () { CS.files.snap(p.project_id, 'Before AI edit of ' + cur, U.clone(files)).then(function () { files[cur] = nt; ta.value = nt; return save(); }).then(paint); }]]); }).catch(function (e) { say(e.message); }); res(); }]]); }); });
      tbtn('History', function () { return CS.files.snaps(p.project_id).then(function (s) { var v = h('div'); if (!s.length) v.textContent = 'No versions yet.'; s.forEach(function (x) { var r = h('div', 'cs-row'); r.append(h('span', 'g', x.label + ' · ' + ago(x.t)), (function () { var q = h('button', 'cs-b o', 'Restore'); q.onclick = function () { CS.fix.rollback(p, x.id).then(function (f) { say('Restored'); go('workspace'); }).catch(function (e) { say(e.message); }); }; return q; })()); v.appendChild(r); }); modal('Project history', v, [['Close']]); }); });
      tbtn('Push to GitHub', function () { return CS.git.push(p, files, 'Zen AI Cloud Studio: edit ' + new Date().toISOString().slice(0, 16)).then(function (r) { return db.save().then(function () { say(r.changed ? 'Pushed ' + r.changed + ' file(s)' : 'Already up to date'); }); }); }, '');
      b.append(tb, info, ed);
      CS.files.get(p.project_id).then(function (f) { files = f; drawList(); if (cur && files[cur] != null) open(cur); else { ta.disabled = true; paint(); var first = Object.keys(files).find(function (k) { return /MainActivity/.test(k); }); if (first) open(first); } });
    };

    /* ---------- 5 Android SDK ---------- */
    VIEWS.sdk = function (b) {
      b.appendChild(h('p', '', 'The Android SDK is installed on the GitHub cloud runner for every build, never on this phone. Pick extra packages here; the build workflow installs them with sdkmanager (licences accepted) next to the platform your project needs.'));
      if (!needProject(b)) return; b.appendChild(projectPicker(function () { go('sdk'); })); var p = project(); p.sdk = p.sdk || [];
      CS.files.get(p.project_id).then(function (f) { var g = f['app/build.gradle.kts'] || '', cs = /compileSdk\s*=\s*(\d+)/.exec(g); b.insertBefore(h('div', 'cs-card', 'Project compileSdk: ' + (cs ? cs[1] : '?') + ' · installed automatically as platforms;android-' + (cs ? cs[1] : '34') + ' with build-tools;34.0.0 and platform-tools.'), b.children[2]); });
      b.appendChild(h('h3', '', 'Extra packages for the next builds'));
      [['platforms;android-33', 'Android 13 platform'], ['platforms;android-35', 'Android 15 platform'], ['build-tools;35.0.0', 'Build tools 35.0.0'], ['ndk;26.1.10909125', 'NDK 26.1 (native code, large download)'], ['cmake;3.22.1', 'CMake 3.22.1']].forEach(function (x) {
        var r = h('label'), c = h('input'); c.type = 'checkbox'; c.checked = p.sdk.indexOf(x[0]) >= 0; c.onchange = function () { p.sdk = p.sdk.filter(function (y) { return y !== x[0]; }); if (c.checked) p.sdk.push(x[0]); db.save(); }; r.append(c, document.createTextNode(x[1] + '  (' + x[0] + ')')); r.style.margin = '8px 0'; b.appendChild(r); });
      var chk = h('button', 'cs-b', 'Install and verify now (debug build)'); b.appendChild(chk); b.appendChild(h('p', 'mu', 'This runs a real debug build; the build summary on GitHub lists the installed SDK packages. Result appears in Build Center and Build History.')); chk.onclick = function () { go('build'); };
    };

    /* ---------- 6 Build Center ---------- */
    VIEWS.build = function (b) {
      var g = setupGate(); if (g) b.appendChild(g); if (!needProject(b)) return; b.appendChild(projectPicker(function () { go('build'); })); var p = project();
      var bar = h('div', 'cs-bar'), fill = h('i'); bar.appendChild(fill); var stat = h('div', 'mu'), res = h('div'), logBox = h('div'), act = h('div', 'cs-row');
      var af = h('input'); af.type = 'checkbox'; af.checked = !!CS.cfg.v.retryLimit; var afl = h('label'); afl.append(af, document.createTextNode('Auto-fix errors with AI (up to ' + CS.cfg.v.retryLimit + ' fixes, minor fixes applied automatically, major ones ask you)')); afl.style.margin = '6px 0';
      var cur = null, running = false;
      function onUpdate(x) { cur = x; var pc = x.progress.total ? Math.round(100 * x.progress.done / x.progress.total) : (x.build_status === 'success' ? 100 : 5); fill.style.width = pc + '%'; stat.innerHTML = ''; stat.append(pill(x.build_status), document.createTextNode(' ' + (x.progress.step || '') + (x.guard ? ' · ' + x.guard : ''))); }
      function approve(rv, pr, err) { var v = h('div'); v.append(h('p', '', pr.summary || 'AI fix'), h('small', 'mu', rv.reasons.join(' · ')), diffView(rv)); return new Promise(function (r) { modal('Approve this fix?', v, [['Reject', 'o', function () { r(false); }], ['Apply and rebuild', '', function () { r(true); }]]); }); }
      function finish(b2) { res.innerHTML = ''; logBox.innerHTML = ''; if (!b2) return; var c = h('div', b2.build_status === 'success' ? 'cs-card' : 'cs-err'); c.append(h('b', '', b2.build_status === 'success' ? 'Build succeeded' : 'Build ' + b2.build_status), h('div', '', b2.summary || '')); res.appendChild(c);
        if (b2.build_status === 'success' && b2.build_type !== 'test') { var k = h('button', 'cs-b', 'Open APK Manager'); k.onclick = function () { go('apk'); }; res.appendChild(k); } if (b2.build_status === 'success' && b2.build_type === 'test') { var k2 = h('button', 'cs-b', 'Open Virtual Device results'); k2.onclick = function () { go('device'); }; res.appendChild(k2); }
        if (b2.error && /keystore|CLOUD_/i.test(b2.error.excerpt + b2.summary)) res.appendChild(h('div', 'cs-warn', 'Release signing is not set up. Add the CLOUD_* secrets listed in the Setup guide (Cloud Settings).'));
        CS.logs.get(b2.build_id).then(function (t) { if (!t) return; var lb = h('button', 'cs-b o', 'Show build log'); lb.onclick = function () { logBox.innerHTML = ''; logBox.appendChild(h('pre', 'log', t.slice(-60000).replace(/^\d{4}-\d\d-\d\dT[\d:.]+Z /gm, ''))); }; res.appendChild(lb); });
        if (b2.build_status === 'failed' && b2.error && b2.error.fixable) { var fb = h('button', 'cs-b', 'Fix with AI and rebuild'); fb.onclick = function () { start(b2.build_type, true, true); }; res.appendChild(fb); } }
      function start(kind, autofix, askAll) { if (running) return say('A build is already being followed here.'); var chk = setupGate(); if (chk) return say('Finish the setup in Cloud Settings first.'); running = true; res.innerHTML = ''; logBox.innerHTML = ''; fill.style.width = '3%';
        var opts = { sdkPackages: (p.sdk || []).join(' ') }; var pr;
        if (autofix) { var saved = CS.cfg.v.autoApplyMinor; if (askAll) CS.cfg.v.autoApplyMinor = false; pr = CS.fix.loop(p, kind, { onBuild: onUpdate, onStatus: function (m) { stat.textContent = m; }, onProposal: approve }).then(function (r) { CS.cfg.v.autoApplyMinor = saved; if (!r.ok) say(r.reason || 'Build did not succeed'); if (r.snaps && r.snaps.length) res.appendChild(h('div', 'cs-card', 'AI changed the project ' + r.snaps.length + ' time(s). Undo: Code Workspace > History.')); return r.build; }).catch(function (e) { CS.cfg.v.autoApplyMinor = saved; throw e; }); }
        else pr = CS.build.start(p, { kind: kind, onUpdate: onUpdate, sdkPackages: opts.sdkPackages });
        pr.then(finish).catch(function (e) { stat.textContent = ''; res.innerHTML = ''; res.appendChild(h('div', 'cs-err', e.message)); say(e.message); }).then(function () { running = false; act.querySelector('.cx').style.display = 'none'; }); act.querySelector('.cx').style.display = ''; }
      [['Build debug APK', 'debug'], ['Build release APK', 'release'], ['Test on emulator', 'test']].forEach(function (x) { var k = h('button', 'cs-b' + (x[1] === 'debug' ? '' : ' o'), x[0]); k.onclick = function () { if (x[1] === 'release') confirm('Build a release APK?', 'Builds unsigned in the cloud, then signs it with YOUR key from GitHub secrets (CLOUD_KEYSTORE_*). Without those secrets the signing step fails with a clear message.', 'Build').then(function (y) { if (y) start('release', af.checked); }); else start(x[1], af.checked && x[1] !== 'test'); }; act.appendChild(k); });
      var cx = h('button', 'cs-b d cx', 'Cancel build'); cx.style.display = 'none'; cx.onclick = function () { if (cur) CS.build.cancel(cur.build_id).then(function () { say('Cancelling…'); }).catch(function (e) { say(e.message); }); }; act.appendChild(cx);
      b.append(afl, act, bar, stat, res, logBox);
      var last = db.builds.list(p.project_id)[0]; if (last && last.build_status !== 'running') { onUpdate(last); finish(last); }
    };

    /* ---------- 7 Live Preview ---------- */
    VIEWS.preview = function (b) {
      if (!needProject(b)) return; b.appendChild(projectPicker(function () { go('preview'); })); var p = project(); b.appendChild(h('div', 'cs-warn', 'Visual preview only. This is NOT an Android emulator: it shows HTML/CSS/JS in a browser engine, and an approximate drawing of XML layouts. Use Virtual Device for a real Android run.'));
      var sel = h('select'), size = h('select'), view = h('div'), btns = h('div', 'cs-row'); [['360', 'Phone 360'], ['412', 'Phone 412'], ['768', 'Tablet 768'], ['1280', 'Desktop 1280']].forEach(function (x) { var o = h('option', '', x[1]); o.value = x[0]; size.appendChild(o); });
      CS.files.get(p.project_id).then(function (f) { var ks = Object.keys(f).filter(function (k) { return /\.html?$/i.test(k) || /res\/layout[^/]*\/[^/]+\.xml$/.test(k); }); if (!ks.length) { view.appendChild(h('p', 'mu', 'This project has no HTML file and no layout XML to preview.')); return; } ks.forEach(function (k) { var o = h('option', '', k.replace(/^app\/src\/main\//, '…/')); o.value = k; sel.appendChild(o); });
        function show() { view.innerHTML = ''; var k = sel.value, w2 = +size.value; if (/\.xml$/.test(k)) { var html = CS.preview.xmlToHtml(f[k], f); if (!html) { view.appendChild(h('div', 'cs-err', 'This XML is not valid, so it cannot be drawn.')); return; } var d = h('div', 'cs-dev'), fr = h('iframe'); fr.setAttribute('sandbox', ''); fr.srcdoc = html; var sc = Math.min(1, (root.clientWidth - 40) / w2); d.style.width = w2 * sc + 'px'; d.style.height = Math.min(640, w2 * 1.9) * sc + 'px'; fr.style.cssText = 'width:' + w2 + 'px;height:' + Math.min(640, w2 * 1.9) + 'px;transform:scale(' + sc + ');transform-origin:0 0'; d.appendChild(fr); view.append(d, h('small', 'mu', 'Static drawing from the layout XML (no code runs).')); }
          else { var e = CS.preview.htmlEntry(f), run = h('button', 'cs-b', 'Open isolated preview'); view.appendChild(h('p', 'mu', 'HTML runs in a separate sandbox window with no network and no access to Zen AI data: ' + (e ? e.path : k))); run.onclick = function () { if (!CS.nativeOk()) return say('Needs the Zen AI app'); var r = W.A2ZCloud.openPreview(p.project_name, e.html, w2 > 400 ? w2 : 0); if (r !== 'ok') say(r === 'too_big' ? 'Page is too large to preview' : 'Preview could not open'); }; view.appendChild(run); } }
        sel.onchange = size.onchange = show; show(); }); b.append(field('File', sel), field('Screen size', size), view);
    };

    /* ---------- 8 Virtual Device ---------- */
    VIEWS.device = function (b) {
      var g = setupGate(); if (g) b.appendChild(g);
      b.appendChild(h('div', 'cs-warn', 'What this is: a REAL Android emulator on a GitHub runner that installs your app, launches it, runs a random UI test, restarts it, and returns screenshots, logcat and a crash report. What it is NOT: a live, touchable, streamed device. GitHub Actions cannot stream one. Needs a runner with KVM (works on public repositories).'));
      if (!needProject(b)) return; b.appendChild(projectPicker(function () { go('device'); })); var p = project();
      var api = h('select'); ['34', '33', '30'].forEach(function (x) { var o = h('option', '', 'Android API ' + x); o.value = x; api.appendChild(o); }); api.value = CS.cfg.v.emulatorApi; var ev = input(CS.cfg.v.uiEvents, 'UI events', 'number'); b.append(field('Virtual device', api), field('Random UI events (50-2000)', ev));
      var run = h('button', 'cs-b', 'Run emulator test'), out = h('div'); b.append(run, out);
      var st2 = h('div', 'mu'); b.appendChild(st2);
      run.onclick = function () { busy(run, function () { return CS.cfg.save({ emulatorApi: api.value, uiEvents: Math.max(50, Math.min(2000, +ev.value || 300)) }).then(function () { return CS.build.start(p, { kind: 'test', sdkPackages: (p.sdk || []).join(' '), onUpdate: function (x) { st2.textContent = x.build_status + ' · ' + (x.progress.step || ''); } }); }).then(function (r) { say('Emulator test ' + r.build_status); go('device'); }); }); };
      var tests = db.builds.list(p.project_id).filter(function (x) { return x.build_type === 'test'; }); if (!tests.length) out.appendChild(h('p', 'mu', 'No emulator test has run for this project yet.'));
      tests.slice(0, 3).forEach(function (t) { var c = h('div', 'cs-card'); c.append(h('b', '', 'Test ' + ago(t.started_at) + ' '), pill(t.build_status)); var art = db.artifacts.forBuild(t.build_id).find(function (a) { return a.kind === 'emulator'; });
        if (art) { var v = h('button', 'cs-b o', 'Load screenshots and logcat'); v.onclick = function () { busy(v, function () { return CS.apk.reports(art).then(function (fs) { var wrap = h('div'), sh = h('div', 'cs-shots'); fs.filter(function (f2) { return f2.b64 && /\.png$/.test(f2.name); }).forEach(function (f2) { var im = h('img'); im.src = 'data:image/png;base64,' + f2.b64; im.alt = f2.name; sh.appendChild(im); }); var crash = fs.find(function (f2) { return f2.name === 'crash-report.txt'; }), lc = fs.find(function (f2) { return f2.name === 'logcat.txt'; }); wrap.appendChild(sh); wrap.appendChild(h('div', crash && crash.text && crash.text.trim() ? 'cs-err' : 'cs-card', crash && crash.text && crash.text.trim() ? 'Crash report:\n' + crash.text.slice(0, 1500) : 'No crash detected.')); if (lc && lc.text) wrap.appendChild(h('pre', 'log', lc.text.slice(-20000))); c.appendChild(wrap); v.remove(); }); }); }; c.appendChild(v); } b.appendChild(c); });
      b.appendChild(h('h3', '', 'Live streamed device (optional, external)')); b.appendChild(h('p', 'mu', 'For a touchable remote device you need an external emulator service (for example a hosted device-streaming provider or your own server). Zen AI does not include or pay for one. Save its address in Cloud Settings; it opens in your browser, outside Zen AI, with no access to your data.'));
      var u = CS.cfg.v.externalEmulatorUrl; if (/^https:\/\//.test(u)) { var o = h('button', 'cs-b o', 'Open external emulator'); o.onclick = function () { confirm('Open external site?', u + '\n\nThis service is not part of Zen AI.', 'Open').then(function (y) { if (y) W.open(u, '_blank'); }); }; b.appendChild(o); } else b.appendChild(h('small', 'mu', 'No external emulator service configured.'));
    };

    /* ---------- 9 APK Manager ---------- */
    VIEWS.apk = function (b) {
      var arts = db.artifacts.list().filter(function (a) { return /^(debug|release|unsigned)$/.test(a.kind); }); if (!arts.length) b.appendChild(h('p', 'mu', 'No APKs yet. Build one in Build Center.'));
      arts.forEach(function (a) { var bd = db.builds.get(a.build_id), p = bd && db.projects.get(bd.project_id), c = h('div', 'cs-card'), exp = a.expiration_time && a.expiration_time < Date.now();
        c.append(h('b', '', (p ? p.project_name : 'Project') + ' · ' + ({ debug: 'Debug (debug key)', release: 'Release (signed)', unsigned: 'Release (UNSIGNED)' })[a.kind]), h('div', 'mu', (a.file_name || '') + ' · ' + U.bytes(a.file_size) + ' · built ' + (bd ? new Date(bd.completed_at || bd.started_at).toLocaleString() : '') + (a.expiration_time ? ' · ' + (exp ? 'EXPIRED on GitHub' : 'available until ' + new Date(a.expiration_time).toLocaleDateString()) : '')));
        if (a.checksum) c.appendChild(h('div', 'mu', 'Package ' + (a.package || '?') + ' · v' + (a.versionName || '?') + ' (' + (a.versionCode || '?') + ')\nSHA-256 ' + a.checksum + (a.certSha256 ? '\nSigning certificate SHA-256 ' + a.certSha256 : '') + '\nSaved: ' + a.storage_location)); c.lastChild.style.whiteSpace = 'pre-wrap'; c.lastChild.style.wordBreak = 'break-all';
        var dl = h('button', 'cs-b', a.checksum ? 'Download again' : 'Download'), sh = h('button', 'cs-b o', 'Share…'), rm = h('button', 'cs-b o', 'Delete from GitHub');
        if (a.kind === 'unsigned') c.appendChild(h('div', 'cs-warn', 'Unsigned APKs cannot be installed. Use "Build release APK" to sign it.'));
        dl.onclick = function () { busy(dl, function () { return CS.apk.download(a).then(function (x) { say('Saved to ' + x.storage_location); go('apk'); }); }); };
        sh.onclick = function () { if (!a.checksum) return say('Download it first.'); confirm('Share this APK?', 'You are about to hand ' + a.file_name + ' to another app or person. Zen AI never shares APKs by itself. Only share files you trust.', 'Choose where to share').then(function (y) { if (y) say(W.A2ZCloud.shareApk(a.file_name) === 'ok' ? 'Opening share sheet' : 'File not found. Download again.'); }); };
        rm.onclick = function () { confirm('Delete APK on GitHub?', 'Removes this build artifact from your repository storage.', 'Delete', 'd').then(function (y) { if (y) busy(rm, function () { return CS.apk.remove(a).then(function () { go('apk'); }); }); }); };
        c.append(dl, sh, rm); b.appendChild(c); });
      b.appendChild(h('p', 'mu', 'Downloads are authenticated: the token stays in the phone\'s secure storage and the artifact is fetched through GitHub\'s short-lived signed address. Files are saved in Downloads/Zen Ai/Cloud Studio. To install, open the file from your Files app (Android asks you to allow installs from that app). Expiring public links need an external link service, see Setup.'));
    };

    /* ---------- 10 Build History ---------- */
    VIEWS.history = function (b) {
      var top = h('div', 'cs-row'), cl = h('button', 'cs-b o', 'Clean up old artifacts'); cl.onclick = function () { busy(cl, function () { return CS.cleanup().then(function (n) { say(n + ' old artifacts deleted'); }); }); }; top.appendChild(cl); b.appendChild(top);
      var bs = db.builds.list(); if (!bs.length) b.appendChild(h('p', 'mu', 'No builds yet.'));
      bs.forEach(function (x) { var p = db.projects.get(x.project_id), c = h('div', 'cs-card'), r = h('div', 'cs-row'); r.append(h('b', 'g', (p ? p.project_name : '?') + ' · ' + x.build_type + (x.attempt > 1 ? ' #' + x.attempt : '')), pill(x.build_status)); c.append(r, h('div', 'mu', ago(x.started_at) + (x.duration ? ' · ' + x.duration + ' s' : '') + ' · ' + (x.summary || '')));
        var det = h('div'); c.appendChild(det); var open = S.buildId === x.build_id;
        function expand() { det.innerHTML = ''; var lg = h('button', 'cs-b o', 'Build log'), rt = h('button', 'cs-b o', 'Retry'), gh = h('button', 'cs-b o', 'Open on GitHub'); lg.onclick = function () { CS.logs.get(x.build_id).then(function (t) { det.appendChild(h('pre', 'log', (t || 'No log stored for this build.').slice(-60000).replace(/^\d{4}-\d\d-\d\dT[\d:.]+Z /gm, ''))); }); }; rt.onclick = function () { S.pid = x.project_id; go('build'); }; gh.onclick = function () { if (x.html_url) W.open(x.html_url, '_blank'); }; det.append(lg, rt, gh); if (x.error) det.appendChild(h('div', 'cs-err', x.error.title + ' — ' + x.error.summary + (x.error.file ? '\n' + x.error.file + ':' + x.error.line : ''))); }
        c.onclick = function (e) { if (e.target.tagName === 'BUTTON' || e.target.tagName === 'PRE') return; if (!det.children.length) expand(); }; if (open) expand(); b.appendChild(c); });
    };

    /* ---------- 11 Cloud Settings ---------- */
    VIEWS.settings = function (b) {
      var c = CS.cfg.v;
      b.appendChild(h('h3', '', '1 · GitHub token'));
      b.appendChild(h('p', 'mu', 'Create a fine-grained token on github.com (Settings > Developer settings > Personal access tokens) for ONE repository with: Contents = read and write, Actions = read and write, Metadata = read. Nothing else. It is stored encrypted in the Android Keystore and never shown again or sent anywhere except api.github.com.'));
      var tk = input('', CS.token.has() ? 'Token saved (hidden). Paste a new one to replace it.' : 'github_pat_…', 'password'), sv = h('button', 'cs-b', 'Save and test token'), rm = h('button', 'cs-b o', 'Remove token'); b.append(tk, sv, rm);
      sv.onclick = function () { busy(sv, function () { return CS.token.set(tk.value).then(function (u) { tk.value = ''; say('Connected as ' + u.login); go('settings'); }); }); }; rm.onclick = function () { CS.token.clear(); say('Token removed'); go('settings'); };
      b.appendChild(h('h3', '', '2 · Repository'));
      var rp = input(c.repo, 'owner/name'), tr = h('button', 'cs-b', 'Save and test repository'), out = h('div'); b.append(rp, tr, out);
      tr.onclick = function () { busy(tr, function () { return CS.cfg.save({ repo: rp.value.trim() }).then(function () { return CS.git.repo(); }).then(function (r) { var q = CS.repoParts(); return Promise.all(['cloud-android-build.yml', 'cloud-android-debug.yml', 'cloud-android-release.yml', 'cloud-android-test.yml', 'cloud-android-cleanup.yml'].map(function (f) { return CS.gh('GET', q.path + '/contents/.github/workflows/' + f + '?ref=' + encodeURIComponent(r.default_branch)).then(function (x) { return [f, x.ok]; }); })).then(function (m) { out.innerHTML = ''; out.appendChild(h('div', 'cs-card', 'Repository ' + r.full_name + ' (' + (r.private ? 'private' : 'public') + '), default branch ' + r.default_branch)); m.forEach(function (x) { out.appendChild(h('div', x[1] ? 'mu' : 'cs-err', (x[1] ? '✓ ' : '✗ missing on ' + r.default_branch + ': ') + '.github/workflows/' + x[0])); }); }); }); }); };
      b.appendChild(h('h3', '', '3 · Limits and defaults'));
      var f = { retryLimit: input(c.retryLimit, '', 'number'), maxActive: input(c.maxActive, '', 'number'), monthlyMinutes: input(c.monthlyMinutes, '', 'number'), storageLimitMB: input(c.storageLimitMB, '', 'number'), retentionDays: input(c.retentionDays, '', 'number'), gradleVersion: input(c.gradleVersion), externalEmulatorUrl: input(c.externalEmulatorUrl, 'https://… (optional)') };
      [['retryLimit', 'Automatic fix attempts per build (0-6)'], ['maxActive', 'Cloud builds allowed at the same time (1-3)'], ['monthlyMinutes', 'Monthly Actions minutes you allow (private repos)'], ['storageLimitMB', 'Artifact storage you allow (MB)'], ['retentionDays', 'Keep APKs on GitHub (days, 1-30)'], ['gradleVersion', 'Gradle version for cloud builds'], ['externalEmulatorUrl', 'External emulator service address']].forEach(function (x) { b.appendChild(field(x[1], f[x[0]])); });
      var am = h('input'); am.type = 'checkbox'; am.checked = c.autoApplyMinor; var aml = h('label'); aml.append(am, document.createTextNode('Apply small AI fixes automatically (major changes always ask)')); b.appendChild(aml);
      var sl = h('button', 'cs-b', 'Save limits'); b.appendChild(sl); sl.onclick = function () { var patch = { autoApplyMinor: am.checked }; Object.keys(f).forEach(function (k) { patch[k] = k === 'gradleVersion' || k === 'externalEmulatorUrl' ? f[k].value.trim() : +f[k].value; }); if (!/^\d+\.\d+(\.\d+)?$/.test(patch.gradleVersion)) return say('Gradle version looks like 8.7'); if (patch.externalEmulatorUrl && !/^https:\/\//.test(patch.externalEmulatorUrl)) return say('The emulator address must start with https://'); CS.cfg.save(patch).then(function () { say('Saved'); }); };
      b.appendChild(h('h3', '', 'Costs and limits (read this)')); b.appendChild(h('p', 'mu', 'Free first: public repositories get free standard GitHub-hosted runners; private ones get a monthly allowance (about 2000 minutes and 500 MB of artifacts on the Free plan). Zen AI shows an estimate, checks it before every build and stops when your limit is reached. Zen AI never switches on paid services. Emulator tests use many minutes. GitHub deletes artifacts after the retention days you choose.'));
    };

    go('overview');
    CS.init().then(function () { go(S.sec); });
  }

  try { if (typeof ALL !== 'undefined' && !ALL.find(function (x) { return x.id === 'cloudstudio'; })) ALL.push({ id: 'cloudstudio', cat: 'create', name: 'Zen AI Cloud Studio', desc: 'AI builds real Android apps in the cloud (GitHub Actions)', icon: 'kcd', run: cloudTool, manual: 1 }); } catch (e) { }
  CS.open = cloudTool;
})(typeof window !== 'undefined' ? window : globalThis);
