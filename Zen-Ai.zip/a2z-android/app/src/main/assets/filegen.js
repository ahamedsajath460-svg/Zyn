/* Zen Ai file generator: builds real Word, Excel, PowerPoint, PDF and PNG files on the device.
 * No library and no internet are needed. The chat model writes plain text (Markdown / CSV / SVG) inside a fenced
 * block whose file name ends in .docx .xlsx .pptx .pdf .png .jpg; the app turns that text into the real file.
 * Public API: window.ZenGen = { isBin, build, zip, preview, icon, label, mime }  (also module.exports for tests). */
(function (root) {
  'use strict';
  var te = new TextEncoder();
  var MIME = {
    docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    pptx: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    pdf: 'application/pdf', png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', webp: 'image/webp'
  };
  var LABEL = { docx: 'Word document', xlsx: 'Excel spreadsheet', pptx: 'PowerPoint', pdf: 'PDF document', png: 'PNG image', jpg: 'JPEG image', jpeg: 'JPEG image', webp: 'WebP image' };
  var extOf = function (n) { return String(n || '').split('.').pop().toLowerCase(); };
  var isBin = function (n) { return Object.prototype.hasOwnProperty.call(MIME, extOf(n)) && String(n || '').indexOf('.') > 0; };

  /* ---------- helpers ---------- */
  var esc = function (s) {
    return String(s == null ? '' : s).replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f￾￿]/g, '')
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  };
  var XML = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n';

  /* ---------- zip (store only, bytes) ---------- */
  var CRCT = (function () { var t = new Uint32Array(256); for (var n = 0; n < 256; n++) { var c = n; for (var k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
  function crc32(u) { var c = 0xFFFFFFFF; for (var i = 0; i < u.length; i++) c = CRCT[(c ^ u[i]) & 255] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; }
  function zipBlob(files, mime) {
    var parts = [], cd = [], d = new Date(), off = 0;
    var dt = ((Math.max(d.getFullYear(), 1980) - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate();
    var tm = (d.getHours() << 11) | (d.getMinutes() << 5) | (d.getSeconds() >> 1);
    files.forEach(function (f) {
      var nm = te.encode(f.name), data = typeof f.data === 'string' ? te.encode(f.data) : f.data, crc = crc32(data);
      var h = new DataView(new ArrayBuffer(30));
      h.setUint32(0, 0x04034b50, true); h.setUint16(4, 20, true); h.setUint16(6, 0x0800, true); h.setUint16(10, tm, true); h.setUint16(12, dt, true);
      h.setUint32(14, crc, true); h.setUint32(18, data.length, true); h.setUint32(22, data.length, true); h.setUint16(26, nm.length, true);
      parts.push(new Uint8Array(h.buffer), nm, data);
      var c = new DataView(new ArrayBuffer(46));
      c.setUint32(0, 0x02014b50, true); c.setUint16(4, 20, true); c.setUint16(6, 20, true); c.setUint16(8, 0x0800, true); c.setUint16(12, tm, true); c.setUint16(14, dt, true);
      c.setUint32(16, crc, true); c.setUint32(20, data.length, true); c.setUint32(24, data.length, true); c.setUint16(28, nm.length, true); c.setUint32(42, off, true);
      cd.push(new Uint8Array(c.buffer), nm); off += 30 + nm.length + data.length;
    });
    var cs = 0; cd.forEach(function (x) { cs += x.length; });
    var e = new DataView(new ArrayBuffer(22));
    e.setUint32(0, 0x06054b50, true); e.setUint16(8, files.length, true); e.setUint16(10, files.length, true); e.setUint32(12, cs, true); e.setUint32(16, off, true);
    return new Blob(parts.concat(cd, [new Uint8Array(e.buffer)]), { type: mime || 'application/zip' });
  }

  /* ---------- Markdown parser (shared by Word, PowerPoint, PDF) ---------- */
  function inl(s, base) {
    base = base || {};
    s = String(s).replace(/<br\s*\/?>/gi, ' ');
    var out = [], re = /\*\*\*(.+?)\*\*\*|\*\*(.+?)\*\*|\*(?![\s*])(.+?)(?<![\s*])\*|~~(.+?)~~|`([^`]+)`|\[([^\]]+)\]\(([^)\s]+)\)/g, last = 0, m;
    var plain = function (t) { if (t) out.push(Object.assign({}, base, { t: t.replace(/\\([*_`~\[\]#|\\>-])/g, '$1') })); };
    while ((m = re.exec(s))) {
      plain(s.slice(last, m.index));
      if (m[1] != null) out.push.apply(out, inl(m[1], Object.assign({}, base, { b: 1, i: 1 })));
      else if (m[2] != null) out.push.apply(out, inl(m[2], Object.assign({}, base, { b: 1 })));
      else if (m[3] != null) out.push.apply(out, inl(m[3], Object.assign({}, base, { i: 1 })));
      else if (m[4] != null) out.push.apply(out, inl(m[4], Object.assign({}, base, { s: 1 })));
      else if (m[5] != null) out.push(Object.assign({}, base, { t: m[5], c: 1 }));
      else if (m[6] != null) { out.push.apply(out, inl(m[6], base)); if (/^https?:/i.test(m[7]) && m[6].trim() !== m[7]) out.push(Object.assign({}, base, { t: ' (' + m[7] + ')' })); }
      last = m.index + m[0].length;
    }
    plain(s.slice(last));
    return out;
  }
  var SEP = /^\s*\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?\s*$/;
  var splitRow = function (s) {
    s = s.trim().replace(/^\|/, '').replace(/\|$/, '');
    return s.split(/(?<!\\)\|/).map(function (c) { return c.trim().replace(/\\\|/g, '|'); });
  };
  function parseMd(src) {
    var L = String(src == null ? '' : src).replace(/\r\n?/g, '\n').replace(/\t/g, '    ').split('\n'), out = [], i = 0, m;
    var starter = function (s) { return /^\s*(`{3,}|~{3,}|#{1,6}\s|>|[-*•+]\s|\d+[.)]\s|\|)/.test(s) || /^\s*([-*_])(\s*\1){2,}\s*$/.test(s); };
    while (i < L.length) {
      var s = L[i];
      if ((m = s.match(/^\s*(`{3,}|~{3,})/))) {
        var fc = m[1][0], fn = m[1].length, b = [], cl = new RegExp('^\\s*' + (fc === '`' ? '`' : '~') + '{' + fn + ',}\\s*$');
        i++; while (i < L.length && !cl.test(L[i])) b.push(L[i++]); i++;
        out.push({ t: 'code', text: b.join('\n') }); continue;
      }
      if (!s.trim()) { i++; continue; }
      if ((m = s.match(/^(#{1,6})\s+(.*?)\s*#*\s*$/))) { out.push({ t: 'h', l: Math.min(m[1].length, 3), r: inl(m[2]) }); i++; continue; }
      if (/^\s*([-*_])(\s*\1){2,}\s*$/.test(s)) { out.push({ t: 'hr' }); i++; continue; }
      if (/^\s*\|/.test(s) || (s.indexOf('|') > 0 && L[i + 1] && SEP.test(L[i + 1]) && L[i + 1].indexOf('-') >= 0)) {
        var rows = [], head = false;
        while (i < L.length && L[i].trim() && L[i].indexOf('|') >= 0) {
          if (SEP.test(L[i]) && L[i].indexOf('-') >= 0) { if (rows.length === 1) head = true; i++; continue; }
          rows.push(splitRow(L[i]).map(function (c) { return inl(c); })); i++;
        }
        var w = 0; rows.forEach(function (r) { w = Math.max(w, r.length); });
        rows.forEach(function (r) { while (r.length < w) r.push([]); });
        if (rows.length) out.push({ t: 'table', rows: rows, head: head || rows.length > 1 });
        continue;
      }
      if ((m = s.match(/^(\s*)([-*•+]|\d+[.)])\s+(.*)$/))) {
        var txt = m[3], ck = txt.match(/^\[([ xX])\]\s+(.*)$/);
        if (ck) txt = (ck[1] === ' ' ? '☐ ' : '☑ ') + ck[2];
        out.push({ t: 'li', lvl: Math.min(2, Math.floor(m[1].length / 2)), ord: /\d/.test(m[2]), n: parseInt(m[2], 10) || 1, r: inl(txt) }); i++; continue;
      }
      if (/^\s*>/.test(s)) {
        var q = []; while (i < L.length && /^\s*>/.test(L[i])) q.push(L[i++].replace(/^\s*>\s?/, ''));
        out.push({ t: 'q', r: inl(q.join(' ')) }); continue;
      }
      var p = [s.trim()]; i++;
      while (i < L.length && L[i].trim() && !starter(L[i])) p.push(L[i++].trim());
      out.push({ t: 'p', r: inl(p.join(' ')) });
    }
    return out;
  }
  var plainOf = function (runs) { return (runs || []).map(function (r) { return r.t; }).join(''); };

  /* ============================== DOCX ============================== */
  var WNS = 'xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"';
  function wRuns(runs, o) {
    o = o || {};
    return runs.map(function (r) {
      var p = '';
      if (r.c) p += '<w:rFonts w:ascii="Consolas" w:hAnsi="Consolas" w:cs="Consolas"/>';
      if (r.b || o.b) p += '<w:b/><w:bCs/>';
      if (r.i || o.i) p += '<w:i/><w:iCs/>';
      if (r.s) p += '<w:strike/>';
      if (o.color) p += '<w:color w:val="' + o.color + '"/>';
      if (r.c) p += '<w:sz w:val="20"/><w:szCs w:val="20"/><w:shd w:val="clear" w:color="auto" w:fill="F2F2F2"/>';
      return '<w:r>' + (p ? '<w:rPr>' + p + '</w:rPr>' : '') + '<w:t xml:space="preserve">' + esc(r.t) + '</w:t></w:r>';
    }).join('');
  }
  function buildDocx(text) {
    var blocks = parseMd(text), body = [], nums = [], curOrd = 0, nextNum = 2;
    var para = function (runs, pp, o) { return '<w:p>' + (pp ? '<w:pPr>' + pp + '</w:pPr>' : '') + wRuns(runs, o) + '</w:p>'; };
    blocks.forEach(function (b) {
      if (b.t !== 'li' || !b.ord) { if (b.t !== 'li') curOrd = 0; }
      if (b.t === 'h') body.push(para(b.r, '<w:pStyle w:val="Heading' + b.l + '"/>'));
      else if (b.t === 'p') body.push(para(b.r, ''));
      else if (b.t === 'li') {
        var id = 1;
        if (b.ord) { if (!curOrd) { curOrd = nextNum++; nums.push(curOrd); } id = curOrd; } else curOrd = 0;
        body.push(para(b.r, '<w:pStyle w:val="ListParagraph"/><w:numPr><w:ilvl w:val="' + b.lvl + '"/><w:numId w:val="' + id + '"/></w:numPr>'));
      }
      else if (b.t === 'q') body.push(para(b.r, '<w:pStyle w:val="Quote"/>'));
      else if (b.t === 'hr') body.push('<w:p><w:pPr><w:pBdr><w:bottom w:val="single" w:sz="6" w:space="1" w:color="A6A6A6"/></w:pBdr></w:pPr></w:p>');
      else if (b.t === 'code') {
        var ls = b.text.split('\n');
        ls.forEach(function (l, k) { body.push('<w:p><w:pPr><w:pStyle w:val="CodeBlock"/>' + (k === ls.length - 1 ? '<w:spacing w:after="160"/>' : '') + '</w:pPr><w:r><w:t xml:space="preserve">' + esc(l) + '</w:t></w:r></w:p>'); });
      }
      else if (b.t === 'table') {
        var n = b.rows[0].length, tw = 9026, cw = Math.floor(tw / n);
        var x = '<w:tbl><w:tblPr><w:tblStyle w:val="TableGrid"/><w:tblW w:w="' + tw + '" w:type="dxa"/><w:tblBorders>' +
          ['top', 'left', 'bottom', 'right', 'insideH', 'insideV'].map(function (k) { return '<w:' + k + ' w:val="single" w:sz="4" w:space="0" w:color="BFBFBF"/>'; }).join('') +
          '</w:tblBorders><w:tblLayout w:type="fixed"/><w:tblCellMar><w:top w:w="60" w:type="dxa"/><w:left w:w="100" w:type="dxa"/><w:bottom w:w="60" w:type="dxa"/><w:right w:w="100" w:type="dxa"/></w:tblCellMar></w:tblPr><w:tblGrid>';
        for (var g = 0; g < n; g++) x += '<w:gridCol w:w="' + cw + '"/>';
        x += '</w:tblGrid>';
        b.rows.forEach(function (row, ri) {
          var hd = b.head && ri === 0;
          x += '<w:tr>' + (hd ? '<w:trPr><w:tblHeader/></w:trPr>' : '');
          row.forEach(function (cell) {
            x += '<w:tc><w:tcPr><w:tcW w:w="' + cw + '" w:type="dxa"/>' + (hd ? '<w:shd w:val="clear" w:color="auto" w:fill="D9E2F3"/>' : '') + '</w:tcPr>' +
              para(cell.length ? cell : [{ t: '' }], '<w:spacing w:before="0" w:after="0"/>', { b: hd }) + '</w:tc>';
          });
          x += '</w:tr>';
        });
        body.push(x + '</w:tbl>', '<w:p><w:pPr><w:spacing w:after="0"/></w:pPr></w:p>');
      }
    });
    if (!body.length) body.push('<w:p/>');
    var doc = XML + '<w:document ' + WNS + '><w:body>' + body.join('') +
      '<w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1440" w:right="1440" w:bottom="1440" w:left="1440" w:header="708" w:footer="708" w:gutter="0"/></w:sectPr></w:body></w:document>';
    var hs = function (id, name, sz, before) {
      return '<w:style w:type="paragraph" w:styleId="Heading' + id + '"><w:name w:val="heading ' + id + '"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/>' +
        '<w:pPr><w:keepNext/><w:keepLines/><w:spacing w:before="' + before + '" w:after="120"/><w:outlineLvl w:val="' + (id - 1) + '"/></w:pPr>' +
        '<w:rPr><w:b/><w:bCs/><w:color w:val="1F3864"/><w:sz w:val="' + sz + '"/><w:szCs w:val="' + sz + '"/></w:rPr></w:style>';
    };
    var styles = XML + '<w:styles ' + WNS + '><w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="Calibri" w:hAnsi="Calibri" w:eastAsia="Calibri" w:cs="Nirmala UI"/><w:sz w:val="22"/><w:szCs w:val="22"/><w:lang w:val="en-US" w:eastAsia="en-US" w:bidi="ta-IN"/></w:rPr></w:rPrDefault>' +
      '<w:pPrDefault><w:pPr><w:spacing w:after="120" w:line="276" w:lineRule="auto"/></w:pPr></w:pPrDefault></w:docDefaults>' +
      '<w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/><w:qFormat/></w:style>' +
      hs(1, 'Heading 1', 36, 360) + hs(2, 'Heading 2', 30, 280) + hs(3, 'Heading 3', 26, 200) +
      '<w:style w:type="paragraph" w:styleId="ListParagraph"><w:name w:val="List Paragraph"/><w:basedOn w:val="Normal"/><w:qFormat/><w:pPr><w:spacing w:after="60"/><w:contextualSpacing/></w:pPr></w:style>' +
      '<w:style w:type="paragraph" w:styleId="Quote"><w:name w:val="Quote"/><w:basedOn w:val="Normal"/><w:qFormat/><w:pPr><w:pBdr><w:left w:val="single" w:sz="18" w:space="8" w:color="A6B4C8"/></w:pBdr><w:ind w:left="567"/></w:pPr><w:rPr><w:i/><w:iCs/><w:color w:val="595959"/></w:rPr></w:style>' +
      '<w:style w:type="paragraph" w:styleId="CodeBlock"><w:name w:val="Code Block"/><w:basedOn w:val="Normal"/><w:pPr><w:shd w:val="clear" w:color="auto" w:fill="F2F2F2"/><w:spacing w:before="0" w:after="0" w:line="240" w:lineRule="auto"/><w:ind w:left="170" w:right="170"/></w:pPr><w:rPr><w:rFonts w:ascii="Consolas" w:hAnsi="Consolas" w:cs="Consolas"/><w:sz w:val="19"/><w:szCs w:val="19"/></w:rPr></w:style>' +
      '<w:style w:type="table" w:default="1" w:styleId="TableNormal"><w:name w:val="Normal Table"/><w:uiPriority w:val="99"/><w:semiHidden/><w:tblPr><w:tblInd w:w="0" w:type="dxa"/><w:tblCellMar><w:top w:w="0" w:type="dxa"/><w:left w:w="108" w:type="dxa"/><w:bottom w:w="0" w:type="dxa"/><w:right w:w="108" w:type="dxa"/></w:tblCellMar></w:tblPr></w:style>' +
      '<w:style w:type="table" w:styleId="TableGrid"><w:name w:val="Table Grid"/><w:basedOn w:val="TableNormal"/><w:tblPr><w:tblBorders><w:top w:val="single" w:sz="4" w:space="0" w:color="auto"/><w:left w:val="single" w:sz="4" w:space="0" w:color="auto"/><w:bottom w:val="single" w:sz="4" w:space="0" w:color="auto"/><w:right w:val="single" w:sz="4" w:space="0" w:color="auto"/><w:insideH w:val="single" w:sz="4" w:space="0" w:color="auto"/><w:insideV w:val="single" w:sz="4" w:space="0" w:color="auto"/></w:tblBorders></w:tblPr></w:style></w:styles>';
    var lvl = function (i, fmt, txt) {
      return '<w:lvl w:ilvl="' + i + '"><w:start w:val="1"/><w:numFmt w:val="' + fmt + '"/><w:lvlText w:val="' + txt + '"/><w:lvlJc w:val="left"/><w:pPr><w:ind w:left="' + (720 + 360 * i) + '" w:hanging="360"/></w:pPr></w:lvl>';
    };
    var numbering = XML + '<w:numbering ' + WNS + '>' +
      '<w:abstractNum w:abstractNumId="0"><w:multiLevelType w:val="hybridMultilevel"/>' + lvl(0, 'bullet', '•') + lvl(1, 'bullet', '◦') + lvl(2, 'bullet', '▪') + '</w:abstractNum>' +
      '<w:abstractNum w:abstractNumId="1"><w:multiLevelType w:val="hybridMultilevel"/>' + lvl(0, 'decimal', '%1.') + lvl(1, 'lowerLetter', '%2.') + lvl(2, 'lowerRoman', '%3.') + '</w:abstractNum>' +
      '<w:num w:numId="1"><w:abstractNumId w:val="0"/></w:num>' +
      nums.map(function (id) { return '<w:num w:numId="' + id + '"><w:abstractNumId w:val="1"/><w:lvlOverride w:ilvl="0"><w:startOverride w:val="1"/></w:lvlOverride></w:num>'; }).join('') + '</w:numbering>';
    var title = '';
    for (var k = 0; k < blocks.length; k++) if (blocks[k].t === 'h') { title = plainOf(blocks[k].r); break; }
    return zipBlob([
      { name: '[Content_Types].xml', data: XML + '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/><Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/><Override PartName="/word/numbering.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.numbering+xml"/><Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/></Types>' },
      { name: '_rels/.rels', data: XML + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/></Relationships>' },
      { name: 'docProps/core.xml', data: XML + '<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:title>' + esc(title) + '</dc:title><dc:creator>Zen Ai</dc:creator><dcterms:created xsi:type="dcterms:W3CDTF">' + new Date().toISOString().replace(/\.\d+Z$/, 'Z') + '</dcterms:created></cp:coreProperties>' },
      { name: 'word/_rels/document.xml.rels', data: XML + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/numbering" Target="numbering.xml"/></Relationships>' },
      { name: 'word/document.xml', data: doc }, { name: 'word/styles.xml', data: styles }, { name: 'word/numbering.xml', data: numbering }
    ], MIME.docx);
  }

  /* ============================== XLSX ============================== */
  function parseCsv(t) {
    t = String(t).replace(/^﻿/, '');
    var first = t.split('\n').slice(0, 5).join('\n'), d = ',';
    var cnt = function (c) { return (first.match(new RegExp(c === '\t' ? '\\t' : '\\' + c, 'g')) || []).length; };
    if (cnt('\t') > cnt(d)) d = '\t'; else if (cnt(';') > cnt(d)) d = ';';
    var rows = [], row = [], cell = '', q = false, i = 0, n = t.length;
    for (; i < n; i++) {
      var ch = t[i];
      if (q) { if (ch === '"') { if (t[i + 1] === '"') { cell += '"'; i++; } else q = false; } else cell += ch; }
      else if (ch === '"' && cell === '') q = true;
      else if (ch === d) { row.push(cell); cell = ''; }
      else if (ch === '\n' || ch === '\r') { if (ch === '\r' && t[i + 1] === '\n') i++; row.push(cell); cell = ''; rows.push(row); row = []; }
      else cell += ch;
    }
    if (cell !== '' || row.length) { row.push(cell); rows.push(row); }
    while (rows.length && rows[rows.length - 1].every(function (c) { return c === ''; })) rows.pop();
    return rows;
  }
  function parseSheets(text) {
    var src = String(text == null ? '' : text).replace(/\r\n?/g, '\n').replace(/^\s*```[^\n]*\n([\s\S]*?)\n```\s*$/, '$1');
    var tr = src.trim(), sheets = [];
    if (/^[\[{]/.test(tr)) {
      try {
        var j = JSON.parse(tr);
        var fromArr = function (a) {
          if (!Array.isArray(a) || !a.length) return [];
          if (Array.isArray(a[0])) return a;
          if (a[0] && typeof a[0] === 'object') { var ks = []; a.forEach(function (o) { Object.keys(o).forEach(function (k) { if (ks.indexOf(k) < 0) ks.push(k); }); }); return [ks].concat(a.map(function (o) { return ks.map(function (k) { return o[k] == null ? '' : o[k]; }); })); }
          return a.map(function (v) { return [v]; });
        };
        if (Array.isArray(j)) sheets.push({ name: 'Sheet1', rows: fromArr(j) });
        else if (Array.isArray(j.sheets)) j.sheets.forEach(function (s, k) { sheets.push({ name: s.name || 'Sheet' + (k + 1), rows: fromArr(s.rows || s.data || []) }); });
        else Object.keys(j).forEach(function (k) { sheets.push({ name: k, rows: fromArr(j[k]) }); });
        if (sheets.length) return sheets;
      } catch (e) { sheets = []; }
    }
    var parts = [], cur = { name: 'Sheet1', lines: [] }, hasMark = false;
    src.split('\n').forEach(function (l) {
      var m = l.match(/^#{1,3}\s*(?:sheet\s*[:\-]\s*)?(.+?)\s*$/i);
      if (m) {
        if (cur.lines.some(function (x) { return x.trim(); })) parts.push(cur);
        cur = { name: m[1].replace(/^["'`]|["'`]$/g, ''), lines: [] }; hasMark = true;
      } else cur.lines.push(l);
    });
    parts.push(cur);
    if (!hasMark) parts = [{ name: 'Sheet1', lines: src.split('\n') }];
    parts.forEach(function (p) {
      var body = p.lines.join('\n').replace(/^\s*```[^\n]*\n([\s\S]*?)\n?```\s*$/, '$1').trim(), rows;
      if (/^\|/.test(body)) rows = body.split('\n').filter(function (l) { return l.trim() && !(SEP.test(l) && l.indexOf('-') >= 0); }).map(function (l) { return splitRow(l).map(function (c) { return plainOf(inl(c)); }); });
      else rows = parseCsv(body);
      if (rows.length || !sheets.length) sheets.push({ name: p.name, rows: rows });
    });
    return sheets;
  }
  var colName = function (i) { var s = ''; i++; while (i > 0) { var m = (i - 1) % 26; s = String.fromCharCode(65 + m) + s; i = Math.floor((i - 1) / 26); } return s; };
  var NUM = /^[-+]?(\d+\.?\d*|\.\d+)([eE][-+]?\d+)?$/;
  function buildXlsx(text) {
    var sheets = parseSheets(text), used = {};
    if (!sheets.length) sheets = [{ name: 'Sheet1', rows: [] }];
    sheets = sheets.map(function (s, k) {
      var n = String(s.name || 'Sheet' + (k + 1)).replace(/[\[\]:*?\/\\]/g, ' ').trim().slice(0, 31) || 'Sheet' + (k + 1), base = n, c = 2;
      while (used[n.toLowerCase()]) { n = base.slice(0, 28) + ' ' + c++; }
      used[n.toLowerCase()] = 1; return { name: n, rows: s.rows };
    });
    var sheetXml = sheets.map(function (s) {
      var rows = s.rows, w = 0; rows.forEach(function (r) { w = Math.max(w, r.length); });
      var hdr = rows.length > 1 && rows[0].length > 0 && rows[0].every(function (c) { c = String(c == null ? '' : c).trim(); return c !== '' && !NUM.test(c) && c[0] !== '='; });
      var widths = []; for (var c0 = 0; c0 < w; c0++) widths[c0] = 8;
      var sd = rows.map(function (r, ri) {
        var cells = '';
        r.forEach(function (v, ci) {
          var raw = v == null ? '' : String(v), t = raw.trim(), ref = colName(ci) + (ri + 1), st = hdr && ri === 0 ? ' s="1"' : '';
          var len = 0; raw.split('\n').forEach(function (l) { len = Math.max(len, Array.from(l).length); });
          widths[ci] = Math.max(widths[ci], Math.min(60, len * 1.15 + 2));
          if (t === '') return;
          if (t[0] === '=' && t.length > 1) cells += '<c r="' + ref + '"' + st + '><f>' + esc(t.slice(1)) + '</f></c>';
          else if (NUM.test(t) && !/^[-+]?0\d/.test(t) && t.replace(/\D/g, '').length < 16) cells += '<c r="' + ref + '"' + st + '><v>' + t + '</v></c>';
          else if (/^[-+]?\d+(\.\d+)?%$/.test(t)) cells += '<c r="' + ref + '" s="2"><v>' + (parseFloat(t) / 100) + '</v></c>';
          else cells += '<c r="' + ref + '"' + (st || (raw.indexOf('\n') >= 0 ? ' s="3"' : '')) + ' t="inlineStr"><is><t xml:space="preserve">' + esc(raw) + '</t></is></c>';
        });
        return '<row r="' + (ri + 1) + '">' + cells + '</row>';
      }).join('');
      return XML + '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">' +
        '<dimension ref="A1' + (w && rows.length ? ':' + colName(w - 1) + rows.length : '') + '"/>' +
        '<sheetViews><sheetView workbookViewId="0">' + (hdr ? '<pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/>' : '') + '</sheetView></sheetViews><sheetFormatPr defaultRowHeight="15"/>' +
        (w ? '<cols>' + widths.map(function (x, i) { return '<col min="' + (i + 1) + '" max="' + (i + 1) + '" width="' + x.toFixed(1) + '" customWidth="1"/>'; }).join('') + '</cols>' : '') +
        '<sheetData>' + sd + '</sheetData>' + (hdr && w ? '<autoFilter ref="A1:' + colName(w - 1) + rows.length + '"/>' : '') + '</worksheet>';
    });
    var styles = XML + '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">' +
      '<fonts count="2"><font><sz val="11"/><name val="Calibri"/><family val="2"/></font><font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/><family val="2"/></font></fonts>' +
      '<fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF1F4E78"/><bgColor indexed="64"/></patternFill></fill></fills>' +
      '<borders count="2"><border><left/><right/><top/><bottom/><diagonal/></border><border><left style="thin"><color rgb="FFBFBFBF"/></left><right style="thin"><color rgb="FFBFBFBF"/></right><top style="thin"><color rgb="FFBFBFBF"/></top><bottom style="thin"><color rgb="FFBFBFBF"/></bottom><diagonal/></border></borders>' +
      '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>' +
      '<cellXfs count="4"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment vertical="center" wrapText="1"/></xf><xf numFmtId="9" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment vertical="top" wrapText="1"/></xf></cellXfs>' +
      '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>';
    var files = [
      { name: '[Content_Types].xml', data: XML + '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>' + sheets.map(function (_, i) { return '<Override PartName="/xl/worksheets/sheet' + (i + 1) + '.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'; }).join('') + '</Types>' },
      { name: '_rels/.rels', data: XML + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>' },
      { name: 'xl/workbook.xml', data: XML + '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><bookViews><workbookView/></bookViews><sheets>' + sheets.map(function (s, i) { return '<sheet name="' + esc(s.name) + '" sheetId="' + (i + 1) + '" r:id="rId' + (i + 1) + '"/>'; }).join('') + '</sheets><calcPr calcId="191029" fullCalcOnLoad="1"/></workbook>' },
      { name: 'xl/_rels/workbook.xml.rels', data: XML + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' + sheets.map(function (_, i) { return '<Relationship Id="rId' + (i + 1) + '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet' + (i + 1) + '.xml"/>'; }).join('') + '<Relationship Id="rId' + (sheets.length + 1) + '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>' },
      { name: 'xl/styles.xml', data: styles }
    ];
    sheetXml.forEach(function (x, i) { files.push({ name: 'xl/worksheets/sheet' + (i + 1) + '.xml', data: x }); });
    return zipBlob(files, MIME.xlsx);
  }

  /* ============================== PPTX ============================== */
  var EMU = { W: 12192000, H: 6858000, MX: 640080 };
  var PNS = 'xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"';
  var GRP = '<p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr>';
  function aRuns(runs, sz, color, bold) {
    return runs.map(function (r) {
      return '<a:r><a:rPr lang="en-US" sz="' + (r.c ? Math.round(sz * 0.9) : sz) + '"' + (r.b || bold ? ' b="1"' : '') + (r.i ? ' i="1"' : '') + (r.s ? ' strike="sngStrike"' : '') + ' dirty="0"><a:solidFill><a:srgbClr val="' + color + '"/></a:solidFill>' + (r.c ? '<a:latin typeface="Consolas"/>' : '') + '</a:rPr><a:t>' + esc(r.t) + '</a:t></a:r>';
    }).join('');
  }
  function aPara(runs, o) {
    var ind = o.bullet ? (o.lvl ? 685800 : 342900) : 0, mar = o.bullet ? (o.lvl ? 685800 + 228600 : 342900) : 0;
    return '<a:p><a:pPr marL="' + (o.bullet ? mar : 0) + '" indent="' + (o.bullet ? -342900 : 0) + '"' + (o.algn ? ' algn="' + o.algn + '"' : '') + '><a:spcBef><a:spcPts val="' + (o.before == null ? 600 : o.before) + '"/></a:spcBef>' +
      (o.bullet ? '<a:buClr><a:srgbClr val="2E75B6"/></a:buClr><a:buFont typeface="Arial"/><a:buChar char="' + (o.lvl ? '–' : '•') + '"/>' : '<a:buNone/>') + '</a:pPr>' +
      aRuns(runs, o.sz, o.color, o.b) + '<a:endParaRPr lang="en-US" sz="' + o.sz + '" dirty="0"/></a:p>';
  }
  function parseSlides(text) {
    var src = String(text == null ? '' : text).replace(/\r\n?/g, '\n'), chunks;
    if (/^\s*(-{3,}|\*{3,}|_{3,})\s*$/m.test(src)) chunks = src.split(/^\s*(?:-{3,}|\*{3,}|_{3,})\s*$/m);
    else chunks = src.split(/\n(?=#{1,2}\s)/);
    var slides = [];
    chunks.forEach(function (ch) {
      var bl = parseMd(ch); if (!bl.length) return;
      var title = '', ti = -1;
      for (var i = 0; i < bl.length; i++) if (bl[i].t === 'h') { title = bl[i]; ti = i; break; }
      var rest = bl.filter(function (_, k) { return k !== ti; });
      slides.push({ title: title ? title.r : [], lvl: title ? title.l : 0, blocks: rest });
    });
    if (!slides.length) slides.push({ title: [{ t: 'Untitled' }], lvl: 1, blocks: [] });
    var out = [];
    slides.forEach(function (s, idx) {
      var cover = idx === 0 && !s.blocks.some(function (b) { return b.t === 'li' || b.t === 'table'; });
      if (cover) { out.push({ cover: true, title: s.title, blocks: s.blocks }); return; }
      var tbl = s.blocks.filter(function (b) { return b.t === 'table'; })[0], txt = s.blocks.filter(function (b) { return b.t !== 'table' && b.t !== 'hr'; });
      if (tbl || txt.length <= 7) { out.push({ title: s.title, blocks: txt, table: tbl }); return; }
      for (var k = 0; k < txt.length; k += 7) out.push({ title: k ? s.title.concat([{ t: ' (cont.)' }]) : s.title, blocks: txt.slice(k, k + 7) });
    });
    return out;
  }
  function slideXml(s) {
    var id = 1, sp = [], nid = function () { return ++id; };
    var title = s.title.length ? s.title : [{ t: '' }];
    if (s.cover) {
      sp.push('<p:sp><p:nvSpPr><p:cNvPr id="' + nid() + '" name="Title"/><p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr><p:nvPr><p:ph type="title"/></p:nvPr></p:nvSpPr><p:spPr><a:xfrm><a:off x="' + EMU.MX + '" y="1900000"/><a:ext cx="10911840" cy="1700000"/></a:xfrm></p:spPr><p:txBody><a:bodyPr anchor="b"><a:normAutofit/></a:bodyPr><a:lstStyle/>' + aPara(title, { sz: 4400, color: 'FFFFFF', b: 1, before: 0 }) + '</p:txBody></p:sp>');
      sp.push('<p:sp><p:nvSpPr><p:cNvPr id="' + nid() + '" name="Accent"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr><p:spPr><a:xfrm><a:off x="' + EMU.MX + '" y="3750000"/><a:ext cx="1400000" cy="60000"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom><a:solidFill><a:srgbClr val="5BA3E0"/></a:solidFill><a:ln><a:noFill/></a:ln></p:spPr></p:sp>');
      var sub = s.blocks.filter(function (b) { return b.t === 'p' || b.t === 'q' || b.t === 'h'; });
      if (sub.length) sp.push('<p:sp><p:nvSpPr><p:cNvPr id="' + nid() + '" name="Subtitle"/><p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr><p:nvPr><p:ph idx="1"/></p:nvPr></p:nvSpPr><p:spPr><a:xfrm><a:off x="' + EMU.MX + '" y="3950000"/><a:ext cx="10911840" cy="1500000"/></a:xfrm></p:spPr><p:txBody><a:bodyPr><a:normAutofit/></a:bodyPr><a:lstStyle/>' +
        sub.map(function (b) { return aPara(b.r, { sz: 2200, color: 'C9D6EA', before: 300 }); }).join('') + '</p:txBody></p:sp>');
      return XML + '<p:sld ' + PNS + '><p:cSld><p:bg><p:bgPr><a:solidFill><a:srgbClr val="1F3864"/></a:solidFill><a:effectLst/></p:bgPr></p:bg><p:spTree>' + GRP + sp.join('') + '</p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sld>';
    }
    sp.push('<p:sp><p:nvSpPr><p:cNvPr id="' + nid() + '" name="Title"/><p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr><p:nvPr><p:ph type="title"/></p:nvPr></p:nvSpPr><p:spPr><a:xfrm><a:off x="' + EMU.MX + '" y="380000"/><a:ext cx="10911840" cy="900000"/></a:xfrm></p:spPr><p:txBody><a:bodyPr anchor="ctr"><a:normAutofit/></a:bodyPr><a:lstStyle/>' + aPara(title, { sz: 3200, color: '1F3864', b: 1, before: 0 }) + '</p:txBody></p:sp>');
    sp.push('<p:sp><p:nvSpPr><p:cNvPr id="' + nid() + '" name="Accent"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr><p:spPr><a:xfrm><a:off x="' + EMU.MX + '" y="1300000"/><a:ext cx="1200000" cy="54000"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom><a:solidFill><a:srgbClr val="2E75B6"/></a:solidFill><a:ln><a:noFill/></a:ln></p:spPr></p:sp>');
    var n = s.blocks.length, chars = 0;
    s.blocks.forEach(function (b) { chars += b.t === 'code' ? b.text.length : plainOf(b.r).length; });
    var sz = (n <= 3 && chars < 220) ? 3000 : (n <= 5 && chars < 420) ? 2600 : (n <= 7 && chars < 700) ? 2200 : 1800;
    if (n || !s.table) {
      var bh = s.table ? Math.min(2100000, 650000 + n * 420000) : 4700000, paras = '';
      s.blocks.forEach(function (b) {
        if (b.t === 'li') paras += aPara(b.r, { sz: b.lvl ? sz - 200 : sz, color: '262626', bullet: 1, lvl: b.lvl });
        else if (b.t === 'code') b.text.split('\n').forEach(function (l) { paras += aPara([{ t: l, c: 1 }], { sz: sz - 400, color: '404040', before: 0 }); });
        else if (b.t === 'h') paras += aPara(b.r, { sz: sz, color: '1F3864', b: 1 });
        else if (b.t === 'q') paras += aPara(b.r.map(function (r) { return Object.assign({}, r, { i: 1 }); }), { sz: sz, color: '595959' });
        else paras += aPara(b.r, { sz: sz, color: '262626' });
      });
      if (paras) sp.push('<p:sp><p:nvSpPr><p:cNvPr id="' + nid() + '" name="Content"/><p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr><p:nvPr><p:ph idx="1"/></p:nvPr></p:nvSpPr><p:spPr><a:xfrm><a:off x="' + EMU.MX + '" y="1550000"/><a:ext cx="10911840" cy="' + bh + '"/></a:xfrm></p:spPr><p:txBody><a:bodyPr><a:normAutofit/></a:bodyPr><a:lstStyle/>' + paras + '</p:txBody></p:sp>');
      if (s.table) s.tableTop = 1550000 + (paras ? bh + 100000 : 0);
    }
    if (s.table) {
      var rows = s.table.rows, cols = rows[0].length, cw = Math.floor(10911840 / cols), fs = cols <= 3 ? 1800 : cols <= 5 ? 1600 : 1200;
      var ln = function (t) { return '<a:' + t + ' w="9525"><a:solidFill><a:srgbClr val="BFBFBF"/></a:solidFill></a:' + t + '>'; };
      var tr = rows.map(function (row, ri) {
        var hd = s.table.head && ri === 0;
        return '<a:tr h="400000">' + row.map(function (cell) {
          return '<a:tc><a:txBody><a:bodyPr/><a:lstStyle/><a:p><a:pPr><a:buNone/></a:pPr>' + aRuns(cell.length ? cell : [{ t: '' }], fs, hd ? 'FFFFFF' : '262626', hd) + '<a:endParaRPr lang="en-US" sz="' + fs + '" dirty="0"/></a:p></a:txBody><a:tcPr marL="91440" marR="91440" marT="45720" marB="45720" anchor="ctr">' + ln('lnL') + ln('lnR') + ln('lnT') + ln('lnB') + '<a:solidFill><a:srgbClr val="' + (hd ? '1F4E78' : (ri % 2 ? 'F3F6FA' : 'FFFFFF')) + '"/></a:solidFill></a:tcPr></a:tc>';
        }).join('') + '</a:tr>';
      }).join('');
      var gx = ''; for (var g = 0; g < cols; g++) gx += '<a:gridCol w="' + cw + '"/>';
      sp.push('<p:graphicFrame><p:nvGraphicFramePr><p:cNvPr id="' + nid() + '" name="Table"/><p:cNvGraphicFramePr><a:graphicFrameLocks noGrp="1"/></p:cNvGraphicFramePr><p:nvPr/></p:nvGraphicFramePr><p:xfrm><a:off x="' + EMU.MX + '" y="' + (s.tableTop || 1550000) + '"/><a:ext cx="' + (cw * cols) + '" cy="' + (400000 * rows.length) + '"/></p:xfrm><a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/table"><a:tbl><a:tblPr firstRow="1" bandRow="1"/><a:tblGrid>' + gx + '</a:tblGrid>' + tr + '</a:tbl></a:graphicData></a:graphic></p:graphicFrame>');
    }
    return XML + '<p:sld ' + PNS + '><p:cSld><p:spTree>' + GRP + sp.join('') + '</p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sld>';
  }
  function buildPptx(text) {
    var slides = parseSlides(text), N = slides.length;
    var ph = function (id, name, phx, x, y, cx, cy) { return '<p:sp><p:nvSpPr><p:cNvPr id="' + id + '" name="' + name + '"/><p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr><p:nvPr><p:ph ' + phx + '/></p:nvPr></p:nvSpPr><p:spPr>' + (cx ? '<a:xfrm><a:off x="' + x + '" y="' + y + '"/><a:ext cx="' + cx + '" cy="' + cy + '"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom>' : '') + '</p:spPr><p:txBody><a:bodyPr/><a:lstStyle/><a:p><a:r><a:rPr lang="en-US"/><a:t>' + (phx.indexOf('title') >= 0 ? 'Click to edit title' : 'Click to edit text') + '</a:t></a:r></a:p></p:txBody></p:sp>'; };
    var lvlStyle = function (i, sz) { return '<a:lvl' + i + 'pPr marL="' + (342900 * i) + '" indent="-342900" algn="l" defTabSz="914400" rtl="0" eaLnBrk="1" latinLnBrk="0" hangingPunct="1"><a:spcBef><a:spcPts val="600"/></a:spcBef><a:buFont typeface="Arial"/><a:buChar char="•"/><a:defRPr sz="' + sz + '" kern="1200"><a:solidFill><a:schemeClr val="tx1"/></a:solidFill><a:latin typeface="+mn-lt"/><a:ea typeface="+mn-ea"/><a:cs typeface="+mn-cs"/></a:defRPr></a:lvl' + i + 'pPr>'; };
    var master = XML + '<p:sldMaster ' + PNS + '><p:cSld><p:bg><p:bgRef idx="1001"><a:schemeClr val="bg1"/></p:bgRef></p:bg><p:spTree>' + GRP +
      ph(2, 'Title Placeholder 1', 'type="title"', EMU.MX, 380000, 10911840, 900000) + ph(3, 'Text Placeholder 2', 'type="body" idx="1"', EMU.MX, 1550000, 10911840, 4700000) +
      '</p:spTree></p:cSld><p:clrMap bg1="lt1" tx1="dk1" bg2="lt2" tx2="dk2" accent1="accent1" accent2="accent2" accent3="accent3" accent4="accent4" accent5="accent5" accent6="accent6" hlink="hlink" folHlink="folHlink"/>' +
      '<p:sldLayoutIdLst><p:sldLayoutId id="2147483649" r:id="rId1"/></p:sldLayoutIdLst><p:txStyles><p:titleStyle><a:lvl1pPr algn="l" defTabSz="914400" rtl="0" eaLnBrk="1" latinLnBrk="0" hangingPunct="1"><a:lnSpc><a:spcPct val="90000"/></a:lnSpc><a:spcBef><a:spcPct val="0"/></a:spcBef><a:buNone/><a:defRPr sz="3200" b="1" kern="1200"><a:solidFill><a:schemeClr val="tx2"/></a:solidFill><a:latin typeface="+mj-lt"/><a:ea typeface="+mj-ea"/><a:cs typeface="+mj-cs"/></a:defRPr></a:lvl1pPr></p:titleStyle>' +
      '<p:bodyStyle>' + lvlStyle(1, 2400) + lvlStyle(2, 2000) + lvlStyle(3, 1800) + '</p:bodyStyle><p:otherStyle><a:defPPr><a:defRPr lang="en-US"/></a:defPPr></p:otherStyle></p:txStyles></p:sldMaster>';
    var layout = XML + '<p:sldLayout ' + PNS + ' type="obj" preserve="1"><p:cSld name="Title and Content"><p:spTree>' + GRP + ph(2, 'Title 1', 'type="title"') + ph(3, 'Content Placeholder 2', 'idx="1"') + '</p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sldLayout>';
    var fill = function (n) { return '<a:solidFill><a:schemeClr val="phClr"/></a:solidFill>'.repeat(n); };
    var lnx = function (w) { return '<a:ln w="' + w + '" cap="flat" cmpd="sng" algn="ctr"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:prstDash val="solid"/></a:ln>'; };
    var theme = XML + '<a:theme xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" name="Zen Ai"><a:themeElements><a:clrScheme name="Zen Ai"><a:dk1><a:srgbClr val="262626"/></a:dk1><a:lt1><a:srgbClr val="FFFFFF"/></a:lt1><a:dk2><a:srgbClr val="1F3864"/></a:dk2><a:lt2><a:srgbClr val="EEF2F7"/></a:lt2><a:accent1><a:srgbClr val="2E75B6"/></a:accent1><a:accent2><a:srgbClr val="ED7D31"/></a:accent2><a:accent3><a:srgbClr val="70AD47"/></a:accent3><a:accent4><a:srgbClr val="FFC000"/></a:accent4><a:accent5><a:srgbClr val="5B9BD5"/></a:accent5><a:accent6><a:srgbClr val="7F7F7F"/></a:accent6><a:hlink><a:srgbClr val="0563C1"/></a:hlink><a:folHlink><a:srgbClr val="954F72"/></a:folHlink></a:clrScheme>' +
      '<a:fontScheme name="Zen Ai"><a:majorFont><a:latin typeface="Calibri"/><a:ea typeface=""/><a:cs typeface=""/></a:majorFont><a:minorFont><a:latin typeface="Calibri"/><a:ea typeface=""/><a:cs typeface=""/></a:minorFont></a:fontScheme>' +
      '<a:fmtScheme name="Zen Ai"><a:fillStyleLst>' + fill(3) + '</a:fillStyleLst><a:lnStyleLst>' + lnx(6350) + lnx(12700) + lnx(19050) + '</a:lnStyleLst><a:effectStyleLst><a:effectStyle><a:effectLst/></a:effectStyle><a:effectStyle><a:effectLst/></a:effectStyle><a:effectStyle><a:effectLst/></a:effectStyle></a:effectStyleLst><a:bgFillStyleLst>' + fill(3) + '</a:bgFillStyleLst></a:fmtScheme></a:themeElements></a:theme>';
    var R = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships';
    var files = [
      { name: '[Content_Types].xml', data: XML + '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/ppt/presentation.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml"/><Override PartName="/ppt/slideMasters/slideMaster1.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slideMaster+xml"/><Override PartName="/ppt/slideLayouts/slideLayout1.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slideLayout+xml"/><Override PartName="/ppt/theme/theme1.xml" ContentType="application/vnd.openxmlformats-officedocument.theme+xml"/>' + slides.map(function (_, i) { return '<Override PartName="/ppt/slides/slide' + (i + 1) + '.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slide+xml"/>'; }).join('') + '</Types>' },
      { name: '_rels/.rels', data: XML + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="' + R + '/officeDocument" Target="ppt/presentation.xml"/></Relationships>' },
      { name: 'ppt/presentation.xml', data: XML + '<p:presentation ' + PNS + ' saveSubsetFonts="1"><p:sldMasterIdLst><p:sldMasterId id="2147483648" r:id="rId1"/></p:sldMasterIdLst><p:sldIdLst>' + slides.map(function (_, i) { return '<p:sldId id="' + (256 + i) + '" r:id="rId' + (i + 3) + '"/>'; }).join('') + '</p:sldIdLst><p:sldSz cx="' + EMU.W + '" cy="' + EMU.H + '"/><p:notesSz cx="6858000" cy="9144000"/></p:presentation>' },
      { name: 'ppt/_rels/presentation.xml.rels', data: XML + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="' + R + '/slideMaster" Target="slideMasters/slideMaster1.xml"/><Relationship Id="rId2" Type="' + R + '/theme" Target="theme/theme1.xml"/>' + slides.map(function (_, i) { return '<Relationship Id="rId' + (i + 3) + '" Type="' + R + '/slide" Target="slides/slide' + (i + 1) + '.xml"/>'; }).join('') + '</Relationships>' },
      { name: 'ppt/slideMasters/slideMaster1.xml', data: master },
      { name: 'ppt/slideMasters/_rels/slideMaster1.xml.rels', data: XML + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="' + R + '/slideLayout" Target="../slideLayouts/slideLayout1.xml"/><Relationship Id="rId2" Type="' + R + '/theme" Target="../theme/theme1.xml"/></Relationships>' },
      { name: 'ppt/slideLayouts/slideLayout1.xml', data: layout },
      { name: 'ppt/slideLayouts/_rels/slideLayout1.xml.rels', data: XML + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="' + R + '/slideMaster" Target="../slideMasters/slideMaster1.xml"/></Relationships>' },
      { name: 'ppt/theme/theme1.xml', data: theme }
    ];
    slides.forEach(function (s, i) {
      files.push({ name: 'ppt/slides/slide' + (i + 1) + '.xml', data: slideXml(s) });
      files.push({ name: 'ppt/slides/_rels/slide' + (i + 1) + '.xml.rels', data: XML + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="' + R + '/slideLayout" Target="../slideLayouts/slideLayout1.xml"/></Relationships>' });
    });
    void N;
    return zipBlob(files, MIME.pptx);
  }

  /* ============================== PDF (canvas based, so Tamil / Sinhala / Hindi always draw correctly) ============================== */
  async function buildPdf(text) {
    var S = 2, PW = 595.28, PH = 841.89, M = 54, CW = PW - 2 * M;
    var FAM = "'Noto Sans Tamil','Noto Sans Sinhala','Noto Sans Devanagari','Noto Sans','Nirmala UI','Latha',system-ui,'Segoe UI',Roboto,Arial,sans-serif";
    var MONO = "ui-monospace,Consolas,'Courier New',monospace";
    var pages = [], cv, cx, y;
    var newPage = function () {
      cv = document.createElement('canvas'); cv.width = Math.round(PW * S); cv.height = Math.round(PH * S);
      cx = cv.getContext('2d'); cx.scale(S, S); cx.fillStyle = '#ffffff'; cx.fillRect(0, 0, PW, PH); cx.textBaseline = 'alphabetic';
      cv._cx = cx; pages.push(cv); y = M;
    };
    var font = function (sz, b, i, mono) { return (i ? 'italic ' : '') + (b ? '700 ' : '400 ') + sz + 'px ' + (mono ? MONO : FAM); };
    var need = function (h) { if (y + h > PH - M) newPage(); };
    var flow = function (runs, width, sz, base) {
      var lines = [[]], x = 0;
      runs.forEach(function (r) {
        var f = font(r.c ? sz * 0.92 : sz, r.b || base.b, r.i || base.i, r.c);
        cx.font = f;
        r.t.split(/(\s+)/).filter(function (s) { return s !== ''; }).forEach(function (tk) {
          var sp = /^\s+$/.test(tk), w = cx.measureText(sp ? ' ' : tk).width, ln = lines[lines.length - 1];
          if (sp) { if (ln.length) { ln.push({ t: ' ', f: f, w: w, r: r }); x += w; } return; }
          if (x + w > width && ln.length) { while (ln.length && ln[ln.length - 1].t === ' ') x -= ln.pop().w; lines.push([]); x = 0; }
          if (w > width) {
            Array.from(tk).forEach(function (ch) { var cw = cx.measureText(ch).width; if (x + cw > width && lines[lines.length - 1].length) { lines.push([]); x = 0; } lines[lines.length - 1].push({ t: ch, f: f, w: cw, r: r }); x += cw; });
          } else { lines[lines.length - 1].push({ t: tk, f: f, w: w, r: r }); x += w; }
        });
      });
      lines.forEach(function (l) { while (l.length && l[l.length - 1].t === ' ') l.pop(); });
      return lines;
    };
    var drawLine = function (ln, x0, base, sz, color) {
      var x = x0;
      ln.forEach(function (tk) {
        cx.font = tk.f;
        if (tk.r.c) { cx.fillStyle = '#F0F1F4'; cx.fillRect(x - 1, base - sz * 0.9, tk.w + 2, sz * 1.2); }
        cx.fillStyle = tk.r.c ? '#B3261E' : color; cx.fillText(tk.t, x, base);
        if (tk.r.s) { cx.fillRect(x, base - sz * 0.3, tk.w, 0.8); }
        x += tk.w;
      });
    };
    var textBlock = function (runs, x0, width, sz, color, base, after, bar) {
      var lh = sz * 1.55, lines = flow(runs, width, sz, base || {});
      lines.forEach(function (ln, k) {
        need(lh); if (bar) { cx.fillStyle = '#9AA5B1'; cx.fillRect(x0 - 10, y, 3, lh); }
        drawLine(ln, x0, y + sz * 1.08, sz, color); y += lh;
      });
      y += after;
    };
    newPage();
    var blocks = parseMd(text), ordN = 0;
    blocks.forEach(function (b) {
      if (b.t !== 'li') ordN = 0;
      if (b.t === 'h') {
        var sz = { 1: 22, 2: 17, 3: 14 }[b.l]; if (y > M + 1) y += sz * 0.55; need(sz * 2.2);
        textBlock(b.r, M, CW, sz, '#1F3864', { b: 1 }, b.l === 1 ? 2 : 3);
        if (b.l === 1) { cx.fillStyle = '#C9D3E3'; cx.fillRect(M, y, CW, 1); y += 8; }
      }
      else if (b.t === 'p') textBlock(b.r, M, CW, 11, '#222222', {}, 6);
      else if (b.t === 'li') {
        var ind = 16 + b.lvl * 18, lab = b.ord ? (++ordN) + '.' : (b.lvl ? '◦' : '•');
        if (!b.ord) ordN = 0;
        need(17); cx.font = font(11, 0, 0); cx.fillStyle = '#444'; cx.fillText(lab, M + ind - 14 - (b.ord ? 4 : 0), y + 11 * 1.08);
        textBlock(b.r, M + ind + 4, CW - ind - 4, 11, '#222222', {}, 3);
      }
      else if (b.t === 'q') textBlock(b.r, M + 14, CW - 14, 11, '#555555', { i: 1 }, 6, true);
      else if (b.t === 'hr') { need(14); y += 5; cx.fillStyle = '#C4C9D0'; cx.fillRect(M, y, CW, 1); y += 9; }
      else if (b.t === 'code') {
        var lh = 9.5 * 1.45; cx.font = font(9.5, 0, 0, 1); y += 2;
        b.text.split('\n').forEach(function (l) {
          var chunks = [], cur = '';
          Array.from(l === '' ? ' ' : l).forEach(function (ch) { if (cx.measureText(cur + ch).width > CW - 16 && cur) { chunks.push(cur); cur = ch; } else cur += ch; });
          chunks.push(cur);
          chunks.forEach(function (c) { need(lh); cx.fillStyle = '#F3F4F6'; cx.fillRect(M, y, CW, lh); cx.font = font(9.5, 0, 0, 1); cx.fillStyle = '#1F2933'; cx.fillText(c, M + 8, y + 9.5 * 1.02); y += lh; });
        });
        y += 8;
      }
      else if (b.t === 'table') {
        var n = b.rows[0].length, mx = [];
        for (var c = 0; c < n; c++) { var m = 6; b.rows.forEach(function (r) { m = Math.max(m, Math.min(40, plainOf(r[c]).length)); }); mx.push(m); }
        var tot = mx.reduce(function (a, v) { return a + v; }, 0), ws = mx.map(function (v) { return Math.max(34, CW * v / tot); });
        var sc = CW / ws.reduce(function (a, v) { return a + v; }, 0); ws = ws.map(function (v) { return v * sc; });
        y += 2;
        b.rows.forEach(function (row, ri) {
          var hd = b.head && ri === 0, sz = 10, lh = sz * 1.5, cl = row.map(function (cell, ci) { return flow(cell, ws[ci] - 10, sz, hd ? { b: 1 } : {}); });
          var h = Math.max.apply(null, cl.map(function (l) { return l.length; })) * lh + 8; need(h);
          var x = M;
          cl.forEach(function (lines, ci) {
            cx.fillStyle = hd ? '#E3EAF5' : (ri % 2 ? '#F8FAFC' : '#FFFFFF'); cx.fillRect(x, y, ws[ci], h);
            cx.strokeStyle = '#C7CED6'; cx.lineWidth = 0.6; cx.strokeRect(x, y, ws[ci], h);
            lines.forEach(function (ln, k) { drawLine(ln, x + 5, y + 4 + k * lh + sz * 1.08, sz, '#222222'); });
            x += ws[ci];
          });
          y += h;
        });
        y += 10;
      }
    });
    var out = [];
    for (var i = 0; i < pages.length; i++) {
      var c2 = pages[i]._cx; c2.font = font(9, 0, 0); c2.fillStyle = '#8A8F98'; c2.textAlign = 'center';
      if (pages.length > 1) c2.fillText((i + 1) + ' / ' + pages.length, PW / 2, PH - 26);
      var blob = await new Promise(function (res) { pages[i].toBlob(res, 'image/jpeg', 0.92); });
      out.push({ jpg: new Uint8Array(await blob.arrayBuffer()), w: pages[i].width, h: pages[i].height });
    }
    return pdfAssemble(out, PW, PH);
  }
  function pdfAssemble(pgs, PW, PH) {
    var parts = [], off = 0, offs = [], push = function (u) { parts.push(u); off += u.length; }, s = function (x) { push(te.encode(x)); };
    var obj = function (id, fn) { offs[id] = off; s(id + ' 0 obj\n'); fn(); s('\nendobj\n'); };
    push(new Uint8Array([37, 80, 68, 70, 45, 49, 46, 52, 10, 37, 226, 227, 207, 211, 10]));
    var n = pgs.length;
    obj(1, function () { s('<< /Type /Catalog /Pages 2 0 R >>'); });
    obj(2, function () { var k = []; for (var i = 0; i < n; i++) k.push((3 + 3 * i) + ' 0 R'); s('<< /Type /Pages /Count ' + n + ' /Kids [' + k.join(' ') + '] >>'); });
    pgs.forEach(function (p, i) {
      var pid = 3 + 3 * i, cid = pid + 1, iid = pid + 2, content = 'q ' + PW.toFixed(2) + ' 0 0 ' + PH.toFixed(2) + ' 0 0 cm /Im0 Do Q';
      obj(pid, function () { s('<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ' + PW.toFixed(2) + ' ' + PH.toFixed(2) + '] /Resources << /XObject << /Im0 ' + iid + ' 0 R >> /ProcSet [/PDF /ImageC] >> /Contents ' + cid + ' 0 R >>'); });
      obj(cid, function () { s('<< /Length ' + content.length + ' >>\nstream\n' + content + '\nendstream'); });
      obj(iid, function () { s('<< /Type /XObject /Subtype /Image /Width ' + p.w + ' /Height ' + p.h + ' /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ' + p.jpg.length + ' >>\nstream\n'); push(p.jpg); s('\nendstream'); });
    });
    var xr = off, total = 3 + 3 * n;
    s('xref\n0 ' + total + '\n0000000000 65535 f \n');
    for (var i = 1; i < total; i++) s(('0000000000' + offs[i]).slice(-10) + ' 00000 n \n');
    s('trailer\n<< /Size ' + total + ' /Root 1 0 R >>\nstartxref\n' + xr + '\n%%EOF\n');
    return new Blob(parts, { type: MIME.pdf });
  }

  /* ============================== PNG / JPG from SVG ============================== */
  async function svgToImage(text, mime) {
    var svg = String(text || '').trim();
    var at = svg.search(/<svg[\s>]/i);
    if (at < 0) throw new Error('PNG needs SVG code inside the block');
    svg = svg.slice(at);
    if (!/<svg[^>]*\sxmlns=/i.test(svg)) svg = svg.replace(/<svg/i, '<svg xmlns="http://www.w3.org/2000/svg"');
    var head = svg.match(/<svg[^>]*>/i)[0], w = 0, h = 0, m;
    if ((m = head.match(/\swidth="([\d.]+)(px)?"/i))) w = parseFloat(m[1]);
    if ((m = head.match(/\sheight="([\d.]+)(px)?"/i))) h = parseFloat(m[1]);
    if ((!w || !h) && (m = head.match(/viewBox="[-\d.]+[ ,]+[-\d.]+[ ,]+([\d.]+)[ ,]+([\d.]+)"/i))) { w = w || parseFloat(m[1]); h = h || parseFloat(m[2]); }
    w = w || 1024; h = h || 768;
    if (!/\swidth=/i.test(head) || !/\sheight=/i.test(head)) svg = svg.replace(/<svg/i, '<svg width="' + w + '" height="' + h + '"');
    var k = Math.min(3, 2400 / Math.max(w, h)); k = Math.max(k, 0.5);
    var url = URL.createObjectURL(new Blob([svg], { type: 'image/svg+xml;charset=utf-8' }));
    try {
      var img = new Image(); img.src = url; await img.decode();
      var cv = document.createElement('canvas'); cv.width = Math.round(w * k); cv.height = Math.round(h * k);
      var cx = cv.getContext('2d'); if (mime !== 'image/png') { cx.fillStyle = '#fff'; cx.fillRect(0, 0, cv.width, cv.height); }
      cx.drawImage(img, 0, 0, cv.width, cv.height);
      return await new Promise(function (res, rej) { cv.toBlob(function (b) { b ? res(b) : rej(new Error('image export failed')); }, mime, 0.92); });
    } finally { URL.revokeObjectURL(url); }
  }

  /* ============================== public API ============================== */
  async function build(name, text) {
    var e = extOf(name);
    if (e === 'docx') return buildDocx(text);
    if (e === 'xlsx') return buildXlsx(text);
    if (e === 'pptx') return buildPptx(text);
    if (e === 'pdf') return buildPdf(text);
    if (MIME[e]) return svgToImage(text, MIME[e]);
    throw new Error('Unknown file type: ' + e);
  }
  async function zip(files) {
    var out = [];
    for (var i = 0; i < files.length; i++) {
      var f = files[i], data;
      if (isBin(f.name)) { try { data = new Uint8Array(await (await build(f.name, f.text)).arrayBuffer()); } catch (e) { data = te.encode(String(f.text)); f = { name: f.name + '.txt' }; } }
      else data = te.encode(String(f.text));
      out.push({ name: f.name, data: data });
    }
    return zipBlob(out, 'application/zip');
  }
  function preview(name, text, show) {
    var e = extOf(name);
    if (e === 'xlsx') {
      var html = '<!doctype html><meta name="viewport" content="width=device-width,initial-scale=1"><style>body{font:14px system-ui,sans-serif;padding:12px;color:#222}h3{margin:18px 0 6px}table{border-collapse:collapse;margin-bottom:8px}td,th{border:1px solid #c9ced6;padding:4px 8px;white-space:pre-wrap}tr:first-child td{background:#e8eef7;font-weight:600}</style>';
      parseSheets(text).forEach(function (s) { html += '<h3>' + esc(s.name) + '</h3><table>' + s.rows.map(function (r) { return '<tr>' + r.map(function (c) { return '<td>' + esc(c) + '</td>'; }).join('') + '</tr>'; }).join('') + '</table>'; });
      return show(html, 'html', name);
    }
    if (/^(docx|pdf|pptx)$/.test(e)) return show(String(text), 'md', name);
    if (MIME[e]) { var u = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(String(text)); return show('<!doctype html><body style="margin:0;display:grid;place-items:center;min-height:100vh;background:#fff"><img style="max-width:100%" src="' + u + '">', 'html', name); }
  }
  var BADGE = { docx: ['W', '#2B579A'], xlsx: ['X', '#217346'], pptx: ['P', '#C43E1C'], pdf: ['PDF', '#D93025'], png: ['IMG', '#7B61FF'], jpg: ['IMG', '#7B61FF'], jpeg: ['IMG', '#7B61FF'], webp: ['IMG', '#7B61FF'], zip: ['ZIP', '#7A5AF8'] };
  var CAT = [
    ['#E4572E', 'html htm css scss svg vue jsx tsx'],
    ['#0B6E99', 'js mjs ts py java kt c h cpp cs go rs php rb swift dart lua r pl sh bat ps1 sql ipynb'],
    ['#2E8B57', 'json xml yml yaml toml ini csv tsv env'],
    ['#5F6B7A', 'txt md tex rtf log diff'],
    ['#B8860B', 'ics vcf']
  ];
  function badge(name) {
    var e = extOf(name);
    if (BADGE[e]) return BADGE[e];
    for (var i = 0; i < CAT.length; i++) if (CAT[i][1].split(' ').indexOf(e) >= 0) return [e.toUpperCase().slice(0, 4), CAT[i][0]];
    return [(e || 'FILE').toUpperCase().slice(0, 4), '#666666'];
  }
  /* one icon style for every file type: page outline + coloured type badge */
  function icon(name) {
    var b = badge(name), n = b[0].length;
    /* inline styles on purpose: the app's own CSS paints svg fills, inline style wins */
    return '<svg viewBox="0 0 24 24" width="34" height="34" style="width:34px;height:34px;fill:none;color:' + b[1] + '" stroke="' + b[1] + '" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path style="fill:#fff;stroke:' + b[1] + '" d="M14 2H7a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V7z"/><path style="fill:none;stroke:' + b[1] + '" d="M14 2v5h5"/><text x="12" y="17.2" text-anchor="middle" font-size="' + (n === 1 ? 7.5 : n === 2 ? 5.6 : n === 3 ? 4.8 : 4) + '" font-weight="800" font-family="system-ui,sans-serif" style="fill:' + b[1] + ';stroke:none">' + esc(b[0]) + '</text></svg>';
  }
  var API = { isBin: isBin, build: build, zip: zip, preview: preview, icon: icon, label: function (n) { return LABEL[extOf(n)] || ''; }, mime: function (n) { return MIME[extOf(n)] || ''; }, _parseMd: parseMd, _parseSheets: parseSheets, _parseSlides: parseSlides, _buildDocx: buildDocx, _buildXlsx: buildXlsx, _buildPptx: buildPptx, _zipBlob: zipBlob };
  root.ZenGen = API;
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
})(typeof window !== 'undefined' ? window : globalThis);
