/* Zen Ai file generator: builds real Word, Excel, PowerPoint, PDF and PNG files on the device.
 * No library and no internet are needed. The chat model writes plain text (Markdown / CSV / SVG) inside a fenced
 * block whose file name ends in .docx .xlsx .pptx .pdf .png .jpg; the app turns that text into the real file.
 * Public API: window.ZenGen = { isBin, build, zip, preview, icon, label, mime }  (also module.exports for tests). */
(function (root) {
  'use strict';
  var te = new TextEncoder();
  var MIME = {
    docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    pptx: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    pdf: 'application/pdf', png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', webp: 'image/webp',
    odt: 'application/vnd.oasis.opendocument.text', ods: 'application/vnd.oasis.opendocument.spreadsheet', odp: 'application/vnd.oasis.opendocument.presentation',
    epub: 'application/epub+zip', rtf: 'application/rtf',
    dotx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.template', docm: 'application/vnd.ms-word.document.macroEnabled.12', doc: 'application/msword',
    xltx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.template', xlsm: 'application/vnd.ms-excel.sheet.macroEnabled.12', xls: 'application/vnd.ms-excel',
    ppsx: 'application/vnd.openxmlformats-officedocument.presentationml.slideshow', potx: 'application/vnd.openxmlformats-officedocument.presentationml.template', pptm: 'application/vnd.ms-powerpoint.presentation.macroEnabled.12',
    mp3: 'audio/mpeg', m4a: 'audio/mp4', aac: 'audio/aac', ogg: 'audio/ogg', oga: 'audio/ogg', opus: 'audio/ogg', flac: 'audio/flac',
    mp4: 'video/mp4', mov: 'video/quicktime', webm: 'video/webm', mkv: 'video/x-matroska',
    bmp: 'image/bmp', gif: 'image/gif', ico: 'image/x-icon', tiff: 'image/tiff', tif: 'image/tiff', wav: 'audio/wav', mid: 'audio/midi', midi: 'audio/midi'
  };
  var LABEL = { docx: 'Word document', xlsx: 'Excel spreadsheet', pptx: 'PowerPoint', pdf: 'PDF document', png: 'PNG image', jpg: 'JPEG image', jpeg: 'JPEG image', webp: 'WebP image', odt: 'OpenDocument text', ods: 'OpenDocument spreadsheet', odp: 'OpenDocument presentation', epub: 'E-book', rtf: 'Rich Text document', dotx: 'Word template', docm: 'Word macro document', doc: 'Word 97-2003 document', xltx: 'Excel template', xlsm: 'Excel macro workbook', xls: 'Excel 97-2003 workbook', ppsx: 'PowerPoint slideshow', potx: 'PowerPoint template', pptm: 'PowerPoint macro presentation', bmp: 'BMP image', gif: 'GIF image', ico: 'Icon', tiff: 'TIFF image', tif: 'TIFF image', mp4: 'MP4 video', mov: 'QuickTime video', webm: 'WebM video', mkv: 'MKV video', mp3: 'MP3 audio', m4a: 'M4A audio', aac: 'AAC audio', ogg: 'OGG audio', oga: 'OGG audio', opus: 'Opus audio', flac: 'FLAC audio', wav: 'WAV audio', mid: 'MIDI audio', midi: 'MIDI audio' };
  var extOf = function (n) { return String(n || '').split('.').pop().toLowerCase(); };
  var isBin = function (n) { return Object.prototype.hasOwnProperty.call(MIME, extOf(n)) && String(n || '').indexOf('.') > 0; };

  /* ---------- helpers ---------- */
  var esc = function (s) {
    return String(s == null ? '' : s).replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f￾￿]/g, '')
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  };
  var XML = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n';

  /* ---------- zip (store only, bytes) ---------- */
  var CRCT = (function () { var t = new Uint32Array(256); for (var n = 0; n < 256; n++) { var c = n; for (var k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
  function crc32(u) { var c = 0xFFFFFFFF; for (var i = 0; i < u.length; i++) c = CRCT[(c ^ u[i]) & 255] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; }
  function zipBlob(files, mime) {
    var parts = [], cd = [], d = new Date(), off = 0;
    var dt = ((Math.max(d.getFullYear(), 1980) - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate();
    var tm = (d.getHours() << 11) | (d.getMinutes() << 5) | (d.getSeconds() >> 1);
    files.forEach(function (f) {
      var nm = te.encode(f.name), data = typeof f.data === 'string' ? te.encode(f.data) : f.data, crc = crc32(data);
      var h = new DataView(new ArrayBuffer(30));
      h.setUint32(0, 0x04034b50, true); h.setUint16(4, 20, true); h.setUint16(6, 0x0800, true); h.setUint16(10, tm, true); h.setUint16(12, dt, true);
      h.setUint32(14, crc, true); h.setUint32(18, data.length, true); h.setUint32(22, data.length, true); h.setUint16(26, nm.length, true);
      parts.push(new Uint8Array(h.buffer), nm, data);
      var c = new DataView(new ArrayBuffer(46));
      c.setUint32(0, 0x02014b50, true); c.setUint16(4, 20, true); c.setUint16(6, 20, true); c.setUint16(8, 0x0800, true); c.setUint16(12, tm, true); c.setUint16(14, dt, true);
      c.setUint32(16, crc, true); c.setUint32(20, data.length, true); c.setUint32(24, data.length, true); c.setUint16(28, nm.length, true); c.setUint32(42, off, true);
      cd.push(new Uint8Array(c.buffer), nm); off += 30 + nm.length + data.length;
    });
    var cs = 0; cd.forEach(function (x) { cs += x.length; });
    var e = new DataView(new ArrayBuffer(22));
    e.setUint32(0, 0x06054b50, true); e.setUint16(8, files.length, true); e.setUint16(10, files.length, true); e.setUint32(12, cs, true); e.setUint32(16, off, true);
    return new Blob(parts.concat(cd, [new Uint8Array(e.buffer)]), { type: mime || 'application/zip' });
  }

  /* ---------- Markdown parser (shared by Word, PowerPoint, PDF) ---------- */
  function inl(s, base) {
    base = base || {};
    s = String(s).replace(/<br\s*\/?>/gi, ' ');
    var out = [], re = /\*\*\*(.+?)\*\*\*|\*\*(.+?)\*\*|\*(?![\s*])(.+?)(?<![\s*])\*|~~(.+?)~~|`([^`]+)`|\[([^\]]+)\]\(([^)\s]+)\)/g, last = 0, m;
    var plain = function (t) { if (t) out.push(Object.assign({}, base, { t: t.replace(/\\([*_`~\[\]#|\\>-])/g, '$1') })); };
    while ((m = re.exec(s))) {
      plain(s.slice(last, m.index));
      if (m[1] != null) out.push.apply(out, inl(m[1], Object.assign({}, base, { b: 1, i: 1 })));
      else if (m[2] != null) out.push.apply(out, inl(m[2], Object.assign({}, base, { b: 1 })));
      else if (m[3] != null) out.push.apply(out, inl(m[3], Object.assign({}, base, { i: 1 })));
      else if (m[4] != null) out.push.apply(out, inl(m[4], Object.assign({}, base, { s: 1 })));
      else if (m[5] != null) out.push(Object.assign({}, base, { t: m[5], c: 1 }));
      else if (m[6] != null) { out.push.apply(out, inl(m[6], base)); if (/^https?:/i.test(m[7]) && m[6].trim() !== m[7]) out.push(Object.assign({}, base, { t: ' (' + m[7] + ')' })); }
      last = m.index + m[0].length;
    }
    plain(s.slice(last));
    return out;
  }
  var SEP = /^\s*\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?\s*$/;
  var splitRow = function (s) {
    s = s.trim().replace(/^\|/, '').replace(/\|$/, '');
    return s.split(/(?<!\\)\|/).map(function (c) { return c.trim().replace(/\\\|/g, '|'); });
  };
  function parseMd(src) {
    var L = String(src == null ? '' : src).replace(/\r\n?/g, '\n').replace(/\t/g, '    ').split('\n'), out = [], i = 0, m;
    var starter = function (s) { return /^\s*(`{3,}|~{3,}|#{1,6}\s|>|[-*•+]\s|\d+[.)]\s|\|)/.test(s) || /^\s*([-*_])(\s*\1){2,}\s*$/.test(s); };
    while (i < L.length) {
      var s = L[i];
      if ((m = s.match(/^\s*(`{3,}|~{3,})/))) {
        var fc = m[1][0], fn = m[1].length, b = [], cl = new RegExp('^\\s*' + (fc === '`' ? '`' : '~') + '{' + fn + ',}\\s*$');
        i++; while (i < L.length && !cl.test(L[i])) b.push(L[i++]); i++;
        out.push({ t: 'code', text: b.join('\n') }); continue;
      }
      if (!s.trim()) { i++; continue; }
      if ((m = s.match(/^(#{1,6})\s+(.*?)\s*#*\s*$/))) { out.push({ t: 'h', l: Math.min(m[1].length, 3), r: inl(m[2]) }); i++; continue; }
      if (/^\s*([-*_])(\s*\1){2,}\s*$/.test(s)) { out.push({ t: 'hr' }); i++; continue; }
      if (/^\s*\|/.test(s) || (s.indexOf('|') > 0 && L[i + 1] && SEP.test(L[i + 1]) && L[i + 1].indexOf('-') >= 0)) {
        var rows = [], head = false;
        while (i < L.length && L[i].trim() && L[i].indexOf('|') >= 0) {
          if (SEP.test(L[i]) && L[i].indexOf('-') >= 0) { if (rows.length === 1) head = true; i++; continue; }
          rows.push(splitRow(L[i]).map(function (c) { return inl(c); })); i++;
        }
        var w = 0; rows.forEach(function (r) { w = Math.max(w, r.length); });
        rows.forEach(function (r) { while (r.length < w) r.push([]); });
        if (rows.length) out.push({ t: 'table', rows: rows, head: head || rows.length > 1 });
        continue;
      }
      if ((m = s.match(/^(\s*)([-*•+]|\d+[.)])\s+(.*)$/))) {
        var txt = m[3], ck = txt.match(/^\[([ xX])\]\s+(.*)$/);
        if (ck) txt = (ck[1] === ' ' ? '☐ ' : '☑ ') + ck[2];
        out.push({ t: 'li', lvl: Math.min(2, Math.floor(m[1].length / 2)), ord: /\d/.test(m[2]), n: parseInt(m[2], 10) || 1, r: inl(txt) }); i++; continue;
      }
      if (/^\s*>/.test(s)) {
        var q = []; while (i < L.length && /^\s*>/.test(L[i])) q.push(L[i++].replace(/^\s*>\s?/, ''));
        out.push({ t: 'q', r: inl(q.join(' ')) }); continue;
      }
      var p = [s.trim()]; i++;
      while (i < L.length && L[i].trim() && !starter(L[i])) p.push(L[i++].trim());
      out.push({ t: 'p', r: inl(p.join(' ')) });
    }
    return out;
  }
  var plainOf = function (runs) { return (runs || []).map(function (r) { return r.t; }).join(''); };

  /* ============================== DOCX ============================== */
  var WNS = 'xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"';
  function wRuns(runs, o) {
    o = o || {};
    return runs.map(function (r) {
      var p = '';
      if (r.c) p += '<w:rFonts w:ascii="Consolas" w:hAnsi="Consolas" w:cs="Consolas"/>';
      if (r.b || o.b) p += '<w:b/><w:bCs/>';
      if (r.i || o.i) p += '<w:i/><w:iCs/>';
      if (r.s) p += '<w:strike/>';
      if (o.color) p += '<w:color w:val="' + o.color + '"/>';
      if (r.c) p += '<w:sz w:val="20"/><w:szCs w:val="20"/><w:shd w:val="clear" w:color="auto" w:fill="F2F2F2"/>';
      return '<w:r>' + (p ? '<w:rPr>' + p + '</w:rPr>' : '') + '<w:t xml:space="preserve">' + esc(r.t) + '</w:t></w:r>';
    }).join('');
  }
  function buildDocx(text) {
    var blocks = parseMd(text), body = [], nums = [], curOrd = 0, nextNum = 2;
    var para = function (runs, pp, o) { return '<w:p>' + (pp ? '<w:pPr>' + pp + '</w:pPr>' : '') + wRuns(runs, o) + '</w:p>'; };
    blocks.forEach(function (b) {
      if (b.t !== 'li' || !b.ord) { if (b.t !== 'li') curOrd = 0; }
      if (b.t === 'h') body.push(para(b.r, '<w:pStyle w:val="Heading' + b.l + '"/>'));
      else if (b.t === 'p') body.push(para(b.r, ''));
      else if (b.t === 'li') {
        var id = 1;
        if (b.ord) { if (!curOrd) { curOrd = nextNum++; nums.push(curOrd); } id = curOrd; } else curOrd = 0;
        body.push(para(b.r, '<w:pStyle w:val="ListParagraph"/><w:numPr><w:ilvl w:val="' + b.lvl + '"/><w:numId w:val="' + id + '"/></w:numPr>'));
      }
      else if (b.t === 'q') body.push(para(b.r, '<w:pStyle w:val="Quote"/>'));
      else if (b.t === 'hr') body.push('<w:p><w:pPr><w:pBdr><w:bottom w:val="single" w:sz="6" w:space="1" w:color="A6A6A6"/></w:pBdr></w:pPr></w:p>');
      else if (b.t === 'code') {
        var ls = b.text.split('\n');
        ls.forEach(function (l, k) { body.push('<w:p><w:pPr><w:pStyle w:val="CodeBlock"/>' + (k === ls.length - 1 ? '<w:spacing w:after="160"/>' : '') + '</w:pPr><w:r><w:t xml:space="preserve">' + esc(l) + '</w:t></w:r></w:p>'); });
      }
      else if (b.t === 'table') {
        var n = b.rows[0].length, tw = 9026, cw = Math.floor(tw / n);
        var x = '<w:tbl><w:tblPr><w:tblStyle w:val="TableGrid"/><w:tblW w:w="' + tw + '" w:type="dxa"/><w:tblBorders>' +
          ['top', 'left', 'bottom', 'right', 'insideH', 'insideV'].map(function (k) { return '<w:' + k + ' w:val="single" w:sz="4" w:space="0" w:color="BFBFBF"/>'; }).join('') +
          '</w:tblBorders><w:tblLayout w:type="fixed"/><w:tblCellMar><w:top w:w="60" w:type="dxa"/><w:left w:w="100" w:type="dxa"/><w:bottom w:w="60" w:type="dxa"/><w:right w:w="100" w:type="dxa"/></w:tblCellMar></w:tblPr><w:tblGrid>';
        for (var g = 0; g < n; g++) x += '<w:gridCol w:w="' + cw + '"/>';
        x += '</w:tblGrid>';
        b.rows.forEach(function (row, ri) {
          var hd = b.head && ri === 0;
          x += '<w:tr>' + (hd ? '<w:trPr><w:tblHeader/></w:trPr>' : '');
          row.forEach(function (cell) {
            x += '<w:tc><w:tcPr><w:tcW w:w="' + cw + '" w:type="dxa"/>' + (hd ? '<w:shd w:val="clear" w:color="auto" w:fill="D9E2F3"/>' : '') + '</w:tcPr>' +
              para(cell.length ? cell : [{ t: '' }], '<w:spacing w:before="0" w:after="0"/>', { b: hd }) + '</w:tc>';
          });
          x += '</w:tr>';
        });
        body.push(x + '</w:tbl>', '<w:p><w:pPr><w:spacing w:after="0"/></w:pPr></w:p>');
      }
    });
    if (!body.length) body.push('<w:p/>');
    var doc = XML + '<w:document ' + WNS + '><w:body>' + body.join('') +
      '<w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1440" w:right="1440" w:bottom="1440" w:left="1440" w:header="708" w:footer="708" w:gutter="0"/></w:sectPr></w:body></w:document>';
    var hs = function (id, name, sz, before) {
      return '<w:style w:type="paragraph" w:styleId="Heading' + id + '"><w:name w:val="heading ' + id + '"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/>' +
        '<w:pPr><w:keepNext/><w:keepLines/><w:spacing w:before="' + before + '" w:after="120"/><w:outlineLvl w:val="' + (id - 1) + '"/></w:pPr>' +
        '<w:rPr><w:b/><w:bCs/><w:color w:val="1F3864"/><w:sz w:val="' + sz + '"/><w:szCs w:val="' + sz + '"/></w:rPr></w:style>';
    };
    var styles = XML + '<w:styles ' + WNS + '><w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="Calibri" w:hAnsi="Calibri" w:eastAsia="Calibri" w:cs="Nirmala UI"/><w:sz w:val="22"/><w:szCs w:val="22"/><w:lang w:val="en-US" w:eastAsia="en-US" w:bidi="ta-IN"/></w:rPr></w:rPrDefault>' +
      '<w:pPrDefault><w:pPr><w:spacing w:after="120" w:line="276" w:lineRule="auto"/></w:pPr></w:pPrDefault></w:docDefaults>' +
      '<w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/><w:qFormat/></w:style>' +
      hs(1, 'Heading 1', 36, 360) + hs(2, 'Heading 2', 30, 280) + hs(3, 'Heading 3', 26, 200) +
      '<w:style w:type="paragraph" w:styleId="ListParagraph"><w:name w:val="List Paragraph"/><w:basedOn w:val="Normal"/><w:qFormat/><w:pPr><w:spacing w:after="60"/><w:contextualSpacing/></w:pPr></w:style>' +
      '<w:style w:type="paragraph" w:styleId="Quote"><w:name w:val="Quote"/><w:basedOn w:val="Normal"/><w:qFormat/><w:pPr><w:pBdr><w:left w:val="single" w:sz="18" w:space="8" w:color="A6B4C8"/></w:pBdr><w:ind w:left="567"/></w:pPr><w:rPr><w:i/><w:iCs/><w:color w:val="595959"/></w:rPr></w:style>' +
      '<w:style w:type="paragraph" w:styleId="CodeBlock"><w:name w:val="Code Block"/><w:basedOn w:val="Normal"/><w:pPr><w:shd w:val="clear" w:color="auto" w:fill="F2F2F2"/><w:spacing w:before="0" w:after="0" w:line="240" w:lineRule="auto"/><w:ind w:left="170" w:right="170"/></w:pPr><w:rPr><w:rFonts w:ascii="Consolas" w:hAnsi="Consolas" w:cs="Consolas"/><w:sz w:val="19"/><w:szCs w:val="19"/></w:rPr></w:style>' +
      '<w:style w:type="table" w:default="1" w:styleId="TableNormal"><w:name w:val="Normal Table"/><w:uiPriority w:val="99"/><w:semiHidden/><w:tblPr><w:tblInd w:w="0" w:type="dxa"/><w:tblCellMar><w:top w:w="0" w:type="dxa"/><w:left w:w="108" w:type="dxa"/><w:bottom w:w="0" w:type="dxa"/><w:right w:w="108" w:type="dxa"/></w:tblCellMar></w:tblPr></w:style>' +
      '<w:style w:type="table" w:styleId="TableGrid"><w:name w:val="Table Grid"/><w:basedOn w:val="TableNormal"/><w:tblPr><w:tblBorders><w:top w:val="single" w:sz="4" w:space="0" w:color="auto"/><w:left w:val="single" w:sz="4" w:space="0" w:color="auto"/><w:bottom w:val="single" w:sz="4" w:space="0" w:color="auto"/><w:right w:val="single" w:sz="4" w:space="0" w:color="auto"/><w:insideH w:val="single" w:sz="4" w:space="0" w:color="auto"/><w:insideV w:val="single" w:sz="4" w:space="0" w:color="auto"/></w:tblBorders></w:tblPr></w:style></w:styles>';
    var lvl = function (i, fmt, txt) {
      return '<w:lvl w:ilvl="' + i + '"><w:start w:val="1"/><w:numFmt w:val="' + fmt + '"/><w:lvlText w:val="' + txt + '"/><w:lvlJc w:val="left"/><w:pPr><w:ind w:left="' + (720 + 360 * i) + '" w:hanging="360"/></w:pPr></w:lvl>';
    };
    var numbering = XML + '<w:numbering ' + WNS + '>' +
      '<w:abstractNum w:abstractNumId="0"><w:multiLevelType w:val="hybridMultilevel"/>' + lvl(0, 'bullet', '•') + lvl(1, 'bullet', '◦') + lvl(2, 'bullet', '▪') + '</w:abstractNum>' +
      '<w:abstractNum w:abstractNumId="1"><w:multiLevelType w:val="hybridMultilevel"/>' + lvl(0, 'decimal', '%1.') + lvl(1, 'lowerLetter', '%2.') + lvl(2, 'lowerRoman', '%3.') + '</w:abstractNum>' +
      '<w:num w:numId="1"><w:abstractNumId w:val="0"/></w:num>' +
      nums.map(function (id) { return '<w:num w:numId="' + id + '"><w:abstractNumId w:val="1"/><w:lvlOverride w:ilvl="0"><w:startOverride w:val="1"/></w:lvlOverride></w:num>'; }).join('') + '</w:numbering>';
    var title = '';
    for (var k = 0; k < blocks.length; k++) if (blocks[k].t === 'h') { title = plainOf(blocks[k].r); break; }
    return zipBlob([
      { name: '[Content_Types].xml', data: XML + '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="' + ctm('docx') + '"/><Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/><Override PartName="/word/numbering.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.numbering+xml"/><Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/></Types>' },
      { name: '_rels/.rels', data: XML + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/></Relationships>' },
      { name: 'docProps/core.xml', data: XML + '<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:title>' + esc(title) + '</dc:title><dc:creator>Zen Ai</dc:creator><dcterms:created xsi:type="dcterms:W3CDTF">' + new Date().toISOString().replace(/\.\d+Z$/, 'Z') + '</dcterms:created></cp:coreProperties>' },
      { name: 'word/_rels/document.xml.rels', data: XML + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/numbering" Target="numbering.xml"/></Relationships>' },
      { name: 'word/document.xml', data: doc }, { name: 'word/styles.xml', data: styles }, { name: 'word/numbering.xml', data: numbering }
    ], MIME.docx);
  }

  /* ============================== XLSX ============================== */
  function parseCsv(t) {
    t = String(t).replace(/^﻿/, '');
    var first = t.split('\n').slice(0, 5).join('\n'), d = ',';
    var cnt = function (c) { return (first.match(new RegExp(c === '\t' ? '\\t' : '\\' + c, 'g')) || []).length; };
    if (cnt('\t') > cnt(d)) d = '\t'; else if (cnt(';') > cnt(d)) d = ';';
    var rows = [], row = [], cell = '', q = false, i = 0, n = t.length;
    for (; i < n; i++) {
      var ch = t[i];
      if (q) { if (ch === '"') { if (t[i + 1] === '"') { cell += '"'; i++; } else q = false; } else cell += ch; }
      else if (ch === '"' && cell === '') q = true;
      else if (ch === d) { row.push(cell); cell = ''; }
      else if (ch === '\n' || ch === '\r') { if (ch === '\r' && t[i + 1] === '\n') i++; row.push(cell); cell = ''; rows.push(row); row = []; }
      else cell += ch;
    }
    if (cell !== '' || row.length) { row.push(cell); rows.push(row); }
    while (rows.length && rows[rows.length - 1].every(function (c) { return c === ''; })) rows.pop();
    return rows;
  }
  function parseSheets(text) {
    var src = String(text == null ? '' : text).replace(/\r\n?/g, '\n').replace(/^\s*```[^\n]*\n([\s\S]*?)\n```\s*$/, '$1');
    var tr = src.trim(), sheets = [];
    if (/^[\[{]/.test(tr)) {
      try {
        var j = JSON.parse(tr);
        var fromArr = function (a) {
          if (!Array.isArray(a) || !a.length) return [];
          if (Array.isArray(a[0])) return a;
          if (a[0] && typeof a[0] === 'object') { var ks = []; a.forEach(function (o) { Object.keys(o).forEach(function (k) { if (ks.indexOf(k) < 0) ks.push(k); }); }); return [ks].concat(a.map(function (o) { return ks.map(function (k) { return o[k] == null ? '' : o[k]; }); })); }
          return a.map(function (v) { return [v]; });
        };
        if (Array.isArray(j)) sheets.push({ name: 'Sheet1', rows: fromArr(j) });
        else if (Array.isArray(j.sheets)) j.sheets.forEach(function (s, k) { sheets.push({ name: s.name || 'Sheet' + (k + 1), rows: fromArr(s.rows || s.data || []) }); });
        else Object.keys(j).forEach(function (k) { sheets.push({ name: k, rows: fromArr(j[k]) }); });
        if (sheets.length) return sheets;
      } catch (e) { sheets = []; }
    }
    var parts = [], cur = { name: 'Sheet1', lines: [] }, hasMark = false;
    src.split('\n').forEach(function (l) {
      var m = l.match(/^#{1,3}\s*(?:sheet\s*[:\-]\s*)?(.+?)\s*$/i);
      if (m) {
        if (cur.lines.some(function (x) { return x.trim(); })) parts.push(cur);
        cur = { name: m[1].replace(/^["'`]|["'`]$/g, ''), lines: [] }; hasMark = true;
      } else cur.lines.push(l);
    });
    parts.push(cur);
    if (!hasMark) parts = [{ name: 'Sheet1', lines: src.split('\n') }];
    parts.forEach(function (p) {
      var body = p.lines.join('\n').replace(/^\s*```[^\n]*\n([\s\S]*?)\n?```\s*$/, '$1').trim(), rows;
      if (/^\|/.test(body)) rows = body.split('\n').filter(function (l) { return l.trim() && !(SEP.test(l) && l.indexOf('-') >= 0); }).map(function (l) { return splitRow(l).map(function (c) { return plainOf(inl(c)); }); });
      else rows = parseCsv(body);
      if (rows.length || !sheets.length) sheets.push({ name: p.name, rows: rows });
    });
    return sheets;
  }
  var colName = function (i) { var s = ''; i++; while (i > 0) { var m = (i - 1) % 26; s = String.fromCharCode(65 + m) + s; i = Math.floor((i - 1) / 26); } return s; };
  var NUM = /^[-+]?(\d+\.?\d*|\.\d+)([eE][-+]?\d+)?$/;
  function buildXlsx(text) {
    var sheets = parseSheets(text), used = {};
    if (!sheets.length) sheets = [{ name: 'Sheet1', rows: [] }];
    sheets = sheets.map(function (s, k) {
      var n = String(s.name || 'Sheet' + (k + 1)).replace(/[\[\]:*?\/\\]/g, ' ').trim().slice(0, 31) || 'Sheet' + (k + 1), base = n, c = 2;
      while (used[n.toLowerCase()]) { n = base.slice(0, 28) + ' ' + c++; }
      used[n.toLowerCase()] = 1; return { name: n, rows: s.rows };
    });
    var sheetXml = sheets.map(function (s) {
      var rows = s.rows, w = 0; rows.forEach(function (r) { w = Math.max(w, r.length); });
      var hdr = rows.length > 1 && rows[0].length > 0 && rows[0].every(function (c) { c = String(c == null ? '' : c).trim(); return c !== '' && !NUM.test(c) && c[0] !== '='; });
      var widths = []; for (var c0 = 0; c0 < w; c0++) widths[c0] = 8;
      var sd = rows.map(function (r, ri) {
        var cells = '';
        r.forEach(function (v, ci) {
          var raw = v == null ? '' : String(v), t = raw.trim(), ref = colName(ci) + (ri + 1), st = hdr && ri === 0 ? ' s="1"' : '';
          var len = 0; raw.split('\n').forEach(function (l) { len = Math.max(len, Array.from(l).length); });
          widths[ci] = Math.max(widths[ci], Math.min(60, len * 1.15 + 2));
          if (t === '') return;
          if (t[0] === '=' && t.length > 1) cells += '<c r="' + ref + '"' + st + '><f>' + esc(t.slice(1)) + '</f></c>';
          else if (NUM.test(t) && !/^[-+]?0\d/.test(t) && t.replace(/\D/g, '').length < 16) cells += '<c r="' + ref + '"' + st + '><v>' + t + '</v></c>';
          else if (/^[-+]?\d+(\.\d+)?%$/.test(t)) cells += '<c r="' + ref + '" s="2"><v>' + (parseFloat(t) / 100) + '</v></c>';
          else cells += '<c r="' + ref + '"' + (st || (raw.indexOf('\n') >= 0 ? ' s="3"' : '')) + ' t="inlineStr"><is><t xml:space="preserve">' + esc(raw) + '</t></is></c>';
        });
        return '<row r="' + (ri + 1) + '">' + cells + '</row>';
      }).join('');
      return XML + '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">' +
        '<dimension ref="A1' + (w && rows.length ? ':' + colName(w - 1) + rows.length : '') + '"/>' +
        '<sheetViews><sheetView workbookViewId="0">' + (hdr ? '<pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/>' : '') + '</sheetView></sheetViews><sheetFormatPr defaultRowHeight="15"/>' +
        (w ? '<cols>' + widths.map(function (x, i) { return '<col min="' + (i + 1) + '" max="' + (i + 1) + '" width="' + x.toFixed(1) + '" customWidth="1"/>'; }).join('') + '</cols>' : '') +
        '<sheetData>' + sd + '</sheetData>' + (hdr && w ? '<autoFilter ref="A1:' + colName(w - 1) + rows.length + '"/>' : '') + '</worksheet>';
    });
    var styles = XML + '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">' +
      '<fonts count="2"><font><sz val="11"/><name val="Calibri"/><family val="2"/></font><font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/><family val="2"/></font></fonts>' +
      '<fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF1F4E78"/><bgColor indexed="64"/></patternFill></fill></fills>' +
      '<borders count="2"><border><left/><right/><top/><bottom/><diagonal/></border><border><left style="thin"><color rgb="FFBFBFBF"/></left><right style="thin"><color rgb="FFBFBFBF"/></right><top style="thin"><color rgb="FFBFBFBF"/></top><bottom style="thin"><color rgb="FFBFBFBF"/></bottom><diagonal/></border></borders>' +
      '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>' +
      '<cellXfs count="4"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment vertical="center" wrapText="1"/></xf><xf numFmtId="9" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment vertical="top" wrapText="1"/></xf></cellXfs>' +
      '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>';
    var files = [
      { name: '[Content_Types].xml', data: XML + '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="' + ctm('xlsx') + '"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>' + sheets.map(function (_, i) { return '<Override PartName="/xl/worksheets/sheet' + (i + 1) + '.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'; }).join('') + '</Types>' },
      { name: '_rels/.rels', data: XML + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>' },
      { name: 'xl/workbook.xml', data: XML + '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><bookViews><workbookView/></bookViews><sheets>' + sheets.map(function (s, i) { return '<sheet name="' + esc(s.name) + '" sheetId="' + (i + 1) + '" r:id="rId' + (i + 1) + '"/>'; }).join('') + '</sheets><calcPr calcId="191029" fullCalcOnLoad="1"/></workbook>' },
      { name: 'xl/_rels/workbook.xml.rels', data: XML + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' + sheets.map(function (_, i) { return '<Relationship Id="rId' + (i + 1) + '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet' + (i + 1) + '.xml"/>'; }).join('') + '<Relationship Id="rId' + (sheets.length + 1) + '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>' },
      { name: 'xl/styles.xml', data: styles }
    ];
    sheetXml.forEach(function (x, i) { files.push({ name: 'xl/worksheets/sheet' + (i + 1) + '.xml', data: x }); });
    return zipBlob(files, MIME.xlsx);
  }

  /* ============================== PPTX ============================== */
  var EMU = { W: 12192000, H: 6858000, MX: 640080 };
  var PNS = 'xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"';
  var GRP = '<p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr>';
  function aRuns(runs, sz, color, bold) {
    return runs.map(function (r) {
      return '<a:r><a:rPr lang="en-US" sz="' + (r.c ? Math.round(sz * 0.9) : sz) + '"' + (r.b || bold ? ' b="1"' : '') + (r.i ? ' i="1"' : '') + (r.s ? ' strike="sngStrike"' : '') + ' dirty="0"><a:solidFill><a:srgbClr val="' + color + '"/></a:solidFill>' + (r.c ? '<a:latin typeface="Consolas"/>' : '') + '</a:rPr><a:t>' + esc(r.t) + '</a:t></a:r>';
    }).join('');
  }
  function aPara(runs, o) {
    var ind = o.bullet ? (o.lvl ? 685800 : 342900) : 0, mar = o.bullet ? (o.lvl ? 685800 + 228600 : 342900) : 0;
    return '<a:p><a:pPr marL="' + (o.bullet ? mar : 0) + '" indent="' + (o.bullet ? -342900 : 0) + '"' + (o.algn ? ' algn="' + o.algn + '"' : '') + '><a:spcBef><a:spcPts val="' + (o.before == null ? 600 : o.before) + '"/></a:spcBef>' +
      (o.bullet ? '<a:buClr><a:srgbClr val="2E75B6"/></a:buClr><a:buFont typeface="Arial"/><a:buChar char="' + (o.lvl ? '–' : '•') + '"/>' : '<a:buNone/>') + '</a:pPr>' +
      aRuns(runs, o.sz, o.color, o.b) + '<a:endParaRPr lang="en-US" sz="' + o.sz + '" dirty="0"/></a:p>';
  }
  function parseSlides(text) {
    var src = String(text == null ? '' : text).replace(/\r\n?/g, '\n'), chunks;
    if (/^\s*(-{3,}|\*{3,}|_{3,})\s*$/m.test(src)) chunks = src.split(/^\s*(?:-{3,}|\*{3,}|_{3,})\s*$/m);
    else chunks = src.split(/\n(?=#{1,2}\s)/);
    var slides = [];
    chunks.forEach(function (ch) {
      var bl = parseMd(ch); if (!bl.length) return;
      var title = '', ti = -1;
      for (var i = 0; i < bl.length; i++) if (bl[i].t === 'h') { title = bl[i]; ti = i; break; }
      var rest = bl.filter(function (_, k) { return k !== ti; });
      slides.push({ title: title ? title.r : [], lvl: title ? title.l : 0, blocks: rest });
    });
    if (!slides.length) slides.push({ title: [{ t: 'Untitled' }], lvl: 1, blocks: [] });
    var out = [];
    slides.forEach(function (s, idx) {
      var cover = idx === 0 && !s.blocks.some(function (b) { return b.t === 'li' || b.t === 'table'; });
      if (cover) { out.push({ cover: true, title: s.title, blocks: s.blocks }); return; }
      var tbl = s.blocks.filter(function (b) { return b.t === 'table'; })[0], txt = s.blocks.filter(function (b) { return b.t !== 'table' && b.t !== 'hr'; });
      if (tbl || txt.length <= 7) { out.push({ title: s.title, blocks: txt, table: tbl }); return; }
      for (var k = 0; k < txt.length; k += 7) out.push({ title: k ? s.title.concat([{ t: ' (cont.)' }]) : s.title, blocks: txt.slice(k, k + 7) });
    });
    return out;
  }
  function slideXml(s) {
    var id = 1, sp = [], nid = function () { return ++id; };
    var title = s.title.length ? s.title : [{ t: '' }];
    if (s.cover) {
      sp.push('<p:sp><p:nvSpPr><p:cNvPr id="' + nid() + '" name="Title"/><p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr><p:nvPr><p:ph type="title"/></p:nvPr></p:nvSpPr><p:spPr><a:xfrm><a:off x="' + EMU.MX + '" y="1900000"/><a:ext cx="10911840" cy="1700000"/></a:xfrm></p:spPr><p:txBody><a:bodyPr anchor="b"><a:normAutofit/></a:bodyPr><a:lstStyle/>' + aPara(title, { sz: 4400, color: 'FFFFFF', b: 1, before: 0 }) + '</p:txBody></p:sp>');
      sp.push('<p:sp><p:nvSpPr><p:cNvPr id="' + nid() + '" name="Accent"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr><p:spPr><a:xfrm><a:off x="' + EMU.MX + '" y="3750000"/><a:ext cx="1400000" cy="60000"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom><a:solidFill><a:srgbClr val="5BA3E0"/></a:solidFill><a:ln><a:noFill/></a:ln></p:spPr></p:sp>');
      var sub = s.blocks.filter(function (b) { return b.t === 'p' || b.t === 'q' || b.t === 'h'; });
      if (sub.length) sp.push('<p:sp><p:nvSpPr><p:cNvPr id="' + nid() + '" name="Subtitle"/><p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr><p:nvPr><p:ph idx="1"/></p:nvPr></p:nvSpPr><p:spPr><a:xfrm><a:off x="' + EMU.MX + '" y="3950000"/><a:ext cx="10911840" cy="1500000"/></a:xfrm></p:spPr><p:txBody><a:bodyPr><a:normAutofit/></a:bodyPr><a:lstStyle/>' +
        sub.map(function (b) { return aPara(b.r, { sz: 2200, color: 'C9D6EA', before: 300 }); }).join('') + '</p:txBody></p:sp>');
      return XML + '<p:sld ' + PNS + '><p:cSld><p:bg><p:bgPr><a:solidFill><a:srgbClr val="1F3864"/></a:solidFill><a:effectLst/></p:bgPr></p:bg><p:spTree>' + GRP + sp.join('') + '</p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sld>';
    }
    sp.push('<p:sp><p:nvSpPr><p:cNvPr id="' + nid() + '" name="Title"/><p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr><p:nvPr><p:ph type="title"/></p:nvPr></p:nvSpPr><p:spPr><a:xfrm><a:off x="' + EMU.MX + '" y="380000"/><a:ext cx="10911840" cy="900000"/></a:xfrm></p:spPr><p:txBody><a:bodyPr anchor="ctr"><a:normAutofit/></a:bodyPr><a:lstStyle/>' + aPara(title, { sz: 3200, color: '1F3864', b: 1, before: 0 }) + '</p:txBody></p:sp>');
    sp.push('<p:sp><p:nvSpPr><p:cNvPr id="' + nid() + '" name="Accent"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr><p:spPr><a:xfrm><a:off x="' + EMU.MX + '" y="1300000"/><a:ext cx="1200000" cy="54000"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom><a:solidFill><a:srgbClr val="2E75B6"/></a:solidFill><a:ln><a:noFill/></a:ln></p:spPr></p:sp>');
    var n = s.blocks.length, chars = 0;
    s.blocks.forEach(function (b) { chars += b.t === 'code' ? b.text.length : plainOf(b.r).length; });
    var sz = (n <= 3 && chars < 220) ? 3000 : (n <= 5 && chars < 420) ? 2600 : (n <= 7 && chars < 700) ? 2200 : 1800;
    if (n || !s.table) {
      var bh = s.table ? Math.min(2100000, 650000 + n * 420000) : 4700000, paras = '';
      s.blocks.forEach(function (b) {
        if (b.t === 'li') paras += aPara(b.r, { sz: b.lvl ? sz - 200 : sz, color: '262626', bullet: 1, lvl: b.lvl });
        else if (b.t === 'code') b.text.split('\n').forEach(function (l) { paras += aPara([{ t: l, c: 1 }], { sz: sz - 400, color: '404040', before: 0 }); });
        else if (b.t === 'h') paras += aPara(b.r, { sz: sz, color: '1F3864', b: 1 });
        else if (b.t === 'q') paras += aPara(b.r.map(function (r) { return Object.assign({}, r, { i: 1 }); }), { sz: sz, color: '595959' });
        else paras += aPara(b.r, { sz: sz, color: '262626' });
      });
      if (paras) sp.push('<p:sp><p:nvSpPr><p:cNvPr id="' + nid() + '" name="Content"/><p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr><p:nvPr><p:ph idx="1"/></p:nvPr></p:nvSpPr><p:spPr><a:xfrm><a:off x="' + EMU.MX + '" y="1550000"/><a:ext cx="10911840" cy="' + bh + '"/></a:xfrm></p:spPr><p:txBody><a:bodyPr><a:normAutofit/></a:bodyPr><a:lstStyle/>' + paras + '</p:txBody></p:sp>');
      if (s.table) s.tableTop = 1550000 + (paras ? bh + 100000 : 0);
    }
    if (s.table) {
      var rows = s.table.rows, cols = rows[0].length, cw = Math.floor(10911840 / cols), fs = cols <= 3 ? 1800 : cols <= 5 ? 1600 : 1200;
      var ln = function (t) { return '<a:' + t + ' w="9525"><a:solidFill><a:srgbClr val="BFBFBF"/></a:solidFill></a:' + t + '>'; };
      var tr = rows.map(function (row, ri) {
        var hd = s.table.head && ri === 0;
        return '<a:tr h="400000">' + row.map(function (cell) {
          return '<a:tc><a:txBody><a:bodyPr/><a:lstStyle/><a:p><a:pPr><a:buNone/></a:pPr>' + aRuns(cell.length ? cell : [{ t: '' }], fs, hd ? 'FFFFFF' : '262626', hd) + '<a:endParaRPr lang="en-US" sz="' + fs + '" dirty="0"/></a:p></a:txBody><a:tcPr marL="91440" marR="91440" marT="45720" marB="45720" anchor="ctr">' + ln('lnL') + ln('lnR') + ln('lnT') + ln('lnB') + '<a:solidFill><a:srgbClr val="' + (hd ? '1F4E78' : (ri % 2 ? 'F3F6FA' : 'FFFFFF')) + '"/></a:solidFill></a:tcPr></a:tc>';
        }).join('') + '</a:tr>';
      }).join('');
      var gx = ''; for (var g = 0; g < cols; g++) gx += '<a:gridCol w="' + cw + '"/>';
      sp.push('<p:graphicFrame><p:nvGraphicFramePr><p:cNvPr id="' + nid() + '" name="Table"/><p:cNvGraphicFramePr><a:graphicFrameLocks noGrp="1"/></p:cNvGraphicFramePr><p:nvPr/></p:nvGraphicFramePr><p:xfrm><a:off x="' + EMU.MX + '" y="' + (s.tableTop || 1550000) + '"/><a:ext cx="' + (cw * cols) + '" cy="' + (400000 * rows.length) + '"/></p:xfrm><a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/table"><a:tbl><a:tblPr firstRow="1" bandRow="1"/><a:tblGrid>' + gx + '</a:tblGrid>' + tr + '</a:tbl></a:graphicData></a:graphic></p:graphicFrame>');
    }
    return XML + '<p:sld ' + PNS + '><p:cSld><p:spTree>' + GRP + sp.join('') + '</p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sld>';
  }
  function buildPptx(text) {
    var slides = parseSlides(text), N = slides.length;
    var ph = function (id, name, phx, x, y, cx, cy) { return '<p:sp><p:nvSpPr><p:cNvPr id="' + id + '" name="' + name + '"/><p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr><p:nvPr><p:ph ' + phx + '/></p:nvPr></p:nvSpPr><p:spPr>' + (cx ? '<a:xfrm><a:off x="' + x + '" y="' + y + '"/><a:ext cx="' + cx + '" cy="' + cy + '"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom>' : '') + '</p:spPr><p:txBody><a:bodyPr/><a:lstStyle/><a:p><a:r><a:rPr lang="en-US"/><a:t>' + (phx.indexOf('title') >= 0 ? 'Click to edit title' : 'Click to edit text') + '</a:t></a:r></a:p></p:txBody></p:sp>'; };
    var lvlStyle = function (i, sz) { return '<a:lvl' + i + 'pPr marL="' + (342900 * i) + '" indent="-342900" algn="l" defTabSz="914400" rtl="0" eaLnBrk="1" latinLnBrk="0" hangingPunct="1"><a:spcBef><a:spcPts val="600"/></a:spcBef><a:buFont typeface="Arial"/><a:buChar char="•"/><a:defRPr sz="' + sz + '" kern="1200"><a:solidFill><a:schemeClr val="tx1"/></a:solidFill><a:latin typeface="+mn-lt"/><a:ea typeface="+mn-ea"/><a:cs typeface="+mn-cs"/></a:defRPr></a:lvl' + i + 'pPr>'; };
    var master = XML + '<p:sldMaster ' + PNS + '><p:cSld><p:bg><p:bgRef idx="1001"><a:schemeClr val="bg1"/></p:bgRef></p:bg><p:spTree>' + GRP +
      ph(2, 'Title Placeholder 1', 'type="title"', EMU.MX, 380000, 10911840, 900000) + ph(3, 'Text Placeholder 2', 'type="body" idx="1"', EMU.MX, 1550000, 10911840, 4700000) +
      '</p:spTree></p:cSld><p:clrMap bg1="lt1" tx1="dk1" bg2="lt2" tx2="dk2" accent1="accent1" accent2="accent2" accent3="accent3" accent4="accent4" accent5="accent5" accent6="accent6" hlink="hlink" folHlink="folHlink"/>' +
      '<p:sldLayoutIdLst><p:sldLayoutId id="2147483649" r:id="rId1"/></p:sldLayoutIdLst><p:txStyles><p:titleStyle><a:lvl1pPr algn="l" defTabSz="914400" rtl="0" eaLnBrk="1" latinLnBrk="0" hangingPunct="1"><a:lnSpc><a:spcPct val="90000"/></a:lnSpc><a:spcBef><a:spcPct val="0"/></a:spcBef><a:buNone/><a:defRPr sz="3200" b="1" kern="1200"><a:solidFill><a:schemeClr val="tx2"/></a:solidFill><a:latin typeface="+mj-lt"/><a:ea typeface="+mj-ea"/><a:cs typeface="+mj-cs"/></a:defRPr></a:lvl1pPr></p:titleStyle>' +
      '<p:bodyStyle>' + lvlStyle(1, 2400) + lvlStyle(2, 2000) + lvlStyle(3, 1800) + '</p:bodyStyle><p:otherStyle><a:defPPr><a:defRPr lang="en-US"/></a:defPPr></p:otherStyle></p:txStyles></p:sldMaster>';
    var layout = XML + '<p:sldLayout ' + PNS + ' type="obj" preserve="1"><p:cSld name="Title and Content"><p:spTree>' + GRP + ph(2, 'Title 1', 'type="title"') + ph(3, 'Content Placeholder 2', 'idx="1"') + '</p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sldLayout>';
    var fill = function (n) { return '<a:solidFill><a:schemeClr val="phClr"/></a:solidFill>'.repeat(n); };
    var lnx = function (w) { return '<a:ln w="' + w + '" cap="flat" cmpd="sng" algn="ctr"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:prstDash val="solid"/></a:ln>'; };
    var theme = XML + '<a:theme xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" name="Zen Ai"><a:themeElements><a:clrScheme name="Zen Ai"><a:dk1><a:srgbClr val="262626"/></a:dk1><a:lt1><a:srgbClr val="FFFFFF"/></a:lt1><a:dk2><a:srgbClr val="1F3864"/></a:dk2><a:lt2><a:srgbClr val="EEF2F7"/></a:lt2><a:accent1><a:srgbClr val="2E75B6"/></a:accent1><a:accent2><a:srgbClr val="ED7D31"/></a:accent2><a:accent3><a:srgbClr val="70AD47"/></a:accent3><a:accent4><a:srgbClr val="FFC000"/></a:accent4><a:accent5><a:srgbClr val="5B9BD5"/></a:accent5><a:accent6><a:srgbClr val="7F7F7F"/></a:accent6><a:hlink><a:srgbClr val="0563C1"/></a:hlink><a:folHlink><a:srgbClr val="954F72"/></a:folHlink></a:clrScheme>' +
      '<a:fontScheme name="Zen Ai"><a:majorFont><a:latin typeface="Calibri"/><a:ea typeface=""/><a:cs typeface=""/></a:majorFont><a:minorFont><a:latin typeface="Calibri"/><a:ea typeface=""/><a:cs typeface=""/></a:minorFont></a:fontScheme>' +
      '<a:fmtScheme name="Zen Ai"><a:fillStyleLst>' + fill(3) + '</a:fillStyleLst><a:lnStyleLst>' + lnx(6350) + lnx(12700) + lnx(19050) + '</a:lnStyleLst><a:effectStyleLst><a:effectStyle><a:effectLst/></a:effectStyle><a:effectStyle><a:effectLst/></a:effectStyle><a:effectStyle><a:effectLst/></a:effectStyle></a:effectStyleLst><a:bgFillStyleLst>' + fill(3) + '</a:bgFillStyleLst></a:fmtScheme></a:themeElements></a:theme>';
    var R = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships';
    var files = [
      { name: '[Content_Types].xml', data: XML + '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/ppt/presentation.xml" ContentType="' + ctm('pptx') + '"/><Override PartName="/ppt/slideMasters/slideMaster1.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slideMaster+xml"/><Override PartName="/ppt/slideLayouts/slideLayout1.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slideLayout+xml"/><Override PartName="/ppt/theme/theme1.xml" ContentType="application/vnd.openxmlformats-officedocument.theme+xml"/>' + slides.map(function (_, i) { return '<Override PartName="/ppt/slides/slide' + (i + 1) + '.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slide+xml"/>'; }).join('') + '</Types>' },
      { name: '_rels/.rels', data: XML + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="' + R + '/officeDocument" Target="ppt/presentation.xml"/></Relationships>' },
      { name: 'ppt/presentation.xml', data: XML + '<p:presentation ' + PNS + ' saveSubsetFonts="1"><p:sldMasterIdLst><p:sldMasterId id="2147483648" r:id="rId1"/></p:sldMasterIdLst><p:sldIdLst>' + slides.map(function (_, i) { return '<p:sldId id="' + (256 + i) + '" r:id="rId' + (i + 3) + '"/>'; }).join('') + '</p:sldIdLst><p:sldSz cx="' + EMU.W + '" cy="' + EMU.H + '"/><p:notesSz cx="6858000" cy="9144000"/></p:presentation>' },
      { name: 'ppt/_rels/presentation.xml.rels', data: XML + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="' + R + '/slideMaster" Target="slideMasters/slideMaster1.xml"/><Relationship Id="rId2" Type="' + R + '/theme" Target="theme/theme1.xml"/>' + slides.map(function (_, i) { return '<Relationship Id="rId' + (i + 3) + '" Type="' + R + '/slide" Target="slides/slide' + (i + 1) + '.xml"/>'; }).join('') + '</Relationships>' },
      { name: 'ppt/slideMasters/slideMaster1.xml', data: master },
      { name: 'ppt/slideMasters/_rels/slideMaster1.xml.rels', data: XML + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="' + R + '/slideLayout" Target="../slideLayouts/slideLayout1.xml"/><Relationship Id="rId2" Type="' + R + '/theme" Target="../theme/theme1.xml"/></Relationships>' },
      { name: 'ppt/slideLayouts/slideLayout1.xml', data: layout },
      { name: 'ppt/slideLayouts/_rels/slideLayout1.xml.rels', data: XML + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="' + R + '/slideMaster" Target="../slideMasters/slideMaster1.xml"/></Relationships>' },
      { name: 'ppt/theme/theme1.xml', data: theme }
    ];
    slides.forEach(function (s, i) {
      files.push({ name: 'ppt/slides/slide' + (i + 1) + '.xml', data: slideXml(s) });
      files.push({ name: 'ppt/slides/_rels/slide' + (i + 1) + '.xml.rels', data: XML + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="' + R + '/slideLayout" Target="../slideLayouts/slideLayout1.xml"/></Relationships>' });
    });
    void N;
    return zipBlob(files, MIME.pptx);
  }

  /* ============================== PDF (canvas based, so Tamil / Sinhala / Hindi always draw correctly) ============================== */
  async function buildPdf(text) {
    var S = 2, PW = 595.28, PH = 841.89, M = 54, CW = PW - 2 * M;
    var FAM = "'Noto Sans Tamil','Noto Sans Sinhala','Noto Sans Devanagari','Noto Sans','Nirmala UI','Latha',system-ui,'Segoe UI',Roboto,Arial,sans-serif";
    var MONO = "ui-monospace,Consolas,'Courier New',monospace";
    var pages = [], cv, cx, y;
    var newPage = function () {
      cv = document.createElement('canvas'); cv.width = Math.round(PW * S); cv.height = Math.round(PH * S);
      cx = cv.getContext('2d'); cx.scale(S, S); cx.fillStyle = '#ffffff'; cx.fillRect(0, 0, PW, PH); cx.textBaseline = 'alphabetic';
      cv._cx = cx; pages.push(cv); y = M;
    };
    var font = function (sz, b, i, mono) { return (i ? 'italic ' : '') + (b ? '700 ' : '400 ') + sz + 'px ' + (mono ? MONO : FAM); };
    var need = function (h) { if (y + h > PH - M) newPage(); };
    var flow = function (runs, width, sz, base) {
      var lines = [[]], x = 0;
      runs.forEach(function (r) {
        var f = font(r.c ? sz * 0.92 : sz, r.b || base.b, r.i || base.i, r.c);
        cx.font = f;
        r.t.split(/(\s+)/).filter(function (s) { return s !== ''; }).forEach(function (tk) {
          var sp = /^\s+$/.test(tk), w = cx.measureText(sp ? ' ' : tk).width, ln = lines[lines.length - 1];
          if (sp) { if (ln.length) { ln.push({ t: ' ', f: f, w: w, r: r }); x += w; } return; }
          if (x + w > width && ln.length) { while (ln.length && ln[ln.length - 1].t === ' ') x -= ln.pop().w; lines.push([]); x = 0; }
          if (w > width) {
            Array.from(tk).forEach(function (ch) { var cw = cx.measureText(ch).width; if (x + cw > width && lines[lines.length - 1].length) { lines.push([]); x = 0; } lines[lines.length - 1].push({ t: ch, f: f, w: cw, r: r }); x += cw; });
          } else { lines[lines.length - 1].push({ t: tk, f: f, w: w, r: r }); x += w; }
        });
      });
      lines.forEach(function (l) { while (l.length && l[l.length - 1].t === ' ') l.pop(); });
      return lines;
    };
    var drawLine = function (ln, x0, base, sz, color) {
      var x = x0;
      ln.forEach(function (tk) {
        cx.font = tk.f;
        if (tk.r.c) { cx.fillStyle = '#F0F1F4'; cx.fillRect(x - 1, base - sz * 0.9, tk.w + 2, sz * 1.2); }
        cx.fillStyle = tk.r.c ? '#B3261E' : color; cx.fillText(tk.t, x, base);
        if (tk.r.s) { cx.fillRect(x, base - sz * 0.3, tk.w, 0.8); }
        x += tk.w;
      });
    };
    var textBlock = function (runs, x0, width, sz, color, base, after, bar) {
      var lh = sz * 1.55, lines = flow(runs, width, sz, base || {});
      lines.forEach(function (ln, k) {
        need(lh); if (bar) { cx.fillStyle = '#9AA5B1'; cx.fillRect(x0 - 10, y, 3, lh); }
        drawLine(ln, x0, y + sz * 1.08, sz, color); y += lh;
      });
      y += after;
    };
    newPage();
    var blocks = parseMd(text), ordN = 0;
    blocks.forEach(function (b) {
      if (b.t !== 'li') ordN = 0;
      if (b.t === 'h') {
        var sz = { 1: 22, 2: 17, 3: 14 }[b.l]; if (y > M + 1) y += sz * 0.55; need(sz * 2.2);
        textBlock(b.r, M, CW, sz, '#1F3864', { b: 1 }, b.l === 1 ? 2 : 3);
        if (b.l === 1) { cx.fillStyle = '#C9D3E3'; cx.fillRect(M, y, CW, 1); y += 8; }
      }
      else if (b.t === 'p') textBlock(b.r, M, CW, 11, '#222222', {}, 6);
      else if (b.t === 'li') {
        var ind = 16 + b.lvl * 18, lab = b.ord ? (++ordN) + '.' : (b.lvl ? '◦' : '•');
        if (!b.ord) ordN = 0;
        need(17); cx.font = font(11, 0, 0); cx.fillStyle = '#444'; cx.fillText(lab, M + ind - 14 - (b.ord ? 4 : 0), y + 11 * 1.08);
        textBlock(b.r, M + ind + 4, CW - ind - 4, 11, '#222222', {}, 3);
      }
      else if (b.t === 'q') textBlock(b.r, M + 14, CW - 14, 11, '#555555', { i: 1 }, 6, true);
      else if (b.t === 'hr') { need(14); y += 5; cx.fillStyle = '#C4C9D0'; cx.fillRect(M, y, CW, 1); y += 9; }
      else if (b.t === 'code') {
        var lh = 9.5 * 1.45; cx.font = font(9.5, 0, 0, 1); y += 2;
        b.text.split('\n').forEach(function (l) {
          var chunks = [], cur = '';
          Array.from(l === '' ? ' ' : l).forEach(function (ch) { if (cx.measureText(cur + ch).width > CW - 16 && cur) { chunks.push(cur); cur = ch; } else cur += ch; });
          chunks.push(cur);
          chunks.forEach(function (c) { need(lh); cx.fillStyle = '#F3F4F6'; cx.fillRect(M, y, CW, lh); cx.font = font(9.5, 0, 0, 1); cx.fillStyle = '#1F2933'; cx.fillText(c, M + 8, y + 9.5 * 1.02); y += lh; });
        });
        y += 8;
      }
      else if (b.t === 'table') {
        var n = b.rows[0].length, mx = [];
        for (var c = 0; c < n; c++) { var m = 6; b.rows.forEach(function (r) { m = Math.max(m, Math.min(40, plainOf(r[c]).length)); }); mx.push(m); }
        var tot = mx.reduce(function (a, v) { return a + v; }, 0), ws = mx.map(function (v) { return Math.max(34, CW * v / tot); });
        var sc = CW / ws.reduce(function (a, v) { return a + v; }, 0); ws = ws.map(function (v) { return v * sc; });
        y += 2;
        b.rows.forEach(function (row, ri) {
          var hd = b.head && ri === 0, sz = 10, lh = sz * 1.5, cl = row.map(function (cell, ci) { return flow(cell, ws[ci] - 10, sz, hd ? { b: 1 } : {}); });
          var h = Math.max.apply(null, cl.map(function (l) { return l.length; })) * lh + 8; need(h);
          var x = M;
          cl.forEach(function (lines, ci) {
            cx.fillStyle = hd ? '#E3EAF5' : (ri % 2 ? '#F8FAFC' : '#FFFFFF'); cx.fillRect(x, y, ws[ci], h);
            cx.strokeStyle = '#C7CED6'; cx.lineWidth = 0.6; cx.strokeRect(x, y, ws[ci], h);
            lines.forEach(function (ln, k) { drawLine(ln, x + 5, y + 4 + k * lh + sz * 1.08, sz, '#222222'); });
            x += ws[ci];
          });
          y += h;
        });
        y += 10;
      }
    });
    var out = [];
    for (var i = 0; i < pages.length; i++) {
      var c2 = pages[i]._cx; c2.font = font(9, 0, 0); c2.fillStyle = '#8A8F98'; c2.textAlign = 'center';
      if (pages.length > 1) c2.fillText((i + 1) + ' / ' + pages.length, PW / 2, PH - 26);
      var blob = await new Promise(function (res) { pages[i].toBlob(res, 'image/jpeg', 0.92); });
      out.push({ jpg: new Uint8Array(await blob.arrayBuffer()), w: pages[i].width, h: pages[i].height });
    }
    return pdfAssemble(out, PW, PH);
  }
  function pdfAssemble(pgs, PW, PH) {
    var parts = [], off = 0, offs = [], push = function (u) { parts.push(u); off += u.length; }, s = function (x) { push(te.encode(x)); };
    var obj = function (id, fn) { offs[id] = off; s(id + ' 0 obj\n'); fn(); s('\nendobj\n'); };
    push(new Uint8Array([37, 80, 68, 70, 45, 49, 46, 52, 10, 37, 226, 227, 207, 211, 10]));
    var n = pgs.length;
    obj(1, function () { s('<< /Type /Catalog /Pages 2 0 R >>'); });
    obj(2, function () { var k = []; for (var i = 0; i < n; i++) k.push((3 + 3 * i) + ' 0 R'); s('<< /Type /Pages /Count ' + n + ' /Kids [' + k.join(' ') + '] >>'); });
    pgs.forEach(function (p, i) {
      var pid = 3 + 3 * i, cid = pid + 1, iid = pid + 2, content = 'q ' + PW.toFixed(2) + ' 0 0 ' + PH.toFixed(2) + ' 0 0 cm /Im0 Do Q';
      obj(pid, function () { s('<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ' + PW.toFixed(2) + ' ' + PH.toFixed(2) + '] /Resources << /XObject << /Im0 ' + iid + ' 0 R >> /ProcSet [/PDF /ImageC] >> /Contents ' + cid + ' 0 R >>'); });
      obj(cid, function () { s('<< /Length ' + content.length + ' >>\nstream\n' + content + '\nendstream'); });
      obj(iid, function () { s('<< /Type /XObject /Subtype /Image /Width ' + p.w + ' /Height ' + p.h + ' /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ' + p.jpg.length + ' >>\nstream\n'); push(p.jpg); s('\nendstream'); });
    });
    var xr = off, total = 3 + 3 * n;
    s('xref\n0 ' + total + '\n0000000000 65535 f \n');
    for (var i = 1; i < total; i++) s(('0000000000' + offs[i]).slice(-10) + ' 00000 n \n');
    s('trailer\n<< /Size ' + total + ' /Root 1 0 R >>\nstartxref\n' + xr + '\n%%EOF\n');
    return new Blob(parts, { type: MIME.pdf });
  }

  /* ============================== PNG / JPG from SVG ============================== */
  async function svgToImage(text, mime) {
    var svg = String(text || '').trim();
    var at = svg.search(/<svg[\s>]/i);
    if (at < 0) throw new Error('PNG needs SVG code inside the block');
    svg = svg.slice(at);
    if (!/<svg[^>]*\sxmlns=/i.test(svg)) svg = svg.replace(/<svg/i, '<svg xmlns="http://www.w3.org/2000/svg"');
    var head = svg.match(/<svg[^>]*>/i)[0], w = 0, h = 0, m;
    if ((m = head.match(/\swidth="([\d.]+)(px)?"/i))) w = parseFloat(m[1]);
    if ((m = head.match(/\sheight="([\d.]+)(px)?"/i))) h = parseFloat(m[1]);
    if ((!w || !h) && (m = head.match(/viewBox="[-\d.]+[ ,]+[-\d.]+[ ,]+([\d.]+)[ ,]+([\d.]+)"/i))) { w = w || parseFloat(m[1]); h = h || parseFloat(m[2]); }
    w = w || 1024; h = h || 768;
    if (!/\swidth=/i.test(head) || !/\sheight=/i.test(head)) svg = svg.replace(/<svg/i, '<svg width="' + w + '" height="' + h + '"');
    var k = Math.min(3, 2400 / Math.max(w, h)); k = Math.max(k, 0.5);
    var url = URL.createObjectURL(new Blob([svg], { type: 'image/svg+xml;charset=utf-8' }));
    try {
      var img = new Image(); img.src = url; await img.decode();
      var cv = document.createElement('canvas'); cv.width = Math.round(w * k); cv.height = Math.round(h * k);
      var cx = cv.getContext('2d'); if (mime !== 'image/png') { cx.fillStyle = '#fff'; cx.fillRect(0, 0, cv.width, cv.height); }
      cx.drawImage(img, 0, 0, cv.width, cv.height);
      return await new Promise(function (res, rej) { cv.toBlob(function (b) { b ? res(b) : rej(new Error('image export failed')); }, mime, 0.92); });
    } finally { URL.revokeObjectURL(url); }
  }

  /* ============================== public API ============================== */
  async function build(name, text) {
    var e = extOf(name);
    if (e === 'docx') return buildDocx(text);
    if (e === 'xlsx') return buildXlsx(text);
    if (e === 'pptx') return buildPptx(text);
    if (e === 'pdf') return buildPdf(text);
    if (e === 'odt') return buildOdt(text);
    if (e === 'ods') return buildOds(text);
    if (e === 'odp') return buildOdp(text);
    if (e === 'epub') return buildEpub(text);
    if (e === 'rtf') return buildRtf(text);
    if (e === 'doc') return buildRtf(text).then(function (b) { return new Blob([b], { type: 'application/msword' }); });
    if (OFFV[e]) return buildVariant(e, text);
    if (e === 'xls') return buildXlsLegacy(text);
    if (/^(bmp|gif|ico|tiff|tif)$/.test(e)) return buildRaster(e === 'tif' ? 'tiff' : e, text);
    if (e === 'wav') return buildWav(text);
    if (/^(mp4|mov|webm|mkv)$/.test(e)) return buildVideo(e, text);
    if (e === 'flac') return buildFlac(text);
    if (e === 'mp3') return buildMp3(text);
    if (e === 'ogg' || e === 'oga' || e === 'opus') return buildOgg(text);
    if (e === 'm4a' || e === 'aac') return buildAac(e, text);
    if (e === 'mid' || e === 'midi') return buildMidi(text);
    if (MIME[e]) return svgToImage(text, MIME[e]);
    throw new Error('Unknown file type: ' + e);
  }
  async function zip(files) {
    var out = [];
    for (var i = 0; i < files.length; i++) {
      var f = files[i], data;
      if (isBin(f.name)) { try { data = new Uint8Array(await (await build(f.name, f.text)).arrayBuffer()); } catch (e) { data = te.encode(String(f.text)); f = { name: f.name + '.txt' }; } }
      else data = te.encode(String(f.text));
      out.push({ name: f.name, data: data });
    }
    return zipBlob(out, 'application/zip');
  }
  /* ============================== v6: real in-app preview for sound, video and pictures ============================== */
  function mediaKind(e) {
    if (/^(wav|mp3|m4a|aac|ogg|oga|opus|flac)$/.test(e)) return 'audio';
    if (e === 'mid' || e === 'midi') return 'midi';
    if (/^(mp4|mov|webm|mkv)$/.test(e)) return 'video';
    if (/^(png|jpg|jpeg|webp|gif|bmp|ico)$/.test(e)) return 'img';
    return null;
  }
  function fmtBytes(n) { return n < 1024 ? n + ' B' : n < 1048576 ? (n / 1024).toFixed(1) + ' KB' : (n / 1048576).toFixed(1) + ' MB'; }
  async function mediaHtml(name, text) {
    var e = extOf(name), k = mediaKind(e);
    if (!k) return null;
    var blob = k === 'midi' ? await buildWav(text) : await build(name, text);
    var url = await new Promise(function (res, rej) { var r = new FileReader(); r.onload = function () { res(r.result); }; r.onerror = function () { rej(r.error || new Error('read failed')); }; r.readAsDataURL(blob); });
    var head = '<!doctype html><meta name="viewport" content="width=device-width,initial-scale=1"><body style="margin:0;display:grid;place-items:center;min-height:100vh;background:#111;color:#eee;font:14px system-ui,sans-serif;text-align:center">';
    var info = esc((LABEL[e] || e.toUpperCase()) + ' \u00b7 ' + fmtBytes(blob.size) + (k === 'midi' ? ' \u00b7 played as a simple tone (MIDI cannot play in a browser)' : ''));
    if (k === 'audio' || k === 'midi') return head + '<div style="padding:24px;width:100%;box-sizing:border-box"><div style="font-size:46px;line-height:1">\u266A</div><div style="margin:10px 0 18px;word-break:break-all">' + esc(name) + '</div><audio controls style="width:100%" src="' + url + '"></audio><div style="opacity:.6;margin-top:14px">' + info + '</div></div>';
    if (k === 'video') return head + '<div style="width:100%"><video controls playsinline style="width:100%;max-height:100vh;background:#000" src="' + url + '"></video><div style="opacity:.6;padding:10px">' + esc(name) + ' \u00b7 ' + info + '</div></div>';
    return head + '<div style="padding:12px"><img style="max-width:100%;max-height:90vh;background:#fff" src="' + url + '"><div style="opacity:.6;margin-top:10px">' + esc(name) + ' \u00b7 ' + info + '</div></div>';
  }
  function preview(name, text, show) {
    var e = extOf(name);
    if (mediaKind(e)) return mediaHtml(name, text).then(function (h) { return show(h, 'html', name); }).catch(function (er) { if (typeof toast === 'function') toast('Preview failed: ' + ((er && er.message) || er)); });
    if (e === 'xlsx' || e === 'ods' || e === 'xls' || e === 'xltx' || e === 'xlsm') {
      var html = '<!doctype html><meta name="viewport" content="width=device-width,initial-scale=1"><style>body{font:14px system-ui,sans-serif;padding:12px;color:#222}h3{margin:18px 0 6px}table{border-collapse:collapse;margin-bottom:8px}td,th{border:1px solid #c9ced6;padding:4px 8px;white-space:pre-wrap}tr:first-child td{background:#e8eef7;font-weight:600}</style>';
      parseSheets(text).forEach(function (s) { html += '<h3>' + esc(s.name) + '</h3><table>' + s.rows.map(function (r) { return '<tr>' + r.map(function (c) { return '<td>' + esc(c) + '</td>'; }).join('') + '</tr>'; }).join('') + '</table>'; });
      return show(html, 'html', name);
    }
    if (/^(docx|pdf|pptx|odt|odp|epub|rtf|doc|dotx|docm|ppsx|potx|pptm|wav|mid|midi|mp3|m4a|aac|ogg|oga|opus|flac|mp4|mov|webm|mkv)$/.test(e)) return show(String(text), 'md', name);
    if (MIME[e]) { var u = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(String(text)); return show('<!doctype html><body style="margin:0;display:grid;place-items:center;min-height:100vh;background:#fff"><img style="max-width:100%" src="' + u + '">', 'html', name); }
  }
  var BADGE = { docx: ['W', '#2B579A'], xlsx: ['X', '#217346'], pptx: ['P', '#C43E1C'], pdf: ['PDF', '#D93025'], png: ['IMG', '#7B61FF'], jpg: ['IMG', '#7B61FF'], jpeg: ['IMG', '#7B61FF'], webp: ['IMG', '#7B61FF'], zip: ['ZIP', '#7A5AF8'], odt: ['ODT', '#2B579A'], ods: ['ODS', '#217346'], odp: ['ODP', '#C43E1C'], epub: ['EPUB', '#6B4FBB'], rtf: ['RTF', '#2B579A'], dotx: ['DOTX', '#2B579A'], docm: ['DOCM', '#2B579A'], doc: ['DOC', '#2B579A'], xltx: ['XLTX', '#217346'], xlsm: ['XLSM', '#217346'], xls: ['XLS', '#217346'], ppsx: ['PPSX', '#C43E1C'], potx: ['POTX', '#C43E1C'], pptm: ['PPTM', '#C43E1C'], bmp: ['IMG', '#7B61FF'], gif: ['IMG', '#7B61FF'], ico: ['IMG', '#7B61FF'], tiff: ['IMG', '#7B61FF'], tif: ['IMG', '#7B61FF'], mp4: ['MP4', '#B4287C'], mov: ['MOV', '#B4287C'], webm: ['WEBM', '#B4287C'], mkv: ['MKV', '#B4287C'], mp3: ['MP3', '#0B6E99'], m4a: ['M4A', '#0B6E99'], aac: ['AAC', '#0B6E99'], ogg: ['OGG', '#0B6E99'], oga: ['OGG', '#0B6E99'], opus: ['OPUS', '#0B6E99'], flac: ['FLAC', '#0B6E99'], wav: ['WAV', '#0B6E99'], mid: ['MID', '#0B6E99'], midi: ['MID', '#0B6E99'] };
  var CAT = [
    ['#E4572E', 'html htm css scss svg vue jsx tsx'],
    ['#0B6E99', 'js mjs ts py java kt c h cpp cs go rs php rb swift dart lua r pl sh bat ps1 sql ipynb'],
    ['#2E8B57', 'json xml yml yaml toml ini csv tsv env'],
    ['#5F6B7A', 'txt md tex rtf log diff'],
    ['#B8860B', 'ics vcf']
  ];
  function badge(name) {
    var e = extOf(name);
    if (BADGE[e]) return BADGE[e];
    for (var i = 0; i < CAT.length; i++) if (CAT[i][1].split(' ').indexOf(e) >= 0) return [e.toUpperCase().slice(0, 4), CAT[i][0]];
    return [(e || 'FILE').toUpperCase().slice(0, 4), '#666666'];
  }
  /* one icon style for every file type: page outline + coloured type badge */
  function icon(name) {
    var b = badge(name), n = b[0].length;
    /* inline styles on purpose: the app's own CSS paints svg fills, inline style wins */
    return '<svg viewBox="0 0 24 24" width="34" height="34" style="width:34px;height:34px;fill:none;color:' + b[1] + '" stroke="' + b[1] + '" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path style="fill:#fff;stroke:' + b[1] + '" d="M14 2H7a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V7z"/><path style="fill:none;stroke:' + b[1] + '" d="M14 2v5h5"/><text x="12" y="17.2" text-anchor="middle" font-size="' + (n === 1 ? 7.5 : n === 2 ? 5.6 : n === 3 ? 4.8 : 4) + '" font-weight="800" font-family="system-ui,sans-serif" style="fill:' + b[1] + ';stroke:none">' + esc(b[0]) + '</text></svg>';
  }
  /* ============================== v2: OpenDocument (.odt .ods .odp), EPUB (.epub), RTF (.rtf) ============================== */
  var ONS = 'xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" xmlns:style="urn:oasis:names:tc:opendocument:xmlns:style:1.0" xmlns:text="urn:oasis:names:tc:opendocument:xmlns:text:1.0" xmlns:table="urn:oasis:names:tc:opendocument:xmlns:table:1.0" xmlns:draw="urn:oasis:names:tc:opendocument:xmlns:drawing:1.0" xmlns:fo="urn:oasis:names:tc:opendocument:xmlns:xsl-fo-compatible:1.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:meta="urn:oasis:names:tc:opendocument:xmlns:meta:1.0" xmlns:number="urn:oasis:names:tc:opendocument:xmlns:datastyle:1.0" xmlns:svg="urn:oasis:names:tc:opendocument:xmlns:svg-compatible:1.0" xmlns:presentation="urn:oasis:names:tc:opendocument:xmlns:presentation:1.0" xmlns:of="urn:oasis:names:tc:opendocument:xmlns:of:1.2" office:version="1.2"';
  var odfT = function (s) {
    return esc(s).replace(/ {2,}/g, function (m) { return ' <text:s text:c="' + (m.length - 1) + '"/>'; }).replace(/\t/g, '<text:tab/>').replace(/\n/g, '<text:line-break/>');
  };
  var spanDefs = function (used) {
    var d = '';
    Object.keys(used).forEach(function (k) {
      var p = '';
      if (k.indexOf('B') >= 0) p += ' fo:font-weight="bold" style:font-weight-asian="bold" style:font-weight-complex="bold"';
      if (k.indexOf('I') >= 0) p += ' fo:font-style="italic" style:font-style-asian="italic" style:font-style-complex="italic"';
      if (k.indexOf('C') >= 0) p += ' fo:font-family="\'Courier New\'" fo:background-color="#f2f2f2"';
      if (k.indexOf('S') >= 0) p += ' style:text-line-through-style="solid" style:text-line-through-type="single"';
      d += '<style:style style:name="T' + k + '" style:family="text"><style:text-properties' + p + '/></style:style>';
    });
    return d;
  };
  var oRuns = function (runs, used, o) {
    o = o || {};
    return (runs || []).map(function (r) {
      var k = ((r.b || o.b) ? 'B' : '') + ((r.i || o.i) ? 'I' : '') + (r.c ? 'C' : '') + (r.s ? 'S' : '');
      if (!k) return odfT(r.t);
      used[k] = 1; return '<text:span text:style-name="T' + k + '">' + odfT(r.t) + '</text:span>';
    }).join('');
  };
  var listStyles = function () {
    var mk = function (name, ord) {
      var o = '<text:list-style style:name="' + name + '">';
      for (var l = 1; l <= 3; l++) {
        var pr = '<style:list-level-properties text:space-before="' + (0.2 + 0.8 * (l - 1)).toFixed(2) + 'cm" text:min-label-width="0.7cm"/>';
        o += ord ? '<text:list-level-style-number text:level="' + l + '" style:num-suffix="." style:num-format="1">' + pr + '</text:list-level-style-number>'
          : '<text:list-level-style-bullet text:level="' + l + '" text:bullet-relative-size="100%" text:bullet-char="' + (l === 1 ? '\u2022' : '\u25E6') + '">' + pr + '</text:list-level-style-bullet>';
      }
      return o + '</text:list-style>';
    };
    return mk('LB', false) + mk('LN', true);
  };
  function odfList(items, used, pstyle) {
    var out = '', st = [], kind = !!(items[0] && items[0].ord);
    items.forEach(function (it) {
      var L = Math.min(it.lvl || 0, st.length);
      while (st.length > L + 1) { out += '</text:list-item></text:list>'; st.pop(); }
      if (L === 0 && st.length === 1 && !!it.ord !== kind) { out += '</text:list-item></text:list>'; st.pop(); }
      if (!st.length) kind = !!it.ord;
      if (st.length === L + 1) out += '</text:list-item><text:list-item>';
      else { out += '<text:list text:style-name="' + (it.ord ? 'LN' : 'LB') + '"><text:list-item>'; st.push(1); }
      out += '<text:p text:style-name="' + (pstyle || 'Standard') + '">' + oRuns(it.r, used) + '</text:p>';
    });
    while (st.length) { out += '</text:list-item></text:list>'; st.pop(); }
    return out;
  }
  function odfTable(b, used) {
    var n = b.rows[0] ? b.rows[0].length : 1, o = '<table:table table:style-name="Tbl"><table:table-column table:number-columns-repeated="' + n + '"/>';
    b.rows.forEach(function (r, ri) {
      var hd = b.head && ri === 0;
      o += '<table:table-row table:style-name="Row">' + r.map(function (c) {
        return '<table:table-cell table:style-name="' + (hd ? 'CellH' : 'Cell') + '" office:value-type="string"><text:p text:style-name="Standard">' + oRuns(c, used, { b: hd }) + '</text:p></table:table-cell>';
      }).join('') + '</table:table-row>';
    });
    return o + '</table:table>';
  }
  var odfManifest = function (mime, extra) {
    return XML + '<manifest:manifest xmlns:manifest="urn:oasis:names:tc:opendocument:xmlns:manifest:1.0" manifest:version="1.2"><manifest:file-entry manifest:full-path="/" manifest:version="1.2" manifest:media-type="' + mime + '"/><manifest:file-entry manifest:full-path="content.xml" manifest:media-type="text/xml"/><manifest:file-entry manifest:full-path="styles.xml" manifest:media-type="text/xml"/><manifest:file-entry manifest:full-path="meta.xml" manifest:media-type="text/xml"/></manifest:manifest>';
  };
  var odfMeta = function (title) {
    return XML + '<office:document-meta ' + ONS + '><office:meta><meta:generator>Zen Ai</meta:generator><dc:title>' + esc(title || '') + '</dc:title><meta:creation-date>' + new Date().toISOString().replace(/\.\d+Z$/, '') + '</meta:creation-date></office:meta></office:document-meta>';
  };
  var odfPack = function (mime, content, styles, title) {
    return zipBlob([
      { name: 'mimetype', data: mime },
      { name: 'META-INF/manifest.xml', data: odfManifest(mime) },
      { name: 'meta.xml', data: odfMeta(title) },
      { name: 'styles.xml', data: styles },
      { name: 'content.xml', data: content }
    ], mime);
  };
  var tblStyles = '<style:style style:name="Tbl" style:family="table"><style:table-properties style:width="17cm" table:align="margins" fo:margin-top="0.2cm" fo:margin-bottom="0.3cm"/></style:style>' +
    '<style:style style:name="Row" style:family="table-row"><style:table-row-properties style:row-height="0.95cm" style:use-optimal-row-height="true"/></style:style>' +
    '<style:style style:name="Cell" style:family="table-cell"><style:table-cell-properties fo:padding="0.12cm" fo:border="0.5pt solid #9aa3ad" fo:background-color="#ffffff"/></style:style>' +
    '<style:style style:name="CellH" style:family="table-cell"><style:table-cell-properties fo:padding="0.12cm" fo:border="0.5pt solid #9aa3ad" fo:background-color="#e8eef7"/></style:style>';

  /* ----- ODT ----- */
  function buildOdt(text) {
    var bl = parseMd(text), used = {}, body = '', i = 0, title = '';
    while (i < bl.length) {
      var b = bl[i];
      if (b.t === 'h') { if (!title) title = plainOf(b.r); body += '<text:h text:style-name="Heading_20_' + b.l + '" text:outline-level="' + b.l + '">' + oRuns(b.r, used) + '</text:h>'; i++; }
      else if (b.t === 'li') { var g = []; while (i < bl.length && bl[i].t === 'li') g.push(bl[i++]); body += odfList(g, used); }
      else if (b.t === 'table') { body += odfTable(b, used); i++; }
      else if (b.t === 'q') { body += '<text:p text:style-name="Quote">' + oRuns(b.r, used) + '</text:p>'; i++; }
      else if (b.t === 'code') { body += '<text:p text:style-name="CodeBlock">' + odfT(b.text) + '</text:p>'; i++; }
      else if (b.t === 'hr') { body += '<text:p text:style-name="Hr"/>'; i++; }
      else { body += '<text:p text:style-name="Standard">' + oRuns(b.r, used) + '</text:p>'; i++; }
    }
    var content = XML + '<office:document-content ' + ONS + '><office:automatic-styles>' + spanDefs(used) + tblStyles + listStyles() + '</office:automatic-styles><office:body><office:text>' + body + '</office:text></office:body></office:document-content>';
    var hs = function (n, sz, mt) { return '<style:style style:name="Heading_20_' + n + '" style:display-name="Heading ' + n + '" style:family="paragraph" style:parent-style-name="Standard" style:next-style-name="Standard" style:default-outline-level="' + n + '"><style:paragraph-properties fo:margin-top="' + mt + 'cm" fo:margin-bottom="0.2cm" fo:keep-with-next="always"/><style:text-properties fo:font-size="' + sz + 'pt" fo:font-weight="bold" style:font-weight-asian="bold" style:font-weight-complex="bold" style:font-size-asian="' + sz + 'pt" style:font-size-complex="' + sz + 'pt"/></style:style>'; };
    var styles = XML + '<office:document-styles ' + ONS + '><office:styles><style:default-style style:family="paragraph"><style:paragraph-properties fo:orphans="2" fo:widows="2"/><style:text-properties fo:font-size="11pt" fo:language="en" fo:country="US"/></style:default-style>' +
      '<style:style style:name="Standard" style:family="paragraph" style:class="text"><style:paragraph-properties fo:margin-top="0cm" fo:margin-bottom="0.25cm" fo:line-height="125%"/></style:style>' +
      hs(1, 22, 0.5) + hs(2, 16, 0.4) + hs(3, 13, 0.3) +
      '<style:style style:name="Quote" style:family="paragraph" style:parent-style-name="Standard"><style:paragraph-properties fo:margin-left="0.8cm" fo:padding-left="0.3cm" fo:border-left="2pt solid #b0b7c3"/><style:text-properties fo:font-style="italic" fo:color="#4a5565"/></style:style>' +
      '<style:style style:name="CodeBlock" style:family="paragraph" style:parent-style-name="Standard"><style:paragraph-properties fo:background-color="#f2f2f2" fo:padding="0.15cm"/><style:text-properties fo:font-family="\'Courier New\'" fo:font-size="9.5pt"/></style:style>' +
      '<style:style style:name="Hr" style:family="paragraph" style:parent-style-name="Standard"><style:paragraph-properties fo:margin-top="0.2cm" fo:margin-bottom="0.2cm" fo:border-bottom="0.75pt solid #9aa3ad" fo:padding="0cm"/></style:style>' +
      '</office:styles><office:automatic-styles><style:page-layout style:name="pm1"><style:page-layout-properties fo:page-width="21cm" fo:page-height="29.7cm" fo:margin-top="2cm" fo:margin-bottom="2cm" fo:margin-left="2cm" fo:margin-right="2cm"/></style:page-layout></office:automatic-styles><office:master-styles><style:master-page style:name="Standard" style:page-layout-name="pm1"/></office:master-styles></office:document-styles>';
    return odfPack('application/vnd.oasis.opendocument.text', content, styles, title);
  }

  /* ----- ODS ----- */
  var xl2of = function (f) {
    var parts = String(f).slice(1).split(/("(?:[^"]|"")*")/), o = '';
    parts.forEach(function (p, k) {
      if (k % 2) { o += p; return; }
      o += p.replace(/(\$?[A-Z]{1,3}\$?\d+)(?::(\$?[A-Z]{1,3}\$?\d+))?/g, function (m, a, b) { return '[.' + a + (b ? ':.' + b : '') + ']'; }).replace(/,/g, ';');
    });
    return 'of:=' + o;
  };
  function buildOds(text) {
    var sheets = parseSheets(text), names = {}, body = '';
    sheets.forEach(function (s, si) {
      var nm = String(s.name || 'Sheet' + (si + 1)).replace(/[\[\]:*?\/\\'"]/g, ' ').trim().slice(0, 31) || 'Sheet' + (si + 1);
      var base = nm, k = 2; while (names[nm.toLowerCase()]) nm = base.slice(0, 28) + ' ' + (k++); names[nm.toLowerCase()] = 1;
      var w = 1; s.rows.forEach(function (r) { w = Math.max(w, r.length); });
      body += '<table:table table:name="' + esc(nm) + '"><table:table-column table:number-columns-repeated="' + w + '"/>';
      s.rows.forEach(function (r, ri) {
        body += '<table:table-row>';
        for (var c = 0; c < w; c++) {
          var v = r[c] == null ? '' : String(r[c]), st = ri === 0 ? ' table:style-name="ceH"' : '';
          if (v === '') body += '<table:table-cell' + st + '/>';
          else if (v.charAt(0) === '=' && v.length > 1) body += '<table:table-cell' + st + ' table:formula="' + esc(xl2of(v)) + '"/>';
          else if (/^-?\d+(\.\d+)?$/.test(v.trim()) && ri > 0) body += '<table:table-cell' + st + ' office:value-type="float" office:value="' + v.trim() + '"><text:p>' + esc(v.trim()) + '</text:p></table:table-cell>';
          else body += '<table:table-cell' + st + ' office:value-type="string"><text:p>' + odfT(v) + '</text:p></table:table-cell>';
        }
        body += '</table:table-row>';
      });
      body += '</table:table>';
    });
    var content = XML + '<office:document-content ' + ONS + '><office:automatic-styles><style:style style:name="ceH" style:family="table-cell"><style:table-cell-properties fo:background-color="#e8eef7"/><style:text-properties fo:font-weight="bold"/></style:style></office:automatic-styles><office:body><office:spreadsheet>' + body + '</office:spreadsheet></office:body></office:document-content>';
    var styles = XML + '<office:document-styles ' + ONS + '><office:styles><style:default-style style:family="table-cell"><style:text-properties fo:font-size="11pt"/></style:default-style></office:styles></office:document-styles>';
    return odfPack('application/vnd.oasis.opendocument.spreadsheet', content, styles, '');
  }

  /* ----- ODP ----- */
  function buildOdp(text) {
    var slides = parseSlides(text), used = {}, pages = '';
    var frame = function (x, y, w, h, inner) { return '<draw:frame draw:style-name="gr1" draw:layer="layout" svg:x="' + x + 'cm" svg:y="' + y + 'cm" svg:width="' + w + 'cm" svg:height="' + h + 'cm">' + inner + '</draw:frame>'; };
    slides.forEach(function (s, i) {
      var p = '<draw:page draw:name="page' + (i + 1) + '" draw:style-name="dp1" draw:master-page-name="Default">';
      if (s.cover) {
        p += '<draw:rect draw:style-name="bar" draw:layer="layout" svg:x="2cm" svg:y="5.2cm" svg:width="2.2cm" svg:height="0.18cm"/>';
        p += frame(2, 5.6, 24, 3.6, '<draw:text-box><text:p text:style-name="PCover">' + oRuns(s.title, used) + '</text:p></draw:text-box>');
        var sub = (s.blocks || []).map(function (b) { return b.r ? '<text:p text:style-name="PSub">' + oRuns(b.r, used) + '</text:p>' : ''; }).join('');
        if (sub) p += frame(2, 9.4, 24, 3.4, '<draw:text-box>' + sub + '</draw:text-box>');
      } else {
        p += '<draw:rect draw:style-name="bar" draw:layer="layout" svg:x="2cm" svg:y="0cm" svg:width="24cm" svg:height="0.22cm"/>';
        p += frame(2, 0.9, 24, 2.4, '<draw:text-box><text:p text:style-name="PTitle">' + oRuns(s.title, used) + '</text:p></draw:text-box>');
        if (s.table) {
          var tb = odfTable(s.table, used).replace('table:style-name="Tbl"', 'table:style-name="Tbl"');
          p += frame(2, 3.8, 24, Math.min(10, 0.95 * s.table.rows.length + 0.2), tb);
        } else {
          var inner = '', j = 0, bl = s.blocks || [];
          while (j < bl.length) {
            if (bl[j].t === 'li') { var g = []; while (j < bl.length && bl[j].t === 'li') g.push(bl[j++]); inner += odfList(g, used, 'PBody'); }
            else { inner += '<text:p text:style-name="PBody">' + oRuns(bl[j].r || [{ t: bl[j].text || '' }], used) + '</text:p>'; j++; }
          }
          p += frame(2, 3.8, 24, 10.4, '<draw:text-box>' + inner + '</draw:text-box>');
        }
      }
      pages += p + '</draw:page>';
    });
    var ps = function (n, sz, b, col, extra) { return '<style:style style:name="' + n + '" style:family="paragraph"><style:paragraph-properties fo:margin-top="0cm" fo:margin-bottom="' + (extra || '0.25cm') + '"/><style:text-properties fo:font-size="' + sz + 'pt" fo:color="' + col + '"' + (b ? ' fo:font-weight="bold" style:font-weight-asian="bold" style:font-weight-complex="bold"' : '') + '/></style:style>'; };
    var content = XML + '<office:document-content ' + ONS + '><office:automatic-styles>' + spanDefs(used) + tblStyles + listStyles() +
      '<style:style style:name="dp1" style:family="drawing-page"><style:drawing-page-properties draw:fill="solid" draw:fill-color="#ffffff"/></style:style>' +
      '<style:style style:name="gr1" style:family="graphic"><style:graphic-properties draw:stroke="none" draw:fill="none" draw:auto-grow-height="false" draw:auto-grow-width="false" draw:textarea-vertical-align="top" fo:padding="0cm"/></style:style>' +
      '<style:style style:name="bar" style:family="graphic"><style:graphic-properties draw:stroke="none" draw:fill="solid" draw:fill-color="#2b6cb0"/></style:style>' +
      ps('Standard', 16, false, '#262626', '0cm') + ps('PTitle', 30, true, '#1a2433') + ps('PBody', 20, false, '#262626', '0.3cm') + ps('PCover', 40, true, '#1a2433') + ps('PSub', 22, false, '#5b6678') +
      '</office:automatic-styles><office:body><office:presentation>' + pages + '</office:presentation></office:body></office:document-content>';
    var styles = XML + '<office:document-styles ' + ONS + '><office:styles/><office:automatic-styles><style:page-layout style:name="PM1"><style:page-layout-properties fo:margin-top="0cm" fo:margin-bottom="0cm" fo:margin-left="0cm" fo:margin-right="0cm" fo:page-width="28cm" fo:page-height="15.75cm" style:print-orientation="landscape"/></style:page-layout></office:automatic-styles><office:master-styles><style:master-page style:name="Default" style:page-layout-name="PM1"/></office:master-styles></office:document-styles>';
    return odfPack('application/vnd.oasis.opendocument.presentation', content, styles, plainOf((slides[0] || {}).title));
  }

  /* ----- EPUB ----- */
  function xRuns(runs) {
    return (runs || []).map(function (r) {
      var s = esc(r.t);
      if (r.c) s = '<code>' + s + '</code>'; if (r.s) s = '<del>' + s + '</del>'; if (r.i) s = '<em>' + s + '</em>'; if (r.b) s = '<strong>' + s + '</strong>';
      return s;
    }).join('');
  }
  function xBlocks(bl) {
    var o = '', i = 0;
    while (i < bl.length) {
      var b = bl[i];
      if (b.t === 'h') { o += '<h' + b.l + '>' + xRuns(b.r) + '</h' + b.l + '>'; i++; }
      else if (b.t === 'li') {
        var tag = b.ord ? 'ol' : 'ul', g = [];
        while (i < bl.length && bl[i].t === 'li' && !!bl[i].ord === !!b.ord) g.push(bl[i++]);
        o += '<' + tag + '>' + g.map(function (x) { return '<li>' + xRuns(x.r) + '</li>'; }).join('') + '</' + tag + '>';
      }
      else if (b.t === 'table') {
        o += '<table>' + b.rows.map(function (r, ri) { var tg = b.head && ri === 0 ? 'th' : 'td'; return '<tr>' + r.map(function (c) { return '<' + tg + '>' + xRuns(c) + '</' + tg + '>'; }).join('') + '</tr>'; }).join('') + '</table>'; i++;
      }
      else if (b.t === 'q') { o += '<blockquote><p>' + xRuns(b.r) + '</p></blockquote>'; i++; }
      else if (b.t === 'code') { o += '<pre>' + esc(b.text) + '</pre>'; i++; }
      else if (b.t === 'hr') { o += '<hr/>'; i++; }
      else { o += '<p>' + xRuns(b.r) + '</p>'; i++; }
    }
    return o;
  }
  function buildEpub(text) {
    var bl = parseMd(text), chapters = [], cur = { title: '', blocks: [] }, bookTitle = '';
    bl.forEach(function (b) {
      if (b.t === 'h') {
        if (!bookTitle && b.l === 1) bookTitle = plainOf(b.r);
        if (b.l <= 2 && cur.blocks.length) { chapters.push(cur); cur = { title: '', blocks: [] }; }
        if (!cur.title) cur.title = plainOf(b.r);
      }
      cur.blocks.push(b);
    });
    if (cur.blocks.length) chapters.push(cur);
    if (!chapters.length) chapters.push({ title: 'Untitled', blocks: [{ t: 'p', r: [{ t: String(text || '') }] }] });
    if (!bookTitle) bookTitle = chapters[0].title || 'Untitled';
    var raw = String(text || ''), lang = /[\u0B80-\u0BFF]/.test(raw) ? 'ta' : /[\u0D80-\u0DFF]/.test(raw) ? 'si' : /[\u0900-\u097F]/.test(raw) ? 'hi' : 'en';
    var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) { var r = Math.random() * 16 | 0; return (c === 'x' ? r : (r & 3 | 8)).toString(16); });
    var NSX = 'xmlns="http://www.w3.org/1999/xhtml" xmlns:epub="http://www.idpf.org/2007/ops"';
    var page = function (title, inner) { return XML + '<!DOCTYPE html>\n<html ' + NSX + ' lang="' + lang + '" xml:lang="' + lang + '"><head><meta charset="utf-8"/><title>' + esc(title) + '</title><link rel="stylesheet" type="text/css" href="style.css"/></head><body>' + inner + '</body></html>'; };
    var files = [
      { name: 'mimetype', data: 'application/epub+zip' },
      { name: 'META-INF/container.xml', data: XML + '<container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container"><rootfiles><rootfile full-path="OEBPS/content.opf" media-type="application/oebps-package+xml"/></rootfiles></container>' },
      { name: 'OEBPS/style.css', data: 'body{font-family:serif;line-height:1.55;margin:5%}h1,h2,h3{font-family:sans-serif;line-height:1.25}h1{margin-top:1.2em}pre,code{font-family:monospace;font-size:.9em;background:#f2f2f2}pre{padding:.6em;white-space:pre-wrap}blockquote{margin:1em 0 1em 1em;padding-left:.8em;border-left:3px solid #b0b7c3;font-style:italic}table{border-collapse:collapse;margin:1em 0}td,th{border:1px solid #999;padding:.3em .5em}th{background:#eee}img{max-width:100%}' }
    ];
    var man = '', spine = '', nav = '', ncx = '';
    chapters.forEach(function (c, i) {
      var id = 'c' + (i + 1), href = id + '.xhtml', t = c.title || ('Part ' + (i + 1));
      files.push({ name: 'OEBPS/' + href, data: page(t, xBlocks(c.blocks)) });
      man += '<item id="' + id + '" href="' + href + '" media-type="application/xhtml+xml"/>';
      spine += '<itemref idref="' + id + '"/>';
      nav += '<li><a href="' + href + '">' + esc(t) + '</a></li>';
      ncx += '<navPoint id="n' + (i + 1) + '" playOrder="' + (i + 1) + '"><navLabel><text>' + esc(t) + '</text></navLabel><content src="' + href + '"/></navPoint>';
    });
    files.push({ name: 'OEBPS/nav.xhtml', data: XML + '<!DOCTYPE html>\n<html ' + NSX + ' lang="' + lang + '" xml:lang="' + lang + '"><head><meta charset="utf-8"/><title>Contents</title></head><body><nav epub:type="toc" id="toc"><h1>' + esc(bookTitle) + '</h1><ol>' + nav + '</ol></nav></body></html>' });
    files.push({ name: 'OEBPS/toc.ncx', data: XML + '<ncx xmlns="http://www.daisy.org/z3986/2005/ncx/" version="2005-1"><head><meta name="dtb:uid" content="urn:uuid:' + uuid + '"/><meta name="dtb:depth" content="1"/><meta name="dtb:totalPageCount" content="0"/><meta name="dtb:maxPageNumber" content="0"/></head><docTitle><text>' + esc(bookTitle) + '</text></docTitle><navMap>' + ncx + '</navMap></ncx>' });
    files.push({ name: 'OEBPS/content.opf', data: XML + '<package xmlns="http://www.idpf.org/2007/opf" version="3.0" unique-identifier="bookid" xml:lang="' + lang + '"><metadata xmlns:dc="http://purl.org/dc/elements/1.1/"><dc:identifier id="bookid">urn:uuid:' + uuid + '</dc:identifier><dc:title>' + esc(bookTitle) + '</dc:title><dc:language>' + lang + '</dc:language><dc:creator>Zen Ai</dc:creator><meta property="dcterms:modified">' + new Date().toISOString().replace(/\.\d+Z$/, 'Z') + '</meta></metadata><manifest><item id="nav" href="nav.xhtml" media-type="application/xhtml+xml" properties="nav"/><item id="ncx" href="toc.ncx" media-type="application/x-dtbncx+xml"/><item id="css" href="style.css" media-type="text/css"/>' + man + '</manifest><spine toc="ncx">' + spine + '</spine></package>' });
    return zipBlob(files, 'application/epub+zip');
  }

  /* ----- RTF ----- */
  var rEsc = function (s) {
    var o = '';
    for (var i = 0; i < s.length; i++) {
      var ch = s.charAt(i), c = s.charCodeAt(i);
      if (ch === '\\' || ch === '{' || ch === '}') o += '\\' + ch;
      else if (ch === '\n') o += '\\line ';
      else if (ch === '\t') o += '\\tab ';
      else if (c < 32) o += '';
      else if (c < 128) o += ch;
      else o += '\\u' + (c > 32767 ? c - 65536 : c) + '?';
    }
    return o;
  };
  var rRuns = function (runs, o) {
    o = o || {};
    return (runs || []).map(function (r) {
      var on = '', off = '';
      if (r.b || o.b) { on += '\\b '; off = '\\b0 ' + off; }
      if (r.i) { on += '\\i '; off = '\\i0 ' + off; }
      if (r.s) { on += '\\strike '; off = '\\strike0 ' + off; }
      if (r.c) { on += '\\f1 '; off = '\\f0 ' + off; }
      return on ? '{' + on + rEsc(r.t) + '}' : rEsc(r.t);
    }).join('');
  };
  function buildRtf(text) {
    var bl = parseMd(text), o = '{\\rtf1\\ansi\\ansicpg1252\\deff0\\uc1{\\fonttbl{\\f0\\fswiss Calibri;}{\\f1\\fmodern Courier New;}}{\\colortbl;\\red26\\green36\\blue51;\\red91\\green102\\blue120;\\red232\\green238\\blue247;}\\viewkind4\\paperw11906\\paperh16838\\margl1134\\margr1134\\margt1134\\margb1134\n';
    var sizes = { 1: 44, 2: 32, 3: 26 }, num = 0;
    bl.forEach(function (b) {
      if (b.t !== 'li') num = 0;
      if (b.t === 'h') o += '\\pard\\sb240\\sa120\\keepn\\b\\fs' + sizes[b.l] + ' ' + rRuns(b.r) + '\\b0\\fs22\\par\n';
      else if (b.t === 'li') {
        var ind = 360 + 360 * (b.lvl || 0); num = b.ord ? num + 1 : 0;
        o += '\\pard\\fi-360\\li' + ind + '\\sa80 ' + (b.ord ? num + '.\\tab ' : '\\u8226?\\tab ') + rRuns(b.r) + '\\par\n';
      }
      else if (b.t === 'q') o += '\\pard\\li567\\sa120\\i ' + rRuns(b.r) + '\\i0\\par\n';
      else if (b.t === 'code') o += '\\pard\\li113\\sa120\\f1\\fs19 ' + rEsc(b.text) + '\\f0\\fs22\\par\n';
      else if (b.t === 'hr') o += '\\pard\\sa120\\brdrb\\brdrs\\brdrw10\\brsp20 \\par\n';
      else if (b.t === 'table') {
        var n = b.rows[0] ? b.rows[0].length : 1, cw = Math.floor(9638 / n);
        b.rows.forEach(function (r, ri) {
          var hd = b.head && ri === 0, row = '\\trowd\\trgaph108';
          for (var k = 0; k < n; k++) row += '\\clbrdrt\\brdrs\\brdrw10\\clbrdrl\\brdrs\\brdrw10\\clbrdrb\\brdrs\\brdrw10\\clbrdrr\\brdrs\\brdrw10' + (hd ? '\\clshdrawnil\\clcbpat3' : '') + '\\cellx' + (cw * (k + 1));
          o += row + '\n' + r.map(function (c) { return '\\pard\\intbl ' + rRuns(c, { b: hd }) + '\\cell'; }).join('') + '\\row\n';
        });
        o += '\\pard\\sa120\\par\n';
      }
      else o += '\\pard\\sa140\\sl300\\slmult1 ' + rRuns(b.r) + '\\par\n';
    });
    return Promise.resolve(new Blob([o + '}'], { type: 'application/rtf' }));
  }

  /* ============================== v3: Office variants, .doc/.xls, BMP/GIF/ICO/TIFF, WAV/MIDI ============================== */
  var CTD = {
    docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml',
    xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml',
    pptx: 'application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml'
  };
  var CTM = null;
  function ctm(k) { return (CTM && CTM[k]) || CTD[k]; }
  var OFFV = {
    dotx: ['docx', 'application/vnd.openxmlformats-officedocument.wordprocessingml.template.main+xml'],
    docm: ['docx', 'application/vnd.ms-word.document.macroEnabled.main+xml'],
    xltx: ['xlsx', 'application/vnd.openxmlformats-officedocument.spreadsheetml.template.main+xml'],
    xlsm: ['xlsx', 'application/vnd.ms-excel.sheet.macroEnabled.main+xml'],
    ppsx: ['pptx', 'application/vnd.openxmlformats-officedocument.presentationml.slideshow.main+xml'],
    potx: ['pptx', 'application/vnd.openxmlformats-officedocument.presentationml.template.main+xml'],
    pptm: ['pptx', 'application/vnd.ms-powerpoint.presentation.macroEnabled.main+xml']
  };
  async function buildVariant(e, text) {
    var v = OFFV[e], fn = v[0] === 'docx' ? buildDocx : v[0] === 'xlsx' ? buildXlsx : buildPptx;
    CTM = {}; CTM[v[0]] = v[1];
    try { return new Blob([await fn(text)], { type: MIME[e] }); } finally { CTM = null; }
  }

  /* ----- .xls (HTML table workbook: Excel, WPS and LibreOffice open it) ----- */
  function buildXlsLegacy(text) {
    var sheets = parseSheets(text), h = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><meta charset="utf-8"/><style>td,th{border:.5pt solid #999;padding:2px 6px;font-family:Calibri,sans-serif}th{background:#e8eef7;font-weight:bold}</style></head><body>';
    sheets.forEach(function (s, si) {
      if (sheets.length > 1) h += '<p><b>' + esc(s.name) + '</b></p>';
      h += '<table>' + s.rows.map(function (r, ri) {
        return '<tr>' + r.map(function (c) {
          var v = c == null ? '' : String(c), tg = ri === 0 ? 'th' : 'td';
          if (v.charAt(0) === '=' && v.length > 1) return '<' + tg + ' x:fmla="' + esc(v) + '">' + esc(v) + '</' + tg + '>';
          return '<' + tg + (/^-?\d+(\.\d+)?$/.test(v.trim()) && ri > 0 ? ' x:num="' + v.trim() + '"' : '') + '>' + esc(v) + '</' + tg + '>';
        }).join('') + '</tr>';
      }).join('') + '</table>' + (si < sheets.length - 1 ? '<br/>' : '');
    });
    return Promise.resolve(new Blob([h + '</body></html>'], { type: 'application/vnd.ms-excel' }));
  }

  /* ----- raster images from SVG (BMP / GIF / ICO / TIFF) ----- */
  async function svgCanvas(text, maxSide) {
    var svg = String(text || '').trim(), at = svg.search(/<svg[\s>]/i);
    if (at < 0) throw new Error('Image needs SVG code inside the block');
    svg = svg.slice(at);
    if (!/<svg[^>]*\sxmlns=/i.test(svg)) svg = svg.replace(/<svg/i, '<svg xmlns="http://www.w3.org/2000/svg"');
    var head = svg.match(/<svg[^>]*>/i)[0], w = 0, h = 0, m;
    if ((m = head.match(/\swidth="([\d.]+)(px)?"/i))) w = parseFloat(m[1]);
    if ((m = head.match(/\sheight="([\d.]+)(px)?"/i))) h = parseFloat(m[1]);
    if ((!w || !h) && (m = head.match(/viewBox="[-\d.]+[ ,]+[-\d.]+[ ,]+([\d.]+)[ ,]+([\d.]+)"/i))) { w = w || parseFloat(m[1]); h = h || parseFloat(m[2]); }
    w = w || 512; h = h || 512;
    if (!/\swidth=/i.test(head) || !/\sheight=/i.test(head)) svg = svg.replace(/<svg/i, '<svg width="' + w + '" height="' + h + '"');
    var k = Math.min(maxSide / Math.max(w, h), 3), url = URL.createObjectURL(new Blob([svg], { type: 'image/svg+xml;charset=utf-8' }));
    try {
      var img = new Image(); img.src = url; await img.decode();
      var cv = document.createElement('canvas'); cv.width = Math.max(1, Math.round(w * k)); cv.height = Math.max(1, Math.round(h * k));
      var cx = cv.getContext('2d'); cx.fillStyle = '#fff'; cx.fillRect(0, 0, cv.width, cv.height); cx.drawImage(img, 0, 0, cv.width, cv.height);
      return cv;
    } finally { URL.revokeObjectURL(url); }
  }
  var u16 = function (v, n) { v[n.o++] = n.x & 255; };
  function bmpEncode(w, h, px) {
    var rs = (w * 3 + 3) & ~3, size = 54 + rs * h, b = new Uint8Array(size), d = new DataView(b.buffer);
    b[0] = 66; b[1] = 77; d.setUint32(2, size, true); d.setUint32(10, 54, true); d.setUint32(14, 40, true);
    d.setInt32(18, w, true); d.setInt32(22, h, true); d.setUint16(26, 1, true); d.setUint16(28, 24, true); d.setUint32(34, rs * h, true); d.setInt32(38, 2835, true); d.setInt32(42, 2835, true);
    for (var y = 0; y < h; y++) for (var x = 0; x < w; x++) {
      var s = ((h - 1 - y) * w + x) * 4, o = 54 + y * rs + x * 3, a = px[s + 3] / 255;
      b[o] = Math.round(px[s + 2] * a + 255 * (1 - a)); b[o + 1] = Math.round(px[s + 1] * a + 255 * (1 - a)); b[o + 2] = Math.round(px[s] * a + 255 * (1 - a));
    }
    return b;
  }
  function tiffEncode(w, h, px) {
    var n = 10, ifdOff = 8, ifdLen = 2 + n * 12 + 4, extOff = ifdOff + ifdLen, dataOff = extOff + 6 + 16, size = dataOff + w * h * 3;
    var b = new Uint8Array(size), d = new DataView(b.buffer);
    b[0] = 73; b[1] = 73; d.setUint16(2, 42, true); d.setUint32(4, ifdOff, true); d.setUint16(ifdOff, n, true);
    var tag = function (i, t, ty, cnt, val) { var o = ifdOff + 2 + i * 12; d.setUint16(o, t, true); d.setUint16(o + 2, ty, true); d.setUint32(o + 4, cnt, true); if (ty === 3 && cnt === 1) d.setUint16(o + 8, val, true); else d.setUint32(o + 8, val, true); };
    tag(0, 256, 4, 1, w); tag(1, 257, 4, 1, h); tag(2, 258, 3, 3, extOff); tag(3, 259, 3, 1, 1); tag(4, 262, 3, 1, 2); tag(5, 273, 4, 1, dataOff);
    tag(6, 277, 3, 1, 3); tag(7, 278, 4, 1, h); tag(8, 279, 4, 1, w * h * 3); tag(9, 284, 3, 1, 1);
    d.setUint16(extOff, 8, true); d.setUint16(extOff + 2, 8, true); d.setUint16(extOff + 4, 8, true);
    for (var i = 0, o = dataOff; i < w * h; i++) { var a = px[i * 4 + 3] / 255; for (var c = 0; c < 3; c++) b[o++] = Math.round(px[i * 4 + c] * a + 255 * (1 - a)); }
    return b;
  }
  function gifEncode(w, h, px) {
    var out = [], pal = [], r, g, bl;
    for (r = 0; r < 6; r++) for (g = 0; g < 6; g++) for (bl = 0; bl < 6; bl++) pal.push(r * 51, g * 51, bl * 51);
    while (pal.length < 768) pal.push(0, 0, 0);
    out.push(71, 73, 70, 56, 57, 97, w & 255, w >> 8, h & 255, h >> 8, 0xF7, 0, 0); out.push.apply(out, pal);
    out.push(0x2C, 0, 0, 0, 0, w & 255, w >> 8, h & 255, h >> 8, 0, 8);
    var idx = new Uint8Array(w * h);
    for (var i = 0; i < w * h; i++) {
      var a = px[i * 4 + 3] / 255, q = function (c) { return Math.min(5, Math.round((c * a + 255 * (1 - a)) / 51)); };
      idx[i] = q(px[i * 4]) * 36 + q(px[i * 4 + 1]) * 6 + q(px[i * 4 + 2]);
    }
    var bytes = [], cur = 0, nb = 0, cs = 9, next, dict, emit = function (code) { cur |= code << nb; nb += cs; while (nb >= 8) { bytes.push(cur & 255); cur >>>= 8; nb -= 8; } };
    var reset = function () { dict = new Map(); next = 258; cs = 9; };
    reset(); emit(256);
    var pre = idx[0];
    for (var k = 1; k < idx.length; k++) {
      var c = idx[k], key = pre * 256 + c, hit = dict.get(key);
      if (hit !== undefined) { pre = hit; continue; }
      emit(pre);
      if (next < 4096) { dict.set(key, next++); if (next > (1 << cs) && cs < 12) cs++; }
      else { emit(256); reset(); }
      pre = c;
    }
    emit(pre); emit(257); if (nb > 0) bytes.push(cur & 255);
    for (var p = 0; p < bytes.length; p += 255) { var n = Math.min(255, bytes.length - p); out.push(n); for (var z = 0; z < n; z++) out.push(bytes[p + z]); }
    out.push(0, 0x3B);
    return new Uint8Array(out);
  }
  async function buildRaster(e, text) {
    var cv = await svgCanvas(text, e === 'ico' ? 256 : 1600), w = cv.width, h = cv.height;
    if (e === 'ico') {
      var png = new Uint8Array(await (await new Promise(function (res, rej) { cv.toBlob(function (b) { b ? res(b) : rej(new Error('icon export failed')); }, 'image/png'); })).arrayBuffer());
      var hd = new Uint8Array(22 + png.length), dv = new DataView(hd.buffer);
      dv.setUint16(2, 1, true); dv.setUint16(4, 1, true); hd[6] = w >= 256 ? 0 : w; hd[7] = h >= 256 ? 0 : h; dv.setUint16(10, 1, true); dv.setUint16(12, 32, true); dv.setUint32(14, png.length, true); dv.setUint32(18, 22, true); hd.set(png, 22);
      return new Blob([hd], { type: 'image/x-icon' });
    }
    var px = cv.getContext('2d').getImageData(0, 0, w, h).data;
    if (e === 'bmp') return new Blob([bmpEncode(w, h, px)], { type: 'image/bmp' });
    if (e === 'gif') return new Blob([gifEncode(w, h, px)], { type: 'image/gif' });
    return new Blob([tiffEncode(w, h, px)], { type: 'image/tiff' });
  }

  /* ----- audio: melody text -> WAV / MIDI ----- */
  function parseMelody(text) {
    var src = String(text || '').replace(/```[^\n]*\n?/g, '').replace(/#[^\n]*$/gm, function (m) { return /^#\s/.test(m) ? '' : m; }), tempo = 120, prog = 0, m;
    if ((m = src.match(/tempo\s*[=:]\s*(\d+)/i))) tempo = Math.max(30, Math.min(300, +m[1]));
    if ((m = src.match(/instrument\s*[=:]\s*(\d+)/i))) prog = Math.max(0, Math.min(127, +m[1]));
    src = src.replace(/(tempo|instrument)\s*[=:]\s*\d+/gi, '');
    var base = { C: 0, D: 2, E: 4, F: 5, G: 7, A: 9, B: 11 }, notes = [];
    src.split(/[\s,;|]+/).forEach(function (tk) {
      if (!tk) return;
      var parts = tk.split(':'), beats = parts[1] ? parseFloat(parts[1]) : 1;
      if (!(beats > 0)) beats = 1; beats = Math.min(beats, 16);
      var head = parts[0], chord = [];
      if (/^[Rr]$/.test(head) || /^rest$/i.test(head)) { notes.push({ n: [], b: beats }); return; }
      head.split('+').forEach(function (nt) {
        var mm = nt.match(/^([A-Ga-g])([#b]?)(-?\d)$/); if (!mm) return;
        var midi = 12 * (parseInt(mm[3], 10) + 1) + base[mm[1].toUpperCase()] + (mm[2] === '#' ? 1 : mm[2] === 'b' ? -1 : 0);
        chord.push(Math.max(0, Math.min(127, midi)));
      });
      if (chord.length) notes.push({ n: chord, b: beats });
    });
    if (!notes.length) throw new Error('Melody needs notes like C4:1 E4:1 G4:2');
    return { tempo: tempo, prog: prog, notes: notes };
  }
  function buildWav(text) {
    var M = parseMelody(text), sr = 22050, spb = 60 / M.tempo, total = 0;
    M.notes.forEach(function (n) { total += n.b * spb; });
    var N = Math.ceil((total + 0.3) * sr), pcm = new Float32Array(N), pos = 0;
    M.notes.forEach(function (n) {
      var len = Math.floor(n.b * spb * sr);
      n.n.forEach(function (mi) {
        var f = 440 * Math.pow(2, (mi - 69) / 12), amp = 0.5 / Math.max(1, n.n.length), tail = Math.floor(0.15 * sr), L = Math.min(N - pos, len + tail);
        for (var i = 0; i < L; i++) {
          var t = i / sr, env = Math.min(1, i / (0.01 * sr)) * (i < len ? Math.exp(-1.2 * t / Math.max(0.2, n.b * spb)) : Math.exp(-1.2 * (len / sr) / Math.max(0.2, n.b * spb)) * Math.max(0, 1 - (i - len) / tail));
          pcm[pos + i] += amp * env * (Math.sin(2 * Math.PI * f * t) + 0.25 * Math.sin(4 * Math.PI * f * t) + 0.1 * Math.sin(6 * Math.PI * f * t));
        }
      });
      pos += len;
    });
    var b = new Uint8Array(44 + N * 2), d = new DataView(b.buffer), W = function (o, s) { for (var i = 0; i < s.length; i++) b[o + i] = s.charCodeAt(i); };
    W(0, 'RIFF'); d.setUint32(4, 36 + N * 2, true); W(8, 'WAVEfmt '); d.setUint32(16, 16, true); d.setUint16(20, 1, true); d.setUint16(22, 1, true); d.setUint32(24, sr, true); d.setUint32(28, sr * 2, true); d.setUint16(32, 2, true); d.setUint16(34, 16, true); W(36, 'data'); d.setUint32(40, N * 2, true);
    for (var i = 0; i < N; i++) d.setInt16(44 + i * 2, Math.max(-1, Math.min(1, pcm[i])) * 32000, true);
    return Promise.resolve(new Blob([b], { type: 'audio/wav' }));
  }
  function buildMidi(text) {
    var M = parseMelody(text), tpq = 480, tr = [];
    var vlq = function (v) { var o = [v & 127]; while ((v >>= 7)) o.unshift((v & 127) | 128); return o; };
    var us = Math.round(60000000 / M.tempo);
    tr.push(0, 0xFF, 0x51, 3, (us >> 16) & 255, (us >> 8) & 255, us & 255); tr.push(0, 0xC0, M.prog);
    var rest = 0;
    M.notes.forEach(function (n) {
      var dur = Math.round(n.b * tpq);
      if (!n.n.length) { rest += dur; return; }
      n.n.forEach(function (mi, i) { tr.push.apply(tr, vlq(i === 0 ? rest : 0)); tr.push(0x90, mi, 90); });
      rest = 0;
      n.n.forEach(function (mi, i) { tr.push.apply(tr, vlq(i === 0 ? dur : 0)); tr.push(0x80, mi, 0); });
    });
    tr.push.apply(tr, vlq(rest)); tr.push(0xFF, 0x2F, 0);
    var h = [77, 84, 104, 100, 0, 0, 0, 6, 0, 0, 0, 1, tpq >> 8, tpq & 255, 77, 84, 114, 107, (tr.length >> 24) & 255, (tr.length >> 16) & 255, (tr.length >> 8) & 255, tr.length & 255];
    return Promise.resolve(new Blob([new Uint8Array(h.concat(tr))], { type: 'audio/midi' }));
  }

  /* ============================== v4: FLAC, OGG/OPUS, M4A/AAC, MP3 ============================== */
  function melodyFloat(text, sr) {
    var M = parseMelody(text), spb = 60 / M.tempo, total = 0;
    M.notes.forEach(function (n) { total += n.b * spb; });
    var N = Math.ceil((total + 0.3) * sr), pcm = new Float32Array(N), pos = 0;
    M.notes.forEach(function (n) {
      var len = Math.floor(n.b * spb * sr);
      n.n.forEach(function (mi) {
        var f = 440 * Math.pow(2, (mi - 69) / 12), amp = 0.5 / Math.max(1, n.n.length), tail = Math.floor(0.15 * sr), L = Math.min(N - pos, len + tail);
        for (var i = 0; i < L; i++) {
          var t = i / sr, env = Math.min(1, i / (0.01 * sr)) * (i < len ? Math.exp(-1.2 * t / Math.max(0.2, n.b * spb)) : Math.exp(-1.2 * (len / sr) / Math.max(0.2, n.b * spb)) * Math.max(0, 1 - (i - len) / tail));
          pcm[pos + i] += amp * env * (Math.sin(2 * Math.PI * f * t) + 0.25 * Math.sin(4 * Math.PI * f * t) + 0.1 * Math.sin(6 * Math.PI * f * t));
        }
      });
      pos += len;
    });
    return pcm;
  }
  var toI16 = function (f) { var o = new Int16Array(f.length); for (var i = 0; i < f.length; i++) o[i] = Math.round(Math.max(-1, Math.min(1, f[i])) * 32000); return o; };

  /* ----- FLAC (lossless, written from scratch) ----- */
  function BitW() { this.a = []; this.cur = 0; this.n = 0; }
  BitW.prototype.put = function (v, b) { for (var i = b - 1; i >= 0; i--) { this.cur = (this.cur << 1) | ((v >>> i) & 1); if (++this.n === 8) { this.a.push(this.cur); this.cur = 0; this.n = 0; } } };
  BitW.prototype.zeros = function (c) { while (c-- > 0) { this.cur <<= 1; if (++this.n === 8) { this.a.push(this.cur); this.cur = 0; this.n = 0; } } };
  BitW.prototype.align = function () { if (this.n) { this.cur <<= (8 - this.n); this.a.push(this.cur); this.cur = 0; this.n = 0; } };
  var crc8 = function (b) { var c = 0; for (var i = 0; i < b.length; i++) { c ^= b[i]; for (var k = 0; k < 8; k++) c = c & 128 ? ((c << 1) ^ 7) & 255 : (c << 1) & 255; } return c; };
  var crc16 = function (b) { var c = 0; for (var i = 0; i < b.length; i++) { c ^= b[i] << 8; for (var k = 0; k < 8; k++) c = c & 0x8000 ? ((c << 1) ^ 0x8005) & 0xFFFF : (c << 1) & 0xFFFF; } return c; };
  var zz = function (v) { return v >= 0 ? v * 2 : -v * 2 - 1; };
  function riceCost(res, from, to, k) { var s = 0; for (var i = from; i < to; i++) s += Math.floor(zz(res[i]) / (1 << k)); return s + (to - from) * (k + 1); }
  function bestRice(res, from, to) { var bk = 0, bc = Infinity; for (var k = 0; k <= 14; k++) { var c = riceCost(res, from, to, k); if (c < bc) { bc = c; bk = k; } } return [bk, bc + 4]; }
  function flacFrame(x, fn, sr, BS) {
    var n = x.length, w = new BitW(), i;
    var SRC = { 8000: 4, 16000: 5, 22050: 6, 24000: 7, 32000: 8, 44100: 9, 48000: 10 };
    w.put(0xFFF8, 16); w.put(n === 4096 ? 12 : 7, 4); w.put(SRC[sr] || 0, 4); w.put(0, 4); w.put(4, 3); w.put(0, 1);
    if (fn < 128) w.put(fn, 8); else if (fn < 2048) { w.put(0xC0 | (fn >> 6), 8); w.put(0x80 | (fn & 63), 8); } else { w.put(0xE0 | (fn >> 12), 8); w.put(0x80 | ((fn >> 6) & 63), 8); w.put(0x80 | (fn & 63), 8); }
    if (n !== 4096) w.put(n - 1, 16);
    w.align(); w.put(crc8(w.a), 8);
    var same = true; for (i = 1; i < n; i++) if (x[i] !== x[0]) { same = false; break; }
    if (same) { w.put(0, 8); w.put(x[0] & 0xFFFF, 16); }
    else {
      var best = { cost: n * 16, o: -1 };
      for (var o = 0; o <= 4 && o < n; o++) {
        var res = new Int32Array(n);
        for (i = o; i < n; i++) res[i] = o === 0 ? x[i] : o === 1 ? x[i] - x[i - 1] : o === 2 ? x[i] - 2 * x[i - 1] + x[i - 2] : o === 3 ? x[i] - 3 * x[i - 1] + 3 * x[i - 2] - x[i - 3] : x[i] - 4 * x[i - 1] + 6 * x[i - 2] - 4 * x[i - 3] + x[i - 4];
        for (var p = 0; p <= 5; p++) {
          var parts = 1 << p; if (n % parts || (n >> p) <= o) break;
          var sz = n >> p, cost = o * 16 + 6 + 4, ks = [];
          for (var q = 0; q < parts; q++) { var br = bestRice(res, q === 0 ? o : q * sz, (q + 1) * sz); ks.push(br[0]); cost += br[1]; }
          if (cost < best.cost) best = { cost: cost, o: o, p: p, ks: ks, res: res };
        }
      }
      if (best.o < 0) { w.put(2, 8); for (i = 0; i < n; i++) w.put(x[i] & 0xFFFF, 16); }
      else {
        w.put((8 + best.o) << 1, 8);
        for (i = 0; i < best.o; i++) w.put(x[i] & 0xFFFF, 16);
        w.put(0, 2); w.put(best.p, 4);
        var psz = n >> best.p;
        for (var q2 = 0; q2 < (1 << best.p); q2++) {
          var k = best.ks[q2]; w.put(k, 4);
          for (i = q2 === 0 ? best.o : q2 * psz; i < (q2 + 1) * psz; i++) { var u = zz(best.res[i]), qq = Math.floor(u / (1 << k)); w.zeros(qq); w.put(1, 1); if (k) w.put(u - qq * (1 << k), k); }
        }
      }
    }
    w.align(); var c16 = crc16(w.a); w.put(c16, 16);
    return w.a;
  }
  function flacEncode(x, sr) {
    var BS = 4096, total = x.length, frames = [], fn = 0;
    for (var off = 0; off < total; off += BS) frames.push(flacFrame(x.subarray(off, Math.min(total, off + BS)), fn++, sr, BS));
    var si = new BitW(); var bsz = Math.max(16, Math.min(BS, total));
    si.put(bsz, 16); si.put(bsz, 16); si.put(0, 24); si.put(0, 24); si.put(sr, 20); si.put(0, 3); si.put(15, 5); si.put(Math.floor(total / 4294967296), 4); si.put(total >>> 0, 32);
    for (var z = 0; z < 16; z++) si.put(0, 8);
    var out = [102, 76, 97, 67, 0x80, 0, 0, 34].concat(si.a);
    frames.forEach(function (f) { out = out.concat(f); });
    return new Uint8Array(out);
  }
  function buildFlac(text) {
    var sr = 22050;
    return Promise.resolve(new Blob([flacEncode(toI16(melodyFloat(text, sr)), sr)], { type: 'audio/flac' }));
  }

  /* ----- browser audio encoders (WebCodecs) ----- */
  async function webEncode(codec, pcm, sr, bitrate, extra) {
    if (typeof AudioEncoder === 'undefined' || typeof AudioData === 'undefined') throw new Error('this browser cannot create ' + (codec === 'opus' ? 'OGG' : 'M4A') + ' sound (Chrome 94 or newer needed)');
    var cfg = { codec: codec, sampleRate: sr, numberOfChannels: 1, bitrate: bitrate };
    if (extra) Object.keys(extra).forEach(function (k) { cfg[k] = extra[k]; });
    var sup = await AudioEncoder.isConfigSupported(cfg);
    if (!sup || !sup.supported) throw new Error('this phone cannot encode ' + (codec === 'opus' ? 'OGG (Opus)' : 'M4A (AAC)') + ' sound');
    var chunks = [], desc = null, err = null;
    var enc = new AudioEncoder({
      output: function (c, m) {
        var u = new Uint8Array(c.byteLength); c.copyTo(u); chunks.push(u);
        if (m && m.decoderConfig && m.decoderConfig.description && !desc) { var d = m.decoderConfig.description; desc = new Uint8Array(d.buffer ? d.buffer.slice(d.byteOffset, d.byteOffset + d.byteLength) : d); }
      },
      error: function (e) { err = e; }
    });
    enc.configure(cfg);
    var step = Math.floor(sr / 2);
    for (var off = 0; off < pcm.length; off += step) {
      var part = pcm.slice(off, Math.min(pcm.length, off + step));
      var ad = new AudioData({ format: 'f32', sampleRate: sr, numberOfFrames: part.length, numberOfChannels: 1, timestamp: Math.round(off / sr * 1e6), data: part });
      enc.encode(ad); ad.close();
    }
    await enc.flush(); enc.close();
    if (err) throw err;
    if (!chunks.length) throw new Error('encoder returned no audio');
    return { chunks: chunks, desc: desc };
  }

  /* ----- OGG container for Opus ----- */
  var OGGCRC = (function () { var t = new Uint32Array(256); for (var i = 0; i < 256; i++) { var r = i << 24; for (var k = 0; k < 8; k++) r = r & 0x80000000 ? ((r << 1) ^ 0x04C11DB7) : (r << 1); t[i] = r >>> 0; } return t; })();
  function oggPage(serial, seq, flags, granule, packets) {
    var segs = [], body = [];
    packets.forEach(function (p) { var l = p.length; while (l >= 255) { segs.push(255); l -= 255; } segs.push(l); body.push(p); });
    var len = 27 + segs.length; body.forEach(function (p) { len += p.length; });
    var b = new Uint8Array(len), d = new DataView(b.buffer);
    b.set([79, 103, 103, 83, 0, flags]); d.setUint32(6, granule % 4294967296 >>> 0, true); d.setUint32(10, Math.floor(granule / 4294967296), true);
    d.setUint32(14, serial, true); d.setUint32(18, seq, true); b[26] = segs.length; b.set(segs, 27);
    var o = 27 + segs.length; body.forEach(function (p) { b.set(p, o); o += p.length; });
    var c = 0; for (var i = 0; i < b.length; i++) c = ((c << 8) ^ OGGCRC[((c >>> 24) ^ b[i]) & 255]) >>> 0;
    d.setUint32(22, c, true);
    return b;
  }
  function oggOpusMux(packets, inputSamples, inRate) {
    var ser = (Math.random() * 4294967295) >>> 0, pre = 312, enc = function (s) { return Array.prototype.map.call(s, function (ch) { return ch.charCodeAt(0); }); };
    var head = new Uint8Array(19); head.set(enc('OpusHead')); head[8] = 1; head[9] = 1; head[10] = pre & 255; head[11] = pre >> 8; new DataView(head.buffer).setUint32(12, inRate || 48000, true);
    var vend = enc('Zen Ai'), tags = new Uint8Array(8 + 4 + vend.length + 4); tags.set(enc('OpusTags')); new DataView(tags.buffer).setUint32(8, vend.length, true); tags.set(vend, 12);
    var pages = [oggPage(ser, 0, 2, 0, [head]), oggPage(ser, 1, 0, 0, [tags])], seq = 2, i = 0, perPage = 40;
    var lastGr = pre + inputSamples;
    while (i < packets.length) {
      var grp = packets.slice(i, i + perPage); i += grp.length;
      var last = i >= packets.length, gr = last ? lastGr : pre + i * 960;
      pages.push(oggPage(ser, seq++, last ? 4 : 0, gr, grp));
    }
    return new Blob(pages, { type: 'audio/ogg' });
  }
  async function buildOgg(text) {
    var sr = 48000, pcm = melodyFloat(text, sr), r = await webEncode('opus', pcm, sr, 64000);
    return oggOpusMux(r.chunks, pcm.length, sr);
  }

  /* ----- MP4 container for AAC (.m4a) and raw .aac ----- */
  var be32 = function (v) { return [(v >>> 24) & 255, (v >>> 16) & 255, (v >>> 8) & 255, v & 255]; };
  var be16 = function (v) { return [(v >> 8) & 255, v & 255]; };
  function mbox(type, parts) {
    var body = [].concat.apply([], parts.map(function (p) { return Array.prototype.slice.call(p); }));
    return [].concat(be32(body.length + 8), Array.prototype.map.call(type, function (c) { return c.charCodeAt(0); }), body);
  }
  var AACSR = [96000, 88200, 64000, 48000, 44100, 32000, 24000, 22050, 16000, 12000, 11025, 8000, 7350];
  function aacAsc(sr) { var i = AACSR.indexOf(sr); if (i < 0) i = 4; return [(2 << 3) | (i >> 1), ((i & 1) << 7) | (1 << 3)]; }
  function m4aMux(frames, sr, desc) {
    var asc = desc && desc.length ? Array.prototype.slice.call(desc) : aacAsc(sr), N = frames.length, dur = N * 1024, mdatLen = 0;
    frames.forEach(function (f) { mdatLen += f.length; });
    var ftyp = mbox('ftyp', [[77, 52, 65, 32], be32(0), [77, 52, 65, 32, 109, 112, 52, 50, 105, 115, 111, 109]]);
    var matrix = [].concat(be32(0x10000), be32(0), be32(0), be32(0), be32(0x10000), be32(0), be32(0), be32(0), be32(0x40000000));
    var z = function (n) { return new Array(n + 1).join('0').split('').map(function () { return 0; }); };
    var esds = mbox('esds', [be32(0), [3, 23 + asc.length - 2 + 2, 0, 0, 0], [4, 15 + asc.length, 0x40, 0x15], z(3), be32(0), be32(0), [5, asc.length], asc, [6, 1, 2]]);
    var mp4a = mbox('mp4a', [z(6), be16(1), z(8), be16(1), be16(16), be16(0), be16(0), be32((sr << 16) >>> 0), esds]);
    var stsd = mbox('stsd', [be32(0), be32(1), mp4a]);
    var stts = mbox('stts', [be32(0), be32(1), be32(N), be32(1024)]);
    var stsc = mbox('stsc', [be32(0), be32(1), be32(1), be32(N), be32(1)]);
    var stsz = mbox('stsz', [be32(0), be32(0), be32(N)].concat(frames.map(function (f) { return be32(f.length); })));
    var stco = mbox('stco', [be32(0), be32(1), be32(ftyp.length + 8)]);
    var stbl = mbox('stbl', [stsd, stts, stsc, stsz, stco]);
    var dinf = mbox('dinf', [mbox('dref', [be32(0), be32(1), mbox('url ', [be32(1)])])]);
    var minf = mbox('minf', [mbox('smhd', [be32(0), be16(0), be16(0)]), dinf, stbl]);
    var hdlr = mbox('hdlr', [be32(0), be32(0), [115, 111, 117, 110], z(12), [83, 111, 117, 110, 100, 0]]);
    var mdia = mbox('mdia', [mbox('mdhd', [be32(0), be32(0), be32(0), be32(sr), be32(dur), be16(0x55C4), be16(0)]), hdlr, minf]);
    var tkhd = mbox('tkhd', [be32(3), be32(0), be32(0), be32(1), be32(0), be32(dur), z(8), be16(0), be16(0), be16(0x100), be16(0), matrix, be32(0), be32(0)]);
    var mvhd = mbox('mvhd', [be32(0), be32(0), be32(0), be32(sr), be32(dur), be32(0x10000), be16(0x100), z(10), matrix, z(24), be32(2)]);
    var moov = mbox('moov', [mvhd, mbox('trak', [tkhd, mdia])]);
    return new Blob([new Uint8Array(ftyp), new Uint8Array(be32(mdatLen + 8).concat([109, 100, 97, 116])), new Blob(frames), new Uint8Array(moov)], { type: 'audio/mp4' });
  }
  function adtsMux(frames, sr) {
    var i = AACSR.indexOf(sr); if (i < 0) i = 4; var parts = [];
    frames.forEach(function (f) { var L = f.length + 7; parts.push(new Uint8Array([0xFF, 0xF1, (1 << 6) | (i << 2) | 0, (1 << 6) | ((L >> 11) & 3), (L >> 3) & 255, ((L & 7) << 5) | 0x1F, 0xFC]), f); });
    return new Blob(parts, { type: 'audio/aac' });
  }
  async function buildAac(e, text) {
    var sr = 44100, pcm = melodyFloat(text, sr), r = await webEncode('mp4a.40.2', pcm, sr, 96000, { aac: { format: 'aac' } });
    return e === 'aac' ? adtsMux(r.chunks, sr) : m4aMux(r.chunks, sr, r.desc);
  }

  /* ----- MP3 (library is fetched once, needs internet that one time) ----- */
  function loadLame() {
    if (typeof window !== 'undefined' && window.lamejs) return Promise.resolve();
    var urls = ['https://cdnjs.cloudflare.com/ajax/libs/lamejs/1.2.1/lame.min.js', 'https://cdn.jsdelivr.net/npm/lamejs@1.2.1/lame.min.js'];
    return urls.reduce(function (p, u) {
      return p.catch(function () {
        return new Promise(function (res, rej) {
          if (window.lamejs) return res();
          var s = document.createElement('script'); s.src = u; s.onload = function () { window.lamejs ? res() : rej(new Error('x')); }; s.onerror = function () { rej(new Error('x')); }; document.head.appendChild(s);
        });
      });
    }, Promise.reject(new Error('start'))).catch(function () { throw new Error('MP3 needs internet the first time (to download the encoder)'); });
  }
  async function buildMp3(text) {
    var sr = 44100, pcm = toI16(melodyFloat(text, sr));
    await loadLame();
    var enc = new window.lamejs.Mp3Encoder(1, sr, 128), out = [];
    for (var i = 0; i < pcm.length; i += 1152) { var b = enc.encodeBuffer(pcm.subarray(i, i + 1152)); if (b && b.length) out.push(new Uint8Array(b)); }
    var f = enc.flush(); if (f && f.length) out.push(new Uint8Array(f));
    return new Blob(out, { type: 'audio/mpeg' });
  }

  /* ============================== v5: VIDEO (.mp4 .mov .webm .mkv) from SVG frames, using the phone's own encoder (no library) ============================== */
  function parseFrames(text) {
    var src = String(text || '').replace(/```[^\n]*\n?/g, ''), sec = 2, fps = 10, m;
    if ((m = src.match(/seconds\s*[=:]\s*([\d.]+)/i))) sec = Math.max(0.1, Math.min(30, +m[1]));
    if ((m = src.match(/fps\s*[=:]\s*(\d+)/i))) fps = Math.max(1, Math.min(30, +m[1]));
    var frames = [];
    src.split(/^\s*-{3,}\s*$/m).forEach(function (p) {
      var i = p.search(/<svg[\s>]/i); if (i < 0) return;
      var j = p.toLowerCase().lastIndexOf('</svg>'); frames.push(j >= 0 ? p.slice(i, j + 6) : p.slice(i));
    });
    if (!frames.length) throw new Error('Video needs SVG frames separated by a line with ---');
    if (frames.length > 90) frames.length = 90;
    var per = Math.max(1, Math.round(sec * fps));
    while (frames.length * per > 1800 && per > 1) per--;
    return { fps: fps, per: per, frames: frames };
  }
  async function encodeVideo(text, kind) {
    var P = parseFrames(text);
    if (typeof VideoEncoder === 'undefined' || typeof VideoFrame === 'undefined') throw new Error('this browser cannot create video (Chrome 94 or newer needed)');
    var first = await svgCanvas(P.frames[0], 1280), W = first.width, H = first.height, sc = Math.min(1, Math.sqrt(921600 / (W * H)), 1280 / Math.max(W, H));
    W = Math.max(16, Math.round(W * sc / 2) * 2); H = Math.max(16, Math.round(H * sc / 2) * 2);
    var cands = kind === 'avc' ? ['avc1.42001f', 'avc1.42E01F', 'avc1.4d001f'] : ['vp8', 'vp09.00.10.08'], cfg = null, i, sup;
    for (i = 0; i < cands.length && !cfg; i++) {
      var c = { codec: cands[i], width: W, height: H, bitrate: 1500000, framerate: P.fps, latencyMode: 'realtime' };
      if (kind === 'avc') c.avc = { format: 'avc' };
      try { sup = await VideoEncoder.isConfigSupported(c); if (sup && sup.supported) cfg = c; } catch (e) { }
    }
    if (!cfg) throw new Error('this phone cannot encode ' + (kind === 'avc' ? 'MP4 (H.264)' : 'WebM') + ' video');
    var out = [], desc = null, err = null;
    var enc = new VideoEncoder({
      output: function (ch, m) {
        var u = new Uint8Array(ch.byteLength); ch.copyTo(u); out.push({ d: u, key: ch.type === 'key', ts: ch.timestamp });
        if (m && m.decoderConfig && m.decoderConfig.description && !desc) { var d = m.decoderConfig.description; desc = new Uint8Array(d.buffer ? d.buffer.slice(d.byteOffset, d.byteOffset + d.byteLength) : d); }
      },
      error: function (e) { err = e; }
    });
    enc.configure(cfg);
    var cv = document.createElement('canvas'); cv.width = W; cv.height = H; var cx = cv.getContext('2d'), n = 0, dur = Math.round(1e6 / P.fps);
    for (var s = 0; s < P.frames.length; s++) {
      var img = s === 0 ? first : await svgCanvas(P.frames[s], Math.max(W, H));
      cx.fillStyle = '#fff'; cx.fillRect(0, 0, W, H);
      var k = Math.min(W / img.width, H / img.height), dw = Math.round(img.width * k), dh = Math.round(img.height * k);
      cx.drawImage(img, Math.round((W - dw) / 2), Math.round((H - dh) / 2), dw, dh);
      for (var r = 0; r < P.per; r++, n++) {
        while (enc.encodeQueueSize > 8) await new Promise(function (res) { setTimeout(res, 5); });
        var vf = new VideoFrame(cv, { timestamp: Math.round(n * 1e6 / P.fps), duration: dur });
        enc.encode(vf, { keyFrame: r === 0 || n % P.fps === 0 }); vf.close();
        if (err) throw err;
      }
    }
    await enc.flush(); enc.close(); if (err) throw err;
    if (!out.length) throw new Error('encoder returned no video');
    return { out: out, desc: desc, W: W, H: H, fps: P.fps, codec: cfg.codec };
  }
  /* MP4 / MOV container for H.264 */
  function mp4VideoMux(r, brand) {
    var N = r.out.length, ts = r.fps * 1000, dur = N * 1000, W = r.W, H = r.H, mdatLen = 0;
    if (!r.desc) throw new Error('encoder gave no H.264 settings');
    r.out.forEach(function (f) { mdatLen += f.d.length; });
    var z = function (c) { var a = []; while (c-- > 0) a.push(0); return a; }, B = function (s) { return Array.prototype.map.call(s, function (ch) { return ch.charCodeAt(0); }); };
    var ftyp = mbox('ftyp', [B(brand), be32(0x200), B(brand), B('isom'), B('avc1'), B('mp42')]);
    var matrix = [].concat(be32(0x10000), be32(0), be32(0), be32(0), be32(0x10000), be32(0), be32(0), be32(0), be32(0x40000000));
    var avc1 = mbox('avc1', [z(6), be16(1), z(16), be16(W), be16(H), be32(0x480000), be32(0x480000), be32(0), be16(1), z(32), be16(0x18), be16(0xFFFF), mbox('avcC', [r.desc])]);
    var keys = []; r.out.forEach(function (f, i) { if (f.key) keys.push(be32(i + 1)); });
    var stbl = mbox('stbl', [mbox('stsd', [be32(0), be32(1), avc1]), mbox('stts', [be32(0), be32(1), be32(N), be32(1000)]),
      mbox('stss', [be32(0), be32(keys.length)].concat(keys)), mbox('stsc', [be32(0), be32(1), be32(1), be32(N), be32(1)]),
      mbox('stsz', [be32(0), be32(0), be32(N)].concat(r.out.map(function (f) { return be32(f.d.length); }))), mbox('stco', [be32(0), be32(1), be32(ftyp.length + 8)])]);
    var minf = mbox('minf', [mbox('vmhd', [be32(1), be16(0), be16(0), be16(0), be16(0)]), mbox('dinf', [mbox('dref', [be32(0), be32(1), mbox('url ', [be32(1)])])]), stbl]);
    var mdia = mbox('mdia', [mbox('mdhd', [be32(0), be32(0), be32(0), be32(ts), be32(dur), be16(0x55C4), be16(0)]), mbox('hdlr', [be32(0), be32(0), B('vide'), z(12), B('VideoHandler'), [0]]), minf]);
    var tkhd = mbox('tkhd', [be32(3), be32(0), be32(0), be32(1), be32(0), be32(Math.round(dur * 1000 / ts)), z(8), be16(0), be16(0), be16(0), be16(0), matrix, be32(W << 16), be32(H << 16)]);
    var mvhd = mbox('mvhd', [be32(0), be32(0), be32(0), be32(1000), be32(Math.round(dur * 1000 / ts)), be32(0x10000), be16(0x100), z(10), matrix, z(24), be32(2)]);
    var moov = mbox('moov', [mvhd, mbox('trak', [tkhd, mdia])]);
    var parts = [new Uint8Array(ftyp), new Uint8Array(be32(mdatLen + 8).concat(B('mdat')))]; r.out.forEach(function (f) { parts.push(f.d); }); parts.push(new Uint8Array(moov));
    return new Blob(parts, { type: brand === 'qt  ' ? 'video/quicktime' : 'video/mp4' });
  }
  /* WebM / Matroska container for VP8 / VP9 */
  function cat(list) { var n = 0; list.forEach(function (a) { n += a.length; }); var o = new Uint8Array(n), p = 0; list.forEach(function (a) { o.set(a, p); p += a.length; }); return o; }
  function wm(id, parts) {
    var body = cat(parts), idb = [], x = id; while (x > 0) { idb.unshift(x % 256); x = Math.floor(x / 256); }
    var l = 1; while (l < 8 && body.length >= Math.pow(2, 7 * l) - 1) l++;
    var sb = [], v = body.length; for (var i = l - 1; i >= 0; i--) { sb[i] = v % 256; v = Math.floor(v / 256); } sb[0] |= (1 << (8 - l));
    return cat([new Uint8Array(idb.concat(sb)), body]);
  }
  var eU = function (id, v) { var b = []; do { b.unshift(v % 256); v = Math.floor(v / 256); } while (v > 0); return wm(id, [new Uint8Array(b)]); };
  var eS = function (id, s) { return wm(id, [new Uint8Array(Array.prototype.map.call(s, function (c) { return c.charCodeAt(0); }))]); };
  var eF = function (id, v) { var b = new Uint8Array(8); new DataView(b.buffer).setFloat64(0, v, false); return wm(id, [b]); };
  function webmMux(r, doc) {
    var N = r.out.length, fd = 1000 / r.fps, total = N * fd;
    var hdr = wm(0x1A45DFA3, [eU(0x4286, 1), eU(0x42F7, 1), eU(0x42F2, 4), eU(0x42F3, 8), eS(0x4282, doc), eU(0x4287, 4), eU(0x4285, 2)]);
    var info = wm(0x1549A966, [eU(0x2AD7B1, 1000000), eS(0x4D80, 'Zen Ai'), eS(0x5741, 'Zen Ai'), eF(0x4489, total)]);
    var vid = wm(0xE0, [eU(0xB0, r.W), eU(0xBA, r.H)]);
    var te = wm(0xAE, [eU(0xD7, 1), eU(0x73C5, 1), eU(0x83, 1), eU(0x9C, 0), eS(0x86, /^vp9|^vp09/.test(r.codec) ? 'V_VP9' : 'V_VP8'), vid]);
    var track = wm(0x1654AE6B, [te]);
    var clusters = [], cur = null;
    r.out.forEach(function (f, i) {
      var t = Math.round(i * fd);
      if (!cur || t - cur.base > 30000 || (f.key && t - cur.base > 4000)) { cur = { base: t, blocks: [] }; clusters.push(cur); }
      var rel = t - cur.base, bl = new Uint8Array(4 + f.d.length); bl[0] = 0x81; bl[1] = (rel >> 8) & 255; bl[2] = rel & 255; bl[3] = f.key ? 0x80 : 0; bl.set(f.d, 4);
      cur.blocks.push(wm(0xA3, [bl]));
    });
    var cl = clusters.map(function (c) { return wm(0x1F43B675, [eU(0xE7, c.base)].concat(c.blocks)); });
    var seg = wm(0x18538067, [info, track].concat(cl));
    return new Blob([hdr, seg], { type: doc === 'webm' ? 'video/webm' : 'video/x-matroska' });
  }
  async function recordWebm(text) {
    var P = parseFrames(text), first = await svgCanvas(P.frames[0], 1280), W = Math.round(first.width / 2) * 2, H = Math.round(first.height / 2) * 2;
    if (typeof MediaRecorder === 'undefined') throw new Error('this browser cannot create video');
    var cv = document.createElement('canvas'); cv.width = W; cv.height = H; var cx = cv.getContext('2d');
    var mt = ['video/webm;codecs=vp8', 'video/webm;codecs=vp9', 'video/webm'].filter(function (m) { return MediaRecorder.isTypeSupported(m); })[0];
    if (!mt) throw new Error('this browser cannot create WebM video');
    var rec = new MediaRecorder(cv.captureStream(P.fps), { mimeType: mt, videoBitsPerSecond: 1500000 }), chunks = [];
    rec.ondataavailable = function (e) { if (e.data && e.data.size) chunks.push(e.data); };
    var done = new Promise(function (res) { rec.onstop = res; }); rec.start(500);
    for (var s = 0; s < P.frames.length; s++) {
      var img = s === 0 ? first : await svgCanvas(P.frames[s], Math.max(W, H));
      cx.fillStyle = '#fff'; cx.fillRect(0, 0, W, H); var k = Math.min(W / img.width, H / img.height);
      cx.drawImage(img, Math.round((W - img.width * k) / 2), Math.round((H - img.height * k) / 2), Math.round(img.width * k), Math.round(img.height * k));
      await new Promise(function (res) { setTimeout(res, P.per / P.fps * 1000); });
    }
    rec.stop(); await done; return new Blob(chunks, { type: 'video/webm' });
  }
  async function buildVideo(e, text) {
    if (e === 'mp4' || e === 'mov') return mp4VideoMux(await encodeVideo(text, 'avc'), e === 'mov' ? 'qt  ' : 'isom');
    try { return webmMux(await encodeVideo(text, 'vpx'), e === 'webm' ? 'webm' : 'matroska'); }
    catch (err) { if (e === 'webm') return recordWebm(text); throw err; }
  }

  var API = { isBin: isBin, build: build, zip: zip, preview: preview, mediaHtml: mediaHtml, icon: icon, label: function (n) { return LABEL[extOf(n)] || ''; }, mime: function (n) { return MIME[extOf(n)] || ''; }, _parseMd: parseMd, _parseSheets: parseSheets, _parseSlides: parseSlides, _buildDocx: buildDocx, _buildXlsx: buildXlsx, _buildPptx: buildPptx, _buildOdt: buildOdt, _mp4v: mp4VideoMux, _webm: webmMux, _video: buildVideo, _flac: flacEncode, _melody: function (t, sr) { return toI16(melodyFloat(t, sr)); }, _oggMux: oggOpusMux, _m4aMux: m4aMux, _adtsMux: adtsMux, _mp3: buildMp3, _ogg: buildOgg, _aac: buildAac, _gif: gifEncode, _bmp: bmpEncode, _tiff: tiffEncode, _wav: buildWav, _mid: buildMidi, _xls: buildXlsLegacy, _build: build, _buildOds: buildOds, _buildOdp: buildOdp, _buildEpub: buildEpub, _buildRtf: buildRtf, _zipBlob: zipBlob };
  root.ZenGen = API;
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
})(typeof window !== 'undefined' ? window : globalThis);
