/* Zen Ai Creative Design Studio: shared local design engine (no image-generation API, no library).
 * Document model -> SVG renderer -> touch editor (select, drag, resize, rotate, text, layers, undo/redo, zoom).
 * Every tool builds its own workspace around this engine. window.Studio is shared; tests load this file in Node/Chromium. */
(function (W) {
  'use strict';
  if (W.Studio) return;
  var S = W.Studio = { version: 1 };
  var clamp = function (v, a, b) { return Math.max(a, Math.min(b, v)); };
  var esc = function (s) { return String(s == null ? '' : s).replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, '').replace(/[&<>"']/g, function (m) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m]; }); };
  var uid = function () { return 'e' + Math.random().toString(36).slice(2, 9); };
  var clone = function (o) { return JSON.parse(JSON.stringify(o)); };
  var num = function (v, d) { v = +v; return isFinite(v) ? v : d; };
  S.esc = esc; S.uid = uid; S.clone = clone; S.clamp = clamp;

  /* ---------------- colour maths (shared with the Colour Palette tool) ---------------- */
  var C = S.color = {};
  C.norm = function (h) { h = String(h || '').trim().replace(/^#/, ''); if (/^[0-9a-f]{3}$/i.test(h)) h = h.replace(/(.)/g, '$1$1'); return /^[0-9a-f]{6}$/i.test(h) ? '#' + h.toLowerCase() : null; };
  C.rgb = function (h) { h = C.norm(h); if (!h) return null; return { r: parseInt(h.substr(1, 2), 16), g: parseInt(h.substr(3, 2), 16), b: parseInt(h.substr(5, 2), 16) }; };
  C.hex = function (r, g, b) { var f = function (v) { v = clamp(Math.round(v), 0, 255); return (v < 16 ? '0' : '') + v.toString(16); }; return '#' + f(r) + f(g) + f(b); };
  C.hsl = function (h) { var c = C.rgb(h); if (!c) return null; var r = c.r / 255, g = c.g / 255, b = c.b / 255, mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 2, hh = 0, s = 0, d = mx - mn;
    if (d) { s = l > 0.5 ? d / (2 - mx - mn) : d / (mx + mn); hh = mx === r ? (g - b) / d + (g < b ? 6 : 0) : mx === g ? (b - r) / d + 2 : (r - g) / d + 4; hh *= 60; }
    return { h: Math.round(hh) % 360, s: Math.round(s * 100), l: Math.round(l * 100) }; };
  C.fromHsl = function (h, s, l) { h = ((h % 360) + 360) % 360; s = clamp(s, 0, 100) / 100; l = clamp(l, 0, 100) / 100;
    var k = function (n) { return (n + h / 30) % 12; }, a = s * Math.min(l, 1 - l), f = function (n) { return l - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1))); };
    return C.hex(f(0) * 255, f(8) * 255, f(4) * 255); };
  C.lum = function (h) { var c = C.rgb(h); if (!c) return 0; var f = function (v) { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }; return 0.2126 * f(c.r) + 0.7152 * f(c.g) + 0.0722 * f(c.b); };
  C.contrast = function (a, b) { var x = C.lum(a), y = C.lum(b); return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05); };
  C.readable = function (bg, a, b) { a = a || '#ffffff'; b = b || '#111111'; return C.contrast(bg, a) >= C.contrast(bg, b) ? a : b; };
  C.mix = function (a, b, t) { var x = C.rgb(a), y = C.rgb(b); if (!x || !y) return a; return C.hex(x.r + (y.r - x.r) * t, x.g + (y.g - x.g) * t, x.b + (y.b - x.b) * t); };
  C.shift = function (h, dh, ds, dl) { var o = C.hsl(h); if (!o) return h; return C.fromHsl(o.h + dh, o.s + ds, o.l + dl); };

  /* ---------------- fonts (names that exist in Android WebView and on desktop) ---------------- */
  S.fonts = [
    ['Sans', 'Roboto, "Segoe UI", Arial, sans-serif'], ['Serif', 'Georgia, "Noto Serif", "Times New Roman", serif'], ['Mono', '"Roboto Mono", Consolas, "Courier New", monospace'],
    ['Condensed', '"Roboto Condensed", "sans-serif-condensed", "Arial Narrow", Arial, sans-serif'], ['Black', '"sans-serif-black", "Arial Black", Impact, Roboto, sans-serif'],
    ['Light', '"sans-serif-light", "Segoe UI Light", Roboto, Arial, sans-serif'], ['Script', '"Dancing Script", "Brush Script MT", cursive'], ['Display', 'Impact, "sans-serif-black", "Arial Black", sans-serif']];
  S.fontCss = function (n) { for (var i = 0; i < S.fonts.length; i++) if (S.fonts[i][0] === n) return S.fonts[i][1]; return n && /[,"]/.test(n) ? n : S.fonts[0][1]; };
  S.pptFont = function (n) { return ({ Sans: 'Arial', Serif: 'Georgia', Mono: 'Courier New', Condensed: 'Arial Narrow', Black: 'Arial Black', Light: 'Calibri Light', Script: 'Segoe Script', Display: 'Impact' })[n] || 'Arial'; };

  /* ---------------- document model ---------------- */
  /* doc = { w, h, bg: paint, els: [element], meta: {} }.  paint = '#rrggbb' | 'transparent' | { g:[c1,c2,..], a:angle(deg, 0=up 90=right), t:'l'|'r' } */
  S.newDoc = function (w, h, bg) { return { w: Math.round(w), h: Math.round(h), bg: bg || '#ffffff', els: [], meta: {} }; };
  S.el = function (type, p) {
    var d = { id: uid(), type: type, x: 0, y: 0, w: 120, h: 120, rot: 0, op: 1, fill: '#888888', stroke: '', sw: 0, vis: true, lock: false, name: type };
    if (type === 'text') Object.assign(d, { text: 'Text', font: 'Sans', size: 48, weight: 700, italic: false, align: 'left', ls: 0, lh: 1.15, upper: false, w: 400, h: 60, fill: '#111111', anchor: 'top' });
    if (type === 'rect') d.r = 0;
    if (type === 'path') { d.d = 'M0 0H100V100H0Z'; d.vb = [100, 100]; }
    if (type === 'image') { d.href = ''; d.fit = 'cover'; d.r = 0; d.fill = ''; }
    return Object.assign(d, p || {});
  };

  var _cv = null;
  function measurer() { if (_cv !== null) return _cv; try { _cv = (W.document && W.document.createElement('canvas').getContext('2d')) || false; } catch (e) { _cv = false; } return _cv; }
  S.textWidth = function (e, s) {
    var cx = measurer(), size = e.size;
    if (cx) { cx.font = (e.italic ? 'italic ' : '') + (e.weight || 400) + ' ' + size + 'px ' + S.fontCss(e.font); return cx.measureText(s).width + (e.ls || 0) * Math.max(0, s.length - 1); }
    return s.length * size * 0.56 + (e.ls || 0) * s.length;
  };
  /* word-wrapped lines of a text element; also sets the element height (auto height) */
  S.layoutText = function (e) {
    var raw = String(e.text == null ? '' : e.text), src = e.upper ? raw.toUpperCase() : raw, out = [];
    src.split('\n').forEach(function (para) {
      if (!para) { out.push(''); return; }
      var words = para.split(/(\s+)/), line = '';
      words.forEach(function (wd) {
        var t = line + wd;
        if (line && S.textWidth(e, t.replace(/\s+$/, '')) > e.w) { out.push(line.replace(/\s+$/, '')); line = /^\s+$/.test(wd) ? '' : wd; }
        else line = t;
      });
      out.push(line.replace(/\s+$/, ''));
    });
    e._lines = out; e.h = Math.max(e.size * e.lh, out.length * e.size * e.lh);
    return out;
  };

  function paintOf(v, id, defs) {
    if (v && typeof v === 'object' && v.g) {
      var gid = 'g' + id, st = v.g.map(function (c, i) {
        var o = Array.isArray(c) ? c : [v.g.length > 1 ? i / (v.g.length - 1) : 0, c]; return '<stop offset="' + Math.round(o[0] * 1000) / 10 + '%" stop-color="' + esc(o[1]) + '"' + (o[2] != null ? ' stop-opacity="' + o[2] + '"' : '') + '/>'; }).join('');
      if (v.t === 'r') defs.push('<radialGradient id="' + gid + '" cx="50%" cy="50%" r="70%">' + st + '</radialGradient>');
      else { var a = (v.a || 0) * Math.PI / 180, dx = Math.sin(a), dy = -Math.cos(a);
        defs.push('<linearGradient id="' + gid + '" x1="' + (0.5 - 0.5 * dx).toFixed(4) + '" y1="' + (0.5 - 0.5 * dy).toFixed(4) + '" x2="' + (0.5 + 0.5 * dx).toFixed(4) + '" y2="' + (0.5 + 0.5 * dy).toFixed(4) + '">' + st + '</linearGradient>'); }
      return 'url(#' + gid + ')';
    }
    if (!v || v === 'transparent' || v === 'none') return 'none';
    return String(v);
  }
  S.paint = paintOf;

  function elSvg(e, defs, o) {
    if (e.vis === false) return '';
    var w = Math.max(1, e.w), h = Math.max(1, e.h), g = '', fill = paintOf(e.fill, e.id, defs), stroke = e.stroke ? paintOf(e.stroke, e.id + 's', defs) : 'none', sw = e.sw || 0;
    var sa = stroke !== 'none' && sw ? ' stroke="' + esc(stroke) + '" stroke-width="' + sw + '" stroke-linejoin="round" stroke-linecap="round"' : '';
    if (e.type === 'rect') g = '<rect width="' + w + '" height="' + h + '" rx="' + (e.r || 0) + '" fill="' + esc(fill) + '"' + sa + '/>';
    else if (e.type === 'ellipse') g = '<ellipse cx="' + w / 2 + '" cy="' + h / 2 + '" rx="' + w / 2 + '" ry="' + h / 2 + '" fill="' + esc(fill) + '"' + sa + '/>';
    else if (e.type === 'path') { var vb = e.vb || [100, 100], sx = w / vb[0], sy = h / vb[1], k = (sx + sy) / 2 || 1;
      g = '<path d="' + esc(e.d) + '" transform="scale(' + sx.toFixed(5) + ' ' + sy.toFixed(5) + ')" fill="' + esc(fill) + '"' + (sa ? ' stroke="' + esc(stroke) + '" stroke-width="' + (sw / k).toFixed(3) + '" stroke-linejoin="round" stroke-linecap="round"' : '') + (e.evenodd ? ' fill-rule="evenodd"' : '') + '/>'; }
    else if (e.type === 'image') {
      var cid = 'c' + e.id, rr = e.r || 0, par = e.fit === 'contain' ? 'xMidYMid meet' : e.fit === 'fill' ? 'none' : 'xMidYMid slice';
      if (e.fill) g += '<rect width="' + w + '" height="' + h + '" rx="' + rr + '" fill="' + esc(paintOf(e.fill, e.id, defs)) + '"/>';
      defs.push('<clipPath id="' + cid + '"><rect width="' + w + '" height="' + h + '" rx="' + rr + '"/></clipPath>');
      g += '<g clip-path="url(#' + cid + ')">' + (e.href ? '<image href="' + esc(e.href) + '" xlink:href="' + esc(e.href) + '" width="' + w + '" height="' + h + '" preserveAspectRatio="' + par + '"/>' : '<rect width="' + w + '" height="' + h + '" fill="#cfd3da"/>') + '</g>';
      if (sa) g += '<rect width="' + w + '" height="' + h + '" rx="' + rr + '" fill="none"' + sa + '/>';
    } else if (e.type === 'text') {
      var lines = S.layoutText(e), lh = e.size * e.lh, ax = e.align === 'center' ? w / 2 : e.align === 'right' ? w : 0, an = e.align === 'center' ? 'middle' : e.align === 'right' ? 'end' : 'start';
      var oc = e.outline && e.outline.w ? ' stroke="' + esc(e.outline.c || '#000') + '" stroke-width="' + e.outline.w * 2 + '" stroke-linejoin="round" paint-order="stroke fill"' : '';
      var ts = lines.map(function (ln, i) { return '<tspan x="' + ax + '" y="' + (e.size * 0.92 + i * lh).toFixed(2) + '">' + (esc(ln) || '&#8203;') + '</tspan>'; }).join('');
      g = '<text font-family="' + esc(S.fontCss(e.font)) + '" font-size="' + e.size + '" font-weight="' + (e.weight || 400) + '"' + (e.italic ? ' font-style="italic"' : '') + ' text-anchor="' + an + '"' + (e.ls ? ' letter-spacing="' + e.ls + '"' : '') + ' fill="' + esc(fill) + '"' + oc + ' xml:space="preserve">' + ts + '</text>';
    }
    var f = '';
    if (e.shadow && (e.shadow.b || e.shadow.x || e.shadow.y)) { var fid = 'f' + e.id; defs.push('<filter id="' + fid + '" x="-30%" y="-30%" width="160%" height="160%"><feDropShadow dx="' + (e.shadow.x || 0) + '" dy="' + (e.shadow.y || 0) + '" stdDeviation="' + (e.shadow.b || 0) / 2 + '" flood-color="' + esc(e.shadow.c || '#000') + '" flood-opacity="' + (e.shadow.o != null ? e.shadow.o : 0.6) + '"/></filter>'); f = ' filter="url(#' + fid + ')"'; }
    if (e.blur) { var bid = 'b' + e.id; defs.push('<filter id="' + bid + '" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="' + e.blur + '"/></filter>'); f = ' filter="url(#' + bid + ')"'; }
    var tr = 'translate(' + r2(e.x) + ' ' + r2(e.y) + ')' + (e.rot ? ' rotate(' + r2(e.rot) + ' ' + r2(w / 2) + ' ' + r2(h / 2) + ')' : '');
    return '<g' + (o && o.clean ? '' : ' data-id="' + e.id + '"') + ' transform="' + tr + '"' + (e.op != null && e.op < 1 ? ' opacity="' + e.op + '"' : '') + f + '>' + g + '</g>';
  }
  function r2(v) { return Math.round(v * 100) / 100; }

  /* inner markup + defs of a document */
  S.render = function (doc, o) {
    o = o || {}; var defs = [], body = '';
    var bg = paintOf(doc.bg, 'bg', defs);
    if (bg !== 'none') body += '<rect width="' + doc.w + '" height="' + doc.h + '" fill="' + esc(bg) + '"' + (o.clean ? '' : ' data-bg="1"') + '/>';
    doc.els.forEach(function (e) { body += elSvg(e, defs, o); });
    return { defs: defs.join(''), body: body };
  };
  S.toSVG = function (doc, o) {
    o = o || {}; var r = S.render(doc, { clean: o.clean !== false });
    return '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 ' + doc.w + ' ' + doc.h + '" width="' + doc.w + '" height="' + doc.h + '"><defs>' + r.defs + '</defs>' + r.body + '</svg>';
  };
  S.bbox = function (e) { return { x: e.x, y: e.y, w: e.w, h: e.h }; };
  S.validate = function (doc) {
    if (!doc || typeof doc !== 'object' || !Array.isArray(doc.els)) return null;
    var d = { w: clamp(Math.round(num(doc.w, 1080)), 16, 8000), h: clamp(Math.round(num(doc.h, 1080)), 16, 8000), bg: doc.bg == null ? '#ffffff' : doc.bg, els: [], meta: doc.meta && typeof doc.meta === 'object' ? doc.meta : {} };
    doc.els.slice(0, 600).forEach(function (e) {
      if (!e || !/^(rect|ellipse|text|path|image)$/.test(e.type)) return;
      var n = S.el(e.type, e); n.id = String(e.id || uid()); ['x', 'y', 'w', 'h', 'rot', 'sw', 'size'].forEach(function (k) { if (n[k] != null) n[k] = num(n[k], 0); });
      n.w = clamp(n.w, 1, 20000); n.h = clamp(n.h, 1, 20000); n.op = clamp(num(n.op, 1), 0, 1); if (n.type === 'text') { n.size = clamp(n.size || 24, 4, 1200); n.text = String(n.text == null ? '' : n.text).slice(0, 4000); }
      if (n.type === 'path' && !/^[MmLlHhVvCcSsQqTtAaZz0-9eE+\-., \n]*$/.test(String(n.d))) return;
      if (n.type === 'image' && n.href && !/^data:image\/(png|jpe?g|webp|gif|svg\+xml);/i.test(n.href)) n.href = '';
      d.els.push(n);
    });
    return d;
  };

  /* ---------------- editor ---------------- */
  var NS = 'http://www.w3.org/2000/svg';
  function Editor(host, doc, o) {
    o = o || {}; var self = this;
    this.host = host; this.doc = doc; this.o = o; this.sel = null; this.zoom = 1; this.undoS = []; this.redoS = []; this.listeners = {}; this._raf = 0; this.guides = null; this.snap = o.snap !== false; this.lockedBg = false;
    host.classList.add('zs-ed'); host.style.overflow = 'auto'; host.style.position = host.style.position || 'relative'; host.style.touchAction = 'pan-x pan-y';
    this.wrap = document.createElement('div'); this.wrap.className = 'zs-wrap'; this.wrap.style.cssText = 'margin:auto;position:relative;flex:none';
    this.svg = document.createElementNS(NS, 'svg'); this.svg.setAttribute('xmlns', NS); this.svg.style.cssText = 'display:block;touch-action:none;user-select:none;-webkit-user-select:none;background:' + (o.checker === false ? 'transparent' : 'repeating-conic-gradient(#d9d9d9 0 25%,#f4f4f4 0 50%) 0 0/16px 16px'); this.svg.setAttribute('class', 'zs-svg');
    this.wrap.appendChild(this.svg); host.appendChild(this.wrap);
    this.svg.addEventListener('pointerdown', function (ev) { self._down(ev); });
    this.svg.addEventListener('pointermove', function (ev) { self._move(ev); });
    this.svg.addEventListener('pointerup', function (ev) { self._up(ev); }); this.svg.addEventListener('pointercancel', function (ev) { self._up(ev); });
    this._key = function (ev) { if (!host.isConnected) { document.removeEventListener('keydown', self._key); return; } var t = ev.target && ev.target.tagName; if (/INPUT|TEXTAREA|SELECT/.test(t || '')) return; if (!host.offsetParent) return;
      if ((ev.key === 'Delete' || ev.key === 'Backspace') && self.sel) { ev.preventDefault(); self.remove(); } else if ((ev.ctrlKey || ev.metaKey) && ev.key === 'z') { ev.preventDefault(); ev.shiftKey ? self.redo() : self.undo(); } else if ((ev.ctrlKey || ev.metaKey) && ev.key === 'y') { ev.preventDefault(); self.redo(); }
      else if ((ev.ctrlKey || ev.metaKey) && ev.key === 'd' && self.sel) { ev.preventDefault(); self.duplicate(); }
      else if (self.sel && /^Arrow/.test(ev.key)) { ev.preventDefault(); var e = self.get(self.sel), st = ev.shiftKey ? 10 : 1; if (e && !e.lock) { self.push('move'); e.x += ev.key === 'ArrowRight' ? st : ev.key === 'ArrowLeft' ? -st : 0; e.y += ev.key === 'ArrowDown' ? st : ev.key === 'ArrowUp' ? -st : 0; self.changed(); } } };
    document.addEventListener('keydown', this._key);
    if (W.ResizeObserver) { this._cw = host.clientWidth; try { new W.ResizeObserver(function () { if (host.clientWidth && host.clientWidth !== self._cw) { self._cw = host.clientWidth; self.fit(true); self.draw(); self.emit('zoom', self.zoom); } }).observe(host); } catch (e) { } }
    this.fit(); this.draw();
  }
  S.Editor = Editor;
  var P = Editor.prototype;
  P.on = function (n, f) { (this.listeners[n] = this.listeners[n] || []).push(f); return this; };
  P.emit = function (n, a) { (this.listeners[n] || []).forEach(function (f) { try { f(a); } catch (e) { if (W.console) console.warn('studio', e && e.message); } }); };
  P.get = function (id) { for (var i = 0; i < this.doc.els.length; i++) if (this.doc.els[i].id === id) return this.doc.els[i]; return null; };
  P.selected = function () { return this.sel ? this.get(this.sel) : null; };
  P.snapshot = function () { var d = this.doc; return JSON.stringify({ w: d.w, h: d.h, bg: d.bg, els: d.els.map(function (e) { var c = Object.assign({}, e); delete c._lines; return c; }), meta: d.meta }); };
  P.restore = function (s) { var d = JSON.parse(s); this.doc.w = d.w; this.doc.h = d.h; this.doc.bg = d.bg; this.doc.els = d.els; this.doc.meta = d.meta; if (this.sel && !this.get(this.sel)) this.sel = null; this.fit(true); this.draw(); this.emit('select', this.selected()); this.emit('change', this.doc); };
  var lastPushKey = '', lastPushT = 0;
  P.push = function (key) { var now = Date.now(); if (key && key === this._pk && now - this._pt < 900) { this._pt = now; return; } this._pk = key; this._pt = now; this.undoS.push(this.snapshot()); if (this.undoS.length > 80) this.undoS.shift(); this.redoS = []; this.emit('history', this); };
  P.undo = function () { if (!this.undoS.length) return false; this.redoS.push(this.snapshot()); this.restore(this.undoS.pop()); this._pk = ''; this.emit('history', this); return true; };
  P.redo = function () { if (!this.redoS.length) return false; this.undoS.push(this.snapshot()); this.restore(this.redoS.pop()); this._pk = ''; this.emit('history', this); return true; };
  P.canUndo = function () { return this.undoS.length > 0; }; P.canRedo = function () { return this.redoS.length > 0; };
  P.changed = function () { this.draw(); this.emit('change', this.doc); };
  P.setDoc = function (doc, keepHistory) { if (!keepHistory) { this.undoS = []; this.redoS = []; } this.doc = doc; this.sel = null; this.fit(true); this.draw(); this.emit('select', null); this.emit('history', this); this.emit('change', doc); };
  P.select = function (id) { this.sel = id || null; this.draw(); this.emit('select', this.selected()); };
  P.add = function (e, noSel) { this.push(); this.doc.els.push(e); if (e.type === 'text') S.layoutText(e); if (!noSel) this.sel = e.id; this.changed(); this.emit('select', this.selected()); return e; };
  P.set = function (patch, id, key) { var e = this.get(id || this.sel); if (!e || (e.lock && !('lock' in patch))) return null; this.push(key || ('set:' + Object.keys(patch).join(','))); Object.assign(e, patch); if (e.type === 'text') S.layoutText(e); this.changed(); return e; };
  P.setDocProps = function (patch) { this.push('doc'); Object.assign(this.doc, patch); this.fit(true); this.changed(); };
  P.remove = function (id) { id = id || this.sel; var i = this.doc.els.findIndex(function (e) { return e.id === id; }); if (i < 0) return; this.push(); this.doc.els.splice(i, 1); if (this.sel === id) this.sel = null; this.changed(); this.emit('select', null); };
  P.duplicate = function (id) { var e = this.get(id || this.sel); if (!e) return null; var c = clone(e); delete c._lines; c.id = uid(); c.x += 24; c.y += 24; c.name = (e.name || e.type) + ' copy'; return this.add(c); };
  P.order = function (dir, id) { id = id || this.sel; var a = this.doc.els, i = a.findIndex(function (e) { return e.id === id; }); if (i < 0) return; var j = dir === 'front' ? a.length - 1 : dir === 'back' ? 0 : clamp(i + (dir === 'up' ? 1 : -1), 0, a.length - 1); if (j === i) return; this.push(); var x = a.splice(i, 1)[0]; a.splice(j, 0, x); this.changed(); };
  P.align = function (how, id) { var e = this.get(id || this.sel); if (!e || e.lock) return; this.push(); var d = this.doc;
    if (how === 'left') e.x = 0; else if (how === 'hcenter') e.x = (d.w - e.w) / 2; else if (how === 'right') e.x = d.w - e.w; else if (how === 'top') e.y = 0; else if (how === 'vcenter') e.y = (d.h - e.h) / 2; else if (how === 'bottom') e.y = d.h - e.h; this.changed(); };
  P.addText = function (text, p) { return this.add(S.el('text', Object.assign({ text: text || 'Your text', x: this.doc.w * 0.1, y: this.doc.h * 0.4, w: this.doc.w * 0.8, size: Math.round(this.doc.w / 14), name: 'Text' }, p || {}))); };
  P.addShape = function (kind, p) {
    var m = Math.min(this.doc.w, this.doc.h), s = Math.round(m * 0.3), b = { x: (this.doc.w - s) / 2, y: (this.doc.h - s) / 2, w: s, h: s, fill: '#6c5ce7', name: kind };
    var paths = { triangle: ['M50 4L96 92H4Z', 'Triangle'], star: ['M50 4L62 38H98L69 59L80 94L50 73L20 94L31 59L2 38H38Z', 'Star'], heart: ['M50 90C10 60 4 38 4 26C4 12 15 4 27 4C38 4 46 10 50 18C54 10 62 4 73 4C85 4 96 12 96 26C96 38 90 60 50 90Z', 'Heart'], hexagon: ['M25 6H75L98 50L75 94H25L2 50Z', 'Hexagon'], diamond: ['M50 2L98 50L50 98L2 50Z', 'Diamond'], arrow: ['M4 38H58V14L96 50L58 86V62H4Z', 'Arrow'], cross: ['M36 4H64V36H96V64H64V96H36V64H4V36H36Z', 'Cross'], bolt: ['M58 2L14 56H44L38 98L86 40H56Z', 'Bolt'], bubble: ['M10 8H90V68H46L22 92V68H10Z', 'Bubble'], ring: ['M50 2A48 48 0 1 0 50.1 2ZM50 22A28 28 0 1 1 49.9 22Z', 'Ring'] };
    var e;
    if (kind === 'rect' || kind === 'rounded') e = S.el('rect', Object.assign(b, { r: kind === 'rounded' ? Math.round(s * 0.18) : 0, name: kind === 'rounded' ? 'Rounded box' : 'Rectangle' }));
    else if (kind === 'ellipse' || kind === 'circle') e = S.el('ellipse', Object.assign(b, { name: 'Circle' }));
    else if (kind === 'line') e = S.el('rect', Object.assign(b, { w: Math.round(m * 0.5), h: 8, y: this.doc.h / 2, x: (this.doc.w - m * 0.5) / 2, name: 'Line' }));
    else if (paths[kind]) e = S.el('path', Object.assign(b, { d: paths[kind][0], vb: [100, 100], name: paths[kind][1], evenodd: kind === 'ring' }));
    else return null;
    return this.add(Object.assign(e, p || {}));
  };
  P.addImage = function (href, iw, ih, p) { var d = this.doc, k = Math.min(d.w * 0.8 / iw, d.h * 0.8 / ih, 1) || 1, w = Math.round(iw * k), h = Math.round(ih * k); return this.add(S.el('image', Object.assign({ href: href, w: w, h: h, x: (d.w - w) / 2, y: (d.h - h) / 2, fit: 'cover', name: 'Image' }, p || {}))); };
  P.addPath = function (d, vb, p) { var m = Math.min(this.doc.w, this.doc.h) * 0.3; return this.add(S.el('path', Object.assign({ d: d, vb: vb || [100, 100], w: m, h: m * ((vb || [100, 100])[1] / (vb || [100, 100])[0]), x: (this.doc.w - m) / 2, y: (this.doc.h - m) / 2, fill: '#6c5ce7', name: 'Shape' }, p || {}))); };

  /* ----- view ----- */
  P.fit = function (quiet) {
    var hw = this.host.clientWidth || this.o.vw || 360, hh = this.host.clientHeight || this.o.vh || 420, pad = 16;
    if (this.o.autoH) { this.zoom = clamp((hw - pad * 2) / this.doc.w, 0.02, 4); this.host.style.height = Math.round(clamp(this.doc.h * this.zoom + 40, 140, 560)) + 'px'; this.applyZoom(quiet); return; }
    this.zoom = clamp(Math.min((hw - pad * 2) / this.doc.w, (hh - pad * 2) / this.doc.h), 0.02, 4); this.applyZoom(quiet);
  };
  P.setZoom = function (z) { this.zoom = clamp(z, 0.05, 6); this.applyZoom(); this.draw(); };
  P.applyZoom = function (quiet) {
    var d = this.doc; this.svg.setAttribute('viewBox', '0 0 ' + d.w + ' ' + d.h); this.svg.style.width = Math.round(d.w * this.zoom) + 'px'; this.svg.style.height = Math.round(d.h * this.zoom) + 'px';
    this.wrap.style.width = Math.round(d.w * this.zoom) + 'px'; this.wrap.style.height = Math.round(d.h * this.zoom) + 'px'; this.wrap.style.margin = '12px auto'; if (!quiet) this.emit('zoom', this.zoom);
  };
  P.zoomBy = function (f) { this.setZoom(this.zoom * f); };
  P.draw = function () { var self = this; if (this._raf) return; var run = function () { self._raf = 0; self._paint(); }; if (W.requestAnimationFrame && !this.o.sync) this._raf = W.requestAnimationFrame(run); else run(); };
  P.drawNow = function () { this._raf = 0; this._paint(); };
  P._paint = function () {
    var d = this.doc, r = S.render(d, {}), z = this.zoom, ov = '';
    if (this.guides) ov += this.guides.map(function (g) { return g.v != null ? '<line x1="' + g.v + '" y1="0" x2="' + g.v + '" y2="' + d.h + '" stroke="#ff2d95" stroke-width="' + 1.5 / z + '" stroke-dasharray="' + 6 / z + '"/>' : '<line x1="0" y1="' + g.h + '" x2="' + d.w + '" y2="' + g.h + '" stroke="#ff2d95" stroke-width="' + 1.5 / z + '" stroke-dasharray="' + 6 / z + '"/>'; }).join('');
    if (this.o.overlay) ov += this.o.overlay(d, z) || '';
    var e = this.selected();
    if (e && e.vis !== false) {
      var hs = 11 / z, w = e.w, h = e.h, c = [[0, 0, -1, -1], [w, 0, 1, -1], [w, h, 1, 1], [0, h, -1, 1]], col = this.o.accent || '#2f8cff';
      ov += '<g transform="translate(' + e.x + ' ' + e.y + ')' + (e.rot ? ' rotate(' + e.rot + ' ' + w / 2 + ' ' + h / 2 + ')' : '') + '" data-ov="1"><rect width="' + w + '" height="' + h + '" fill="none" stroke="' + col + '" stroke-width="' + 1.6 / z + '" stroke-dasharray="' + (e.lock ? 5 / z : 0) + '"/>';
      if (!e.lock) {
        c.forEach(function (p, i) { ov += '<rect data-h="' + i + '" x="' + (p[0] - hs) + '" y="' + (p[1] - hs) + '" width="' + hs * 2 + '" height="' + hs * 2 + '" rx="' + hs * 0.35 + '" fill="#fff" stroke="' + col + '" stroke-width="' + 2 / z + '" style="cursor:nwse-resize"/>'; });
        ov += '<line x1="' + w / 2 + '" y1="0" x2="' + w / 2 + '" y2="' + -34 / z + '" stroke="' + col + '" stroke-width="' + 1.6 / z + '"/><circle data-h="rot" cx="' + w / 2 + '" cy="' + -34 / z + '" r="' + hs + '" fill="' + col + '" stroke="#fff" stroke-width="' + 2 / z + '"/>';
      }
      ov += '</g>';
    }
    this.svg.innerHTML = '<defs>' + r.defs + '</defs><g class="zs-content">' + r.body + '</g><g class="zs-ov">' + ov + '</g>';
  };
  P.toDoc = function (ev) { var rc = this.svg.getBoundingClientRect(); return { x: (ev.clientX - rc.left) * this.doc.w / rc.width, y: (ev.clientY - rc.top) * this.doc.h / rc.height }; };
  P._down = function (ev) {
    if (ev.button > 0) return; var t = ev.target, p = this.toDoc(ev), now = Date.now(), hh = t.getAttribute && t.getAttribute('data-h'), e = this.selected();
    this.svg.setPointerCapture && ev.pointerId != null && this.svg.setPointerCapture(ev.pointerId);
    if (hh != null && e) {
      var cx = e.x + e.w / 2, cy = e.y + e.h / 2;
      this.g = hh === 'rot' ? { m: 'rot', cx: cx, cy: cy, r0: e.rot, a0: Math.atan2(p.y - cy, p.x - cx) } : { m: 'size', i: +hh, o: { x: e.x, y: e.y, w: e.w, h: e.h, rot: e.rot, size: e.size } };
      this.push(); this.moved = true; ev.preventDefault(); return;
    }
    var g = t.closest ? t.closest('[data-id]') : null, id = g && g.getAttribute('data-id'), el = id && this.get(id);
    if (el && el.lock) { el = null; id = null; }
    if (el) {
      var dbl = this._lt && this._lid === id && now - this._lt < 320; this._lt = now; this._lid = id;
      this.sel = id; this.g = { m: 'move', sx: p.x, sy: p.y, ox: el.x, oy: el.y, pushed: false }; this.emit('select', el); this.draw();
      if (dbl && el.type === 'text') { this.g = null; this.editText(id); }
      ev.preventDefault();
    } else { this._lt = 0; if (this.sel) { this.sel = null; this.draw(); this.emit('select', null); } this.g = null; }
  };
  P._move = function (ev) {
    var g = this.g; if (!g) return; var p = this.toDoc(ev), e = this.selected(); if (!e) return;
    if (g.m === 'move') {
      var dx = p.x - g.sx, dy = p.y - g.sy; if (!g.pushed) { if (Math.abs(dx) + Math.abs(dy) < 3 / this.zoom) return; this.push(); g.pushed = true; }
      var nx = g.ox + dx, ny = g.oy + dy; this.guides = null;
      if (this.snap) { var th = 7 / this.zoom, gs = [], cx = nx + e.w / 2, cy = ny + e.h / 2, D = this.doc;
        if (Math.abs(cx - D.w / 2) < th) { nx = D.w / 2 - e.w / 2; gs.push({ v: D.w / 2 }); } if (Math.abs(cy - D.h / 2) < th) { ny = D.h / 2 - e.h / 2; gs.push({ h: D.h / 2 }); }
        if (Math.abs(nx) < th) { nx = 0; gs.push({ v: 0 }); } if (Math.abs(nx + e.w - D.w) < th) { nx = D.w - e.w; gs.push({ v: D.w }); } if (Math.abs(ny) < th) { ny = 0; gs.push({ h: 0 }); } if (Math.abs(ny + e.h - D.h) < th) { ny = D.h - e.h; gs.push({ h: D.h }); }
        this.guides = gs.length ? gs : null; }
      e.x = nx; e.y = ny;
    } else if (g.m === 'rot') {
      var a = Math.atan2(p.y - g.cy, p.x - g.cx), deg = g.r0 + (a - g.a0) * 180 / Math.PI; if (ev.shiftKey || this.snap) { var s = Math.round(deg / 15) * 15; if (Math.abs(deg - s) < 4) deg = s; } e.rot = ((Math.round(deg * 10) / 10) % 360 + 360) % 360; if (e.rot > 180) e.rot -= 360;
    } else if (g.m === 'size') {
      var o = g.o, th2 = o.rot * Math.PI / 180, cs = Math.cos(th2), sn = Math.sin(th2), ccx = o.x + o.w / 2, ccy = o.y + o.h / 2, vx = p.x - ccx, vy = p.y - ccy,
        lx = vx * cs + vy * sn, ly = -vx * sn + vy * cs, sx = [-1, 1, 1, -1][g.i], sy = [-1, -1, 1, 1][g.i], ox = -sx * o.w / 2, oy = -sy * o.h / 2;
      var nw = Math.max(8, Math.abs(lx - ox)), nh = Math.max(8, Math.abs(ly - oy));
      if (e.type === 'text') {
        if (ev.shiftKey) e.size = clamp(Math.round(o.size * nw / o.w), 6, 1200);
        var ncx = (lx + ox) / 2;
        e.w = Math.round(nw); S.layoutText(e);
        e.x = Math.round(ccx + ncx * cs - e.w / 2); e.y = Math.round(ccy + ncx * sn - o.h / 2);
      } else {
        if (ev.shiftKey) { var k2 = Math.max(nw / o.w, nh / o.h); nw = o.w * k2; nh = o.h * k2; }
        var ncx2 = (lx + ox) / 2, ncy2 = (ly + oy) / 2, wx = ccx + ncx2 * cs - ncy2 * sn, wy = ccy + ncx2 * sn + ncy2 * cs;
        e.w = Math.round(nw); e.h = Math.round(nh); e.x = Math.round(wx - e.w / 2); e.y = Math.round(wy - e.h / 2);
      }
    }
    this.moved = true; this.draw(); this.emit('live', e);
  };
  P._up = function (ev) {
    if (this.svg.releasePointerCapture && ev && ev.pointerId != null) { try { this.svg.releasePointerCapture(ev.pointerId); } catch (e) { } }
    if (this.g && (this.g.pushed || this.g.m !== 'move')) { this.g = null; this.guides = null; this.moved = false; this.changed(); return; }
    this.g = null; this.guides = null; this.draw();
  };
  P.editText = function (id) {
    var self = this, e = this.get(id || this.sel); if (!e || e.type !== 'text' || (S.ui && !S.ui.dialog)) return; var ta = document.createElement('textarea'); ta.value = e.text; ta.rows = 5; ta.style.cssText = 'width:100%;box-sizing:border-box;font:16px system-ui,sans-serif;padding:10px;border-radius:10px;border:1px solid #888';
    S.ui.dialog('Edit text', ta, [['Cancel'], ['Done', function () { self.set({ text: ta.value }, e.id, 'text:' + e.id); }, true]]); setTimeout(function () { try { ta.focus(); } catch (x) { } }, 50);
  };
  P.destroy = function () { document.removeEventListener('keydown', this._key); if (this._raf && W.cancelAnimationFrame) W.cancelAnimationFrame(this._raf); this.host.innerHTML = ''; };
  P.svgString = function (o) { return S.toSVG(this.doc, o); };

  if (typeof module !== 'undefined' && module.exports) module.exports = S;
})(typeof window !== 'undefined' ? window : globalThis);
