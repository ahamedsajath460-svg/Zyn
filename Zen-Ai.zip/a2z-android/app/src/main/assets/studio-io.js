/* Zen Ai Creative Design Studio: storage, project manager, exports (SVG, PNG, JPG, PDF, PPTX, ZIP), AI planning helper and small UI helpers.
 * Needs studio-core.js. Uses the page's own storage (idbS / idbG key-value store), text-AI router (ask) and file saver (dlBlob) when they exist. */
(function (W) {
  'use strict';
  var S = W.Studio; if (!S || S.io) return; S.io = 1;
  var esc = S.esc, clamp = S.clamp, te = typeof TextEncoder !== 'undefined' ? new TextEncoder() : null;
  var enc = function (s) { return te ? te.encode(s) : Uint8Array.from(unescape(encodeURIComponent(s)), function (c) { return c.charCodeAt(0); }); };
  var tick = function (m) { try { if (typeof W.toast === 'function') W.toast(m); else if (typeof toast === 'function') toast(m); else if (W.console) console.log('[studio]', m); } catch (e) { } };
  S.tell = tick;

  /* ---------------- storage ---------------- */
  var mem = {};
  var KV = S.kv = {
    get: function (k) { return new Promise(function (res) {
      try { if (typeof idbG === 'function') { idbG('zs:' + k).then(function (v) { if (v != null) return res(v); try { var t = localStorage.getItem('zs:' + k); res(t ? JSON.parse(t) : (mem[k] || null)); } catch (e) { res(mem[k] || null); } }); return; } } catch (e) { }
      try { var t = localStorage.getItem('zs:' + k); res(t ? JSON.parse(t) : (mem[k] || null)); } catch (e) { res(mem[k] || null); } }); },
    set: function (k, v) { mem[k] = v; var done = false; try { if (typeof idbS === 'function') { idbS('zs:' + k, v); done = true; } } catch (e) { }
      if (!done) { try { localStorage.setItem('zs:' + k, JSON.stringify(v)); } catch (e) { } } return Promise.resolve(); },
    del: function (k) { delete mem[k]; try { if (typeof idbS === 'function') idbS('zs:' + k, null); } catch (e) { } try { localStorage.removeItem('zs:' + k); } catch (e) { } return Promise.resolve(); }
  };
  var lmem = {};
  function lsGet(k, d) { try { var v = JSON.parse(localStorage.getItem(k)); if (v != null) return v; } catch (e) { if (lmem[k] != null) return JSON.parse(lmem[k]); } return d; }
  function lsSet(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { lmem[k] = JSON.stringify(v); } }
  S.ls = { get: lsGet, set: lsSet };

  /* ---------------- projects ---------------- */
  var IDX = 'zs_idx', MAXV = 8;
  var Pj = S.proj = {
    list: function (kind) { var a = lsGet(IDX, []); return (kind ? a.filter(function (p) { return p.kind === kind; }) : a).sort(function (x, y) { return y.t - x.t; }); },
    recent: function (n) { return Pj.list().slice(0, n || 8); },
    _idx: function (rec, thumb) { var a = lsGet(IDX, []), i = a.findIndex(function (p) { return p.id === rec.id; }), m = { id: rec.id, kind: rec.kind, name: rec.name, t: rec.t, c: rec.c, thumb: thumb != null ? thumb : (i >= 0 ? a[i].thumb : '') }; if (i >= 0) a[i] = m; else a.push(m); lsSet(IDX, a); },
    create: function (kind, name, data, thumb) { var id = 'p' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6), rec = { id: id, kind: kind, name: name || 'Untitled design', data: data, versions: [], t: Date.now(), c: Date.now() };
      return KV.set('p:' + id, rec).then(function () { Pj._idx(rec, thumb || ''); return rec; }); },
    open: function (id) { return KV.get('p:' + id); },
    save: function (id, data, o) { o = o || {}; return KV.get('p:' + id).then(function (rec) { if (!rec) return null;
      if (o.version) { rec.versions = (rec.versions || []); rec.versions.unshift({ t: rec.t, data: rec.data }); rec.versions = rec.versions.slice(0, MAXV); }
      rec.data = data; rec.t = Date.now(); if (o.name) rec.name = o.name; return KV.set('p:' + id, rec).then(function () { Pj._idx(rec, o.thumb); return rec; }); }); },
    rename: function (id, name) { return KV.get('p:' + id).then(function (rec) { if (!rec) return null; rec.name = String(name || '').trim().slice(0, 80) || rec.name; rec.t = Date.now(); return KV.set('p:' + id, rec).then(function () { Pj._idx(rec); return rec; }); }); },
    duplicate: function (id) { return KV.get('p:' + id).then(function (rec) { if (!rec) return null; var a = lsGet(IDX, []).find(function (p) { return p.id === id; }); return Pj.create(rec.kind, rec.name + ' copy', S.clone(rec.data), a && a.thumb); }); },
    del: function (id) { lsSet(IDX, lsGet(IDX, []).filter(function (p) { return p.id !== id; })); return KV.del('p:' + id); },
    versions: function (id) { return KV.get('p:' + id).then(function (rec) { return rec ? (rec.versions || []).map(function (v, i) { return { i: i, t: v.t }; }) : []; }); },
    restore: function (id, i) { return KV.get('p:' + id).then(function (rec) { if (!rec || !rec.versions || !rec.versions[i]) return null; var v = rec.versions[i]; rec.versions.unshift({ t: rec.t, data: rec.data }); rec.versions = rec.versions.slice(0, MAXV); rec.data = v.data; rec.t = Date.now(); return KV.set('p:' + id, rec).then(function () { Pj._idx(rec); return rec; }); }); },
    exportBlob: function (id) { return KV.get('p:' + id).then(function (rec) { if (!rec) return null; return new Blob([JSON.stringify({ zenstudio: 1, kind: rec.kind, name: rec.name, data: rec.data })], { type: 'application/json' }); }); },
    importText: function (txt, kinds) { var o; try { o = JSON.parse(txt); } catch (e) { return Promise.reject(new Error('This is not a Zen Ai design file.')); }
      if (!o || o.zenstudio !== 1 || !o.kind || o.data == null) return Promise.reject(new Error('This is not a Zen Ai design file.'));
      if (kinds && kinds.indexOf(o.kind) < 0) return Promise.reject(new Error('This file is for the ' + o.kind + ' tool.'));
      return Pj.create(o.kind, String(o.name || 'Imported design').slice(0, 80), o.data, ''); }
  };

  /* ---------------- UI helpers ---------------- */
  var U = S.ui = {};
  U.h = function (tag, cls, txt) { var e = document.createElement(tag); if (cls) e.className = cls; if (txt != null) e.textContent = txt; return e; };
  U.css = function (id, text) { if (document.getElementById(id)) return; var s = document.createElement('style'); s.id = id; s.textContent = text; document.head.appendChild(s); };
  U.btn = function (label, fn, cls, title) { var b = U.h('button', cls || 'zs-b', label); b.type = 'button'; if (title) { b.title = title; b.setAttribute('aria-label', title); } if (fn) b.onclick = function (ev) { ev.preventDefault(); fn(b, ev); }; return b; };
  U.dialog = function (title, body, buttons, o) {
    o = o || {}; var ov = U.h('div', 'zs-ov'), box = U.h('div', 'zs-dlg'); ov.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:99999;display:flex;align-items:center;justify-content:center;padding:14px';
    box.style.cssText = 'background:var(--zs-panel,#222);color:var(--zs-ink,#fff);border:1px solid var(--zs-line,#555);border-radius:16px;max-width:520px;width:100%;max-height:88vh;overflow:auto;padding:16px;box-sizing:border-box;font:14px system-ui,sans-serif';
    var h = U.h('div', 'zs-dh', title); h.style.cssText = 'font-weight:700;font-size:16px;margin-bottom:10px'; box.appendChild(h); if (body) box.appendChild(typeof body === 'string' ? (function () { var d = U.h('div'); d.innerHTML = body; return d; })() : body);
    var row = U.h('div', 'zs-dr'); row.style.cssText = 'display:flex;gap:8px;justify-content:flex-end;margin-top:14px;flex-wrap:wrap';
    var close = function () { ov.remove(); }; (buttons || [['Close']]).forEach(function (b) { var x = U.btn(b[0], function () { var keep = b[1] && b[1](close) === false; if (!keep) close(); }, b[2] ? 'zs-b zs-p' : 'zs-b'); row.appendChild(x); });
    box.appendChild(row); ov.appendChild(box); ov.addEventListener('pointerdown', function (e) { if (e.target === ov && !o.sticky) close(); }); (o.root || document.body).appendChild(ov); ov.close = close; return ov;
  };
  U.prompt = function (title, val, cb) { var i = U.h('input'); i.type = 'text'; i.value = val || ''; i.style.cssText = 'width:100%;box-sizing:border-box;padding:10px;border-radius:10px;border:1px solid #888;font:16px system-ui'; U.dialog(title, i, [['Cancel'], ['OK', function () { cb(i.value); }, true]]); setTimeout(function () { try { i.focus(); i.select(); } catch (e) { } }, 40); };
  U.confirm = function (title, text, cb, okLabel) { U.dialog(title, U.h('div', '', text), [['Cancel'], [okLabel || 'OK', function () { cb(); }, true]]); };
  U.pickFile = function (accept, cb, multiple) { var i = document.createElement('input'); i.type = 'file'; i.accept = accept || ''; if (multiple) i.multiple = true; i.style.display = 'none'; document.body.appendChild(i); i.onchange = function () { var f = [].slice.call(i.files || []); i.remove(); if (f.length) cb(multiple ? f : f[0]); }; i.click(); };
  U.readText = function (f) { return new Promise(function (res, rej) { var r = new FileReader(); r.onload = function () { res(String(r.result || '')); }; r.onerror = function () { rej(new Error('Could not read the file')); }; r.readAsText(f); }); };
  /* photo -> downscaled data URL (keeps transparency for PNG/WebP/SVG) */
  U.readImage = function (f, max) { max = max || 1600; return new Promise(function (res, rej) {
    var url = URL.createObjectURL(f), im = new Image(); im.onload = function () { try { var k = Math.min(1, max / Math.max(im.naturalWidth, im.naturalHeight)), c = document.createElement('canvas'); c.width = Math.max(1, Math.round(im.naturalWidth * k)); c.height = Math.max(1, Math.round(im.naturalHeight * k));
        var cx = c.getContext('2d'); cx.drawImage(im, 0, 0, c.width, c.height); var keep = /png|webp|svg|gif/i.test(f.type || ''); URL.revokeObjectURL(url); res({ href: c.toDataURL(keep ? 'image/png' : 'image/jpeg', 0.88), w: c.width, h: c.height }); } catch (e) { rej(e); } };
    im.onerror = function () { URL.revokeObjectURL(url); rej(new Error('This file is not a picture the app can open.')); }; im.src = url; }); };
  U.field = function (label, input, cls) { var l = U.h('label', 'zs-f ' + (cls || '')), s = U.h('span', 'zs-fl', label); l.append(s, input); return l; };
  U.color = function (val, fn) { var i = U.h('input', 'zs-col'); i.type = 'color'; i.value = S.color.norm(val) || '#000000'; i.oninput = function () { fn(i.value); }; return i; };
  U.range = function (val, min, max, step, fn) { var i = U.h('input', 'zs-rng'); i.type = 'range'; i.min = min; i.max = max; i.step = step || 1; i.value = val; i.oninput = function () { fn(+i.value); }; return i; };
  U.select = function (opts, val, fn) { var s = U.h('select', 'zs-sel'); opts.forEach(function (o) { var a = Array.isArray(o) ? o : [o, o], op = U.h('option', '', a[1]); op.value = a[0]; s.appendChild(op); }); s.value = val; s.onchange = function () { fn(s.value); }; return s; };
  U.text = function (val, fn, ph) { var i = U.h('input', 'zs-in'); i.type = 'text'; i.value = val == null ? '' : val; if (ph) i.placeholder = ph; i.oninput = function () { fn(i.value); }; return i; };
  U.area = function (val, fn, ph, rows) { var i = U.h('textarea', 'zs-in'); i.rows = rows || 3; i.value = val == null ? '' : val; if (ph) i.placeholder = ph; i.oninput = function () { fn(i.value); }; return i; };
  U.num = function (val, fn, min, max, step) { var i = U.h('input', 'zs-in'); i.type = 'number'; i.value = val; if (min != null) i.min = min; if (max != null) i.max = max; if (step) i.step = step; i.onchange = function () { var v = +i.value; if (isFinite(v)) fn(clamp(v, min == null ? -1e9 : min, max == null ? 1e9 : max)); }; return i; };
  U.check = function (label, val, fn) { var l = U.h('label', 'zs-chk'), i = U.h('input'); i.type = 'checkbox'; i.checked = !!val; i.onchange = function () { fn(i.checked); }; l.append(i, document.createTextNode(' ' + label)); return l; };
  U.copy = function (text, msg) { var done = function () { tick(msg || 'Copied'); };
    try { if (navigator.clipboard && navigator.clipboard.writeText) { navigator.clipboard.writeText(text).then(done, function () { fb(); }); return; } } catch (e) { } fb();
    function fb() { var t = document.createElement('textarea'); t.value = text; t.style.cssText = 'position:fixed;opacity:0'; document.body.appendChild(t); t.select(); try { document.execCommand('copy'); done(); } catch (e) { tick('Copy is not available here'); } t.remove(); } };
  U.dataUrl = function (blob) { return new Promise(function (res) { var r = new FileReader(); r.onload = function () { res(String(r.result)); }; r.readAsDataURL(blob); }); };

  /* ---------------- AI planning (text AI only, through the app's own provider router) ---------------- */
  var A = S.ai = {};
  A.available = function () { try { return typeof W.active === 'function' ? W.active().length > 0 : (typeof active === 'function' && active().length > 0); } catch (e) { return false; } };
  A.parse = function (txt) {
    var t = String(txt || '').replace(/```(?:json)?/gi, '').trim(), a = t.indexOf('{'), b = t.lastIndexOf('}'), c = t.indexOf('['), d = t.lastIndexOf(']');
    var cand = []; if (a >= 0 && b > a) cand.push(t.slice(a, b + 1)); if (c >= 0 && d > c && (a < 0 || c < a)) cand.unshift(t.slice(c, d + 1));
    for (var i = 0; i < cand.length; i++) { var s = cand[i]; try { return JSON.parse(s); } catch (e) { try { return JSON.parse(s.replace(/,\s*([}\]])/g, '$1').replace(/[“”]/g, '"')); } catch (e2) { } } }
    return null; };
  /* ask the text model for JSON. Returns the parsed object, or throws a plain error. Nothing is invented when the call fails. */
  A.plan = function (system, prompt, sig) {
    var fn = null; try { fn = typeof ask === 'function' ? ask : (typeof W.ask === 'function' ? W.ask : null); } catch (e) { }
    if (!fn) return Promise.reject(new Error('No AI provider is available. Add one in Settings. The tool still works without it.'));
    return Promise.resolve(fn(system + '\nReply with ONE JSON object only. No markdown, no explanation.', prompt, function () { }, sig)).then(function (r) {
      var txt = r && typeof r === 'object' ? (r.text || r.content || '') : r, o = A.parse(txt);
      if (!o) throw new Error('The AI answer was not usable. Try again, or change the request.'); return o; });
  };
  A.color = function (v, d) { return S.color.norm(v) || d; };

  /* ---------------- exports ---------------- */
  var X = S.exp = {};
  X.save = function (blob, name) { try { if (typeof W.dlBlob === 'function') return W.dlBlob(blob, name); if (typeof dlBlob === 'function') return dlBlob(blob, name); } catch (e) { }
    var u = URL.createObjectURL(blob), a = document.createElement('a'); a.href = u; a.download = name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(function () { URL.revokeObjectURL(u); }, 4000); };
  X.share = function (blob, name) { try { var f = new File([blob], name, { type: blob.type }); if (navigator.canShare && navigator.canShare({ files: [f] })) return navigator.share({ files: [f], title: name }).catch(function () { }); } catch (e) { } X.save(blob, name); return Promise.resolve(); };
  X.svgBlob = function (svg) { return new Blob([svg], { type: 'image/svg+xml' }); };
  X.safe = function (n) { return String(n || 'design').replace(/[^\w\-. ]+/g, '').trim().replace(/\s+/g, '-').slice(0, 50) || 'design'; };
  /* svg string -> raster blob. opts: scale, type 'image/png'|'image/jpeg', q, bg (fill for jpeg) */
  X.raster = function (svg, w, h, o) { o = o || {}; return new Promise(function (res, rej) {
    var sc = o.scale || 1, cw = Math.round(w * sc), ch = Math.round(h * sc), cap = 4096; if (Math.max(cw, ch) > cap) { var k = cap / Math.max(cw, ch); cw = Math.round(cw * k); ch = Math.round(ch * k); }
    var im = new Image(), u = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
    im.onload = function () { try { var c = document.createElement('canvas'); c.width = cw; c.height = ch; var cx = c.getContext('2d'); var type = o.type || 'image/png';
        if (type === 'image/jpeg' || o.bg) { cx.fillStyle = o.bg || '#ffffff'; cx.fillRect(0, 0, cw, ch); } cx.drawImage(im, 0, 0, cw, ch);
        c.toBlob(function (b) { b ? res(b) : rej(new Error('The picture could not be made (too large for this device). Try a smaller size.')); }, type, o.q || 0.92); } catch (e) { rej(new Error('The picture could not be made: ' + (e && e.message))); } };
    im.onerror = function () { rej(new Error('The design could not be drawn. Remove very large images and try again.')); }; im.src = u; }); };
  X.docRaster = function (doc, o) { o = o || {}; return X.raster(S.toSVG(doc), doc.w, doc.h, o); };
  X.thumb = function (doc, wmax) { wmax = wmax || 220; try { var k = wmax / Math.max(doc.w, doc.h); return X.raster(S.toSVG(doc), doc.w, doc.h, { scale: k, type: 'image/jpeg', q: 0.6, bg: typeof doc.bg === 'string' && doc.bg !== 'transparent' ? doc.bg : '#ffffff' }).then(U.dataUrl).catch(function () { return ''; }); } catch (e) { return Promise.resolve(''); } };

  /* crc32 + stored zip */
  var CRCT = (function () { var t = new Uint32Array(256); for (var n = 0; n < 256; n++) { var c = n; for (var k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
  X.crc32 = function (u) { var c = 0xFFFFFFFF; for (var i = 0; i < u.length; i++) c = CRCT[(c ^ u[i]) & 255] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; };
  X.zip = function (files, mime) {
    var parts = [], cd = [], off = 0, d = new Date(), dt = ((Math.max(d.getFullYear(), 1980) - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate(), tm = (d.getHours() << 11) | (d.getMinutes() << 5) | (d.getSeconds() >> 1);
    files.forEach(function (f) { var nm = enc(f.name), data = typeof f.data === 'string' ? enc(f.data) : f.data, crc = X.crc32(data), h = new DataView(new ArrayBuffer(30));
      h.setUint32(0, 0x04034b50, true); h.setUint16(4, 20, true); h.setUint16(6, 0x0800, true); h.setUint16(8, 0, true); h.setUint16(10, tm, true); h.setUint16(12, dt, true); h.setUint32(14, crc, true); h.setUint32(18, data.length, true); h.setUint32(22, data.length, true); h.setUint16(26, nm.length, true); h.setUint16(28, 0, true);
      parts.push(new Uint8Array(h.buffer), nm, data);
      var c = new DataView(new ArrayBuffer(46)); c.setUint32(0, 0x02014b50, true); c.setUint16(4, 20, true); c.setUint16(6, 20, true); c.setUint16(8, 0x0800, true); c.setUint16(10, 0, true); c.setUint16(12, tm, true); c.setUint16(14, dt, true); c.setUint32(16, crc, true); c.setUint32(20, data.length, true); c.setUint32(24, data.length, true); c.setUint16(28, nm.length, true); c.setUint32(42, off, true);
      cd.push(new Uint8Array(c.buffer), nm); off += 30 + nm.length + data.length; });
    var cdl = cd.reduce(function (a, p) { return a + p.length; }, 0), e = new DataView(new ArrayBuffer(22)); e.setUint32(0, 0x06054b50, true); e.setUint16(8, files.length, true); e.setUint16(10, files.length, true); e.setUint32(12, cdl, true); e.setUint32(16, off, true);
    return new Blob(parts.concat(cd, [new Uint8Array(e.buffer)]), { type: mime || 'application/zip' });
  };
  X.u8 = function (blob) { return blob.arrayBuffer ? blob.arrayBuffer().then(function (b) { return new Uint8Array(b); }) : new Promise(function (res) { var r = new FileReader(); r.onload = function () { res(new Uint8Array(r.result)); }; r.readAsArrayBuffer(blob); }); };
  X.b64u8 = function (dataUrl) { var b = atob(dataUrl.slice(dataUrl.indexOf(',') + 1)), u = new Uint8Array(b.length); for (var i = 0; i < b.length; i++) u[i] = b.charCodeAt(i); return u; };

  /* PDF: one JPEG page per document (pixels, so every language and font draws correctly). pages = [{doc}] or [{svg,w,h}] */
  X.pdf = function (pages, o) { o = o || {}; var sc = o.scale || 2;
    return Promise.all(pages.map(function (p) { var w = p.doc ? p.doc.w : p.w, h = p.doc ? p.doc.h : p.h, svg = p.doc ? S.toSVG(p.doc) : p.svg;
      return X.raster(svg, w, h, { scale: sc, type: 'image/jpeg', q: 0.9, bg: p.doc && typeof p.doc.bg === 'string' && p.doc.bg !== 'transparent' ? p.doc.bg : '#ffffff' }).then(X.u8).then(function (u) { return jpegSize(u).then(function (sz) { return { u: u, w: w, h: h, pw: sz.w, ph: sz.h }; }); }); }))
      .then(function (imgs) { return X.pdfFromJpegs(imgs, o); }); };
  function jpegSize(u) { return new Promise(function (res) { var i = 2; while (i < u.length) { if (u[i] !== 0xFF) { i++; continue; } var m = u[i + 1]; if (m >= 0xC0 && m <= 0xC3) { res({ h: (u[i + 5] << 8) | u[i + 6], w: (u[i + 7] << 8) | u[i + 8] }); return; } i += 2 + ((u[i + 2] << 8) | u[i + 3]); } res({ w: 1, h: 1 }); }); }
  X.pdfFromJpegs = function (imgs, o) { o = o || {}; var chunks = [], offs = [], len = 0, push = function (x) { var u = typeof x === 'string' ? enc(x) : x; chunks.push(u); len += u.length; };
    var n = imgs.length, obj = function (id, body) { offs[id] = len; push(id + ' 0 obj\n'); push(body); push('\nendobj\n'); };
    push('%PDF-1.4\n%âãÏÓ\n');
    obj(1, '<< /Type /Catalog /Pages 2 0 R >>'); obj(2, '<< /Type /Pages /Kids [' + imgs.map(function (_, i) { return (3 + i * 3) + ' 0 R'; }).join(' ') + '] /Count ' + n + ' >>');
    imgs.forEach(function (im, i) { var pid = 3 + i * 3, cid = pid + 1, iid = pid + 2, W2 = Math.round(im.w * 0.75 * 100) / 100, H2 = Math.round(im.h * 0.75 * 100) / 100, cs = 'q ' + W2 + ' 0 0 ' + H2 + ' 0 0 cm /Im0 Do Q';
      obj(pid, '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ' + W2 + ' ' + H2 + '] /Resources << /XObject << /Im0 ' + iid + ' 0 R >> /ProcSet [/PDF /ImageC] >> /Contents ' + cid + ' 0 R >>');
      obj(cid, '<< /Length ' + cs.length + ' >>\nstream\n' + cs + '\nendstream');
      offs[iid] = len; push(iid + ' 0 obj\n<< /Type /XObject /Subtype /Image /Width ' + im.pw + ' /Height ' + im.ph + ' /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ' + im.u.length + ' >>\nstream\n'); push(im.u); push('\nendstream\nendobj\n'); });
    var total = 3 + n * 3, xr = len; push('xref\n0 ' + total + '\n0000000000 65535 f \n'); for (var i = 1; i < total; i++) push(('0000000000' + offs[i]).slice(-10) + ' 00000 n \n');
    push('trailer\n<< /Size ' + total + ' /Root 1 0 R /Info << /Producer (Zen Ai Studio) /Title (' + String(o.title || 'Design').replace(/[()\\]/g, ' ') + ') >> >>\nstartxref\n' + xr + '\n%%EOF');
    return new Blob(chunks, { type: 'application/pdf' }); };

  /* ---------------- PPTX (editable shapes, text boxes, pictures, speaker notes) ---------------- */
  var EMU = 9525, X_ = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n';
  var NSA = 'xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"';
  var RT = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships';
  function hex6(c, d) { return (S.color.norm(c) || d || '#000000').slice(1).toUpperCase(); }
  function fillXml(v) {
    if (v && typeof v === 'object' && v.g) { var n = v.g.length, st = v.g.map(function (c, i) { var a = Array.isArray(c) ? c : [n > 1 ? i / (n - 1) : 0, c]; return '<a:gs pos="' + Math.round(a[0] * 100000) + '"><a:srgbClr val="' + hex6(a[1]) + '"/></a:gs>'; }).join('');
      return '<a:gradFill rotWithShape="1"><a:gsLst>' + st + '</a:gsLst>' + (v.t === 'r' ? '<a:path path="circle"><a:fillToRect l="50000" t="50000" r="50000" b="50000"/></a:path>' : '<a:lin ang="' + Math.round((((v.a || 0) - 90) % 360 + 360) % 360 * 60000) + '" scaled="0"/>') + '</a:gradFill>'; }
    if (!v || v === 'transparent' || v === 'none') return '<a:noFill/>'; return '<a:solidFill><a:srgbClr val="' + hex6(v) + '"/></a:solidFill>';
  }
  function lnXml(e) { return e.stroke && e.sw ? '<a:ln w="' + Math.round(e.sw * EMU) + '">' + fillXml(e.stroke) + '</a:ln>' : '<a:ln><a:noFill/></a:ln>'; }
  function xfrm(e) { return '<a:xfrm' + (e.rot ? ' rot="' + Math.round(((e.rot % 360) + 360) % 360 * 60000) + '"' : '') + '><a:off x="' + Math.round(e.x * EMU) + '" y="' + Math.round(e.y * EMU) + '"/><a:ext cx="' + Math.max(1, Math.round(e.w * EMU)) + '" cy="' + Math.max(1, Math.round(e.h * EMU)) + '"/></a:xfrm>'; }
  function pathGeom(e) {
    var vb = e.vb || [100, 100], K = 100, tok = String(e.d).match(/[MLHVCZ]|-?\d*\.?\d+(?:e-?\d+)?/gi); if (!tok || /[^MLHVCZ0-9eE+\-. ,\n]/.test(String(e.d).replace(/[mlhvcz]/g, '')) || /[mlhvczAaQqSsTt]/.test(String(e.d))) return null;
    var i = 0, out = '', cx = 0, cy = 0, sx = 0, sy = 0, cmd = '', pt = function (x, y) { return '<a:pt x="' + Math.round(x * K) + '" y="' + Math.round(y * K) + '"/>'; }, nx = function () { return parseFloat(tok[i++]); };
    while (i < tok.length) { if (/[A-Za-z]/.test(tok[i])) cmd = tok[i++]; if (cmd === 'Z') { out += '<a:close/>'; cx = sx; cy = sy; continue; } var a, b;
      if (cmd === 'M') { a = nx(); b = nx(); out += '<a:moveTo>' + pt(a, b) + '</a:moveTo>'; cx = sx = a; cy = sy = b; cmd = 'L'; }
      else if (cmd === 'L') { a = nx(); b = nx(); out += '<a:lnTo>' + pt(a, b) + '</a:lnTo>'; cx = a; cy = b; }
      else if (cmd === 'H') { a = nx(); out += '<a:lnTo>' + pt(a, cy) + '</a:lnTo>'; cx = a; }
      else if (cmd === 'V') { b = nx(); out += '<a:lnTo>' + pt(cx, b) + '</a:lnTo>'; cy = b; }
      else if (cmd === 'C') { var x1 = nx(), y1 = nx(), x2 = nx(), y2 = nx(), x3 = nx(), y3 = nx(); out += '<a:cubicBezTo>' + pt(x1, y1) + pt(x2, y2) + pt(x3, y3) + '</a:cubicBezTo>'; cx = x3; cy = y3; }
      else return null; if (!isFinite(cx + cy)) return null; }
    return '<a:custGeom><a:avLst/><a:gdLst/><a:ahLst/><a:cxnLst/><a:rect l="0" t="0" r="r" b="b"/><a:pathLst><a:path w="' + Math.round(vb[0] * K) + '" h="' + Math.round(vb[1] * K) + '">' + out + '</a:path></a:pathLst></a:custGeom>';
  }
  function slideXml(doc, imgRel, idc) {
    var nid = function () { return ++idc.n; }, sp = '';
    doc.els.forEach(function (e) {
      if (e.vis === false) return; var id = nid(), nm = esc(e.name || e.type), alpha = e.op != null && e.op < 1;
      var fill = fillXml(e.fill); if (alpha && typeof e.fill === 'string' && e.fill) fill = '<a:solidFill><a:srgbClr val="' + hex6(e.fill) + '"><a:alpha val="' + Math.round(e.op * 100000) + '"/></a:srgbClr></a:solidFill>';
      if (e.type === 'rect' || e.type === 'ellipse') {
        var geom = e.type === 'ellipse' ? '<a:prstGeom prst="ellipse"><a:avLst/></a:prstGeom>' : (e.r ? '<a:prstGeom prst="roundRect"><a:avLst><a:gd name="adj" fmla="val ' + Math.round(clamp(e.r / Math.min(e.w, e.h), 0, 0.5) * 100000) + '"/></a:avLst></a:prstGeom>' : '<a:prstGeom prst="rect"><a:avLst/></a:prstGeom>');
        sp += '<p:sp><p:nvSpPr><p:cNvPr id="' + id + '" name="' + nm + '"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr><p:spPr>' + xfrm(e) + geom + fill + lnXml(e) + '</p:spPr></p:sp>';
      } else if (e.type === 'path') {
        var g = pathGeom(e);
        if (g) sp += '<p:sp><p:nvSpPr><p:cNvPr id="' + id + '" name="' + nm + '"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr><p:spPr>' + xfrm(e) + g + fill + lnXml(e) + '</p:spPr></p:sp>';
        else if (imgRel) { var rid = imgRel(e); if (rid) sp += pic(id, nm, e, rid); }
      } else if (e.type === 'image' && e.href) { var rid2 = imgRel(e, true); if (rid2) sp += pic(id, nm, e, rid2); }
      else if (e.type === 'text') {
        var col = typeof e.fill === 'string' ? e.fill : (e.fill && e.fill.g ? (Array.isArray(e.fill.g[0]) ? e.fill.g[0][1] : e.fill.g[0]) : '#000000'), sz = Math.round(e.size * 0.75 * 100), tf = esc(S.pptFont(e.font));
        var ps = String(e.upper ? String(e.text).toUpperCase() : e.text).split('\n').map(function (line) {
          return '<a:p><a:pPr algn="' + (e.align === 'center' ? 'ctr' : e.align === 'right' ? 'r' : 'l') + '"><a:lnSpc><a:spcPct val="' + Math.round(clamp((e.lh || 1.15) / 1.2, 0.5, 3) * 100000) + '"/></a:lnSpc><a:spcBef><a:spcPts val="0"/></a:spcBef></a:pPr>' +
            (line ? '<a:r><a:rPr lang="en-US" sz="' + sz + '" b="' + ((e.weight || 400) >= 600 ? 1 : 0) + '" i="' + (e.italic ? 1 : 0) + '"' + (e.ls ? ' spc="' + Math.round(e.ls * 75) + '"' : '') + ' dirty="0">' + (e.outline && e.outline.w ? '<a:ln w="' + Math.round(e.outline.w * EMU) + '"><a:solidFill><a:srgbClr val="' + hex6(e.outline.c) + '"/></a:solidFill></a:ln>' : '') +
              (alpha ? '<a:solidFill><a:srgbClr val="' + hex6(col) + '"><a:alpha val="' + Math.round(e.op * 100000) + '"/></a:srgbClr></a:solidFill>' : '<a:solidFill><a:srgbClr val="' + hex6(col) + '"/></a:solidFill>') + '<a:latin typeface="' + tf + '"/><a:cs typeface="' + tf + '"/></a:rPr><a:t>' + esc(line) + '</a:t></a:r>' : '') + '<a:endParaRPr lang="en-US" sz="' + sz + '" dirty="0"/></a:p>'; }).join('');
        sp += '<p:sp><p:nvSpPr><p:cNvPr id="' + id + '" name="' + nm + '"/><p:cNvSpPr txBox="1"/><p:nvPr/></p:nvSpPr><p:spPr>' + xfrm(e) + '<a:prstGeom prst="rect"><a:avLst/></a:prstGeom><a:noFill/></p:spPr><p:txBody><a:bodyPr wrap="square" lIns="0" tIns="0" rIns="0" bIns="0" rtlCol="0" anchor="t"><a:noAutofit/></a:bodyPr><a:lstStyle/>' + ps + '</p:txBody></p:sp>';
      }
    });
    var bg = doc.bg && doc.bg !== 'transparent' ? '<p:bg><p:bgPr>' + fillXml(doc.bg) + '<a:effectLst/></p:bgPr></p:bg>' : '';
    return X_ + '<p:sld ' + NSA + '><p:cSld>' + bg + '<p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr>' + sp + '</p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sld>';
  }
  function pic(id, nm, e, rid) { return '<p:pic><p:nvPicPr><p:cNvPr id="' + id + '" name="' + nm + '"/><p:cNvPicPr><a:picLocks noChangeAspect="1"/></p:cNvPicPr><p:nvPr/></p:nvPicPr><p:blipFill><a:blip r:embed="' + rid + '"/>' + (e.fit === 'fill' ? '<a:stretch><a:fillRect/></a:stretch>' : '<a:stretch><a:fillRect/></a:stretch>') + '</p:blipFill><p:spPr>' + xfrm(e) + '<a:prstGeom prst="' + (e.r ? 'roundRect' : 'rect') + '"><a:avLst/></a:prstGeom></p:spPr></p:pic>'; }
  function themeXml() {
    var f = '<a:solidFill><a:schemeClr val="phClr"/></a:solidFill>', ln = function (w) { return '<a:ln w="' + w + '"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:ln>'; };
    return X_ + '<a:theme xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" name="Zen Ai"><a:themeElements><a:clrScheme name="Zen Ai"><a:dk1><a:srgbClr val="1A1A1A"/></a:dk1><a:lt1><a:srgbClr val="FFFFFF"/></a:lt1><a:dk2><a:srgbClr val="1F3864"/></a:dk2><a:lt2><a:srgbClr val="EEF2F7"/></a:lt2><a:accent1><a:srgbClr val="4472C4"/></a:accent1><a:accent2><a:srgbClr val="ED7D31"/></a:accent2><a:accent3><a:srgbClr val="A5A5A5"/></a:accent3><a:accent4><a:srgbClr val="FFC000"/></a:accent4><a:accent5><a:srgbClr val="5B9BD5"/></a:accent5><a:accent6><a:srgbClr val="70AD47"/></a:accent6><a:hlink><a:srgbClr val="0563C1"/></a:hlink><a:folHlink><a:srgbClr val="954F72"/></a:folHlink></a:clrScheme>' +
      '<a:fontScheme name="Zen Ai"><a:majorFont><a:latin typeface="Arial"/><a:ea typeface=""/><a:cs typeface=""/></a:majorFont><a:minorFont><a:latin typeface="Arial"/><a:ea typeface=""/><a:cs typeface=""/></a:minorFont></a:fontScheme>' +
      '<a:fmtScheme name="Zen Ai"><a:fillStyleLst>' + f + f + f + '</a:fillStyleLst><a:lnStyleLst>' + ln(6350) + ln(12700) + ln(19050) + '</a:lnStyleLst><a:effectStyleLst><a:effectStyle><a:effectLst/></a:effectStyle><a:effectStyle><a:effectLst/></a:effectStyle><a:effectStyle><a:effectLst/></a:effectStyle></a:effectStyleLst><a:bgFillStyleLst>' + f + f + f + '</a:bgFillStyleLst></a:fmtScheme></a:themeElements></a:theme>';
  }
  var GRP = '<p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr>';
  /* slides = [{ doc, notes }]. Returns a Blob. Text, shapes and pictures stay editable in PowerPoint. */
  X.pptx = function (slides, o) { o = o || {};
    var W0 = slides[0].doc.w, H0 = slides[0].doc.h, files = [], media = [], mediaCount = 0, anyNotes = slides.some(function (s) { return s.notes && String(s.notes).trim(); });
    var pending = [];
    var slideParts = slides.map(function (s, i) {
      var rels = [{ id: 'rId1', type: 'slideLayout', target: '../slideLayouts/slideLayout1.xml' }], idc = { n: 1 }, rn = 1;
      var imgRel = function (e, isImg) {
        if (isImg) { var m = /^data:image\/(png|jpe?g|gif|webp);base64,/i.exec(e.href); if (!m) return null; var ext = m[1].toLowerCase().replace('jpeg', 'jpg'); if (ext === 'webp') { return rasterEl(e); } var nm = 'image' + (++mediaCount) + '.' + ext; media.push({ name: 'ppt/media/' + nm, data: X.b64u8(e.href) }); rels.push({ id: 'rId' + (++rn + 0), type: 'image', target: '../media/' + nm }); return 'rId' + rn; }
        return rasterEl(e); };
      function rasterEl(e) { var nm = 'image' + (++mediaCount) + '.png', rid = 'rId' + (++rn); rels.push({ id: rid, type: 'image', target: '../media/' + nm });
        var d1 = { w: Math.ceil(e.w), h: Math.ceil(e.h), bg: 'transparent', els: [Object.assign({}, e, { x: 0, y: 0, rot: 0, op: 1 })], meta: {} };
        pending.push(X.raster(S.toSVG(d1), d1.w, d1.h, { scale: 2 }).then(X.u8).then(function (u) { media.push({ name: 'ppt/media/' + nm, data: u }); })); return rid; }
      var xml = slideXml(s.doc, imgRel, idc);
      if (anyNotes) rels.push({ id: 'rId' + (++rn), type: 'notesSlide', target: '../notesSlides/notesSlide' + (i + 1) + '.xml' });
      return { xml: xml, rels: rels };
    });
    return Promise.all(pending).then(function () {
      var N = slides.length, ct = '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Default Extension="png" ContentType="image/png"/><Default Extension="jpg" ContentType="image/jpeg"/><Default Extension="gif" ContentType="image/gif"/>' +
        '<Override PartName="/ppt/presentation.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml"/><Override PartName="/ppt/slideMasters/slideMaster1.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slideMaster+xml"/><Override PartName="/ppt/slideLayouts/slideLayout1.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slideLayout+xml"/><Override PartName="/ppt/theme/theme1.xml" ContentType="application/vnd.openxmlformats-officedocument.theme+xml"/>' +
        (anyNotes ? '<Override PartName="/ppt/notesMasters/notesMaster1.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.notesMaster+xml"/><Override PartName="/ppt/theme/theme2.xml" ContentType="application/vnd.openxmlformats-officedocument.theme+xml"/>' : '');
      for (var i = 1; i <= N; i++) ct += '<Override PartName="/ppt/slides/slide' + i + '.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slide+xml"/>' + (anyNotes ? '<Override PartName="/ppt/notesSlides/notesSlide' + i + '.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.notesSlide+xml"/>' : '');
      ct += '<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/><Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>';
      var R = function (a) { return X_ + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' + a.map(function (r) { return '<Relationship Id="' + r.id + '" Type="' + RT + '/' + r.type + '" Target="' + r.target + '"/>'; }).join('') + '</Relationships>'; };
      files.push({ name: '[Content_Types].xml', data: X_ + '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">' + ct + '</Types>' });
      files.push({ name: '_rels/.rels', data: R([{ id: 'rId1', type: 'officeDocument', target: 'ppt/presentation.xml' }, { id: 'rId2', type: 'extended-properties', target: 'docProps/app.xml' }]).replace('</Relationships>', '<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/></Relationships>') });
      files.push({ name: 'docProps/core.xml', data: X_ + '<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:title>' + esc(o.title || 'Presentation') + '</dc:title><dc:creator>Zen Ai</dc:creator><dcterms:created xsi:type="dcterms:W3CDTF">' + new Date().toISOString().replace(/\.\d+Z$/, 'Z') + '</dcterms:created></cp:coreProperties>' });
      files.push({ name: 'docProps/app.xml', data: X_ + '<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties"><Application>Zen Ai</Application><Slides>' + N + '</Slides></Properties>' });
      var pr = [{ id: 'rId1', type: 'slideMaster', target: 'slideMasters/slideMaster1.xml' }, { id: 'rId2', type: 'theme', target: 'theme/theme1.xml' }], k = 3, ids = '';
      for (i = 1; i <= N; i++) { pr.push({ id: 'rId' + k, type: 'slide', target: 'slides/slide' + i + '.xml' }); ids += '<p:sldId id="' + (255 + i) + '" r:id="rId' + k + '"/>'; k++; }
      var nmid = ''; if (anyNotes) { pr.push({ id: 'rId' + k, type: 'notesMaster', target: 'notesMasters/notesMaster1.xml' }); nmid = '<p:notesMasterIdLst><p:notesMasterId r:id="rId' + k + '"/></p:notesMasterIdLst>'; }
      files.push({ name: 'ppt/presentation.xml', data: X_ + '<p:presentation ' + NSA + ' saveSubsetFonts="1"><p:sldMasterIdLst><p:sldMasterId id="2147483648" r:id="rId1"/></p:sldMasterIdLst>' + nmid + '<p:sldIdLst>' + ids + '</p:sldIdLst><p:sldSz cx="' + Math.round(W0 * EMU) + '" cy="' + Math.round(H0 * EMU) + '"/><p:notesSz cx="6858000" cy="9144000"/></p:presentation>' });
      files.push({ name: 'ppt/_rels/presentation.xml.rels', data: R(pr) });
      var tx = '<p:txStyles><p:titleStyle><a:lvl1pPr><a:defRPr sz="3200"/></a:lvl1pPr></p:titleStyle><p:bodyStyle><a:lvl1pPr><a:defRPr sz="1800"/></a:lvl1pPr></p:bodyStyle><p:otherStyle><a:defPPr><a:defRPr lang="en-US"/></a:defPPr></p:otherStyle></p:txStyles>';
      files.push({ name: 'ppt/slideMasters/slideMaster1.xml', data: X_ + '<p:sldMaster ' + NSA + '><p:cSld><p:bg><p:bgRef idx="1001"><a:schemeClr val="bg1"/></p:bgRef></p:bg><p:spTree>' + GRP + '</p:spTree></p:cSld><p:clrMap bg1="lt1" tx1="dk1" bg2="lt2" tx2="dk2" accent1="accent1" accent2="accent2" accent3="accent3" accent4="accent4" accent5="accent5" accent6="accent6" hlink="hlink" folHlink="folHlink"/><p:sldLayoutIdLst><p:sldLayoutId id="2147483649" r:id="rId1"/></p:sldLayoutIdLst>' + tx + '</p:sldMaster>' });
      files.push({ name: 'ppt/slideMasters/_rels/slideMaster1.xml.rels', data: R([{ id: 'rId1', type: 'slideLayout', target: '../slideLayouts/slideLayout1.xml' }, { id: 'rId2', type: 'theme', target: '../theme/theme1.xml' }]) });
      files.push({ name: 'ppt/slideLayouts/slideLayout1.xml', data: X_ + '<p:sldLayout ' + NSA + ' type="blank" preserve="1"><p:cSld name="Blank"><p:spTree>' + GRP + '</p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sldLayout>' });
      files.push({ name: 'ppt/slideLayouts/_rels/slideLayout1.xml.rels', data: R([{ id: 'rId1', type: 'slideMaster', target: '../slideMasters/slideMaster1.xml' }]) });
      files.push({ name: 'ppt/theme/theme1.xml', data: themeXml() });
      if (anyNotes) {
        files.push({ name: 'ppt/theme/theme2.xml', data: themeXml() });
        files.push({ name: 'ppt/notesMasters/notesMaster1.xml', data: X_ + '<p:notesMaster ' + NSA + '><p:cSld><p:bg><p:bgRef idx="1001"><a:schemeClr val="bg1"/></p:bgRef></p:bg><p:spTree>' + GRP + '<p:sp><p:nvSpPr><p:cNvPr id="2" name="Slide Image Placeholder 1"/><p:cNvSpPr><a:spLocks noGrp="1" noRot="1" noChangeAspect="1"/></p:cNvSpPr><p:nvPr><p:ph type="sldImg" idx="2"/></p:nvPr></p:nvSpPr><p:spPr><a:xfrm><a:off x="685800" y="1143000"/><a:ext cx="5486400" cy="3086100"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></p:spPr></p:sp><p:sp><p:nvSpPr><p:cNvPr id="3" name="Notes Placeholder 2"/><p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr><p:nvPr><p:ph type="body" sz="quarter" idx="3"/></p:nvPr></p:nvSpPr><p:spPr><a:xfrm><a:off x="685800" y="4400550"/><a:ext cx="5486400" cy="3600450"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></p:spPr><p:txBody><a:bodyPr/><a:lstStyle/><a:p><a:endParaRPr lang="en-US"/></a:p></p:txBody></p:sp></p:spTree></p:cSld><p:clrMap bg1="lt1" tx1="dk1" bg2="lt2" tx2="dk2" accent1="accent1" accent2="accent2" accent3="accent3" accent4="accent4" accent5="accent5" accent6="accent6" hlink="hlink" folHlink="folHlink"/><p:notesStyle><a:lvl1pPr marL="0" algn="l"><a:defRPr sz="1200"/></a:lvl1pPr></p:notesStyle></p:notesMaster>' });
        files.push({ name: 'ppt/notesMasters/_rels/notesMaster1.xml.rels', data: R([{ id: 'rId1', type: 'theme', target: '../theme/theme2.xml' }]) });
      }
      slideParts.forEach(function (sp, i) {
        files.push({ name: 'ppt/slides/slide' + (i + 1) + '.xml', data: sp.xml }); files.push({ name: 'ppt/slides/_rels/slide' + (i + 1) + '.xml.rels', data: R(sp.rels) });
        if (anyNotes) { var nt = String(slides[i].notes || '').split('\n').map(function (l) { return '<a:p>' + (l ? '<a:r><a:rPr lang="en-US" dirty="0"/><a:t>' + esc(l) + '</a:t></a:r>' : '<a:endParaRPr lang="en-US"/>') + '</a:p>'; }).join('');
          files.push({ name: 'ppt/notesSlides/notesSlide' + (i + 1) + '.xml', data: X_ + '<p:notes ' + NSA + '><p:cSld><p:spTree>' + GRP + '<p:sp><p:nvSpPr><p:cNvPr id="2" name="Slide Image Placeholder 1"/><p:cNvSpPr><a:spLocks noGrp="1" noRot="1" noChangeAspect="1"/></p:cNvSpPr><p:nvPr><p:ph type="sldImg"/></p:nvPr></p:nvSpPr><p:spPr/></p:sp><p:sp><p:nvSpPr><p:cNvPr id="3" name="Notes Placeholder 2"/><p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr><p:nvPr><p:ph type="body" idx="1"/></p:nvPr></p:nvSpPr><p:spPr/><p:txBody><a:bodyPr/><a:lstStyle/>' + nt + '</p:txBody></p:sp></p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:notes>' });
          files.push({ name: 'ppt/notesSlides/_rels/notesSlide' + (i + 1) + '.xml.rels', data: R([{ id: 'rId1', type: 'notesMaster', target: '../notesMasters/notesMaster1.xml' }, { id: 'rId2', type: 'slide', target: '../slides/slide' + (i + 1) + '.xml' }]) }); }
      });
      return X.zip(files.concat(media), 'application/vnd.openxmlformats-officedocument.presentationml.presentation');
    });
  };

  /* ---------------- project bar: new / projects / save / history / import / export project ---------------- */
  /* ctx: { kind, kinds?, label, getState(), setState(data,name), makeNew(), thumb() -> Promise<string>, theme: css class } */
  U.projectBar = function (ctx) {
    var bar = U.h('div', 'zs-pbar'), st = { id: null, name: ctx.defaultName || 'Untitled design', dirty: false, n: 0 }, nameEl = U.h('button', 'zs-pname', st.name), stat = U.h('span', 'zs-pstat', ''), timer = 0;
    var setStat = function (t) { stat.textContent = t; };
    function persist(manual) { clearTimeout(timer); var data = ctx.getState(); if (data == null) return Promise.resolve(); setStat('Saving…');
      return Promise.resolve(ctx.thumb ? ctx.thumb() : '').catch(function () { return ''; }).then(function (th) {
        var p = st.id ? Pj.save(st.id, data, { version: manual || (++st.n % 12 === 0), thumb: th }) : Pj.create(ctx.kind, st.name, data, th).then(function (r) { st.id = r.id; return r; });
        return p.then(function () { st.dirty = false; setStat(manual ? 'Saved' : 'Autosaved'); }); }).catch(function () { setStat('Could not save'); }); }
    bar.touch = function () { st.dirty = true; setStat('Unsaved'); clearTimeout(timer); timer = setTimeout(function () { persist(false); }, 1500); };
    bar.state = st; bar.flush = function () { return st.dirty ? persist(false) : Promise.resolve(); };
    bar.load = function (rec) { st.id = rec.id; st.name = rec.name; nameEl.textContent = rec.name; st.dirty = false; ctx.setState(rec.data, rec.name); setStat('Opened'); };
    bar.openId = function (id) { return Pj.open(id).then(function (rec) { if (rec) bar.load(rec); else tick('That design was not found.'); }); };
    var kinds = ctx.kinds || [ctx.kind];
    nameEl.title = 'Rename'; nameEl.onclick = function () { U.prompt('Rename design', st.name, function (v) { v = String(v || '').trim(); if (!v) return; st.name = v.slice(0, 80); nameEl.textContent = st.name; if (st.id) Pj.rename(st.id, st.name); else persist(true); }); };
    function listDialog() { var box = U.h('div', 'zs-plist'), draw = function () { box.innerHTML = ''; var items = []; kinds.forEach(function (k) { items = items.concat(Pj.list(k)); }); items.sort(function (a, b) { return b.t - a.t; });
        if (!items.length) { box.appendChild(U.h('div', 'zs-empty', 'No saved designs yet. Your work is saved automatically.')); return; }
        items.forEach(function (p) { var row = U.h('div', 'zs-prow'), im = U.h('div', 'zs-pth'); if (p.thumb) im.style.backgroundImage = 'url(' + p.thumb + ')'; var info = U.h('div', 'zs-pinfo'); info.append(U.h('b', '', p.name), U.h('small', '', new Date(p.t).toLocaleString()));
          var act = U.h('div', 'zs-pact'); act.append(U.btn('Open', function () { dlg.close(); bar.openId(p.id); }, 'zs-b zs-p'), U.btn('Duplicate', function () { Pj.duplicate(p.id).then(draw); }), U.btn('Rename', function () { U.prompt('Rename design', p.name, function (v) { Pj.rename(p.id, v).then(draw); }); }),
            U.btn('Export', function () { Pj.exportBlob(p.id).then(function (b) { if (b) X.save(b, X.safe(p.name) + '.zenstudio.json'); }); }), U.btn('Delete', function () { U.confirm('Delete design', 'Delete "' + p.name + '"? This cannot be undone.', function () { Pj.del(p.id).then(function () { if (st.id === p.id) st.id = null; draw(); }); }, 'Delete'); }));
          row.append(im, info, act); box.appendChild(row); }); };
      draw(); var dlg = U.dialog('My designs', box, [['Close']]); }
    function histDialog() { if (!st.id) { tick('Save the design first (it saves automatically after your first change).'); return; } Pj.versions(st.id).then(function (vs) { var box = U.h('div');
        if (!vs.length) box.appendChild(U.h('div', 'zs-empty', 'No earlier versions yet. Tap Save to keep a version.')); vs.forEach(function (v) { var r = U.h('div', 'zs-prow'); r.append(U.h('div', 'zs-pinfo', 'Version from ' + new Date(v.t).toLocaleString()), U.btn('Restore', function () { U.confirm('Restore version', 'Go back to this version? Your current version is kept in history.', function () { Pj.restore(st.id, v.i).then(function () { dlg.close(); bar.openId(st.id); }); }, 'Restore'); }, 'zs-b zs-p')); box.appendChild(r); });
        var dlg = U.dialog('Design history', box, [['Close']]); }); }
    var b = function (t, f, tt) { return U.btn(t, f, 'zs-b zs-pb', tt); };
    bar.append(nameEl, stat, b('New', function () { bar.flush().then(function () { st.id = null; st.name = ctx.defaultName || 'Untitled design'; nameEl.textContent = st.name; ctx.makeNew(); setStat('New'); }); }), b('Designs', listDialog, 'Open, duplicate, rename or delete designs'),
      b('Save', function () { persist(true).then(function () { tick('Saved'); }); }), b('History', histDialog, 'Restore an earlier version'),
      b('Import', function () { U.pickFile('.json,application/json', function (f) { U.readText(f).then(function (t) { return Pj.importText(t, kinds); }).then(function (rec) { bar.load(rec); tick('Imported'); }).catch(function (e) { tick(e.message || 'Could not import'); }); }); }, 'Import a Zen Ai design file'),
      b('Export file', function () { persist(true).then(function () { return st.id && Pj.exportBlob(st.id); }).then(function (bl) { if (bl) X.save(bl, X.safe(st.name) + '.zenstudio.json'); }); }, 'Save the project file'));
    if (S.pendingOpen && kinds.indexOf(S.pendingOpen.kind) >= 0) { var po = S.pendingOpen; S.pendingOpen = null; setTimeout(function () { bar.openId(po.id); }, 30); }
    return bar;
  };

  /* shared base CSS for the bits every tool uses (each tool's own theme overrides the --zs-* variables) */
  U.css('zs-base', '.zs-root{--zs-bg:#111;--zs-panel:#1b1b1b;--zs-ink:#f1f1f1;--zs-mut:#9a9a9a;--zs-line:#333;--zs-acc:#6c5ce7;--zs-acc2:#a29bfe;--zs-onacc:#fff;--zs-rad:12px;color:var(--zs-ink);background:var(--zs-bg);font:14px/1.35 system-ui,Roboto,sans-serif;box-sizing:border-box}' +
    '.zs-root *{box-sizing:border-box}.zs-b{font:inherit;color:var(--zs-ink);background:var(--zs-panel);border:1px solid var(--zs-line);border-radius:calc(var(--zs-rad) - 2px);padding:8px 12px;min-height:38px;cursor:pointer}.zs-b:active{transform:scale(.97)}.zs-b.zs-p,.zs-b.on{background:var(--zs-acc);color:var(--zs-onacc);border-color:var(--zs-acc)}' +
    '.zs-in,.zs-sel{width:100%;font:inherit;color:var(--zs-ink);background:var(--zs-bg);border:1px solid var(--zs-line);border-radius:8px;padding:8px;min-height:36px}.zs-col{width:100%;height:36px;border:1px solid var(--zs-line);border-radius:8px;background:none;padding:2px}.zs-rng{width:100%;accent-color:var(--zs-acc)}' +
    '.zs-f{display:flex;flex-direction:column;gap:4px;margin:0 0 8px}.zs-fl{font-size:11px;letter-spacing:.04em;text-transform:uppercase;color:var(--zs-mut)}.zs-chk{display:flex;align-items:center;gap:6px;margin:4px 0}' +
    '.zs-pbar{display:flex;gap:6px;align-items:center;flex-wrap:wrap;padding:8px;border-bottom:1px solid var(--zs-line)}.zs-pname{font:inherit;font-weight:700;color:var(--zs-ink);background:none;border:0;border-bottom:1px dashed var(--zs-line);padding:4px 2px;max-width:46vw;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.zs-pstat{font-size:11px;color:var(--zs-mut);margin-right:auto}.zs-pb{padding:6px 10px;min-height:34px;font-size:13px}' +
    '.zs-prow{display:flex;gap:10px;align-items:center;padding:8px 0;border-bottom:1px solid var(--zs-line,#444);flex-wrap:wrap}.zs-pth{width:64px;height:48px;border-radius:8px;background:#444 center/cover;flex:none}.zs-pinfo{flex:1;min-width:120px;display:flex;flex-direction:column}.zs-pinfo small{color:var(--zs-mut,#999)}.zs-pact{display:flex;gap:6px;flex-wrap:wrap}.zs-pact .zs-b{padding:5px 9px;min-height:32px;font-size:12px}.zs-empty{padding:18px;text-align:center;color:var(--zs-mut,#999)}' +
    '.zs-ed{background:var(--zs-canvas,#2a2a2a);display:flex;min-height:240px}.zs-err{color:#ff7675;font-size:13px;margin:6px 0}.zs-note{color:var(--zs-mut);font-size:12px;margin:6px 0}');
})(typeof window !== 'undefined' ? window : globalThis);
