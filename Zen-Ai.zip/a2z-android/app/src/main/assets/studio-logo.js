/* Zen Ai Creative Design Studio: tool kit (mounting, project wiring) + Logo Studio (premium black and gold). */
(function (W) {
  'use strict';
  var S = W.Studio; if (!S || !S.uiLib || S.kit) return;
  var U = S.ui, h = U.h, X = S.exp, C = S.color, clamp = S.clamp, esc = S.esc;

  /* ---------------- kit shared by every tool ---------------- */
  var K = S.kit = {};
  S.tools = S.tools || {};
  S.register = function (t) { S.tools[t.id] = t; try { if (typeof ALL !== 'undefined' && !ALL.find(function (x) { return x.id === t.id; })) ALL.push(Object.assign({ cat: 'create' }, t)); } catch (e) { } };
  K.mount = function (w, cls, css) { U.css('zs-th-' + cls, css); var r = h('div', 'zs-root ' + cls); w.appendChild(r); return r; };
  K.host = function (root, cls) { var hst = h('div', cls || 'zs-host'); hst.style.cssText += ';min-height:260px;height:clamp(260px,46vh,560px);border-radius:var(--zs-rad);overflow:auto'; return hst; };
  K.cleanDoc = function (ed) { return JSON.parse(ed.snapshot()); };
  /* project bar wired to an editor: state = { doc, x } */
  K.wire = function (o) {
    var ed = o.ed, bar = U.projectBar({ kind: o.kind, defaultName: o.defaultName, getState: function () { return { doc: K.cleanDoc(ed), x: o.getExtra ? o.getExtra() : null }; },
      setState: function (d) { var doc = S.validate(d && d.doc); if (!doc) { S.tell('This design file is damaged.'); return; } if (o.setExtra) o.setExtra(d.x); ed.setDoc(doc); },
      makeNew: o.makeNew, thumb: function () { return X.thumb(ed.doc); } });
    ed.on('change', function () { bar.touch(); }); return bar;
  };
  K.png = function (ed, scale, transparent) { var d = S.clone(JSON.parse(ed.snapshot())); if (transparent) d.bg = 'transparent'; return X.docRaster(d, { scale: scale || 1 }); };
  K.exporter = function (ed, o) {
    o = o || {}; return U.exportRow({ formats: o.formats || ['png', 'jpg', 'pdf', 'svg'], name: o.name || function () { return 'design'; }, share: true,
      make: function (f) { var d = JSON.parse(ed.snapshot()); if (o.transparent && o.transparent() && (f === 'png' || f === 'svg' || f === 'pdf')) d.bg = 'transparent'; var sc = o.scale ? o.scale() : 1;
        if (f === 'svg') return Promise.resolve(X.svgBlob(S.toSVG(d))); if (f === 'png') return X.docRaster(d, { scale: sc }); if (f === 'jpg') return X.docRaster(d, { scale: sc, type: 'image/jpeg', q: 0.93, bg: typeof d.bg === 'string' && d.bg !== 'transparent' ? d.bg : '#ffffff' }); if (f === 'pdf') return X.pdf([{ doc: d }], { title: o.name ? o.name() : 'Design', scale: Math.max(1, Math.min(2, sc))}); } });
  };
  K.fileToText = function (f) { return U.readText(f); };
  K.chips = function (items, cur, fn) { var r = h('div', 'zs-chips'); items.forEach(function (it) { var a = Array.isArray(it) ? it : [it, it], b = h('button', 'zs-chip' + (a[0] === cur ? ' on' : ''), a[1]); b.type = 'button'; b.onclick = function () { [].forEach.call(r.children, function (c) { c.classList.remove('on'); }); b.classList.add('on'); fn(a[0]); }; r.appendChild(b); }); return r; };

  /* ======================= LOGO STUDIO ======================= */
  var LPAL = [['Black & Gold', ['#0b0b0b', '#d4af37', '#f3e3a4', '#b8860b']], ['Ivory & Emerald', ['#f7f3e8', '#0f5132', '#c9a24b', '#198754']], ['Midnight Cyan', ['#0a1128', '#22d3ee', '#a5f3fc', '#0ea5e9']], ['Burgundy Rose', ['#2a0a12', '#e11d48', '#fecdd3', '#be123c']],
    ['Graphite Orange', ['#18181b', '#f97316', '#fed7aa', '#ea580c']], ['Paper Blue', ['#ffffff', '#1d4ed8', '#93c5fd', '#2563eb']], ['Forest Mint', ['#052e16', '#34d399', '#bbf7d0', '#10b981']], ['Violet Pink', ['#1e1b4b', '#a78bfa', '#f9a8d4', '#ec4899']]];
  var LTPL = [['stack', 'Stacked'], ['badge', 'Badge'], ['monogram', 'Monogram'], ['side', 'Side by side'], ['shield', 'Shield'], ['hex', 'Hexagon'], ['minimal', 'Minimal'], ['emblem', 'Emblem'], ['square', 'App mark'], ['split', 'Two-tone word']];
  S.logoTemplates = LTPL;
  var initials = function (n) { return String(n || '').trim().split(/\s+/).slice(0, 2).map(function (x) { return x[0] || ''; }).join('').toUpperCase() || 'Z'; };
  function logoDefaults() { return { name: 'Aurum', tagline: 'Crafted with excellence', tpl: 'stack', symbol: 'crown', pal: LPAL[0][1].slice(), font: 'Serif', weight: 700, style: 'line', grad: true, bgMode: 'solid' }; }
  S.logoDefaults = logoDefaults;

  /* the logo as a document (1000 x 1000), a pure function of the brand description */
  S.logoDoc = function (b, size) {
    var bg = b.pal[0], pa = b.pal[1], pb = b.pal[2], pc = b.pal[3], dark = C.lum(bg) < 0.45, prim = b.grad ? { g: [pa, pc], a: 135 } : pa, nameCol = dark ? pb : pa, subCol = dark ? C.mix(pb, bg, 0.25) : C.mix(pa, bg, 0.35);
    var d = S.newDoc(1000, 1000, b.bgMode === 'transparent' ? 'transparent' : b.bgMode === 'gradient' ? { g: [bg, C.shift(bg, 0, 0, dark ? 10 : -6)], a: 160 } : bg), E = function (e) { d.els.push(e); return e; };
    var name = String(b.name || 'Brand').slice(0, 40), tag = String(b.tagline || '').slice(0, 60), solid = b.style === 'solid';
    var sym = function (x, y, s, col) { return E(S.symbolEl(b.symbol, { x: x, y: y, w: s, h: s, fill: solid ? col : 'none', stroke: col, sw: solid ? s / 24 * 0.5 : s / 24 * 1.7, name: 'Symbol' })); };
    var T = function (txt, y, sz, col, o) { return E(S.el('text', Object.assign({ text: txt, x: 50, y: y, w: 900, size: sz, fill: col, align: 'center', font: b.font, weight: b.weight || 700, name: 'Text' }, o || {}))); };
    var tg = function (y, o) { if (tag) T(tag, y, 34, subCol, Object.assign({ font: 'Sans', weight: 400, ls: 6, upper: true, name: 'Tagline' }, o || {})); };
    var fit = function (sz) { var e = { text: name, size: sz, font: b.font, weight: b.weight || 700, ls: 0 }; while (sz > 40 && S.textWidth(e, name) > 820) { sz -= 6; e.size = sz; } return sz; };
    switch (b.tpl) {
      case 'badge': E(S.el('ellipse', { x: 170, y: 90, w: 660, h: 660, fill: 'none', stroke: prim, sw: 16, name: 'Outer ring' })); E(S.el('ellipse', { x: 205, y: 125, w: 590, h: 590, fill: 'none', stroke: pc, sw: 4, name: 'Inner ring' })); sym(340, 260, 320, prim); T(name, 790, fit(96), nameCol, { name: 'Name' }); tg(905); break;
      case 'monogram': E(S.el('ellipse', { x: 210, y: 90, w: 580, h: 580, fill: prim, name: 'Disc' })); T(initials(name), 215, 300, bg === 'transparent' ? '#ffffff' : C.readable(pa, bg, '#ffffff'), { y: 215, name: 'Monogram', w: 580, x: 210 }); T(name, 740, fit(100), nameCol); tg(880); break;
      case 'side': sym(80, 360, 280, prim); T(name, 390, Math.min(96, fit(96)), nameCol, { x: 400, w: 540, align: 'left' }); if (tag) T(tag, 540, 30, subCol, { x: 400, w: 540, align: 'left', font: 'Sans', weight: 400, ls: 4, upper: true, name: 'Tagline' }); break;
      case 'shield': E(S.el('path', { d: SYd('shield'), vb: [24, 24], x: 260, y: 70, w: 480, h: 520, fill: prim, stroke: pb, sw: 10, name: 'Shield' })); sym(370, 210, 260, dark ? bg : '#ffffff'); T(name, 650, fit(104), nameCol); tg(800); break;
      case 'hex': E(S.el('path', { d: SYd('hexagon'), vb: [24, 24], x: 200, y: 70, w: 600, h: 600, fill: 'none', stroke: prim, sw: 16, name: 'Hexagon' })); sym(350, 220, 300, prim); T(name, 740, fit(100), nameCol); tg(880); break;
      case 'minimal': E(S.el('rect', { x: 300, y: 330, w: 400, h: 6, fill: prim, name: 'Line' })); T(name, 400, Math.min(150, fit(150)), nameCol, { ls: 16, weight: 300, name: 'Name', upper: true }); E(S.el('rect', { x: 300, y: 620, w: 400, h: 6, fill: prim, name: 'Line' })); tg(680, { size: 30 }); break;
      case 'emblem': E(S.el('ellipse', { x: 160, y: 60, w: 680, h: 680, fill: 'none', stroke: prim, sw: 12, name: 'Ring' })); E(S.el('ellipse', { x: 205, y: 105, w: 590, h: 590, fill: 'none', stroke: pc, sw: 3, name: 'Thin ring' })); [0, 1, 2, 3, 4].forEach(function (i) { E(S.el('ellipse', { x: 330 + i * 80, y: 520, w: 12, h: 12, fill: pb, name: 'Dot' })); }); sym(380, 230, 240, prim); T(name, 770, fit(88), nameCol); tg(890, { size: 28 }); break;
      case 'square': E(S.el('rect', { x: 200, y: 90, w: 600, h: 600, r: 150, fill: prim, name: 'Tile' })); sym(350, 240, 300, C.readable(pa, bg, '#ffffff')); T(name, 745, fit(100), nameCol); tg(885); break;
      case 'split': { var parts = name.split(/\s+/), a1, a2; if (parts.length > 1) { a1 = parts[0]; a2 = parts.slice(1).join(' '); } else { var m = Math.ceil(name.length / 2); a1 = name.slice(0, m); a2 = name.slice(m); }
        var sz = 130, ee = { size: sz, font: b.font, weight: b.weight || 700, ls: 0 }; while (sz > 40 && S.textWidth(ee, a1 + a2) > 840) { sz -= 6; ee.size = sz; } var w1 = S.textWidth(ee, a1), w2 = S.textWidth(ee, a2), x0 = 500 - (w1 + w2) / 2;
        sym(430, 230, 140, prim); T(a1, 420, sz, nameCol, { x: x0, w: w1 + 30, align: 'left', name: 'Name 1' }); T(a2, 420, sz, prim, { x: x0 + w1, w: w2 + 30, align: 'left', name: 'Name 2' }); tg(620); break; }
      default: sym(350, 170, 300, prim); T(name, 520, fit(112), nameCol); tg(690);
    }
    return d;
  };
  function SYd(n) { return S.symbols[n] || S.symbols.star; }

  function logoCss(c) { return '.' + c + '{--zs-bg:#0a0a0a;--zs-panel:#141311;--zs-ink:#f4ecd8;--zs-mut:#9b917a;--zs-line:#3a3322;--zs-acc:#d4af37;--zs-acc2:#f3e3a4;--zs-onacc:#1a1405;--zs-rad:14px;--zs-canvas:#050505;border:1px solid #3a3322;border-radius:16px;overflow:hidden;font-family:Georgia,"Noto Serif",serif}' +
    '.' + c + ' .zs-b{font-family:system-ui,Roboto,sans-serif;letter-spacing:.02em}.' + c + ' .zl-main{display:flex;flex-direction:column}.' + c + ' .zl-rail{display:flex;gap:6px;padding:8px;overflow-x:auto;background:linear-gradient(180deg,#14110a,#0a0a0a);border-bottom:1px solid #3a3322}.' + c + ' .zl-rail .zs-b{flex:none;min-width:42px;font-size:15px;border-color:#5a4a1a}' +
    '.' + c + ' .zl-title{padding:14px 14px 6px;display:flex;align-items:baseline;gap:10px}.' + c + ' .zl-title b{font-size:20px;letter-spacing:.14em;text-transform:uppercase;background:linear-gradient(90deg,#f3e3a4,#d4af37,#b8860b);-webkit-background-clip:text;background-clip:text;color:transparent}.' + c + ' .zl-title small{color:var(--zs-mut)}' +
    '.' + c + ' .zl-stage{padding:10px;background:radial-gradient(circle at 50% 0,#1c170a,#050505)}.' + c + ' .zs-tab{background:none;border:0;border-bottom:2px solid transparent;border-radius:0;color:var(--zs-mut);font-family:system-ui;letter-spacing:.08em;text-transform:uppercase;font-size:12px}.' + c + ' .zs-tab.on{color:var(--zs-acc2);border-bottom-color:var(--zs-acc);background:none}' +
    '.' + c + ' .zs-tbar{border-bottom:1px solid #2a2415}.' + c + ' .zs-card{background:#0f0e0a;border-color:#3a3322}.' + c + ' .zs-card.on{border-color:#d4af37}.' + c + ' .zl-mock{display:grid;grid-template-columns:repeat(2,1fr);gap:10px}.' + c + ' .zl-m{border-radius:12px;min-height:130px;display:flex;align-items:center;justify-content:center;position:relative;overflow:hidden;border:1px solid #3a3322}.' + c + ' .zl-m img{max-width:70%;max-height:110px}.' + c + ' .zl-m small{position:absolute;left:8px;bottom:6px;font:10px system-ui;opacity:.7;text-transform:uppercase;letter-spacing:.1em}' +
    '.' + c + ' .zl-sy{display:grid;grid-template-columns:repeat(auto-fill,minmax(54px,1fr));gap:6px}.' + c + ' .zl-sy button{aspect-ratio:1;background:#0f0e0a;border:1px solid #3a3322;border-radius:10px;padding:8px;color:#d4af37;cursor:pointer}.' + c + ' .zl-sy button.on{border-color:#d4af37;background:#1d170a}.' + c + ' .zl-sy svg{width:100%;height:100%;fill:none;stroke:currentColor;stroke-width:1.6;stroke-linecap:round;stroke-linejoin:round}' +
    '.' + c + ' .zl-pal{display:flex;gap:6px;flex-wrap:wrap}.' + c + ' .zl-sw{width:44px;height:44px;border-radius:50%;border:2px solid #3a3322;cursor:pointer;padding:0;overflow:hidden;display:grid;grid-template-columns:1fr 1fr}.' + c + ' .zl-sw.on{border-color:#d4af37;box-shadow:0 0 0 2px #0a0a0a,0 0 0 4px #d4af37}.' + c + ' .zl-sw i{display:block}' +
    '@media(min-width:900px){.' + c + ' .zl-main{flex-direction:row;flex-wrap:wrap}.' + c + ' .zl-rail{flex-direction:column;border-bottom:0;border-right:1px solid #3a3322;width:62px;overflow:visible}.' + c + ' .zl-body{flex:1;min-width:0;display:grid;grid-template-columns:minmax(0,1.2fr) minmax(320px,.8fr)}}'; }

  function logoTool(w) {
    var c = 'zs-logo', root = K.mount(w, c, logoCss(c)), b = logoDefaults(), host = K.host(root), ed, bar, panel, tabs, cur = { x: false };
    var doc0 = S.logoDoc(b); ed = new S.Editor(host, doc0, { accent: '#d4af37', checker: true });
    function regen() { ed.push('regen'); ed.setDoc(S.logoDoc(b), true); }
    function setB(p, noRegen) { Object.assign(b, p); if (!noRegen) regen(); bar.touch(); }
    bar = K.wire({ kind: 'logo', ed: ed, defaultName: 'Untitled logo', getExtra: function () { return b; }, setExtra: function (x) { if (x && x.pal) b = Object.assign(logoDefaults(), x); }, makeNew: function () { b = logoDefaults(); ed.setDoc(S.logoDoc(b)); if (tabs) tabs.show(tabs.cur()); } });
    var title = h('div', 'zl-title'); title.append(h('b', '', 'Logo Studio'), h('small', '', 'Premium identity design'));
    var rail = h('div', 'zl-rail'), rb = function (t, f, tt) { var x = U.btn(t, f, 'zs-b', tt); rail.appendChild(x); return x; };
    rb('Aa', function () { ed.addText('Text', { font: b.font, fill: b.pal[2], size: 80, align: 'center' }); tabs.show('edit'); }, 'Add text'); rb('◼', function () { ed.addShape('rounded', { fill: b.pal[1] }); tabs.show('edit'); }, 'Add shape'); rb('◯', function () { ed.addShape('circle', { fill: b.pal[1] }); tabs.show('edit'); }, 'Add circle'); rb('★', function () { tabs.show('symbols'); }, 'Symbols');
    rb('↶', function () { ed.undo(); }, 'Undo'); rb('↷', function () { ed.redo(); }, 'Redo'); rb('⤢', function () { ed.fit(); ed.draw(); }, 'Fit'); rb('+', function () { ed.zoomBy(1.25); }, 'Zoom in'); rb('−', function () { ed.zoomBy(0.8); }, 'Zoom out');
    var stage = h('div', 'zl-stage'); stage.appendChild(host);
    panel = h('div', 'zl-panel');
    function conceptsTab() { var box = h('div'), res = h('div', 'zs-grid'); res.style.marginTop = '10px';
      var ai = U.aiBox({ placeholder: 'Describe the brand: e.g. "Aurum, a luxury jewellery house in Colombo, elegant and timeless"', label: 'Create concepts', system: 'You are a senior brand designer. Create 4 logo concepts for the brand. JSON: {"concepts":[{"name":string,"tagline":string,"template":one of ' + LTPL.map(function (t) { return t[0]; }).join('|') + ',"symbol":one of ' + S.symbolList.join('|') + ',"palette":{"bg":"#hex","primary":"#hex","secondary":"#hex","accent":"#hex"},"font":one of ' + S.fonts.map(function (f) { return f[0]; }).join('|') + ',"style":"line"|"solid"}]}. Names are short. Colours must have strong contrast.',
        apply: function (plan) { var cs = (plan.concepts || plan.logos || []).slice(0, 6), list = []; res.innerHTML = '';
          cs.forEach(function (k) { var p = k.palette || {}, nb = Object.assign({}, b, { name: String(k.name || b.name).slice(0, 40), tagline: String(k.tagline || '').slice(0, 60), tpl: LTPL.some(function (t) { return t[0] === k.template; }) ? k.template : b.tpl, symbol: S.symbols[k.symbol] ? k.symbol : b.symbol, font: S.fonts.some(function (f) { return f[0] === k.font; }) ? k.font : b.font, style: k.style === 'solid' ? 'solid' : 'line',
            pal: [S.ai.color(p.bg, b.pal[0]), S.ai.color(p.primary, b.pal[1]), S.ai.color(p.secondary, b.pal[2]), S.ai.color(p.accent, b.pal[3])] });
            if (C.contrast(nb.pal[0], nb.pal[1]) < 2) nb.pal[1] = C.readable(nb.pal[0], '#f3e3a4', '#222222'); list.push(nb); });
          if (!list.length) throw new Error('The AI sent no usable concepts. Try again.');
          list.forEach(function (nb) { var cd = h('button', 'zs-card'); cd.type = 'button'; var ph = h('div', 'zs-ph'); ph.appendChild(U.preview(S.logoDoc(nb))); cd.append(ph, h('span', '', nb.name)); cd.onclick = function () { ed.push('concept'); b = nb; ed.setDoc(S.logoDoc(b), true); bar.touch(); }; res.appendChild(cd); }); return Promise.resolve(); } });
      box.append(ai, res); return box; }
    function templatesTab() { var g = h('div', 'zs-grid'); LTPL.forEach(function (t) { var cd = h('button', 'zs-card' + (b.tpl === t[0] ? ' on' : '')); cd.type = 'button'; var ph = h('div', 'zs-ph'); ph.appendChild(U.preview(S.logoDoc(Object.assign({}, b, { tpl: t[0] })))); cd.append(ph, h('span', '', t[1])); cd.onclick = function () { setB({ tpl: t[0] }); tabs.show('templates'); }; g.appendChild(cd); }); return g; }
    function symbolsTab() { var box = h('div'), g = h('div', 'zl-sy'); S.symbolList.forEach(function (n) { var bt = h('button', b.symbol === n ? 'on' : ''); bt.type = 'button'; bt.title = n; bt.setAttribute('aria-label', n); bt.innerHTML = '<svg viewBox="0 0 24 24"><path d="' + S.symbols[n] + '"/></svg>'; bt.onclick = function () { setB({ symbol: n }); [].forEach.call(g.children, function (x) { x.classList.remove('on'); }); bt.classList.add('on'); }; g.appendChild(bt); });
      box.append(h('div', 'zs-note', 'Tap a symbol to put it in your logo. Add more symbols from the Edit tab.'), g); return box; }
    function styleTab() { var box = h('div'), pal = h('div', 'zl-pal');
      LPAL.forEach(function (p) { var s = h('button', 'zl-sw' + (b.pal.join() === p[1].join() ? ' on' : '')); s.type = 'button'; s.title = p[0]; s.setAttribute('aria-label', p[0]); p[1].slice(0, 4).forEach(function (cc) { var i = h('i'); i.style.background = cc; s.appendChild(i); }); s.onclick = function () { setB({ pal: p[1].slice() }); styleTab._r(); }; pal.appendChild(s); });
      var cols = h('div', 'zs-r2'); ['Background', 'Primary', 'Secondary', 'Accent'].forEach(function (n, i) { cols.appendChild(U.field(n, U.color(b.pal[i], function (v) { var np = b.pal.slice(); np[i] = v; setB({ pal: np }); }))); });
      box.append(U.field('Brand name', U.text(b.name, function (v) { setB({ name: v }); }, 'Brand name')), U.field('Tagline', U.text(b.tagline, function (v) { setB({ tagline: v }); }, 'Tagline')),
        U.field('Font', U.select(S.fonts.map(function (f) { return f[0]; }), b.font, function (v) { setB({ font: v }); })), U.field('Weight', U.select([['300', 'Light'], ['400', 'Regular'], ['700', 'Bold'], ['900', 'Black']], String(b.weight), function (v) { setB({ weight: +v }); })),
        U.field('Symbol style', U.select([['line', 'Line'], ['solid', 'Solid']], b.style, function (v) { setB({ style: v }); })), U.check('Gold gradient on the main shape', b.grad, function (v) { setB({ grad: v }); }),
        U.field('Background', U.select([['solid', 'Solid colour'], ['gradient', 'Gradient'], ['transparent', 'Transparent']], b.bgMode, function (v) { setB({ bgMode: v }); })), h('div', 'zs-st', 'Colour palette'), pal, h('div', 'zs-note', 'Custom colours'), cols, h('div', 'zs-note', 'Changing these rebuilds the layout from the template. Hand edits made in the Edit tab are kept until then.'));
      styleTab._r = function () { tabs.show('style'); }; return box; }
    function editTab() { var box = h('div'), add = h('div', 'zs-arr'); add.append(U.btn('Add text', function () { ed.addText('Text', { font: b.font, fill: b.pal[2], size: 80, align: 'center' }); }, 'zs-b'), U.btn('Add shape', function () { ed.addShape('rounded', { fill: b.pal[1] }); }, 'zs-b'));
      ['star', 'heart', 'hexagon', 'diamond', 'bolt', 'ring'].forEach(function (k) { add.appendChild(U.btn(k, function () { ed.addShape(k, { fill: b.pal[1] }); }, 'zs-b zs-sm')); });
      add.appendChild(U.btn('Add symbol', function () { ed.add(S.symbolEl(b.symbol, { x: 380, y: 380, w: 240, h: 240, stroke: b.pal[1], sw: 9, fill: 'none' })); }, 'zs-b zs-sm')); add.appendChild(U.addPhoto(ed, 'Add picture'));
      box.append(add, U.inspector(ed, { groups: ['text', 'fill', 'stroke', 'shape', 'effects', 'arrange', 'doc'] }), h('div', 'zs-st', 'Layers'), U.layers(ed)); return box; }
    function variationsTab() { var box = h('div'), g = h('div', 'zs-grid'); box.append(h('div', 'zs-note', 'Colourways of your logo. Tap one to use it.'), g);
      LPAL.forEach(function (p) { var nb = Object.assign({}, b, { pal: p[1].slice() }), cd = h('button', 'zs-card'); cd.type = 'button'; var ph = h('div', 'zs-ph'); ph.appendChild(U.preview(S.logoDoc(nb))); cd.append(ph, h('span', '', p[0])); cd.onclick = function () { setB({ pal: p[1].slice() }); variationsTab._r(); }; g.appendChild(cd); });
      var g2 = h('div', 'zs-grid'); g2.style.marginTop = '10px'; [['line', 'Line'], ['solid', 'Solid']].forEach(function (sty) { LTPL.slice(0, 4).forEach(function (t) { var nb = Object.assign({}, b, { style: sty[0], tpl: t[0] }), cd = h('button', 'zs-card'); cd.type = 'button'; var ph = h('div', 'zs-ph'); ph.appendChild(U.preview(S.logoDoc(nb))); cd.append(ph, h('span', '', sty[1] + ' · ' + t[1])); cd.onclick = function () { setB({ style: sty[0], tpl: t[0] }); variationsTab._r(); }; g2.appendChild(cd); }); });
      box.append(h('div', 'zs-st', 'Layout and style'), g2); variationsTab._r = function () { tabs.show('variations'); }; return box; }
    function previewTab() { var tr = Object.assign({}, b, { bgMode: 'transparent' }), url = function (bb) { return 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(S.toSVG(S.logoDoc(bb))); }, g = h('div', 'zl-mock');
      var m = function (bg, label, inner, style) { var d = h('div', 'zl-m'); d.style.background = bg; if (style) d.style.cssText += style; d.appendChild(inner); d.appendChild(h('small', '', label)); d.querySelector('small').style.color = C.readable(bg.charAt(0) === '#' ? bg : '#888', '#ffffff', '#111111'); g.appendChild(d); };
      var im = function (u, s) { var i = h('img'); i.src = u; i.alt = ''; if (s) i.style.cssText = s; return i; };
      m('#0b0b0b', 'On dark', im(url(Object.assign({}, tr, { pal: [b.pal[0], b.pal[1], b.pal[2], b.pal[3]] })))); m('#f4f1ea', 'On light', im(url(Object.assign({}, tr, { pal: ['#f4f1ea', C.lum(b.pal[1]) > 0.5 ? b.pal[3] : b.pal[1], C.lum(b.pal[1]) > 0.5 ? b.pal[3] : b.pal[1], b.pal[3]] }))));
      var card = h('div'); card.style.cssText = 'width:84%;aspect-ratio:1.75;background:#fff;border-radius:6px;box-shadow:0 8px 24px rgba(0,0,0,.4);display:flex;align-items:center;padding:0 12px;gap:10px;color:#111;font:11px system-ui'; var ci = im(url(Object.assign({}, tr, { pal: ['#ffffff', b.pal[1], b.pal[1], b.pal[3]], tpl: 'square' })), 'width:44px;height:44px;max-width:none;max-height:none'); var tx = h('div'); tx.innerHTML = '<b style="font-size:13px">' + esc(b.name) + '</b><br>' + esc(b.tagline); card.append(ci, tx); m('#2b2b2b', 'Business card', card);
      var ic = h('div'); ic.style.cssText = 'width:96px;height:96px;border-radius:22px;overflow:hidden;box-shadow:0 8px 20px rgba(0,0,0,.5)'; ic.appendChild(im(url(Object.assign({}, b, { tpl: 'square', bgMode: 'solid', tagline: '' })), 'width:100%;height:100%;max-width:none;max-height:none')); m('#1a1a1a', 'App icon', ic);
      var av = h('div'); av.style.cssText = 'width:96px;height:96px;border-radius:50%;overflow:hidden;border:2px solid ' + b.pal[1]; av.appendChild(im(url(Object.assign({}, b, { tpl: 'monogram', bgMode: 'solid', tagline: '' })), 'width:100%;height:100%;max-width:none;max-height:none')); m('#111', 'Profile photo', av); return g; }
    function exportTab() { var box = h('div'), tr = false, sc = 1; var row = K.exporter(ed, { name: function () { return bar.state.name; }, transparent: function () { return tr; }, scale: function () { return sc; } });
      box.append(U.check('Transparent background (PNG, SVG, PDF)', false, function (v) { tr = v; }), U.field('Picture size', U.select([['0.5', '500 px'], ['1', '1000 px'], ['2', '2000 px'], ['3', '3000 px']], '1', function (v) { sc = +v; })), row, h('div', 'zs-note', 'SVG is a true vector file. PNG keeps transparency. PDF holds a high-resolution picture of the logo.')); return box; }
    tabs = U.tabs([['concepts', 'AI Concepts', conceptsTab], ['templates', 'Templates', templatesTab], ['symbols', 'Symbols', symbolsTab], ['style', 'Style', styleTab], ['edit', 'Edit', editTab], ['variations', 'Variations', variationsTab], ['preview', 'Brand Preview', previewTab], ['export', 'Export', exportTab]], 'zl-tabs', 'templates');
    var body = h('div', 'zl-body'); body.append(stage, tabs); var main = h('div', 'zl-main'); main.append(rail, body); root.append(bar, title, main);
    setTimeout(function () { ed.fit(); ed.draw(); }, 60);
    return root;
  }
  S.register({ id: 'logo', name: 'Logo Studio', desc: 'Design logos: templates, symbols, SVG and PNG', icon: 'kstar', run: logoTool, manual: 1 });
})(typeof window !== 'undefined' ? window : globalThis);
