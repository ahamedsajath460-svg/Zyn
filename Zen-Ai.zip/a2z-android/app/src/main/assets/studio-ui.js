/* Zen Ai Creative Design Studio: shared building blocks (symbol library, property inspector, layers, template previews, export menu).
 * Each tool picks the pieces it needs and wraps them in its own workspace and theme. */
(function (W) {
  'use strict';
  var S = W.Studio; if (!S || !S.io || S.uiLib) return; S.uiLib = 1;
  var U = S.ui, h = U.h, X = S.exp, clamp = S.clamp, C = S.color;

  /* ---------------- symbols: 24 x 24 grid, drawn with stroke (line) or fill (solid) ---------------- */
  var circ = function (cx, cy, r) { return 'M' + (cx - r) + ' ' + cy + 'a' + r + ' ' + r + ' 0 1 0 ' + 2 * r + ' 0a' + r + ' ' + r + ' 0 1 0 ' + (-2 * r) + ' 0z'; };
  var SY = S.symbols = {
    star: 'M12 2.5l2.9 6.1 6.6.8-4.9 4.6 1.3 6.6L12 17.3 6.1 20.6l1.3-6.6L2.5 9.4l6.6-.8z', heart: 'M12 20.5S3 15 3 8.8A4.8 4.8 0 0 1 12 6.4a4.8 4.8 0 0 1 9 2.4C21 15 12 20.5 12 20.5z', bolt: 'M13 2L4 14h7l-1 8 9-12h-7z',
    leaf: 'M5 19C5 10 10 5 20 4c0 10-5 15-14 15zM5 19l8-8', flame: 'M12 2c1 4 6 6 6 12a6 6 0 0 1-12 0c0-3 2-4 3-6 1 1 1 2 2 2 0-3 0-5 1-8z', drop: 'M12 2.5S5 10 5 14.5a7 7 0 0 0 14 0C19 10 12 2.5 12 2.5z',
    moon: 'M20 14.5A8.5 8.5 0 1 1 9.5 4 6.8 6.8 0 0 0 20 14.5z', sun: circ(12, 12, 4.5) + 'M12 1.5v3M12 19.5v3M1.5 12h3M19.5 12h3M4.6 4.6l2.1 2.1M17.3 17.3l2.1 2.1M4.6 19.4l2.1-2.1M17.3 6.7l2.1-2.1', cloud: 'M7 18a4 4 0 0 1-.5-8A6 6 0 0 1 18 9a4.5 4.5 0 0 1 0 9z',
    home: 'M3 11l9-8 9 8v9a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z', user: circ(12, 7.5, 4.2) + 'M3.5 21a8.5 8.5 0 0 1 17 0z', mail: 'M3 5h18v14H3zM3 6.5l9 6.5 9-6.5', camera: 'M3 8h4l2-3h6l2 3h4v12H3z' + circ(12, 13.5, 3.8),
    bell: 'M6 17v-6a6 6 0 0 1 12 0v6l2 2H4zM10 21.5a2 2 0 0 0 4 0', lock: 'M5 11h14v10H5zM8 11V7a4 4 0 0 1 8 0v4', key: circ(8, 15, 4.5) + 'M11.2 11.8L20 3M16 7l3 3M18 5l2 2',
    gear: circ(12, 12, 3.2) + 'M10.5 2h3l.5 2.6 2 .9 2.2-1.5 2.1 2.1-1.5 2.2.9 2 2.6.5v3l-2.6.5-.9 2 1.5 2.2-2.1 2.1-2.2-1.5-2 .9-.5 2.6h-3l-.5-2.6-2-.9-2.2 1.5-2.1-2.1 1.5-2.2-.9-2L2 13.5v-3l2.6-.5.9-2L4 5.8l2.1-2.1L8.3 5.2l2-.9z', search: circ(10.5, 10.5, 7) + 'M16 16l5.5 5.5',
    check: 'M4 12.5l5 5L20 6.5', plus: 'M12 4v16M4 12h16', play: 'M7 4l13 8-13 8z', music: 'M9 18V5l11-2v13' + circ(6.5, 18, 2.5) + circ(17.5, 16, 2.5), globe: circ(12, 12, 10) + 'M2 12h20M12 2c3 3 4.5 6.5 4.5 10S15 19 12 22C9 19 7.5 15.5 7.5 12S9 5 12 2z',
    cart: 'M2 3h3l2.5 12h11l2-8H6' + circ(9, 19.5, 1.5) + circ(17, 19.5, 1.5), gift: 'M3 8.5h18v4H3zM5 12.5h14V21H5zM12 8.5V21M12 8.5C9 8.5 7 7 8 5s4 .5 4 3.5zM12 8.5c3 0 5-1.5 4-3.5s-4 .5-4 3.5z', book: 'M4 4h6a2 2 0 0 1 2 2v14a2 2 0 0 0-2-2H4zM20 4h-6a2 2 0 0 0-2 2v14a2 2 0 0 1 2-2h6z',
    code: 'M8 7l-5 5 5 5M16 7l5 5-5 5M14 4l-4 16', chat: 'M4 4h16v12H9l-5 4z', pin: 'M12 21.5s7-6.5 7-12a7 7 0 1 0-14 0c0 5.5 7 12 7 12z' + circ(12, 9.5, 2.5), clock: circ(12, 12, 9) + 'M12 7v5l3.5 2', cup: 'M5 8h12v6a5 5 0 0 1-5 5h-2a5 5 0 0 1-5-5zM17 9h2a2.5 2.5 0 0 1 0 5h-2M7 3v2M11 3v2M15 3v2',
    rocket: 'M12 2c4 2 6 6 6 11l-3 3H9l-3-3c0-5 2-9 6-11z' + circ(12, 10, 2) + 'M9 16l-3 5 4-1.5M15 16l3 5-4-1.5', shield: 'M12 2l8 3v6c0 5-3.5 9-8 11-4.5-2-8-6-8-11V5z', crown: 'M3 8l4.5 4L12 5l4.5 7L21 8l-2 11H5z', diamond: 'M6 3h12l4 6-10 12L2 9zM2 9h20M9 3L7 9l5 12M15 3l2 6-5 12',
    paw: 'M12 12c3 0 5 2.5 5 5s-2 3-5 3-5-.5-5-3 2-5 5-5z' + circ(5.5, 10, 1.8) + circ(18.5, 10, 1.8) + circ(9, 5.5, 1.8) + circ(15, 5.5, 1.8), tree: 'M12 2l6 8h-3l5 7H4l5-7H6zM12 17v5', mountain: 'M2 20l7-12 4 6 3-4 6 10z', wave: 'M2 10c2.5-4 5-4 7.5 0s5 4 7.5 0 3-3 5-2M2 17c2.5-4 5-4 7.5 0s5 4 7.5 0 3-3 5-2',
    compass: circ(12, 12, 10) + 'M15.5 8.5l-2 5-5 2 2-5z', flag: 'M5 21V3M5 4h13l-3 4 3 4H5', trophy: 'M7 4h10v6a5 5 0 0 1-10 0zM7 6H3v2a4 4 0 0 0 4 4M17 6h4v2a4 4 0 0 1-4 4M12 15v4M8 21h8', bulb: 'M9 18h6M10 21h4M12 3a6 6 0 0 0-3.5 10.9c.7.6 1 1.3 1 2.1h5c0-.8.3-1.5 1-2.1A6 6 0 0 0 12 3z',
    eye: 'M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z' + circ(12, 12, 3), pen: 'M4 20l1-5L16 4l4 4L9 19zM14 6l4 4', hexagon: 'M12 2l9 5v10l-9 5-9-5V7z', circle: circ(12, 12, 9.5), square: 'M3.5 3.5h17v17h-17z', triangle: 'M12 3l10 18H2z', arrow: 'M4 12h16M14 6l6 6-6 6',
    infinity: 'M12 12c-2-3-4-5-6.5-5a5 5 0 0 0 0 10c2.5 0 4.5-2 6.5-5zm0 0c2 3 4 5 6.5 5a5 5 0 0 0 0-10c-2.5 0-4.5 2-6.5 5z', plane: 'M21.5 2.5L2.5 10l7 3 3 7zM9.5 13l12-10.5', target: circ(12, 12, 10) + circ(12, 12, 6) + circ(12, 12, 2), layers: 'M12 2L2 7l10 5 10-5zM2 12l10 5 10-5M2 17l10 5 10-5',
    anchor: circ(12, 5, 2.5) + 'M12 7.5V21M5 12H3a9 9 0 0 0 18 0h-2M8 11h8', phone: 'M7 2h10a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1V3a1 1 0 0 1 1-1zM11 19h2', wifi: 'M2 9a15 15 0 0 1 20 0M5.5 12.5a10 10 0 0 1 13 0M9 16a5 5 0 0 1 6 0M12 19.5v.1', cube: 'M12 2l9 5v10l-9 5-9-5V7zM3 7l9 5 9-5M12 12v10', sparkle: 'M12 2c.8 5 2.9 7.2 8 8-5.1.8-7.2 3-8 8-.8-5-2.9-7.2-8-8 5.1-.8 7.2-3 8-8z', chart: 'M3 21h18M6 17v-5M11 17V6M16 17v-8M21 17v-3',
    scissors: circ(6, 6, 2.5) + circ(6, 18, 2.5) + 'M8 7.5L20 18M8 16.5L20 6', brush: 'M20 3L9 14l2 2L22 5zM8.5 14.5C6 14.5 5 16 5 18c0 1.5-1 2.5-2 3 3 .5 7 0 7.5-3.5z', food: 'M6 2v8a3 3 0 0 0 3 3v9M9 2v6M12 2v8a3 3 0 0 1-3 3M18 2c-2 2-3 5-3 8h3v12'
  };
  S.symbolList = Object.keys(SY);
  S.symbolEl = function (name, p) { return S.el('path', Object.assign({ d: SY[name] || SY.star, vb: [24, 24], w: 200, h: 200, fill: 'none', stroke: '#111', sw: 1.6, name: name }, p || {})); };

  /* ---------------- template / variation preview image ---------------- */
  U.preview = function (doc, cls) { var i = h('img', cls || 'zs-tp'); i.alt = ''; i.loading = 'lazy'; i.draggable = false; i.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(S.toSVG(doc)); return i; };

  /* ---------------- property inspector (groups chosen by each tool) ---------------- */
  /* groups: text, fill, stroke, shape, image, arrange, effects, doc */
  U.inspector = function (ed, o) {
    o = o || {}; var box = h('div', 'zs-insp'), groups = o.groups || ['text', 'fill', 'stroke', 'shape', 'image', 'effects', 'arrange'];
    var has = function (g) { return groups.indexOf(g) >= 0; };
    function sec(title, kids) { var s = h('div', 'zs-sec'); if (title) s.appendChild(h('div', 'zs-st', title)); kids.forEach(function (k) { if (k) s.appendChild(k); }); return s; }
    function build() {
      var e = ed.selected(); box.innerHTML = '';
      if (!e) { box.appendChild(h('div', 'zs-hint', o.empty || 'Tap an element on the canvas to edit it.')); if (has('doc')) box.appendChild(docSec()); return; }
      var set = function (patch, key) { ed.set(patch, e.id, key); }, row = function (a, b) { var r = h('div', 'zs-r2'); r.append(a, b); return r; };
      var title = h('div', 'zs-et'); title.append(h('b', '', e.name || e.type), h('small', '', ' · ' + e.type + (e.lock ? ' · locked' : ''))); box.appendChild(title);
      if (e.type === 'text' && has('text')) {
        box.appendChild(sec('Text', [U.field('Content', U.area(e.text, function (v) { set({ text: v }, 'txt'); }, '', 3)),
          row(U.field('Font', U.select(S.fonts.map(function (f) { return f[0]; }), e.font, function (v) { set({ font: v }); })), U.field('Weight', U.select([['300', 'Light'], ['400', 'Regular'], ['600', 'Semi'], ['700', 'Bold'], ['900', 'Black']], String(e.weight), function (v) { set({ weight: +v }); }))),
          U.field('Size ' + e.size, U.range(e.size, 8, Math.max(300, ed.doc.w / 3 | 0), 1, function (v) { set({ size: v }, 'sz'); })),
          row(U.field('Align', U.select(['left', 'center', 'right'], e.align, function (v) { set({ align: v }); })), U.field('Letter space', U.range(e.ls || 0, -5, 40, 0.5, function (v) { set({ ls: v }, 'ls'); }))),
          U.field('Line height ' + (e.lh || 1.15), U.range(e.lh || 1.15, 0.8, 2.2, 0.05, function (v) { set({ lh: v }, 'lh'); })), U.check('UPPERCASE', e.upper, function (v) { set({ upper: v }); }), U.check('Italic', e.italic, function (v) { set({ italic: v }); })]));
      }
      if (has('fill') && e.type !== 'image') {
        var g = e.fill && typeof e.fill === 'object' && e.fill.g, c1 = g ? (Array.isArray(e.fill.g[0]) ? e.fill.g[0][1] : e.fill.g[0]) : (typeof e.fill === 'string' && e.fill !== 'none' ? e.fill : '#000000'), c2 = g ? (function () { var l = e.fill.g[e.fill.g.length - 1]; return Array.isArray(l) ? l[1] : l; })() : C.shift(c1, 30, 0, 12);
        var kids = [row(U.field(e.type === 'text' ? 'Colour' : 'Fill', U.color(c1, function (v) { set({ fill: g ? { g: [v, c2], a: e.fill.a || 0, t: e.fill.t } : v }, 'f1'); })), U.field('Gradient', U.check('On', g, function (v) { set({ fill: v ? { g: [c1, c2], a: 90 } : c1 }); })))];
        if (g) kids.push(row(U.field('Colour 2', U.color(c2, function (v) { set({ fill: { g: [c1, v], a: e.fill.a || 0, t: e.fill.t } }, 'f2'); })), U.field('Angle ' + (e.fill.a || 0), U.range(e.fill.a || 0, 0, 360, 5, function (v) { set({ fill: { g: [c1, c2], a: v, t: e.fill.t } }, 'fa'); }))));
        if (e.type !== 'text' && !g) kids.push(U.check('No fill', e.fill === 'none' || !e.fill, function (v) { set({ fill: v ? 'none' : c1 }); }));
        box.appendChild(sec(e.type === 'text' ? 'Colour' : 'Fill', kids));
      }
      if (e.type === 'image' && has('image')) box.appendChild(sec('Picture', [row(U.field('Fit', U.select([['cover', 'Fill frame'], ['contain', 'Fit inside'], ['fill', 'Stretch']], e.fit, function (v) { set({ fit: v }); })), U.field('Corners ' + (e.r || 0), U.range(e.r || 0, 0, Math.min(e.w, e.h) / 2, 1, function (v) { set({ r: v }, 'r'); }))), U.field('Frame colour', U.color(typeof e.fill === 'string' && e.fill ? e.fill : '#ffffff', function (v) { set({ fill: v }); }))]));
      if (has('stroke') && e.type !== 'text') box.appendChild(sec('Outline', [row(U.field('Colour', U.color(e.stroke || '#000000', function (v) { set({ stroke: v, sw: e.sw || 4 }, 'sc'); })), U.field('Width ' + (e.sw || 0), U.range(e.sw || 0, 0, 40, 0.5, function (v) { set({ sw: v, stroke: e.stroke || '#000000' }, 'sw'); })))]));
      if (e.type === 'text' && has('stroke')) box.appendChild(sec('Text outline', [row(U.field('Colour', U.color((e.outline && e.outline.c) || '#000000', function (v) { set({ outline: { c: v, w: (e.outline && e.outline.w) || 4 } }, 'oc'); })), U.field('Width ' + ((e.outline && e.outline.w) || 0), U.range((e.outline && e.outline.w) || 0, 0, 30, 0.5, function (v) { set({ outline: { c: (e.outline && e.outline.c) || '#000000', w: v } }, 'ow'); })))]));
      if ((e.type === 'rect') && has('shape')) box.appendChild(sec('Shape', [U.field('Corner radius ' + (e.r || 0), U.range(e.r || 0, 0, Math.min(e.w, e.h) / 2, 1, function (v) { set({ r: v }, 'r'); }))]));
      if (has('effects')) { var sh = e.shadow || { b: 0, x: 0, y: 0, c: '#000000' };
        box.appendChild(sec('Effects', [U.field('Opacity ' + Math.round((e.op == null ? 1 : e.op) * 100) + '%', U.range(Math.round((e.op == null ? 1 : e.op) * 100), 0, 100, 1, function (v) { set({ op: v / 100 }, 'op'); })), U.field('Rotation ' + Math.round(e.rot || 0) + '°', U.range(Math.round(e.rot || 0), -180, 180, 1, function (v) { set({ rot: v }, 'rot'); })),
          U.field('Shadow blur ' + (sh.b || 0), U.range(sh.b || 0, 0, 60, 1, function (v) { set({ shadow: { b: v, x: sh.x || 0, y: v ? Math.max(sh.y || 0, 4) : 0, c: sh.c || '#000000', o: 0.55 } }, 'sh'); })), e.type !== 'text' ? U.field('Blur ' + (e.blur || 0), U.range(e.blur || 0, 0, 30, 1, function (v) { set({ blur: v }, 'bl'); })) : null])); }
      if (has('arrange')) {
        var bt = function (t, f, tt) { return U.btn(t, f, 'zs-b zs-sm', tt); }, ar = h('div', 'zs-arr');
        ar.append(bt('Front', function () { ed.order('front'); }, 'Bring to front'), bt('Up', function () { ed.order('up'); }), bt('Down', function () { ed.order('down'); }), bt('Back', function () { ed.order('back'); }), bt('Copy', function () { ed.duplicate(); }, 'Duplicate'), bt(e.lock ? 'Unlock' : 'Lock', function () { ed.set({ lock: !e.lock }); build(); }), bt('Delete', function () { ed.remove(); }));
        var al = h('div', 'zs-arr'); [['left', '⇤'], ['hcenter', '↔'], ['right', '⇥'], ['top', '⤒'], ['vcenter', '↕'], ['bottom', '⤓']].forEach(function (a) { al.appendChild(bt(a[1], function () { ed.align(a[0]); }, 'Align ' + a[0])); });
        box.appendChild(sec('Arrange', [ar, al]));
      }
      if (has('doc')) box.appendChild(docSec());
    }
    function docSec() { return sec('Canvas', [U.field('Background', U.color(typeof ed.doc.bg === 'string' && ed.doc.bg !== 'transparent' ? ed.doc.bg : '#ffffff', function (v) { ed.setDocProps({ bg: v }); })), U.check('Transparent background', ed.doc.bg === 'transparent', function (v) { ed.setDocProps({ bg: v ? 'transparent' : '#ffffff' }); build(); })]); }
    ed.on('select', function () { build(); }); ed.on('history', function () { var e = ed.selected(); if (!e || !box.contains(document.activeElement)) build(); }); build(); box.rebuild = build; return box;
  };

  /* ---------------- layers ---------------- */
  U.layers = function (ed, o) {
    o = o || {}; var box = h('div', 'zs-layers');
    function draw() { box.innerHTML = ''; var els = ed.doc.els.slice().reverse(); if (!els.length) box.appendChild(h('div', 'zs-hint', 'No layers yet.'));
      els.forEach(function (e) { var r = h('div', 'zs-ly' + (ed.sel === e.id ? ' on' : '')), nm = h('button', 'zs-lyn', (e.type === 'text' ? '“' + String(e.text).slice(0, 22) + '”' : (e.name || e.type)));
        nm.onclick = function () { ed.select(e.id); }; var mk = function (t, f, tt) { var b = U.btn(t, f, 'zs-ib', tt); return b; };
        r.append(mk(e.vis === false ? '◌' : '●', function () { ed.set({ vis: e.vis === false }, e.id); }, 'Show or hide'), mk(e.lock ? '🔒' : '🔓', function () { ed.set({ lock: !e.lock }, e.id); }, 'Lock'), nm, mk('▲', function () { ed.order('up', e.id); }, 'Move up'), mk('▼', function () { ed.order('down', e.id); }, 'Move down'), mk('✕', function () { ed.remove(e.id); }, 'Delete'));
        box.appendChild(r); }); }
    ed.on('change', draw); ed.on('select', draw); draw(); return box;
  };

  /* zoom + undo bar */
  U.viewBar = function (ed) {
    var b = h('div', 'zs-vbar'), undo = U.btn('↶', function () { ed.undo(); }, 'zs-b zs-ib', 'Undo'), redo = U.btn('↷', function () { ed.redo(); }, 'zs-b zs-ib', 'Redo'), z = h('span', 'zs-zl', '100%');
    var sync = function () { undo.disabled = !ed.canUndo(); redo.disabled = !ed.canRedo(); undo.style.opacity = undo.disabled ? .4 : 1; redo.style.opacity = redo.disabled ? .4 : 1; z.textContent = Math.round(ed.zoom * 100) + '%'; };
    b.append(undo, redo, U.btn('−', function () { ed.zoomBy(0.8); }, 'zs-b zs-ib', 'Zoom out'), z, U.btn('+', function () { ed.zoomBy(1.25); }, 'zs-b zs-ib', 'Zoom in'), U.btn('Fit', function () { ed.fit(); ed.draw(); sync(); }, 'zs-b zs-sm', 'Fit to screen'));
    ed.on('history', sync); ed.on('zoom', sync); ed.on('change', sync); sync(); b.sync = sync; return b;
  };

  /* add-picture button: reads a photo, downscales it and adds it to the canvas */
  U.addPhoto = function (ed, label, patch) { return U.btn(label || 'Add photo', function () { U.pickFile('image/*', function (f) { U.readImage(f, 1600).then(function (im) { ed.addImage(im.href, im.w, im.h, patch); }).catch(function (e) { S.tell(e.message || 'Could not open the picture'); }); }); }, 'zs-b'); };

  /* export menu: a row of buttons, each producing a real file */
  U.exportRow = function (o) {
    var row = h('div', 'zs-exp'), busy = false;
    (o.formats || ['png', 'jpg', 'pdf', 'svg']).forEach(function (f) {
      var b = U.btn(f.toUpperCase(), function () { if (busy) return; busy = true; b.textContent = '…'; var name = X.safe(o.name ? o.name() : 'design');
        Promise.resolve(o.make(f)).then(function (blob) { if (!blob) throw new Error('Nothing to export'); X.save(blob, name + '.' + (f === 'jpg' ? 'jpg' : f)); S.tell(f.toUpperCase() + ' saved'); }).catch(function (e) { S.tell(e && e.message || 'Export failed'); }).then(function () { busy = false; b.textContent = f.toUpperCase(); }); }, 'zs-b zs-ex', 'Export ' + f.toUpperCase());
      row.appendChild(b); });
    if (o.share) row.appendChild(U.btn('Share', function () { Promise.resolve(o.make(o.shareFormat || 'png')).then(function (bl) { return X.share(bl, X.safe(o.name ? o.name() : 'design') + '.' + (o.shareFormat || 'png')); }).catch(function (e) { S.tell(e && e.message || 'Could not share'); }); }, 'zs-b'));
    return row;
  };

  /* AI box: describe it -> text AI returns a JSON plan -> tool builds the design locally. The tool works without it. */
  U.aiBox = function (o) {
    var box = h('div', 'zs-ai'), ta = U.area('', function () { }, o.placeholder || 'Describe what you want…', 3), go = U.btn(o.label || 'Plan with AI', run, 'zs-b zs-p'), msg = h('div', 'zs-note', S.ai.available() ? 'Uses your text AI. Drawing is done on this device.' : 'No AI provider set up. Pick a template instead, or add a provider in Settings.'), ctl = null;
    ta.addEventListener('input', function () { }); function run() { var q = ta.value.trim(); if (!q) { S.tell('Describe what you want first'); return; } if (ctl) ctl.abort(); ctl = new AbortController(); go.disabled = true; go.textContent = 'Thinking…'; msg.className = 'zs-note'; msg.textContent = 'Asking the AI for a design plan…';
      S.ai.plan(o.system, (o.wrap ? o.wrap(q) : q), ctl.signal).then(function (plan) { return o.apply(plan, q); }).then(function () { msg.textContent = 'Done. Edit anything on the canvas.'; }).catch(function (e) { msg.className = 'zs-err'; msg.textContent = (e && e.message) || 'The AI step failed.'; }).then(function () { go.disabled = false; go.textContent = o.label || 'Plan with AI'; }); }
    box.append(ta, go, msg); box.ta = ta; return box;
  };

  /* tab strip: [[id,label,builder]] -> element; only the visible tab's content stays in the DOM */
  U.tabs = function (items, cls, start) {
    var wrap = h('div', 'zs-tabs ' + (cls || '')), bar = h('div', 'zs-tbar'), body = h('div', 'zs-tbody'), cur = null, btns = {};
    function show(id) { cur = id; Object.keys(btns).forEach(function (k) { btns[k].classList.toggle('on', k === id); }); body.innerHTML = ''; var it = items.filter(function (x) { return x[0] === id; })[0]; if (it) { var c = it[2](); if (c) body.appendChild(c); } wrap.dispatchEvent(new CustomEvent('tab', { detail: id })); }
    items.forEach(function (it) { var b = U.btn(it[1], function () { show(it[0]); }, 'zs-tab'); btns[it[0]] = b; bar.appendChild(b); }); wrap.append(bar, body); wrap.show = show; wrap.cur = function () { return cur; }; show(start || items[0][0]); return wrap;
  };

  /* shared structural CSS (colours come from each tool's theme variables) */
  U.css('zs-ui', '.zs-sec{border:1px solid var(--zs-line);border-radius:var(--zs-rad);padding:10px;margin:0 0 10px;background:var(--zs-panel)}.zs-st{font-size:11px;letter-spacing:.06em;text-transform:uppercase;color:var(--zs-mut);margin-bottom:8px}.zs-et{margin:2px 0 8px}.zs-et small{color:var(--zs-mut)}' +
    '.zs-r2{display:grid;grid-template-columns:1fr 1fr;gap:8px}.zs-hint{padding:12px;color:var(--zs-mut);text-align:center;font-size:13px}.zs-arr{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:6px}.zs-sm{padding:5px 9px!important;min-height:32px!important;font-size:12px!important}.zs-ib{min-width:34px;padding:4px 8px!important;min-height:34px!important}' +
    '.zs-layers{display:flex;flex-direction:column;gap:4px}.zs-ly{display:flex;align-items:center;gap:4px;border:1px solid var(--zs-line);border-radius:10px;padding:2px 4px;background:var(--zs-panel)}.zs-ly.on{border-color:var(--zs-acc);box-shadow:0 0 0 1px var(--zs-acc) inset}.zs-lyn{flex:1;text-align:left;background:none;border:0;color:var(--zs-ink);font:inherit;padding:8px 4px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;min-width:0}.zs-ly .zs-b{border:0;background:none}' +
    '.zs-vbar{display:flex;gap:6px;align-items:center;flex-wrap:wrap}.zs-zl{min-width:44px;text-align:center;font-size:12px;color:var(--zs-mut)}.zs-exp{display:flex;gap:6px;flex-wrap:wrap}.zs-ai{display:flex;flex-direction:column;gap:8px}.zs-tp{width:100%;height:100%;object-fit:contain;display:block;border-radius:6px;background:#fff}' +
    '.zs-tabs{display:flex;flex-direction:column;min-height:0}.zs-tbar{display:flex;gap:4px;overflow-x:auto;padding:6px;scrollbar-width:none}.zs-tbar::-webkit-scrollbar{display:none}.zs-tab{flex:none;white-space:nowrap}.zs-tbody{padding:8px;overflow:auto}' +
    '.zs-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(104px,1fr));gap:8px}.zs-card{border:1px solid var(--zs-line);border-radius:var(--zs-rad);background:var(--zs-panel);padding:6px;cursor:pointer;display:flex;flex-direction:column;gap:4px;text-align:center;font-size:12px;color:var(--zs-ink)}.zs-card.on{border-color:var(--zs-acc);box-shadow:0 0 0 1px var(--zs-acc) inset}.zs-card .zs-ph{aspect-ratio:1/1;display:flex;align-items:center;justify-content:center;overflow:hidden;border-radius:8px}' +
    '.zs-chip{flex:none;padding:6px 12px;border-radius:999px;border:1px solid var(--zs-line);background:var(--zs-panel);color:var(--zs-ink);font:inherit;font-size:13px;cursor:pointer;white-space:nowrap}.zs-chip.on{background:var(--zs-acc);color:var(--zs-onacc);border-color:var(--zs-acc)}.zs-chips{display:flex;gap:6px;overflow-x:auto;padding:4px 0;scrollbar-width:none}.zs-chips::-webkit-scrollbar{display:none}');
})(typeof window !== 'undefined' ? window : globalThis);
