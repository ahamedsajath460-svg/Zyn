/* ===== Zen AI: real web image search + inline display (v22) =====
   Website photos ONLY. No AI image generation is called anywhere in this file.
   Providers: Pexels / Unsplash (keys already in Settings > AI providers > Data),
   Openverse + Wikimedia Commons (free, no key). Optional HTTPS proxy keeps keys on a server.
   Hooks: answer() (search after the text is shown) and fill() (re-draw when a chat is reopened). */
(()=>{try{
if(window.ZWI)return;
const CFGK='zen_wimg_cfg',CACHEK='zen_wimg_cache',CDK='zen_wimg_cd';
const E=encodeURIComponent,TTL=24*3600e3,NEG=10*60e3,COOL=15*60e3;
const PROV={pexels:'Pexels (key)',unsplash:'Unsplash (key)',openverse:'Openverse (free)',commons:'Wikimedia Commons (free)'};
const DEF={on:true,order:['pexels','unsplash','openverse','commons'],off:[],max:4,list:10,proxy:''};
const ls={get(k,d){try{const v=JSON.parse(localStorage.getItem(k));return v==null?d:v}catch(e){return d}},set(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}}};
const cfg=()=>Object.assign({},DEF,ls.get(CFGK,{}));
const saveCfg=c=>ls.set(CFGK,c);

/* ---------- safety helpers ---------- */
const txt=(s,n)=>{s=String(s==null?'':s);if(/[<&]/.test(s)){try{s=new DOMParser().parseFromString(s,'text/html').documentElement.textContent||''}catch(e){s=s.replace(/<[^>]*>/g,'')}}return s.replace(/[\u0000-\u001f\u007f]+/g,' ').replace(/\s+/g,' ').trim().slice(0,n||200)};
const safeUrl=u=>{try{u=String(u||'').trim();if(u.length>2048)return'';const x=new URL(u);if(x.protocol!=='https:'||x.username||x.password)return'';const h=x.hostname.toLowerCase();if(h==='localhost'||h.endsWith('.local')||/^(\d{1,3}\.){3}\d{1,3}$/.test(h)||h.includes(':'))return'';if(/\.(svg|tiff?|exe|apk|zip|js|html?|php|pdf)$/i.test(x.pathname))return'';return x.href}catch(e){return''}};
const pageUrl=u=>{try{const x=new URL(String(u||''));return x.protocol==='https:'||x.protocol==='http:'?x.href:''}catch(e){return''}};
const hostOf=u=>{try{return new URL(u).hostname.replace(/^www\./,'')}catch(e){return''}};
const num=n=>{n=+n;return isFinite(n)&&n>0&&n<100000?Math.round(n):0};

/* ---------- 1. decide whether images help ---------- */
const W=s=>new RegExp('(?:^|[^\\p{L}\\p{N}_])(?:'+s+')(?![\\p{L}\\p{N}_])','iu');
const GREET=/^\s*(hi|hello|hey|hii+|yo|thanks?|thank you|ok(ay)?|bye|good (morning|night|evening)|vanakkam|nandri|sari|சரி|வணக்கம்|நன்றி)[\s!.?]*$/iu;
const GEN=W('(generate|create|make|draw|design|imagine|render|paint)[^.?!]{0,40}?(image|picture|photo|logo|art|wallpaper|poster|painting)s?|(image|picture|photo|logo|art|wallpaper)s?\\s*(generate|create|banao|vara|pannu|podu)|வரை(ந்து|யவும்|ங்க)?|உருவாக்கு');
const NOIMG=W('translate|translation|grammar|proofread|rewrite|paraphrase|summari[sz]e|regex|json|sql|code|script|function|debug|bug|error|compile|html|css|python|kotlin|java|math|solve|equation|calculate|email|letter|essay|poem|resume|cv|மொழிபெயர்\\p{L}*|கணக்கு');
const SHOW=W('show|display|see|photo|photos|pic|pics|picture|pictures|image|images|padam|padangal|padathai|kaattu|kaatu|kaami|kamichu|காட்டு\\p{L}*|காண்பி\\p{L}*|படம்|படங்கள்|படத்தை|புகைப்பட\\p{L}*|போட்டோ\\p{L}*|පින්තූර\\p{L}*|ඡායාරූප\\p{L}*');
const INFOSTART=new RegExp('^\\s*(?:(?:what|who|which|where)\\s+(?:is|are|was|were|does|do)|tell me about|explain|describe|about|how does|how do|enna|yaar|yaaru|edhu|enga)(?![\\p{L}\\p{N}_])','iu');
const INFOANY=W('pathi|patri|vilakku|vilakkam|பற்றி|பத்தி|என்ன|யார்|விளக்கு\\p{L}*|சொல்லு\\p{L}*');
const CHAT=W('i feel|i am (sad|angry|tired|lonely)|i\'m (sad|angry|tired|lonely)|advice|should i|my (life|girlfriend|boyfriend|wife|husband|job)|how are you|who are you|what is your name');
const LISTY=W('list|top\\s*\\d+|top|best|types?|kinds?|examples?|favou?rites?|names?|varieties|ideas?');
const STOP=new Set('show me a an the of for to in on at and or please pls plz tell about explain describe what is are was who which where how does do did can could you your my i we some any with without photo photos pic pics picture pictures image images padam padangal kaattu kaatu kaami kamichu podu pannu panni sollu solluga vilakku vilakkam pathi patri enna yaar yaaru edhu enga irukku iruku konjam oru oru onnu ellam mattrum matrum vendum venum list top best types type examples example give get find search related real'.split(' '));
function decide(user,ans,opt){opt=opt||{};user=String(user||'');ans=String(ans||'');
 const c=cfg();if(!c.on)return{go:false,why:'off'};
 if(!user.trim())return{go:false,why:'empty'};
 if(GREET.test(user))return{go:false,why:'greeting'};
 if(GEN.test(user))return{go:false,why:'generation request (left to the existing image generator)'};
 const explicit=SHOW.test(user);
 if(CHAT.test(user)&&!explicit)return{go:false,why:'personal chat'};
 if(NOIMG.test(user)&&!explicit)return{go:false,why:'text/code task'};
 if(/^\s*(error|\u26a0|no provider|sorry, i can'?t)/i.test(ans))return{go:false,why:'error answer'};
 if((ans.match(/```/g)||[]).length>=2&&!explicit)return{go:false,why:'code answer'};
 const info=INFOSTART.test(user)||INFOANY.test(user),listy=LISTY.test(user);
 if(!explicit&&!info&&!listy)return{go:false,why:'not an informational request'};
 if(!explicit&&ans.length<350)return{go:false,why:'short answer'};
 if(opt.saveData&&!explicit)return{go:false,why:'data saver'};
 return{go:true,explicit,list:listy||explicit,listOnly:!explicit&&!info,why:explicit?'explicit visual request':'informational'}}

/* ---------- 2. queries ---------- */
const latin=s=>(s.match(/[A-Za-z]/g)||[]).length>=Math.max(2,s.replace(/[\s\d\W]/g,'').length*.6);
const cleanQ=s=>txt(String(s||'').replace(/[\u{1F000}-\u{1FFFF}\u2600-\u27BF\uFE0F]/gu,' ').replace(/^[#>*\-\s\d.)(]+/,'').replace(/[*_`#"“”]/g,' ').replace(/[?!.:;,]+/g,' '),90);
function subjects(user){let s=cleanQ(user).toLowerCase();const parts=s.split(/\s+(?:and|&|mattrum|matrum|மற்றும்|vs|with)\s+|,/).map(p=>p.split(/\s+/).filter(w=>w&&!STOP.has(w)).join(' ').trim()).filter(p=>p.length>1);return parts.slice(0,4)}
const GENERIC=/^(introduction|overview|summary|conclusion|key points?|notes?|tips?|steps?|faq|references?|final thoughts?|question|answer|benefits|advantages|disadvantages|pros|cons)$/i;

/* ---------- 3. providers (all return normalised items) ---------- */
const keyOf=re=>{try{const p=(window.P||P).find(x=>re.test((x.name||'')+' '+(x.endpoint||''))&&x.key&&String(x.key).trim());return p?String(p.key).trim():''}catch(e){return''}};
const cdMap=()=>ls.get(CDK,{});
const inCool=p=>(cdMap()[p]||0)>Date.now();
const cool=(p,ms)=>{const m=cdMap();m[p]=Date.now()+(ms||COOL);ls.set(CDK,m)};
async function jget(u,hd,ms){const c=new AbortController(),t=setTimeout(()=>c.abort(),ms||9000);
 try{const r=await fetch(u,{headers:hd||{},signal:c.signal,credentials:'omit',referrerPolicy:'no-referrer'});
  if(!r.ok){const e=new Error('HTTP '+r.status);e.status=r.status;throw e}
  const rem=r.headers&&r.headers.get&&(r.headers.get('x-ratelimit-remaining'));return{j:await r.json(),rem:rem==null?null:+rem}}
 finally{clearTimeout(t)}}
const SRC={
 pexels:async(q,n)=>{const k=keyOf(/pexels/i);if(!k)throw Object.assign(new Error('no key'),{skip:1});
  const {j,rem}=await jget('https://api.pexels.com/v1/search?query='+E(q)+'&per_page='+n,{Authorization:k});if(rem===0)cool('pexels');
  return(j.photos||[]).map(x=>({img:x.src&&(x.src.large||x.src.medium),full:x.src&&(x.src.large2x||x.src.large),raw:x.src&&x.src.original,page:x.url,title:x.alt||'Photo '+(x.id||''),site:'Pexels',creator:x.photographer,license:'Pexels License',licUrl:'https://www.pexels.com/license/',w:x.width,h:x.height}))},
 unsplash:async(q,n)=>{const k=keyOf(/unsplash/i);if(!k)throw Object.assign(new Error('no key'),{skip:1});
  const {j,rem}=await jget('https://api.unsplash.com/search/photos?query='+E(q)+'&per_page='+n+'&content_filter=high',{Authorization:'Client-ID '+k,'Accept-Version':'v1'});if(rem===0)cool('unsplash');
  return(j.results||[]).map(x=>({img:x.urls&&x.urls.small,full:x.urls&&x.urls.regular,raw:x.urls&&x.urls.raw,page:x.links&&x.links.html?x.links.html+'?utm_source=zen_ai&utm_medium=referral':'',title:x.alt_description||x.description||'Unsplash photo',site:'Unsplash',creator:x.user&&x.user.name,license:'Unsplash License',licUrl:'https://unsplash.com/license',w:x.width,h:x.height}))},
 openverse:async(q,n)=>{const {j}=await jget('https://api.openverse.org/v1/images/?q='+E(q)+'&page_size='+n+'&mature=false&aspect_ratio=wide,tall,square');
  return(j.results||[]).map(x=>{const lc=String(x.license||'').toLowerCase(),lab=lc==='cc0'?'CC0 1.0':lc==='pdm'?'Public Domain Mark':'CC '+lc.toUpperCase()+(x.license_version?' '+x.license_version:'');
   return{img:x.thumbnail,full:x.thumbnail,raw:x.url,page:x.foreign_landing_url,title:x.title,site:x.source||hostOf(x.foreign_landing_url)||'Openverse',creator:x.creator,license:lab,licUrl:x.license_url,w:x.width,h:x.height,kw:(x.tags||[]).map(t=>t&&t.name).join(' ')}})},
 commons:async(q,n)=>{const {j}=await jget('https://commons.wikimedia.org/w/api.php?action=query&generator=search&gsrnamespace=6&gsrlimit='+n+'&gsrsearch='+E(q+' filetype:bitmap')+'&prop=imageinfo&iiprop=url|size|mime|extmetadata&iiurlwidth=1000&format=json&origin=*');
  return Object.values((j.query||{}).pages||{}).map(p=>{const i=(p.imageinfo||[])[0]||{},m=i.extmetadata||{},v=k=>m[k]&&m[k].value;
   if(!/^image\/(jpeg|png|webp)$/.test(i.mime||''))return null;
   return{img:i.thumburl,full:i.thumburl,raw:i.url,page:i.descriptionurl,title:(p.title||'').replace(/^File:/,'').replace(/\.\w+$/,''),site:'Wikimedia Commons',creator:v('Artist'),license:v('LicenseShortName')||'',licUrl:v('LicenseUrl'),w:i.thumbwidth||i.width,h:i.thumbheight||i.height}}).filter(Boolean)}};
async function viaProxy(px,prov,q,n){const u=safeUrl(px);if(!u)throw new Error('bad proxy');const {j}=await jget(u+(u.includes('?')?'&':'?')+'provider='+E(prov)+'&q='+E(q)+'&n='+n);return Array.isArray(j.items)?j.items:[]}

/* ---------- 4. validate / filter / dedupe ---------- */
function norm(x,prov){if(!x)return null;const img=safeUrl(x.img);if(!img)return null;
 const it={prov,img,full:safeUrl(x.full)||img,raw:safeUrl(x.raw)||'',page:pageUrl(x.page),title:txt(x.title,140),site:txt(x.site,60)||hostOf(x.page),creator:txt(x.creator,80),license:txt(x.license,60),licUrl:pageUrl(x.licUrl),w:num(x.w),h:num(x.h),kw:txt(x.kw,300).toLowerCase()};
 if(it.w&&it.h){if(it.w<400||it.h<250)return null;const r=it.w/it.h;if(r>3.2||r<.3)return null}
 return it}
const dkey=it=>{let b='';try{const u=new URL(it.raw||it.img);b=u.hostname+u.pathname.split('/').pop().replace(/[-_]?\d{2,4}x\d{2,4}/,'').toLowerCase()}catch(e){b=it.img}return b};
const tkey=it=>(it.title||'').toLowerCase().replace(/[^a-z0-9]+/g,'')+'|'+it.w+'x'+it.h;
const toks=q=>String(q).toLowerCase().split(/[^a-z0-9]+/).filter(w=>w.length>2&&!STOP.has(w));
function relevant(it,q){const t=toks(q);if(!t.length)return true;const hay=(it.title+' '+it.page+' '+it.raw).toLowerCase();return it.prov!=='openverse'?true:t.some(w=>(hay+' '+(it.kw||'')).includes(w))}
let busy=0;const waitQ=[];const slot=()=>new Promise(r=>{if(busy<4){busy++;r()}else waitQ.push(r)}),free=()=>{busy--;const n=waitQ.shift();if(n){busy++;n()}};
async function probe(u,ms){await slot();try{return await new Promise(res=>{const i=new Image(),t=setTimeout(()=>{i.src='';res(null)},ms||8000);i.referrerPolicy='no-referrer';i.onload=()=>{clearTimeout(t);res({w:i.naturalWidth,h:i.naturalHeight})};i.onerror=()=>{clearTimeout(t);res(null)};i.src=u})}finally{free()}}

/* ---------- 5. cache + search ---------- */
function cget(k){const m=ls.get(CACHEK,{}),e=m[k];if(!e)return null;if(Date.now()-e.t>(e.items.length?TTL:NEG)){delete m[k];ls.set(CACHEK,m);return null}return e.items}
function cput(k,items){const m=ls.get(CACHEK,{});m[k]={t:Date.now(),items};const ks=Object.keys(m);if(ks.length>60){ks.sort((a,b)=>m[a].t-m[b].t).slice(0,ks.length-50).forEach(x=>delete m[x])}ls.set(CACHEK,m)}
async function search(q,n,used){q=cleanQ(q);if(!q||!latin(q))return[];used=used||{k:new Set(),t:new Set()};
 const ck=q.toLowerCase()+'|'+n,hit=cget(ck);
 const take=arr=>{const out=[];for(const it of arr){const a=dkey(it),b=tkey(it);if(used.k.has(a)||(it.title&&used.t.has(b)))continue;used.k.add(a);if(it.title)used.t.add(b);out.push(it);if(out.length>=n)break}return out};
 if(hit)return take(hit);
 if(typeof navigator!=='undefined'&&navigator.onLine===false)return[];
 const c=cfg(),order=c.order.filter(p=>PROV[p]&&!c.off.includes(p));let got=[];
 for(const p of order){if(got.length>=n)break;if(inCool(p))continue;
  try{const raw=c.proxy?await viaProxy(c.proxy,p,q,n*3):await SRC[p](q,n*3);
   const seen=new Set(got.map(dkey));
   for(const x of raw){const it=norm(x,p);if(!it||seen.has(dkey(it))||!relevant(it,q))continue;
    const pr=await probe(it.img);if(!pr||pr.w<300||pr.h<180)continue;if(!it.w){it.w=pr.w;it.h=pr.h}seen.add(dkey(it));got.push(it);if(got.length>=n*2)break}}
  catch(e){if(e&&(e.status===429||e.status===402||(e.status===403&&(p==='pexels'||p==='unsplash'))))cool(p);if(e&&e.status===401)cool(p,60*60e3)}}
 cput(ck,got);return take(got)}

/* ---------- 6. plan: where do the images go ---------- */
const BLK='h1,h2,h3,h4,h5,h6,p,ul,ol,blockquote,table,pre';
const blocksOf=root=>[...root.querySelectorAll(':scope > '+BLK.split(',').join(',:scope > '))].filter(b=>!b.closest('.zwi'));
const liTitle=li=>{const s=li.querySelector('strong,b');let t=s?s.textContent:li.textContent.split(/[:\u2013\u2014\-]/)[0];return cleanQ(t)};
function plan(user,ans,d){const c=cfg(),tmp=document.createElement('div');tmp.appendChild(md(ans));const bl=blocksOf(tmp),subs=subjects(user),main=subs[0]||'';const out=[];
 let lst=-1;if(d.list){bl.forEach((b,i)=>{if(lst<0&&/^(UL|OL)$/.test(b.tagName)&&b.querySelectorAll(':scope > li').length>=3)lst=i})}
 if(lst>=0){const lis=[...bl[lst].querySelectorAll(':scope > li')].slice(0,c.list);lis.forEach((li,j)=>{const q=liTitle(li);if(q&&latin(q)&&q.length<60)out.push({q,n:1,at:{t:'li',i:lst,j}})});if(out.length>=3)return out;out.length=0}
 if(d.listOnly)return[];
 const heads=[];bl.forEach((b,i)=>{if(/^H[1-6]$/.test(b.tagName)){const h=cleanQ(b.textContent);if(h&&latin(h)&&!GENERIC.test(h))heads.push({h,i})}});
 const firstP=bl.findIndex(b=>b.tagName==='P');
 if(d.explicit&&subs.length>1&&heads.length<2){subs.forEach(s=>out.push({q:s,n:1,at:{t:'grp',i:Math.max(0,firstP)},g:1}));return out}
 if(heads.length>=2){const tok=toks(main);if(!heads.some(x=>x.i<firstP)&&firstP>=0&&main)out.push({q:main,n:1,at:{t:'b',i:firstP}});
  heads.slice(0,c.max).forEach(x=>{const q=main&&!toks(x.h).some(w=>tok.includes(w))?main+' '+x.h:x.h;const nx=bl.findIndex((b,i)=>i>x.i&&b.tagName==='P');out.push({q,n:1,at:{t:'b',i:nx>=0&&(heads.find(y=>y.i>x.i)?nx<heads.find(y=>y.i>x.i).i:true)?nx:x.i}})});return out.slice(0,c.max)}
 if(!main)return[];
 if(d.explicit){out.push({q:main,n:3,at:{t:'grp',i:Math.max(0,firstP)},g:1});return out}
 out.push({q:main,n:1,at:{t:'b',i:Math.max(0,firstP)}});const ps=bl.map((b,i)=>b.tagName==='P'?i:-1).filter(i=>i>=0);
 if(ps.length>=4&&ans.length>900)out.push({q:main+' diagram',n:1,at:{t:'b',i:ps[2]}});return out}

/* ---------- 7. render ---------- */
const css=document.createElement('style');css.id='zwi-css';css.textContent=`
.zwi{margin:12px 0;padding:0;display:block}
.zwi .zb{position:relative;border-radius:16px;overflow:hidden;background:var(--side,#e9e9ee);cursor:zoom-in;max-width:100%}
.zwi .zb::before{content:"";position:absolute;inset:0;background:linear-gradient(90deg,transparent,rgba(255,255,255,.25),transparent);transform:translateX(-100%);animation:zwis 1.2s infinite}
.zwi.ld .zb::before{display:none}
@keyframes zwis{to{transform:translateX(100%)}}
.zwi img{display:block;width:100%;height:100%;object-fit:cover;opacity:0;transition:opacity .35s}
.zwi.ld img{opacity:1}
.zwi figcaption{font-size:.74rem;line-height:1.35;color:var(--mut,#888);margin-top:6px}
.zwi figcaption b{font-weight:600}
.zwi .zbad{padding:18px 12px;text-align:center;font-size:.8rem;color:var(--mut,#888)}
.zg{display:flex;gap:8px;overflow-x:auto;margin:12px 0;padding-bottom:4px;scroll-snap-type:x proximity;-webkit-overflow-scrolling:touch}
.zg .zwi{flex:0 0 auto;margin:0;width:min(68%,260px);scroll-snap-align:start}
li.zli{display:flow-root}
.zwi.zt{float:left;margin:2px 12px 6px 0;width:84px}
.zwi.zt .zb{width:84px;height:84px;border-radius:14px}
.zwi.zt figcaption{display:none}
#zwv{position:fixed;inset:0;z-index:99999;background:rgba(0,0,0,.93);display:flex;flex-direction:column;color:#fff;touch-action:manipulation}
#zwv .zi{flex:1;display:flex;align-items:center;justify-content:center;min-height:0;padding:8px}
#zwv img{max-width:100%;max-height:100%;object-fit:contain;border-radius:8px}
#zwv .zm{padding:10px 16px calc(14px + env(safe-area-inset-bottom,0px));font-size:.82rem;line-height:1.45;background:rgba(0,0,0,.55)}
#zwv .zm b{font-size:.92rem}
#zwv .zr{display:flex;gap:8px;margin-top:8px;flex-wrap:wrap}
#zwv button{background:rgba(255,255,255,.16);color:#fff;border:0;border-radius:99px;padding:8px 14px;font-size:.82rem}
#zwv .zx{position:absolute;top:calc(8px + env(safe-area-inset-top,0px));right:10px;width:40px;height:40px;padding:0;font-size:1.3rem}
`;document.head.appendChild(css);
const open=u=>{u=pageUrl(u);if(!u)return;try{if(typeof zOpen==='function')return zOpen(u)}catch(e){}try{window.open(u,'_blank','noopener')}catch(e){}};
const cap=it=>[it.site,it.creator,it.license].filter(Boolean).join(' · ');
function viewer(items,i){const old=document.getElementById('zwv');if(old)old.remove();let k=i;const v=document.createElement('div');v.id='zwv';
 const zi=el('div','zi'),im=new Image(),m=el('div','zm'),x=el('button','zx','\u00d7');im.referrerPolicy='no-referrer';zi.appendChild(im);v.append(zi,m,x);
 const close=()=>{v.remove();document.removeEventListener('keydown',kd)},kd=e=>{if(e.key==='Escape')close()};
 const paint=()=>{const it=items[k];im.src=it.full||it.img;im.alt=it.title||'';m.replaceChildren();m.appendChild(el('b',0,it.title||'Image'));m.appendChild(el('div',0,[it.site,it.creator&&'By '+it.creator,it.license&&'License: '+it.license].filter(Boolean).join(' · ')));
  m.appendChild(el('div',0,'Shown from its original website. Copyright belongs to the owner; check the licence on the source page before reuse.')).style.opacity='.7';
  const r=el('div','zr');if(it.page){const b=el('button',0,'Open original website');b.onclick=()=>open(it.page);r.appendChild(b)}
  if(it.licUrl){const b=el('button',0,'View licence');b.onclick=()=>open(it.licUrl);r.appendChild(b)}
  if(items.length>1){const p=el('button',0,'\u2039 Prev'),n=el('button',0,'Next \u203a');p.onclick=()=>{k=(k+items.length-1)%items.length;paint()};n.onclick=()=>{k=(k+1)%items.length;paint()};r.append(p,n)}
  m.appendChild(r)};
 x.onclick=close;zi.onclick=e=>{if(e.target===zi)close()};document.addEventListener('keydown',kd);document.body.appendChild(v);paint()}
function fig(it,all,thumb){const f=el('figure','zwi'+(thumb?' zt':'')),b=el('div','zb'),im=new Image();
 const r=it.w&&it.h?it.w/it.h:4/3;if(!thumb){b.style.aspectRatio=String(r);if(r<1)b.style.maxWidth='min(100%,calc(60vh * '+r.toFixed(3)+'))'}
 im.referrerPolicy='no-referrer';im.loading='lazy';im.decoding='async';im.alt=it.title||'';
 im.onload=()=>f.classList.add('ld');
 im.onerror=()=>{f.classList.add('ld');b.replaceChildren();const bad=el('div','zbad','Image unavailable');if(it.page){const a=el('a',0,' Open source');a.href='#';a.onclick=e=>{e.preventDefault();e.stopPropagation();open(it.page)};bad.appendChild(a)}b.appendChild(bad);b.style.aspectRatio='';b.style.cursor='default';b.onclick=null};
 im.src=it.img;b.appendChild(im);b.onclick=()=>viewer(all,all.indexOf(it));f.appendChild(b);
 if(!thumb){const fc=el('figcaption');fc.appendChild(el('b',0,it.title||it.site));const c=cap(it);if(c)fc.appendChild(el('div',0,c));f.appendChild(fc)}
 return f}
function decorate(root,m){if(!root||!m||!m.wimg||!m.wimg.items)return;root.querySelectorAll('.zwi,.zg').forEach(x=>x.remove());root.querySelectorAll('li.zli').forEach(x=>x.classList.remove('zli'));
 const its=m.wimg.items.map(x=>Object.assign({},x)).filter(x=>safeUrl(x.img)),bl=blocksOf(root),all=its;
 const last=bl[bl.length-1];const at=i=>bl[Math.min(Math.max(0,i),bl.length-1)];
 const groups=new Map();
 its.forEach(it=>{const a=it.at||{};
  if(a.t==='li'){const lb=at(a.i),li=lb&&lb.querySelectorAll(':scope > li')[a.j];if(li){li.classList.add('zli');li.insertBefore(fig(it,all,true),li.firstChild)}}
  else if(a.t==='grp'){const k='g'+a.i;if(!groups.has(k))groups.set(k,{blk:at(a.i),items:[]});groups.get(k).items.push(it)}
  else{const b=at(a.i);if(b){const f=fig(it,all,false);b.parentNode.insertBefore(f,b.nextSibling)}}});
 groups.forEach(g=>{if(!g.blk)return;const w=el('div','zg');g.items.forEach(it=>w.appendChild(fig(it,all,false)));g.blk.parentNode.insertBefore(w,g.blk.nextSibling)})}

/* ---------- 8. orchestration ---------- */
async function enrich(chat,m,user){if(!m||m.wimg||m.role==='user')return;const d=decide(user,m.content,{saveData:!!(navigator.connection&&navigator.connection.saveData)});if(!d.go)return;
 let p=plan(user,m.content,d);
 if(!p.length&&!subjects(user).length&&typeof ask==='function'&&/[^\u0000-\u024f]/.test(user)&&typeof active==='function'&&active().length){ /* Tamil/Sinhala-only subject: translate to English keywords once */
  try{const x=await ask('Turn the text into 2-4 English image search keywords. Output only the keywords.',user,()=>{},new AbortController().signal);const q=cleanQ((typeof split==='function'?split(x.text,x.think)[0]:x.text)||x.text);if(q&&latin(q))p=plan(q,m.content,d)}catch(e){}}
 p=p.slice(0,Math.max(cfg().max,cfg().list));if(!p.length)return;
 const used={k:new Set(),t:new Set()},items=[];
 for(let i=0;i<p.length;i+=3){await Promise.all(p.slice(i,i+3).map(async g=>{try{const r=await search(g.q,g.n,used);r.forEach(it=>items.push(Object.assign(it,{at:g.at,q:g.q})))}catch(e){}}))}
 if(!items.length)return;
 m.wimg={v:1,t:Date.now(),items:items.map(({prov,img,full,raw,page,title,site,creator,license,licUrl,w,h,at,q})=>({prov,img,full,raw,page,title,site,creator,license,licUrl,w,h,at,q}))};
 try{saveChats()}catch(e){}
 try{if(cur===chat){const rows=list.querySelectorAll('.msg.bot'),idx=chat.messages.indexOf(m);let row=[...rows].find(r=>r.dataset.i==String(idx))||rows[rows.length-1];if(row&&chat.messages[chat.messages.length-1]===m)decorate(row.querySelector('.md'),m)}}catch(e){}}
const A0=answer;answer=async function(){const chat=cur,n0=chat&&chat.messages?chat.messages.length:0;const r=await A0.apply(this,arguments);
 try{if(chat&&chat.messages&&chat.messages.length>n0){const m=chat.messages[chat.messages.length-1];let u='';for(let i=chat.messages.length-2;i>=0;i--)if(chat.messages[i].role==='user'){u=chat.messages[i].content;break}
  if(m&&m.role!=='user'&&!m.dev&&!m.err)enrich(chat,m,u).catch(()=>{})}}catch(e){}
 return r};
const F0=fill;fill=function(o,m,last){F0.apply(this,arguments);try{if(m&&m.wimg)decorate(o.c,m)}catch(e){}};

/* ---------- 9. "+" menu: on/off + sources ---------- */
try{const am=$('am'),hr=am&&am.querySelector('hr');if(am&&hr){
 const tb=el('button');tb.innerHTML=(typeof ic==='function'?ic('image'):'')+'<span>Web images in answers</span><b></b>';const pill=tb.querySelector('b');
 const paint=()=>{const on=cfg().on;pill.textContent=on?'ON':'OFF';pill.style.cssText='margin-left:auto;padding:2px 10px;border-radius:99px;font-size:12px;'+(on?'background:#6c63ff;color:#fff':'background:rgba(128,128,128,.25)')};
 tb.onclick=e=>{e.stopPropagation();const c=cfg();c.on=!c.on;saveCfg(c);paint();toast(c.on?'Web images ON: real website photos appear in helpful answers':'Web images OFF')};
 tb.oncontextmenu=e=>{e.preventDefault();sources()};let tm=0;tb.addEventListener('touchstart',()=>{tm=setTimeout(sources,600)},{passive:true});['touchend','touchmove','touchcancel'].forEach(ev=>tb.addEventListener(ev,()=>clearTimeout(tm),{passive:true}));
 const sb=el('button');sb.innerHTML=(typeof ic==='function'?ic('image'):'')+'<span>Web image sources</span>';sb.onclick=e=>{e.stopPropagation();sources()};
 am.insertBefore(tb,hr);am.insertBefore(sb,hr);paint();
 function sources(){const c=cfg(),keyed={pexels:/pexels/i,unsplash:/unsplash/i};
  pick('Web image sources (tap to turn on/off; order = fallback order)',c.order.map(p=>{const off=c.off.includes(p),nk=keyed[p]&&!keyOf(keyed[p]);return[PROV[p]+' \u2014 '+(off?'OFF':nk?'needs key (Settings > AI providers > Data)':'ON'),'',p,'image']}).concat([['Clear image cache','','clear','trash']]),v=>{
   if(v==='clear'){ls.set(CACHEK,{});ls.set(CDK,{});toast('Image search cache cleared');return}
   const x=cfg();x.off=x.off.includes(v)?x.off.filter(y=>y!==v):x.off.concat([v]);saveCfg(x);toast(PROV[v]+(x.off.includes(v)?' OFF':' ON'));setTimeout(sources,150)})}}}catch(e){}

window.ZWI={_enrich:enrich,decide,subjects,plan,search,norm,safeUrl,txt,decorate,cfg,_cache:{get:cget,put:cput},_cool:cool,_inCool:inCool,SRC};
}catch(e){try{console.warn('web images',e&&e.message)}catch(_){}}})();
