package com.a2z.ai

import android.app.Activity
import android.app.AlertDialog
import android.content.Context

/**
 * Prominent, consent-based disclosure shown BEFORE the user is sent to Android Accessibility settings.
 * Nothing is enabled by this class: Android itself still requires the user to switch the service on.
 * The time of the last agreement is stored locally (never uploaded) so the floating panel can tell whether the user has agreed.
 */
object AccessibilityDisclosure {
    private const val PREFS = "zyn_consent"
    private const val KEY = "acc_disclosure_v1"

    fun accepted(ctx: Context): Boolean =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getLong(KEY, 0L) > 0L

    private val TEXT = "Zen Ai Agent uses Android's Accessibility service so that Zen Ai can control your phone for tasks YOU start.\n\n" +
        "What it does\n" +
        "\u2022 Reads the text and layout of the screen that is open while an Agent task is running.\n" +
        "\u2022 Taps, double-taps, long-presses, swipes, drags, scrolls, types and navigates for you.\n\n" +
        "What it does not do\n" +
        "\u2022 It does not run on its own. It only works after you start a task, and a status bar with a Stop button stays visible.\n" +
        "\u2022 It never reads or fills password fields, and it does not touch the lock screen, the app installer or Android permission dialogs.\n" +
        "\u2022 It does not record keystrokes or watch what you do in the background.\n\n" +
        "Your approval\n" +
        "\u2022 By default each action asks for your approval. If you switch on Full Auto, normal taps and typing run without asking, but payments, passwords and irreversible account actions still ask.\n\n" +
        "Your data\n" +
        "\u2022 To decide the next step, the visible screen text of your task may be sent to the AI provider that answers it. Do not run tasks on screens with private information you do not want sent.\n" +
        "\u2022 Zen Ai does not sell this data.\n\n" +
        "You can turn it off at any time in Android Settings > Accessibility > Zen Ai Agent.\n\n" +
        "Tap \"I agree\" to open Android Accessibility settings."

    fun show(activity: Activity, onAgree: () -> Unit) {
        try {
            AlertDialog.Builder(activity)
                .setTitle("Allow Zen Ai Agent to use Accessibility?")
                .setMessage(TEXT)
                .setCancelable(true)
                .setPositiveButton("I agree") { _, _ ->
                    activity.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putLong(KEY, System.currentTimeMillis()).apply()
                    onAgree()
                }
                .setNegativeButton("No thanks", null)
                .show()
        } catch (_: Throwable) { }
    }
}
