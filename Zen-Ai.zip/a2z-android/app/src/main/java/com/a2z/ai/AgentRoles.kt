package com.a2z.ai

/**
 * The seven agent roles. A role is a responsibility with boundaries and a provider kind. It is NOT a separate AI chatbot: all roles share ONE task
 * ([TaskManager]), ONE screen context ([AgentVision] / [FrameStore]) and ONE provider list ([ProviderRouter]).
 * Execution today: PLANNING, CONVERSATION, VISION and SCREEN_INTERACTION / TASK_EXECUTION are carried out by [AgentRunner] (plan call, explain call, observe and
 * verify, and the action loop). RESEARCH and CODING are selected and routed (kind RESEARCH / CODE) but the native runner has no web or code tool of its own:
 * web search stays in the app's WebView (Tavily). Only roles with [canTouchDevice] may act on the phone, and only through [AgentPolicy] and user confirmation.
 */
enum class Role(val title: String, val responsibility: String, val kind: ProviderRouter.Kind, val canTouchDevice: Boolean, val boundary: String) {
    RESEARCH("Research Agent", "Find and summarise information", ProviderRouter.Kind.RESEARCH, false, "No device control. Answers only; web search is done by the app's search tools."),
    CODING("Coding Agent", "Write and explain code", ProviderRouter.Kind.CODE, false, "No device control. Code is shown to the user, never run."),
    VISION("Vision Agent", "Read and verify the screen (frame, OCR, change detection)", ProviderRouter.Kind.VISION, false, "Read-only. Screenshots go only to the user's own image-capable provider."),
    SCREEN_INTERACTION("Screen Interaction Agent", "Choose the next UI action from the screen", ProviderRouter.Kind.CHAT, true, "Proposes one action at a time. AgentPolicy and the user's confirmation decide."),
    PLANNING("Planning Agent", "Understand the request and make a short plan", ProviderRouter.Kind.CHAT, false, "No device control. Plan is shown for approval in Manual mode."),
    CONVERSATION("Conversation Agent", "Answer questions and explain the screen", ProviderRouter.Kind.CHAT, false, "No device control."),
    TASK_EXECUTION("Task Execution Agent", "Run the steps, retry, verify, report", ProviderRouter.Kind.CHAT, true, "Only runs actions that passed AgentPolicy; sensitive ones need a confirmation tap."),
    // ---- 6.0: roles added so every part of the app is one registered team member (see Brain.kt / BrainAgents.kt) ----
    VOICE("Voice Agent", "Speak an answer aloud (text-to-speech); speech input is the user's mic button", ProviderRouter.Kind.CHAT, false, "Speaks only text the user already sees. Never records."),
    MEMORY("Memory Agent", "Recall earlier messages and results of this conversation", ProviderRouter.Kind.CHAT, false, "Read-only. Only the current session's own context; never another account's."),
    TASKS("Task Agent", "Queue, track and report background tasks", ProviderRouter.Kind.CHAT, false, "Queues tasks only; running them on the phone still goes through Task Execution and AgentPolicy."),
    PROVIDER("Provider Agent", "Report provider health, keys (count only), cooldowns and routing", ProviderRouter.Kind.CHAT, false, "Read-only. Never returns an API key."),
    ANALYSIS("Analysis Agent", "Compare, rank and summarise results other agents produced", ProviderRouter.Kind.CHAT, false, "Works only from the results it is given; adds no new facts."),
    VERIFICATION("Verification Agent", "Check that claims are backed by the given sources", ProviderRouter.Kind.CHAT, false, "Works only from the given text and sources; reports what is unsupported.")
}

object Orchestrator {
    enum class Intent { DEVICE_ACTION, SCREEN_QUESTION, RESEARCH, CODE, CHAT }
    enum class Complexity { SIMPLE, MODERATE, COMPLEX }
    class Selection(val intent: Intent, val complexity: Complexity, val roles: List<Role>, val kind: ProviderRouter.Kind)

    private val CODE = Regex("(?i)\\b(code|function|script|html|css|javascript|kotlin|python|bug|compile|regex|sql)\\b")
    private val RESEARCH = Regex("(?i)\\b(search|research|latest|news|price of|who is|what is the|compare|find out|google)\\b")
    private val QUESTION = Regex("(?i)(what('s| is) (on|this)|explain|read (this|the) screen|summari[sz]e|enna irukku|ithu enna|screen (la|il)|where is)")
    private val ACTION = Regex("(?i)\\b(open|tap|click|press|scroll|swipe|drag|type|go back|go home|turn (on|off)|enable|disable|install|send|call|set)\\b|pannu|panni|thira|kaattu|po$")
    private val STEP_WORDS = Regex("(?i)\\b(then|and then|after that|next|finally|also)\\b|pinnadi|appuram|adhuku apram")

    fun intentOf(text: String): Intent = when {
        QUESTION.containsMatchIn(text) -> Intent.SCREEN_QUESTION
        ACTION.containsMatchIn(text) -> Intent.DEVICE_ACTION
        CODE.containsMatchIn(text) -> Intent.CODE
        RESEARCH.containsMatchIn(text) -> Intent.RESEARCH
        else -> Intent.CHAT
    }

    fun complexityOf(text: String): Complexity {
        val words = text.trim().split(Regex("\\s+")).count { it.isNotEmpty() }
        val steps = STEP_WORDS.findAll(text).count()
        return when { steps >= 2 || words > 30 -> Complexity.COMPLEX; steps == 1 || words > 10 -> Complexity.MODERATE; else -> Complexity.SIMPLE }
    }

    /** Which roles work on this request, and the provider kind for its main AI call. A heuristic label; it never decides whether an action is allowed. */
    fun select(text: String, screenLinked: Boolean): Selection {
        val i = intentOf(text); val c = complexityOf(text)
        val roles = ArrayList<Role>()
        when (i) {
            Intent.DEVICE_ACTION -> { if (c != Complexity.SIMPLE) roles.add(Role.PLANNING); if (screenLinked) roles.add(Role.VISION); roles.add(Role.SCREEN_INTERACTION); roles.add(Role.TASK_EXECUTION) }
            Intent.SCREEN_QUESTION -> { if (screenLinked) roles.add(Role.VISION); roles.add(Role.CONVERSATION) }
            Intent.RESEARCH -> { roles.add(Role.RESEARCH); roles.add(Role.CONVERSATION) }
            Intent.CODE -> roles.add(Role.CODING)
            Intent.CHAT -> roles.add(Role.CONVERSATION)
        }
        val kind = when (i) { Intent.RESEARCH -> ProviderRouter.Kind.RESEARCH; Intent.CODE -> ProviderRouter.Kind.CODE; else -> ProviderRouter.Kind.CHAT }
        return Selection(i, c, roles, kind)
    }

    // ---- task ownership: who currently owns the phone. Informational; the runner's single-task guard is what prevents two tasks acting at once. ----
    @Volatile var deviceOwner: Role? = null; private set
    @Synchronized fun claimDevice(r: Role): Boolean { if (!r.canTouchDevice) return false; if (deviceOwner != null) return deviceOwner == r; deviceOwner = r; return true }
    @Synchronized fun releaseDevice() { deviceOwner = null }
}
