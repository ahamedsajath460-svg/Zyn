package com.a2z.ai

import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Semaphore
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLong

/** One structured message between agents. [kind] = request | result | error | cancel. All messages of a task share [taskId] (the shared context id). */
class AgentMsg(val id: Long, val taskId: Long, val from: String, val to: String, val kind: String, val text: String, val depth: Int, val at: Long)

/** What every agent returns. [recoverable] = a retry may help (timeout, busy, network); never true for device actions. */
class AgentResult(val ok: Boolean, val text: String, val sources: List<Pair<String, String>> = emptyList(), val error: String = "", val recoverable: Boolean = false) {
    companion object {
        fun fail(msg: String, recoverable: Boolean = false) = AgentResult(false, "", emptyList(), msg, recoverable)
    }
}

/** One run of an agent (its execution history). */
class AgentRun(val role: Role, val taskId: Long, val input: String, val startedAt: Long) {
    @Volatile var state = "running"      // running | done | failed | cancelled
    @Volatile var endedAt = 0L
    @Volatile var note = ""
}

/** Shared task context: blackboard for results, message trail, deadline, cancellation. One per task. */
class AgentCtx(val taskId: Long, val deadlineAt: Long) {
    val blackboard = ConcurrentHashMap<String, String>()
    val trail = CopyOnWriteArrayList<AgentMsg>()
    @Volatile var cancelled = false
    internal val done = ConcurrentHashMap<String, AgentResult>()
    internal val inFlight = ConcurrentHashMap.newKeySet<String>()
    internal val threads = CopyOnWriteArrayList<Thread>()
    fun expired(now: Long) = now > deadlineAt
}

/** The chain of agents that led to this call (used to stop circular and runaway delegation). */
class AgentCall(val rt: AgentRuntime, val ctx: AgentCtx, val chain: List<Role>) {
    fun delegate(to: Role, input: String, timeoutMs: Long = 60_000L): AgentResult = rt.delegate(ctx, chain, to, input, timeoutMs)
}

/** Input/output contract of an agent. [run] must be cancellable (check [AgentCtx.cancelled]) and must not touch the phone unless [Role.canTouchDevice]. */
interface Agent {
    val role: Role
    /** Null = input accepted, otherwise the reason it is rejected. */
    fun validateInput(input: String): String? = if (input.isBlank()) "empty input" else if (input.length > 6000) "input too long" else null
    fun run(call: AgentCall, input: String): AgentResult
    /** Null = output accepted, otherwise the reason it is rejected. */
    fun validateOutput(r: AgentResult): String? = if (r.ok && r.text.isBlank()) "empty result" else null
    /** Called when the task is cancelled while this agent runs (device agents stop the phone here). */
    fun onCancel(ctx: AgentCtx) {}
}

/**
 * Executes agents. Each run is a real execution on its own thread with a timeout, bounded concurrency ([maxParallel] top-level runs),
 * input and output validation, one retry for recoverable failures, execution history per agent and a structured message trail.
 * Guards: delegation depth ([maxDepth]), circular delegation (an agent already in the chain), duplicate execution (same agent + same input in one task),
 * conflicting device actions (one device-acting agent at a time, across all tasks), cancellation (flag + interrupt + [Agent.onCancel]).
 * Pure Kotlin (no Android classes): unit tested on the JVM with fake agents.
 */
class AgentRuntime(private val maxParallel: Int = 3, private val maxDepth: Int = 3, private val clock: () -> Long = { System.currentTimeMillis() }) {
    private val agents = ConcurrentHashMap<Role, Agent>()
    private val slots = Semaphore(maxParallel)
    private val msgId = AtomicLong(0)
    private val histories = ConcurrentHashMap<Role, CopyOnWriteArrayList<AgentRun>>()
    private val deviceLock = Any()
    @Volatile private var deviceHolder: Pair<Long, Role>? = null

    fun register(a: Agent) { agents[a.role] = a }
    fun registered(): Set<Role> = agents.keys.toSet()
    fun has(r: Role) = agents.containsKey(r)
    fun deviceHolder(): Pair<Long, Role>? = deviceHolder

    fun history(r: Role): List<AgentRun> = histories[r]?.toList() ?: emptyList()
    private fun record(r: AgentRun) { val l = histories.getOrPut(r.role) { CopyOnWriteArrayList() }; l.add(r); while (l.size > 20) l.removeAt(0) }

    private fun log(ctx: AgentCtx, from: String, to: String, kind: String, text: String, depth: Int) {
        ctx.trail.add(AgentMsg(msgId.incrementAndGet(), ctx.taskId, from, to, kind, text.take(300), depth, clock()))
        while (ctx.trail.size > 200) ctx.trail.removeAt(0)
    }

    private fun claimDevice(taskId: Long, role: Role): String? = synchronized(deviceLock) {
        val h = deviceHolder
        if (h == null) { deviceHolder = taskId to role; null }
        else "the phone is already being controlled by ${h.second.title}"
    }
    private fun releaseDevice(taskId: Long, role: Role) = synchronized(deviceLock) { if (deviceHolder == taskId to role) deviceHolder = null }

    /** Runs agent [to] for [ctx]. [chain] = agents that called this one (empty for the coordinator). Never throws. */
    fun delegate(ctx: AgentCtx, chain: List<Role>, to: Role, input: String, timeoutMs: Long = 60_000L): AgentResult {
        val from = chain.lastOrNull()?.name ?: "COORDINATOR"
        val depth = chain.size
        fun fail(msg: String, rec: Boolean = false): AgentResult { log(ctx, to.name, from, "error", msg, depth); return AgentResult.fail(msg, rec) }
        val agent = agents[to] ?: return fail("${to.title} is not available")
        if (ctx.cancelled) return fail("task cancelled")
        if (ctx.expired(clock())) return fail("task timed out", false)
        if (depth >= maxDepth) return fail("delegation is too deep (max $maxDepth)")
        if (to in chain) return fail("circular delegation: ${to.title} is already working on this")
        agent.validateInput(input)?.let { return fail("input rejected: $it") }
        val key = to.name + "|" + input.trim().lowercase()
        ctx.done[key]?.let { return it }                       // same work already finished in this task: reuse, never run twice
        if (!ctx.inFlight.add(key)) return fail("the same request is already running")
        log(ctx, from, to.name, "request", input, depth)
        var attempts = 0
        try {
            while (true) {
                attempts++
                val r = runOnce(ctx, chain, agent, input, timeoutMs, depth)
                if (r.ok) { ctx.done[key] = r; log(ctx, to.name, from, "result", r.text, depth); return r }
                val canRetry = r.recoverable && attempts < 2 && !to.canTouchDevice && !ctx.cancelled && !ctx.expired(clock())
                if (!canRetry) { log(ctx, to.name, from, "error", r.error, depth); return r }
            }
        } finally { ctx.inFlight.remove(key) }
    }

    private fun runOnce(ctx: AgentCtx, chain: List<Role>, agent: Agent, input: String, timeoutMs: Long, depth: Int): AgentResult {
        val role = agent.role
        val top = chain.isEmpty()
        val run = AgentRun(role, ctx.taskId, input.take(200), clock())
        record(run)
        var haveSlot = false; var haveDevice = false
        try {
            if (top) { if (!slots.tryAcquire(10, TimeUnit.SECONDS)) { run.state = "failed"; run.note = "busy"; return AgentResult.fail("agents are busy, try again", true) }; haveSlot = true }
            if (role.canTouchDevice) {
                claimDevice(ctx.taskId, role)?.let { run.state = "failed"; run.note = it; return AgentResult.fail(it, false) }
                haveDevice = true
            }
            val box = arrayOfNulls<AgentResult>(1)
            val th = Thread({
                try { box[0] = agent.run(AgentCall(this, ctx, chain + role), input) }
                catch (e: InterruptedException) { box[0] = AgentResult.fail("cancelled") }
                catch (e: Throwable) { box[0] = AgentResult.fail("${role.title} crashed: ${e.message ?: e.javaClass.simpleName}", true) }
            }, "agent-" + role.name.lowercase())
            th.isDaemon = true
            ctx.threads.add(th); th.start()
            val limit = minOf(timeoutMs, maxOf(1L, ctx.deadlineAt - clock()))
            th.join(limit)
            if (th.isAlive) {
                try { agent.onCancel(ctx) } catch (_: Throwable) { }
                th.interrupt(); th.join(1500)
                run.state = "failed"; run.note = "timeout"
                return AgentResult.fail("${role.title} timed out", !role.canTouchDevice)
            }
            ctx.threads.remove(th)
            val r = box[0] ?: AgentResult.fail("${role.title} returned nothing", true)
            if (ctx.cancelled) { run.state = "cancelled"; return AgentResult.fail("task cancelled") }
            agent.validateOutput(r)?.let { run.state = "failed"; run.note = it; return AgentResult.fail("${role.title} result rejected: $it", false) }
            run.state = if (r.ok) "done" else "failed"; run.note = if (r.ok) "" else r.error.take(120)
            return r
        } finally {
            run.endedAt = clock()
            if (haveDevice) releaseDevice(ctx.taskId, role)
            if (haveSlot) slots.release()
        }
    }

    /** Runs several agents at the same time (at most [maxParallel] at once). Device-acting agents are refused here: they run one after another through [delegate]. */
    fun parallel(ctx: AgentCtx, chain: List<Role>, jobs: List<Pair<Role, String>>, timeoutMs: Long = 60_000L): List<AgentResult> {
        val out = arrayOfNulls<AgentResult>(jobs.size)
        val ths = ArrayList<Thread>()
        for ((i, j) in jobs.withIndex()) {
            if (j.first.canTouchDevice) { out[i] = AgentResult.fail("${j.first.title} acts on the phone and cannot run in parallel"); continue }
            val t = Thread({ out[i] = delegate(ctx, chain, j.first, j.second, timeoutMs) }, "agent-par-$i")
            t.isDaemon = true; ths.add(t); t.start()
        }
        for (t in ths) t.join(timeoutMs + 15_000L)
        return out.map { it ?: AgentResult.fail("no result", true) }
    }

    /** Cancels a task everywhere: flag, agents' own stop (phone), interrupt of every thread still running for it. */
    fun cancel(ctx: AgentCtx) {
        if (ctx.cancelled) return
        ctx.cancelled = true
        log(ctx, "COORDINATOR", "ALL", "cancel", "task cancelled", 0)
        for (a in agents.values) try { a.onCancel(ctx) } catch (_: Throwable) { }
        for (t in ctx.threads) t.interrupt()
    }

    fun statusJson(): org.json.JSONArray {
        val arr = org.json.JSONArray()
        for (r in Role.values()) {
            val h = histories[r]?.toList() ?: emptyList()
            val last = h.lastOrNull()
            arr.put(org.json.JSONObject().put("role", r.name).put("title", r.title).put("available", agents.containsKey(r))
                .put("state", if (last == null) "idle" else last.state).put("runs", h.size).put("failed", h.count { it.state == "failed" }))
        }
        return arr
    }
}
