package com.a2z.ai

import org.json.JSONObject

/**
 * One place where the app's 5.1 settings (kept in the WebView settings store `S`) are applied to the native components. Pure Kotlin.
 * JSON: {depth:"quick|balanced|deep|", auto:bool, agents:{CODING:"deep"}, keyAuto:bool, prices:{model:{in,out}}, budget:{d,w,m}, currency,
 *        ocrLang:"auto|english|tamil|sinhala", ocrConsent:bool, dedup:{on,threshold}, healthMin:number}
 * Unknown or invalid values are ignored (a setting can never put a component into an invalid state).
 */
object AiConfig {
    @Volatile var dedupOn = true; @Volatile var dedupThreshold = 5; @Volatile var healthIntervalMs = 0L

    fun apply(j: JSONObject) {
        ReasoningPolicy.defaultDepth = ReasoningPolicy.parse(j.optString("depth", ""))
        ReasoningPolicy.auto = j.optBoolean("auto", false)
        j.optJSONObject("agents")?.let { a -> for (r in Role.values()) ReasoningPolicy.setAgent(r, ReasoningPolicy.parse(a.optString(r.name, ""))) }
        KeyPool.auto = j.optBoolean("keyAuto", true)
        j.optJSONObject("prices")?.let { p -> for (m in p.keys()) { val o = p.optJSONObject(m) ?: continue; val i = o.optDouble("in", -1.0); val x = o.optDouble("out", -1.0); if (i >= 0 && x >= 0 && !i.isNaN() && !x.isNaN()) UsageTracker.setPrice(m, i, x) } }
        j.optJSONObject("budget")?.let { b -> UsageTracker.dailyBudget = b.optDouble("d", 0.0).coerceAtLeast(0.0); UsageTracker.weeklyBudget = b.optDouble("w", 0.0).coerceAtLeast(0.0); UsageTracker.monthlyBudget = b.optDouble("m", 0.0).coerceAtLeast(0.0) }
        j.optString("currency", "").trim().take(5).takeIf { it.isNotEmpty() }?.let { UsageTracker.currency = it }
        OcrLang.language = when (j.optString("ocrLang", "auto")) { "english" -> OcrLang.Lang.ENGLISH; "tamil" -> OcrLang.Lang.TAMIL; "sinhala" -> OcrLang.Lang.SINHALA; else -> OcrLang.Lang.AUTO }
        OcrLang.onlineConsent = j.optBoolean("ocrConsent", false)
        j.optJSONObject("dedup")?.let { d -> dedupOn = d.optBoolean("on", true); dedupThreshold = d.optInt("threshold", 5).coerceIn(0, 20) }
        healthIntervalMs = (j.optDouble("healthMin", 0.0).let { if (it.isNaN()) 0.0 else it }.coerceIn(0.0, 1440.0) * 60_000.0).toLong()
    }
}
