package com.a2z.ai

import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList

/*
 * Zen AI 6.0: the unified brain (pure Kotlin, no Android classes, so it is unit tested on the JVM).
 *
 * It EXTENDS what 5.x already had instead of replacing it:
 *   AgentRuntime   = AgentRegistry + AgentCommunicationManager (registration, structured messages, timeouts, retry, no circular / duplicate runs)
 *   Coordinator    = AgentCoordinator for phone tasks (kept: checkpoints, resume, one device agent at a time)
 *   TaskManager    = task state + progress; TaskQueue = scheduler for background tasks
 *   AgentPolicy    = the last word on every phone action (unchanged)
 * and adds what was missing: ToolRegistry / ToolExecutor, SharedContext, intent classification, a dependency-graph planner,
 * a scheduler that runs independent steps in parallel, error recovery, result aggregation, response composition, execution monitor and permission checks.
 */

// ====================================================================================================================
// Tools
// ====================================================================================================================

enum class ToolStatus { OK, FAILED, DENIED, UNAVAILABLE, CANCELLED, TIMEOUT }

/** Structured result of every tool call. [data] is machine readable, [text] is what an agent may show. */
class ToolResult(val status: ToolStatus, val text: String = "", val data: JSONObject = JSONObject(), val error: String = "", val recoverable: Boolean = false) {
    val ok get() = status == ToolStatus.OK
    companion object {
        fun ok(text: String, data: JSONObject = JSONObject()) = ToolResult(ToolStatus.OK, text, data)
        fun fail(msg: String, recoverable: Boolean = false) = ToolResult(ToolStatus.FAILED, "", JSONObject(), msg, recoverable)
        fun denied(msg: String) = ToolResult(ToolStatus.DENIED, "", JSONObject(), msg)
        fun unavailable(msg: String) = ToolResult(ToolStatus.UNAVAILABLE, "", JSONObject(), msg)
    }
    fun toJson(): JSONObject = JSONObject().put("status", status.name).put("text", text.take(2000)).put("data", data).put("error", error)
}

class Field(val type: String, val required: Boolean = false, val note: String = "")

/** Declares one tool: unique id, capabilities, input and output schema, whether it can touch the phone. */
class ToolSpec(val id: String, val title: String, val capabilities: Set<String>, val input: Map<String, Field>, val output: Map<String, String>, val needsDevice: Boolean = false, val role: Role? = null) {
    fun toJson(): JSONObject {
        val i = JSONObject(); for ((k, f) in input) i.put(k, JSONObject().put("type", f.type).put("required", f.required).put("note", f.note))
        val o = JSONObject(); for ((k, v) in output) o.put(k, v)
        return JSONObject().put("id", id).put("title", title).put("capabilities", JSONArray(capabilities.toList())).put("input", i).put("output", o)
            .put("needsDevice", needsDevice).put("role", role?.name ?: "")
    }
}

/** A real, working tool. [unavailableReason] is null when the tool can run right now (key present, service on, screen shared, ...). Never register a demo as a tool. */
interface Tool {
    val spec: ToolSpec
    fun unavailableReason(): String? = null
    fun execute(args: JSONObject, ctx: AgentCtx): ToolResult
}

class ToolRegistry {
    private val tools = ConcurrentHashMap<String, Tool>()
    fun register(t: Tool) {
        require(t.spec.id.matches(Regex("[a-z][a-z0-9_.]{2,40}"))) { "bad tool id ${t.spec.id}" }
        require(tools.putIfAbsent(t.spec.id, t) == null) { "duplicate tool id ${t.spec.id}" }
    }
    fun get(id: String): Tool? = tools[id]
    fun ids(): List<String> = tools.keys.sorted()
    fun withCapability(c: String): List<Tool> = tools.values.filter { c in it.spec.capabilities }.sortedBy { it.spec.id }
    /** Discovery list for the orchestrator and the UI: spec plus live availability. */
    fun describe(): JSONArray { val a = JSONArray(); for (id in ids()) { val t = tools[id]!!; a.put(t.spec.toJson().put("available", t.unavailableReason() == null).put("reason", t.unavailableReason() ?: "")) }; return a }
}

class PermissionManager(
    /** null = the phone may be controlled (accessibility on, agent enabled); otherwise the reason. */
    var deviceAllowed: () -> String? = { null },
    var screenShared: () -> Boolean = { false },
) {
    /** Checked BEFORE any step runs. Phone actions additionally pass AgentPolicy and the user's confirmation inside AgentRunner (payments, messages, account changes). */
    fun check(role: Role): String? = when {
        role == Role.VISION && !screenShared() -> "Screen sharing is off. Start screen share, then ask again."
        role.canTouchDevice -> deviceAllowed()
        else -> null
    }
    fun checkTool(spec: ToolSpec): String? = if (spec.needsDevice) deviceAllowed() else null      // tools that need the shared screen say so themselves (unavailableReason)
}

// ====================================================================================================================
// Execution monitor
// ====================================================================================================================

class BrainEvent(val at: Long, val taskId: Long, val stage: String, val node: String, val status: String, val note: String)

/** Records what happened and tells the UI short, plain progress lines (no hidden reasoning is ever exposed). */
class ExecutionMonitor(private val clock: () -> Long = { System.currentTimeMillis() }) {
    val events = CopyOnWriteArrayList<BrainEvent>()
    val listeners = CopyOnWriteArrayList<(BrainEvent) -> Unit>()
    fun emit(taskId: Long, stage: String, node: String = "", status: String = "info", note: String = "") {
        val e = BrainEvent(clock(), taskId, stage, node, status, note.take(200))
        events.add(e); while (events.size > 300) events.removeAt(0)
        for (l in listeners) try { l(e) } catch (_: Throwable) { }
    }
    fun forTask(id: Long) = events.filter { it.taskId == id }
    companion object {
        val STAGES = mapOf("understand" to "Understanding request", "plan" to "Planning task", "search" to "Searching information", "team" to "Collaborating with agents",
            "analyze" to "Analyzing results", "verify" to "Verifying information", "compose" to "Preparing response", "image" to "Creating image", "screen" to "Looking at the screen",
            "device" to "Working on the phone", "tool" to "Running tool", "done" to "Done")
        fun line(stage: String) = STAGES[stage] ?: stage
    }
}

// ====================================================================================================================
// Shared context (one per user session; never shared between sessions or accounts)
// ====================================================================================================================

class Item(val title: String, val url: String, val text: String)

class SharedSession(val key: String) {
    private val lock = Any()
    private val turns = ArrayList<Pair<String, String>>()          // (role, text)
    @Volatile var items: List<Item> = emptyList()                   // the last list of results (research hits), for "compare the first two"
    @Volatile var lastAnswer: String = ""
    val toolResults = ConcurrentHashMap<String, String>()          // last result text per tool id
    fun turns(): List<Pair<String, String>> = synchronized(lock) { turns.toList() }
    fun add(role: String, text: String) = synchronized(lock) { if (text.isNotBlank()) { turns.add(role to text.take(4000)); while (turns.size > 40) turns.removeAt(0); if (role == "assistant") lastAnswer = text } }
    /** Replaces the turns with the chat's own history (the chat page owns its history; the brain only mirrors it). */
    fun load(history: List<Pair<String, String>>) = synchronized(lock) { if (history.isNotEmpty()) { turns.clear(); history.takeLast(40).forEach { turns.add(it.first to it.second.take(4000)) }; turns.lastOrNull { it.first == "assistant" }?.let { lastAnswer = it.second } } }
    fun clear() = synchronized(lock) { turns.clear(); items = emptyList(); lastAnswer = ""; toolResults.clear() }
}

object SharedContextManager {
    private val sessions = ConcurrentHashMap<String, SharedSession>()
    fun forSession(key: String): SharedSession = sessions.getOrPut(key.ifBlank { "local" }) { SharedSession(key.ifBlank { "local" }) }
    fun drop(key: String) { sessions.remove(key)?.clear() }
    fun dropAll() { sessions.values.forEach { it.clear() }; sessions.clear() }

    private val ORD = listOf(Regex("(?i)\\b(first|1st|one|mudhal|mudhalavathu|முதல்)\\b") to 1, Regex("(?i)\\b(second|2nd|two|rendu|rendavathu|இரண்டு)\\b") to 2,
        Regex("(?i)\\b(third|3rd|three|moonu|moondravathu|மூன்று)\\b") to 3, Regex("(?i)\\b(fourth|4th|four|naalu)\\b") to 4, Regex("(?i)\\b(fifth|5th|five)\\b") to 5)
    private val REF = Regex("(?i)\\b(first|second|third|1st|2nd|3rd|top|those|these|them|both|mudhal|rendu|athu|adhu|indha|andha)\\b")

    /** True when the message points back at earlier results ("compare the first two", "the 2nd one", "compare them"). */
    fun refersToItems(text: String, s: SharedSession): Boolean = s.items.size >= 2 && REF.containsMatchIn(text) && text.trim().split(Regex("\\s+")).size <= 25

    /** The items a message points at. "first two" = 1,2; "second" = 2; "compare them/both/these" = the first three. Empty when nothing is referenced. */
    fun resolve(text: String, s: SharedSession): List<Item> {
        val items = s.items; if (items.isEmpty()) return emptyList()
        val t = text.lowercase()
        val first = Regex("(?i)\\b(first|top|mudhal|முதல்)\\s+(two|2|rendu)\\b").containsMatchIn(t); val firstN = Regex("(?i)\\b(first|top)\\s+(three|3|moonu)\\b").containsMatchIn(t)
        if (first) return items.take(2)
        if (firstN) return items.take(3)
        val idx = LinkedHashSet<Int>()
        for ((re, n) in ORD) if (re.containsMatchIn(t) && n <= items.size) idx.add(n - 1)
        if (idx.isNotEmpty()) return idx.sorted().map { items[it] }
        if (Regex("(?i)\\b(them|both|these|those|ellam|ithellam)\\b").containsMatchIn(t)) return items.take(3)
        return emptyList()
    }
}

// ====================================================================================================================
// Intent classification (decides what the brain must do; ordinary chat uses no tool and no extra AI call)
// ====================================================================================================================

enum class BrainIntent { CHAT, RESEARCH, RESEARCH_COMPARE, FOLLOWUP_ITEMS, CODE, SCREEN_QUESTION, DEVICE_ACTION, TASK_QUEUE, VOICE, MEMORY, PROVIDER_INFO,
    SCREEN_TEXT, SHARE_STATUS, SHARE_CONTROL, FLOATING, WEB_LINKS, TRANSFORM,
    /** Creative tools that only the chat page can run (they use the page's video providers and its upload tool). */
    LINK_UPLOAD }
class Decision(val intent: BrainIntent, val reason: String) {
    /** True when the unified brain (not the plain chat path) must handle this message. */
    val needsBrain get() = intent != BrainIntent.CHAT
}

object IntentClassifier {
    private val SCREEN = Regex("(?i)(what('s| is| are)?|whats)\\s+(is\\s+)?(happening|going on|showing|visible|there)?\\s*(on|in)\\s+(my|the|this)\\s+screen|(read|explain|describe|summari[sz]e|translate|ocr)\\s+(this|the|my|current)\\s+screen|screen\\s+(la|il)\\s+enna|ithu enna screen|enna irukku (screen|inga)")
    private val DEVICE = Regex("(?i)^\\s*(please\\s+)?(open|launch|tap|click|press|scroll|swipe|go back|go home|turn (on|off)|enable|disable|toggle|find .{1,30} (in|on) (the )?(settings|phone))\\b|\\b(open|thira|tap|click)\\s+(pannu|pannunga|panni)\\b|\\bon my phone\\b.{0,30}\\b(open|tap|turn|enable|disable|find)\\b")
    private val SCREEN_TEXT = Regex("(?i)\\b(read|copy|extract|get|show|grab)\\b.{0,12}\\b(text|words)\\b.{0,12}\\b(on|from|in|of)\\b.{0,8}\\b(my|the|this)\\b.{0,8}\\bscreen\\b|\\bocr\\b.{0,25}\\bscreen\\b|\\bscreen\\b.{0,6}\\b(text|ocr)\\b")
    private val SHARE_STATUS = Regex("(?i)\\bis\\b.{0,10}\\bscreen\\s*(sharing|share|capture)\\b.{0,12}\\b(on|off|active|running)\\b|\\bscreen\\s*(sharing|share)\\s+status\\b")
    private val SHARE_CONTROL = Regex("(?i)\\b(start|stop|begin|end|turn (on|off)|switch (on|off))\\b.{0,15}\\bscreen\\s*(share|sharing|capture)\\b|\\bscreen\\s*(share|sharing)\\b.{0,10}\\b(start|stop|on|off)\\b")
    private val FLOATING = Regex("(?i)\\b(start|open|show|launch|turn on|enable)\\b.{0,15}\\b(floating\\s*(assistant|bubble|panel|button)|the bubble)\\b")
    private val WEBLINKS = Regex("(?i)\\b(links?|urls?|websites?|web ?pages?|web search results?)\\b.{0,15}\\b(for|about|on|of|to)\\b|\\b(give|show|list|find|get)\\b.{0,14}\\b(links?|urls?|websites)\\b")
    private val TRANSFORM = Regex("(?is)^\\s*(please\\s+)?(translate|summari[sz]e|rewrite|paraphrase|proofread|rephrase)\\b.{30,}")
    private val LINKUP = Regex("(?i)\\b(make|get|give|create|generate|need|want)\\b.{0,20}\\b(short\\s+)?(link|url)\\b.{0,25}\\b(for|of|to)\\b.{0,12}\\b(this|these|my|the|that)\\b.{0,12}\\b(photo|image|picture|video|file)s?\\b|\\bupload\\b.{0,20}\\b(photo|image|picture|video)s?\\b.{0,25}\\b(link|url|catbox|imgbb|litterbox)\\b|\\b(photo|image|picture|video)s?\\b.{0,10}\\b(to|into)\\s+(a\\s+)?(short\\s+)?(link|url)\\b")
    private val TASKQ = Regex("(?i)\\b(queue|add|schedule|submit|create)\\b.{0,15}\\b(a |the )?(background )?(task|job)\\b|\\btask (status|progress|queue)\\b")
    private val VOICE = Regex("(?i)\\b(read|say|speak)\\b.{0,20}\\b(aloud|out loud)\\b|\\bspeak (it|this|that)\\b|\\bsollu\\b.{0,10}\\b(sathama|voice)\\b")
    private val MEMORY = Regex("(?i)\\bwhat did (we|i)\\b.{0,25}\\b(say|talk|discuss|ask)\\b|\\b(earlier|previous|last) (chat|conversation|message)\\b|\\bremind me what\\b|\\benna pesinom\\b")
    private val PROVIDER = Regex("(?i)\\b(which|what)\\b.{0,12}\\b(ai )?(provider|model)s?\\b.{0,25}\\b(using|active|selected|available|working)\\b|\\bprovider (status|health)\\b|\\bapi (key )?(status|quota)\\b")
    private val RESEARCH_STRONG = Regex("(?i)\\b(search|research|latest|news|look up|find (the )?(latest )?(information|info|details)|price of|release date|who won|today's|this week|current version|seithi|vilai)\\b|\\b(latest|newest|upcoming)\\b")
    private val COMPARE = Regex("(?i)\\b(compare|comparison|summary|summari[sz]e|analy[sz]e|pros and cons|verify|prepare)\\b")
    private val CODE = Regex("(?i)\\b(code|function|script|kotlin|python|java|javascript|typescript|bug|compile|regex|sql|html|css|stack ?trace|exception|gradle|android studio|class|api endpoint)\\b")

    fun classify(text: String, session: SharedSession?, screenLinked: Boolean = false): Decision {
        val t = text.trim()
        if (t.isEmpty()) return Decision(BrainIntent.CHAT, "empty")
        if (LINKUP.containsMatchIn(t)) return Decision(BrainIntent.LINK_UPLOAD, "photo / video to link")
        if (SCREEN_TEXT.containsMatchIn(t)) return Decision(BrainIntent.SCREEN_TEXT, "read the text on the screen")
        if (SHARE_STATUS.containsMatchIn(t)) return Decision(BrainIntent.SHARE_STATUS, "screen share status")
        if (SHARE_CONTROL.containsMatchIn(t)) return Decision(BrainIntent.SHARE_CONTROL, "start or stop screen share")
        if (FLOATING.containsMatchIn(t)) return Decision(BrainIntent.FLOATING, "floating assistant")
        if (SCREEN.containsMatchIn(t)) return Decision(BrainIntent.SCREEN_QUESTION, if (screenLinked) "screen question (screen shared)" else "screen question (screen not shared)")
        if (DEVICE.containsMatchIn(t)) return Decision(BrainIntent.DEVICE_ACTION, "phone action")
        if (TASKQ.containsMatchIn(t)) return Decision(BrainIntent.TASK_QUEUE, "task queue")
        if (VOICE.containsMatchIn(t)) return Decision(BrainIntent.VOICE, "speak aloud")
        if (MEMORY.containsMatchIn(t)) return Decision(BrainIntent.MEMORY, "recall conversation")
        if (PROVIDER.containsMatchIn(t)) return Decision(BrainIntent.PROVIDER_INFO, "provider info")
        if (session != null && SharedContextManager.refersToItems(t, session)) return Decision(BrainIntent.FOLLOWUP_ITEMS, "follow-up about earlier results")
        if (WEBLINKS.containsMatchIn(t)) return Decision(BrainIntent.WEB_LINKS, "list of web links")
        if (TRANSFORM.containsMatchIn(t) && !RESEARCH_STRONG.containsMatchIn(t)) return Decision(BrainIntent.TRANSFORM, "translate / summarise given text")
        if (TaskPlanner.vs(t) != null && !CODE.containsMatchIn(t)) return Decision(BrainIntent.RESEARCH_COMPARE, "comparison of two things")
        if (RESEARCH_STRONG.containsMatchIn(t)) return Decision(if (COMPARE.containsMatchIn(t)) BrainIntent.RESEARCH_COMPARE else BrainIntent.RESEARCH, "needs current information")
        if (CODE.containsMatchIn(t) && t.length > 12) return Decision(BrainIntent.CODE, "coding request")
        return Decision(BrainIntent.CHAT, "conversation")
    }
}

// ====================================================================================================================
// Plan: a small dependency graph of agent steps
// ====================================================================================================================

/** One step. A step is run by an agent ([role]) or, when [tool] is set, by that registered tool directly ([toolArg] = the tool input field that receives [input], empty = no input). */
class PlanNode(val id: String, val role: Role, val input: String, val deps: List<String> = emptyList(), val optional: Boolean = false, val stage: String = "team", val timeoutMs: Long = 60_000L,
               val tool: String? = null, val toolArg: String = "")
class Plan(val intent: BrainIntent, val nodes: List<PlanNode>, val finalOrder: List<String>, val delegateToCoordinator: Boolean = false) {
    fun node(id: String) = nodes.firstOrNull { it.id == id }
    /** Nodes grouped in waves: every node of a wave only depends on earlier waves, so a wave can run in parallel. Throws on a cycle or an unknown dependency. */
    fun waves(): List<List<PlanNode>> {
        val done = HashSet<String>(); val out = ArrayList<List<PlanNode>>(); var left = nodes.toList()
        for (n in nodes) for (d in n.deps) require(nodes.any { it.id == d }) { "unknown dependency $d" }
        while (left.isNotEmpty()) {
            val ready = left.filter { n -> n.deps.all { it in done } }
            require(ready.isNotEmpty()) { "circular dependency in plan" }
            out.add(ready); done.addAll(ready.map { it.id }); left = left.filter { it !in ready }
        }
        return out
    }
}

object TaskPlanner {
    private val VS = Regex("(?i)^(.{2,60}?)\\s+(?:vs\\.?|versus)\\s+(.{2,60}?)(?:\\s+(?:comparison|compare|review|specs?|which|better|summary).*)?[?!. ]*$")
    /** "iPhone 17 vs Pixel 10 comparison" -> the two subjects, or null. */
    fun vs(request: String): Pair<String, String>? {
        val m = VS.find(request.trim().replace(Regex("(?i)^(please\\s+)?(research|search|find|compare)\\s+"), "")) ?: return null
        val a = m.groupValues[1].trim(); val b = m.groupValues[2].trim()
        return if (a.isNotEmpty() && b.isNotEmpty() && a.split(" ").size <= 6 && b.split(" ").size <= 6) a to b else null
    }
    fun plan(d: Decision, request: String, screenLinked: Boolean, referred: List<Item> = emptyList()): Plan = when (d.intent) {
        BrainIntent.CHAT -> Plan(d.intent, listOf(PlanNode("n1", Role.CONVERSATION, request)), listOf("n1"))
        BrainIntent.CODE -> Plan(d.intent, listOf(PlanNode("n1", Role.CODING, request)), listOf("n1"))
        BrainIntent.RESEARCH -> Plan(d.intent, listOf(
            PlanNode("n1", Role.RESEARCH, request, stage = "search", timeoutMs = 90_000L),
            PlanNode("n2", Role.VERIFICATION, "ANSWER:\n{{n1}}\n\nSOURCES:\n{{sources:n1}}", deps = listOf("n1"), optional = true, stage = "verify")), listOf("n1"))
        BrainIntent.RESEARCH_COMPARE -> if (vs(request) != null) {
            // "A vs B": the two researches are independent, so they run at the same time; the analysis starts when both are done
            val (a, b) = vs(request)!!
            Plan(d.intent, listOf(
                PlanNode("n1", Role.RESEARCH, a, stage = "search", timeoutMs = 90_000L),
                PlanNode("n2", Role.RESEARCH, b, stage = "search", timeoutMs = 90_000L),
                PlanNode("n3", Role.ANALYSIS, "TASK: $request\nCompare A and B. Cite sources as A[1], B[2] ...\n\nRESULT A ($a):\n{{n1}}\nSOURCES A:\n{{sources:n1}}\n\nRESULT B ($b):\n{{n2}}\nSOURCES B:\n{{sources:n2}}", deps = listOf("n1", "n2"), stage = "analyze")),
                listOf("n3", "n1", "n2"))
        } else Plan(d.intent, listOf(
            PlanNode("n1", Role.RESEARCH, request, stage = "search", timeoutMs = 90_000L),
            PlanNode("n2", Role.ANALYSIS, "TASK: $request\n\nRESEARCH RESULT:\n{{n1}}\n\nSOURCES:\n{{sources:n1}}", deps = listOf("n1"), stage = "analyze"),
            PlanNode("n3", Role.VERIFICATION, "ANSWER:\n{{n2}}\n\nSOURCES:\n{{sources:n1}}", deps = listOf("n2", "n1"), optional = true, stage = "verify"),
            PlanNode("n4", Role.CONVERSATION, "Write the final answer for the user from this analysis. Keep the [n] source numbers. Reply in the user's language.\nUSER REQUEST: $request\n\nANALYSIS:\n{{n2}}\n\nVERIFICATION NOTE:\n{{n3}}", deps = listOf("n2", "n3"), stage = "compose")),
            listOf("n4", "n2", "n1"))
        BrainIntent.FOLLOWUP_ITEMS -> {
            val block = referred.mapIndexed { i, it -> "[${i + 1}] ${it.title} (${it.url})\n${it.text.take(800)}" }.joinToString("\n\n")
            Plan(d.intent, listOf(PlanNode("n1", Role.ANALYSIS, "TASK: $request\n\nTHE ITEMS THE USER MEANS (from earlier in this chat):\n$block", stage = "analyze")), listOf("n1"))
        }
        BrainIntent.SCREEN_QUESTION -> Plan(d.intent, listOf(PlanNode("n1", if (screenLinked) Role.VISION else Role.SCREEN_INTERACTION, request, stage = "screen", timeoutMs = 180_000L)), listOf("n1"))
        BrainIntent.DEVICE_ACTION -> Plan(d.intent, listOf(PlanNode("n1", Role.TASK_EXECUTION, request, stage = "device", timeoutMs = 8 * 60_000L)), listOf("n1"), delegateToCoordinator = true)
        BrainIntent.TASK_QUEUE -> Plan(d.intent, listOf(PlanNode("n1", Role.TASKS, request)), listOf("n1"))
        BrainIntent.VOICE -> Plan(d.intent, listOf(PlanNode("n1", Role.VOICE, request)), listOf("n1"))
        BrainIntent.MEMORY -> Plan(d.intent, listOf(PlanNode("n1", Role.MEMORY, request)), listOf("n1"))
        BrainIntent.PROVIDER_INFO -> Plan(d.intent, listOf(PlanNode("n1", Role.PROVIDER, request)), listOf("n1"))
        // tool steps: the registered tool runs directly (no agent in between), through the same ToolExecutor
        BrainIntent.LINK_UPLOAD -> Plan(d.intent, listOf(PlanNode("n1", Role.CONVERSATION, request)), listOf("n1"))      // never run: handled by [MasterOrchestrator.PAGE_ONLY] before planning
        BrainIntent.SCREEN_TEXT -> Plan(d.intent, listOf(PlanNode("n1", Role.VISION, request, stage = "screen", tool = "vision.ocr")), listOf("n1"))
        BrainIntent.SHARE_STATUS -> Plan(d.intent, listOf(PlanNode("n1", Role.VISION, request, stage = "screen", tool = "screen.share.status")), listOf("n1"))
        BrainIntent.SHARE_CONTROL -> Plan(d.intent, listOf(PlanNode("n1", Role.VISION, request, stage = "screen",
            tool = if (Regex("(?i)\\b(stop|end|off|pause)\\b").containsMatchIn(request)) "screen.share.stop" else "screen.share.start")), listOf("n1"))
        BrainIntent.FLOATING -> Plan(d.intent, listOf(PlanNode("n1", Role.TASKS, request, tool = "floating.open")), listOf("n1"))
        BrainIntent.WEB_LINKS -> Plan(d.intent, listOf(PlanNode("n1", Role.RESEARCH, linksQuery(request), stage = "search", tool = "web.search", toolArg = "query", timeoutMs = 60_000L)), listOf("n1"))
        BrainIntent.TRANSFORM -> Plan(d.intent, listOf(PlanNode("n1", Role.CONVERSATION, request, stage = "compose", tool = "ai.chat", toolArg = "prompt", timeoutMs = 90_000L)), listOf("n1"))
    }
    /** "give me links for kotlin coroutines" -> "kotlin coroutines" */
    fun linksQuery(r: String) = r.replace(Regex("(?i)^\\s*(please\\s+)?(give|show|list|find|get)\\s+(me\\s+)?(some\\s+|the\\s+)?(web\\s*)?(links?|urls?|websites|web ?pages)\\s*(for|about|on|of|to)?\\s*"), "").trim().ifBlank { r.trim() }
}

// ====================================================================================================================
// Verification agent (deterministic: no AI call, no cost; checks that citations map to the sources that were really found)
// ====================================================================================================================

class VerificationAgent : Agent {
    override val role = Role.VERIFICATION
    override fun run(call: AgentCall, input: String): AgentResult {
        val answer = input.substringAfter("ANSWER:", input).substringBefore("\n\nSOURCES:").trim()
        val srcBlock = input.substringAfter("SOURCES:", "")
        val nSources = Regex("(?m)^\\[(\\d+)]").findAll(srcBlock).count()
        val cites = Regex("\\[(\\d{1,2})]").findAll(answer).map { it.groupValues[1].toInt() }.toList()
        val bad = cites.filter { it < 1 || it > nSources }.distinct()
        val claimSentences = answer.split(Regex("(?<=[.!?])\\s+")).filter { Regex("\\b(19|20)\\d{2}\\b|\\d+(\\.\\d+)?\\s?(%|percent|million|billion|GB|MB|mAh|Hz|inch)").containsMatchIn(it) }
        val uncited = claimSentences.count { !Regex("\\[\\d{1,2}]").containsMatchIn(it) }
        val issues = ArrayList<String>()
        if (nSources == 0) issues.add("no sources were found, so nothing here could be checked")
        if (bad.isNotEmpty()) issues.add("it cites source numbers that do not exist (${bad.joinToString(", ")})")
        if (nSources > 0 && cites.isEmpty()) issues.add("it does not cite any source")
        if (uncited > 0) issues.add("$uncited statement(s) with numbers or dates have no source")
        return if (issues.isEmpty()) AgentResult(true, "VERIFIED: ${cites.distinct().size} source(s) cited, all of them exist in the search results.")
        else AgentResult(true, "UNVERIFIED: " + issues.joinToString("; "))
    }
}

// ====================================================================================================================
// Aggregation, composition, recovery
// ====================================================================================================================

class NodeResult(val node: PlanNode, val result: AgentResult?, val skipped: String = "", val degraded: Boolean = false) {
    val ok get() = result?.ok == true
}

class StepReport(val id: String, val role: String, val status: String, val note: String)

class BrainOutcome(val ok: Boolean, val text: String, val sources: List<Pair<String, String>>, val issues: List<String>, val intent: BrainIntent, val steps: List<StepReport>,
                   val artifacts: List<Pair<String, String>> = emptyList(), val partial: Boolean = false) {
    fun toJson(): JSONObject {
        val s = JSONArray(); sources.forEach { s.put(JSONObject().put("t", it.first).put("u", it.second)) }
        val st = JSONArray(); steps.forEach { st.put(JSONObject().put("id", it.id).put("role", it.role).put("status", it.status).put("note", it.note)) }
        val ar = JSONArray(); artifacts.forEach { ar.put(JSONObject().put("kind", it.first).put("path", it.second)) }
        return JSONObject().put("ok", ok).put("text", text).put("sources", s).put("issues", JSONArray(issues)).put("intent", intent.name).put("steps", st).put("artifacts", ar).put("partial", partial)
    }
}

object ResultAggregator {
    class Aggregate(val results: Map<String, NodeResult>) {
        val okIds get() = results.filter { it.value.ok }.keys
        fun text(id: String): String? = results[id]?.takeIf { it.ok }?.result?.text
        val sources: List<Pair<String, String>> get() { val m = LinkedHashMap<String, String>(); for (r in results.values) r.result?.sources?.forEach { m.putIfAbsent(it.second, it.first) }; return m.map { it.value to it.key } }
        val degraded get() = results.values.any { it.degraded && it.ok }
        /** Required (non optional) steps that did not succeed. */
        fun missingRequired(plan: Plan) = plan.nodes.filter { !it.optional && results[it.id]?.ok != true }
    }
    fun aggregate(rs: Collection<NodeResult>) = Aggregate(rs.associateBy { it.node.id })
}

/** Decides what to do when a step fails. Device actions are never re-run or replaced here (AgentPolicy and the user decide). Nothing is ever invented as a replacement for a failed tool. */
object ErrorRecoveryManager {
    /** A degraded fallback node for a failed node, or null when there is none (image, screen, phone, tasks: report the failure instead). */
    fun fallback(n: PlanNode, error: String): PlanNode? = if (n.tool != null) null else when (n.role) {      // a failed tool step (links, OCR, ...) is reported, never replaced by guesses
        Role.RESEARCH -> PlanNode(n.id, Role.CONVERSATION,
            "The web search is not available right now (${error.take(120)}). Answer from general knowledge only, say clearly that this answer is NOT checked against live sources and may be out of date.\n\nQUESTION: ${n.input}", n.deps, n.optional, n.stage, n.timeoutMs)
        else -> null
    }
    fun userMessage(n: PlanNode, error: String) = "${n.role.title}: ${error.ifBlank { "it did not finish" }}"
}

object ResponseComposer {
    /** One final text. Picks the best finished step in [Plan.finalOrder]; adds honest notes for unverified, degraded and failed parts. */
    fun compose(plan: Plan, agg: ResultAggregator.Aggregate, issues: List<String>): String {
        val body = plan.finalOrder.firstNotNullOfOrNull { agg.text(it) }
            ?: agg.results.values.filter { it.ok }.map { it.result!!.text }.lastOrNull()
        val notes = ArrayList<String>()
        val unver = agg.results.values.firstOrNull { it.node.role == Role.VERIFICATION && it.ok && it.result!!.text.startsWith("UNVERIFIED") }
        if (unver != null) notes.add("Not fully verified: " + unver.result!!.text.removePrefix("UNVERIFIED: ").trim())
        if (agg.degraded) notes.add("Live search was unavailable, so this answer comes from general knowledge and may be out of date.")
        val failed = issues.filter { it.isNotBlank() }
        if (body == null) return failed.firstOrNull() ?: "Nothing could be done."
        val sb = StringBuilder(body.trim())
        if (notes.isNotEmpty()) sb.append("\n\n").append(notes.joinToString("\n") { "Note: $it" })
        val miss = failed.filter { f -> notes.none { f in it } }
        if (miss.isNotEmpty()) sb.append("\n\nNot completed: ").append(miss.joinToString("; "))
        return sb.toString()
    }
}

// ====================================================================================================================
// The Master Orchestrator
// ====================================================================================================================

class MasterOrchestrator(
    private val rt: AgentRuntime,
    private val coordinator: Coordinator,
    val tools: ToolRegistry = ToolRegistry(),
    val perms: PermissionManager = PermissionManager(),
    val monitor: ExecutionMonitor = ExecutionMonitor(),
) {
    val executor = ToolExecutor(tools, perms, monitor)
    private val running = ConcurrentHashMap.newKeySet<String>()
    companion object {
        /** Tools that run in the chat page (its video providers and upload tool). Anywhere else the user is told where to do it; nothing is faked. */
        val PAGE_ONLY = mapOf(
            BrainIntent.LINK_UPLOAD to "Photo and video links are made in the Zen Ai chat page: attach the photo there and ask for a link, or open Tools > Image & Video to Link.")
    }

    /** Cheap, no AI call, no network: what the brain would do with this message. Used by the chat to decide between the plain path and the brain. */
    fun classify(text: String, screenLinked: Boolean, sessionKey: String = "local"): Decision = IntentClassifier.classify(text, SharedContextManager.forSession(sessionKey), screenLinked)

    private fun tm(s: TaskState) { try { TaskManager.to(s) } catch (_: Throwable) { } }

    fun run(ctx: AgentCtx, request: String, screenLinked: Boolean, sessionKey: String = "local", history: List<Pair<String, String>> = emptyList()): BrainOutcome {
        val session = SharedContextManager.forSession(sessionKey)
        if (history.isNotEmpty()) session.load(history)
        val guard = sessionKey + "|" + request.trim().lowercase()
        if (!running.add(guard)) return BrainOutcome(false, "The same request is already running.", emptyList(), emptyList(), BrainIntent.CHAT, emptyList())
        try { return runInner(ctx, request.trim(), screenLinked, session) } finally { running.remove(guard) }
    }

    private fun runInner(ctx: AgentCtx, request: String, screenLinked: Boolean, session: SharedSession): BrainOutcome {
        val tid = ctx.taskId
        monitor.emit(tid, "understand")
        val decision = IntentClassifier.classify(request, session, screenLinked)
        val referred = if (decision.intent == BrainIntent.FOLLOWUP_ITEMS) SharedContextManager.resolve(request, session) else emptyList()
        val d = if (decision.intent == BrainIntent.FOLLOWUP_ITEMS && referred.isEmpty()) Decision(BrainIntent.CHAT, "no matching earlier items") else decision
        PAGE_ONLY[d.intent]?.let { msg -> session.add("user", request); monitor.emit(tid, "done", status = "failed", note = d.intent.name); return BrainOutcome(false, msg, emptyList(), listOf(msg), d.intent, listOf(StepReport("n1", d.intent.name, "page only", msg))) }
        monitor.emit(tid, "plan", status = "info", note = d.intent.name + ": " + d.reason)
        tm(TaskState.PLANNING)
        val plan = TaskPlanner.plan(d, withContext(request, session, d.intent), screenLinked, referred)
        ctx.blackboard["lastAnswer"] = session.lastAnswer
        ctx.blackboard["history"] = JSONArray(session.turns().map { JSONArray(listOf(it.first, it.second)) }).toString()      // read by memory.recall
        session.add("user", request)

        // phone actions keep the proven path: checkpoints, resume, one device agent at a time, AgentPolicy + confirmations
        if (plan.delegateToCoordinator) {
            perms.check(Role.TASK_EXECUTION)?.let { return finish(session, d.intent, BrainOutcome(false, it, emptyList(), listOf(it), d.intent, listOf(StepReport("n1", Role.TASK_EXECUTION.name, "denied", it)))) }
            monitor.emit(tid, "device", "n1", "running")
            val o = coordinator.run(ctx, request, screenLinked)
            return finish(session, d.intent, BrainOutcome(o.ok, o.text, o.sources, o.issues, d.intent, listOf(StepReport("n1", Role.TASK_EXECUTION.name, if (o.ok) "ok" else "failed", o.issues.firstOrNull() ?: ""))))
        }

        // permission and availability are checked for every required step BEFORE anything runs
        val issues = ArrayList<String>(); val reports = ArrayList<StepReport>()
        for (n in plan.nodes) {
            val deny = denial(n)
            if (deny != null && !n.optional) {
                monitor.emit(tid, n.stage, n.id, "denied", deny)
                return finish(session, d.intent, BrainOutcome(false, deny, emptyList(), listOf(deny), d.intent, listOf(StepReport(n.id, n.role.name, "denied", deny))))
            }
        }
        tm(TaskState.AGENT_SELECTION)

        val results = LinkedHashMap<String, NodeResult>()
        val texts = HashMap<String, String>(); val srcs = HashMap<String, List<Pair<String, String>>>()
        for (wave in plan.waves()) {
            if (ctx.cancelled) return finish(session, d.intent, BrainOutcome(false, "Cancelled.", emptyList(), issues, d.intent, reports))
            tm(TaskState.EXECUTING)
            val runnable = ArrayList<PlanNode>()
            for (n in wave) {
                val badDep = n.deps.firstOrNull { results[it]?.ok != true && !(plan.node(it)?.optional ?: false) }
                val deny = denial(n)
                when {
                    badDep != null -> { results[n.id] = NodeResult(n, null, "skipped: step $badDep did not finish"); reports.add(StepReport(n.id, n.role.name, "skipped", "step $badDep did not finish")); if (!n.optional) issues.add("${n.role.title}: skipped because an earlier step failed") }
                    deny != null -> { results[n.id] = NodeResult(n, null, "skipped: $deny"); reports.add(StepReport(n.id, n.role.name, "skipped", deny)) }
                    else -> runnable.add(n)
                }
            }
            if (runnable.isEmpty()) continue
            runnable.forEach { monitor.emit(tid, it.stage, it.id, "running", it.role.title) }
            val inputs = runnable.map { fill(it.input, texts, srcs) }
            val toolNodes = runnable.withIndex().filter { it.value.tool != null }
            val seq = runnable.withIndex().filter { it.value.tool == null && it.value.role.canTouchDevice }
            val par = runnable.withIndex().filter { it.value.tool == null && !it.value.role.canTouchDevice }
            val out = arrayOfNulls<AgentResult>(runnable.size)
            for (v in toolNodes) out[v.index] = runToolNode(ctx, v.value, inputs[v.index])
            if (par.isNotEmpty()) {
                val rr = rt.parallel(ctx, emptyList(), par.map { it.value.role to inputs[it.index] }, par.maxOf { it.value.timeoutMs })
                par.forEachIndexed { k, v -> out[v.index] = rr[k] }
            }
            for (v in seq) out[v.index] = rt.delegate(ctx, emptyList(), v.value.role, inputs[v.index], v.value.timeoutMs)
            for ((i, n) in runnable.withIndex()) {
                var r = out[i] ?: AgentResult.fail("no result")
                var degraded = false; var node = n
                if (!r.ok && !ctx.cancelled) {
                    val fb = ErrorRecoveryManager.fallback(n, r.error)       // e.g. search down -> answer from general knowledge, clearly marked
                    if (fb != null && rt.has(fb.role)) {
                        monitor.emit(tid, "team", n.id, "recovering", "using ${fb.role.title} instead")
                        val r2 = rt.delegate(ctx, emptyList(), fb.role, fb.input, fb.timeoutMs)
                        if (r2.ok) { r = r2; degraded = true; node = fb }
                    }
                }
                results[n.id] = NodeResult(n, r, degraded = degraded)
                reports.add(StepReport(n.id, node.role.name, if (r.ok) (if (degraded) "degraded" else "ok") else "failed", if (r.ok) "" else r.error))
                monitor.emit(tid, n.stage, n.id, if (r.ok) "ok" else "failed", r.error)
                if (r.ok) { texts[n.id] = r.text; srcs[n.id] = r.sources; ctx.blackboard["step_" + n.id] = r.text }
                else if (!n.optional) issues.add(ErrorRecoveryManager.userMessage(n, r.error))
            }
        }
        if (ctx.cancelled) return finish(session, d.intent, BrainOutcome(false, "Cancelled.", emptyList(), issues, d.intent, reports))

        tm(TaskState.VERIFYING)
        monitor.emit(tid, "compose")
        val agg = ResultAggregator.aggregate(results.values)
        val missing = agg.missingRequired(plan)
        val text = ResponseComposer.compose(plan, agg, issues)
        val anyOk = agg.okIds.isNotEmpty() && plan.finalOrder.any { agg.text(it) != null }
        val ok = missing.isEmpty() && anyOk
        val artifacts = ctx.blackboard.entries.filter { it.key.startsWith("artifact:") }.map { it.key.removePrefix("artifact:") to it.value }
        val out = BrainOutcome(ok, text, agg.sources, issues, d.intent, reports, artifacts, partial = !ok && anyOk)
        monitor.emit(tid, "done", status = if (ok) "ok" else "failed")
        return finish(session, d.intent, out, agg)
    }

    private fun finish(session: SharedSession, intent: BrainIntent, o: BrainOutcome, agg: ResultAggregator.Aggregate? = null): BrainOutcome {
        if (o.ok || o.partial) session.add("assistant", o.text)
        if (o.sources.isNotEmpty() && (intent == BrainIntent.RESEARCH || intent == BrainIntent.RESEARCH_COMPARE || intent == BrainIntent.WEB_LINKS)) session.items = o.sources.take(8).map { Item(it.first, it.second, "") }
        val rs = agg?.results?.get("n1")?.result
        if (rs != null && rs.ok && o.sources.isNotEmpty() && session.items.isNotEmpty()) session.items = session.items.mapIndexed { i, it -> if (i == 0) Item(it.title, it.url, rs.text.take(600)) else it }
        return o
    }

    /** Follow-ups get the recent conversation so "what about the second one" is not treated as a new, empty request. */
    private fun withContext(request: String, s: SharedSession, intent: BrainIntent): String {
        if (intent == BrainIntent.DEVICE_ACTION || intent == BrainIntent.SCREEN_QUESTION) return request
        val recent = s.turns().takeLast(6)
        if (recent.isEmpty() || intent == BrainIntent.TASK_QUEUE) return request
        if (intent == BrainIntent.CHAT || intent == BrainIntent.CODE || intent == BrainIntent.MEMORY)
            return "CONVERSATION SO FAR:\n" + recent.joinToString("\n") { (if (it.first == "user") "User: " else "Assistant: ") + it.second.take(600) } + "\n\nUSER MESSAGE: " + request
        return request
    }

    private fun fill(input: String, texts: Map<String, String>, srcs: Map<String, List<Pair<String, String>>>): String {
        var s = input
        for ((id, list) in srcs) s = s.replace("{{sources:$id}}", list.mapIndexed { i, x -> "[${i + 1}] ${x.first} (${x.second})" }.joinToString("\n").ifBlank { "(none)" })
        for ((id, t) in texts) s = s.replace("{{$id}}", t.take(4000))
        return s.replace(Regex("\\{\\{(sources:)?n\\d+}}"), "(not available)")
    }

    /** Why this step cannot run right now (null = it can). Tool steps are judged by the tool itself: availability (key, service, screen share) and permission. */
    private fun denial(n: PlanNode): String? {
        val tn = n.tool
        if (tn == null) return perms.check(n.role) ?: if (!rt.has(n.role)) "${n.role.title} is not available" else null
        val t = tools.get(tn) ?: return "Tool $tn is not available"
        return t.unavailableReason() ?: perms.checkTool(t.spec)
    }

    /** Runs a tool step directly and turns its structured result into the agent result shape (sources are taken from the tool's data). */
    private fun runToolNode(ctx: AgentCtx, n: PlanNode, input: String): AgentResult {
        val args = JSONObject(); if (n.toolArg.isNotBlank()) args.put(n.toolArg, input)
        val r = executor.call(n.tool!!, args, ctx, n.timeoutMs)
        if (!r.ok) return AgentResult.fail(r.error.ifBlank { "${n.tool} did not finish" }, r.recoverable)
        val src = ArrayList<Pair<String, String>>()
        for (key in listOf("hits", "sources")) { val a = r.data.optJSONArray(key) ?: continue; for (i in 0 until a.length()) { val o = a.optJSONObject(i) ?: continue; val u = o.optString("url"); if (u.isNotBlank()) src.add(o.optString("title").ifBlank { u } to u) } }
        return AgentResult(true, r.text, src)
    }

    /** Direct tool call from the orchestrator (the same path agents use). */
    fun callTool(id: String, args: JSONObject, ctx: AgentCtx, timeoutMs: Long = 60_000L) = executor.call(id, args, ctx, timeoutMs)
}

class ToolExecutor(private val reg: ToolRegistry, private val perms: PermissionManager, private val monitor: ExecutionMonitor) {
    /** Validates input, availability and permission, then runs the tool with a timeout on its own thread. Never throws; every failure is a structured [ToolResult]. */
    fun call(id: String, args: JSONObject, ctx: AgentCtx, timeoutMs: Long = 60_000L): ToolResult {
        val t = reg.get(id) ?: return ToolResult.unavailable("unknown tool $id")
        for ((k, f) in t.spec.input) if (f.required && (!args.has(k) || args.optString(k).isBlank())) return ToolResult.fail("missing input '$k'")
        if (ctx.cancelled) return ToolResult(ToolStatus.CANCELLED, error = "task cancelled")
        t.unavailableReason()?.let { return ToolResult.unavailable(it) }
        perms.checkTool(t.spec)?.let { return ToolResult.denied(it) }
        monitor.emit(ctx.taskId, "tool", id, "running")
        val box = arrayOfNulls<ToolResult>(1)
        val th = Thread({ box[0] = try { t.execute(args, ctx) } catch (e: InterruptedException) { ToolResult(ToolStatus.CANCELLED, error = "cancelled") } catch (e: Throwable) { ToolResult.fail("${t.spec.title} crashed: ${e.message ?: e.javaClass.simpleName}", true) } }, "tool-$id")
        th.isDaemon = true; th.start(); th.join(timeoutMs)
        val r = if (th.isAlive) { th.interrupt(); ToolResult(ToolStatus.TIMEOUT, error = "${t.spec.title} timed out", recoverable = true) } else box[0] ?: ToolResult.fail("no result")
        monitor.emit(ctx.taskId, "tool", id, r.status.name.lowercase(), r.error)
        if (r.ok) ctx.blackboard["tool:$id"] = r.text.take(2000)
        return r
    }
}
