package com.a2z.ai

import android.content.Context
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicLong

/**
 * Zen AI 6.0: the way a chat (the main chat page and the floating panel) talks to the one brain.
 * The chat asks [classify] (instant, no AI call). Intents the native team executes ([NATIVE]) are run with [start]; progress and the final answer come back through [emit].
 * Plain conversation, web research, follow-ups and code stay in each chat's own streaming pipeline (it already has live streaming, sources and key rotation).
 */
object BrainBridge {
    /** Intents the native agents execute for a chat. */
    val PAGE = setOf(BrainIntent.LINK_UPLOAD)   // run by the chat page itself (its upload tool)
    val NATIVE = BrainIntent.values().filter { it != BrainIntent.CHAT && it !in PAGE }.toSet()
    /** Intents the chat's own pipeline can also answer. If the native run fails the chat falls back to its own pipeline instead of showing an error (screen, phone, image and tool actions never fall back: they are not answerable by chat). */
    val SOFT = setOf(BrainIntent.RESEARCH, BrainIntent.RESEARCH_COMPARE, BrainIntent.FOLLOWUP_ITEMS, BrainIntent.CODE, BrainIntent.TRANSFORM, BrainIntent.WEB_LINKS)
    private val runs = ConcurrentHashMap<String, AgentCtx>()
    private val seq = AtomicLong(2_000_000L)
    private val pool = Executors.newCachedThreadPool { r -> Thread(r, "zen-brain").also { it.isDaemon = true } }

    fun classifyJson(text: String, sessionKey: String): String {
        val d = AgentSystem.brain.classify(text, AgentVision.linked(), sessionKey)
        return JSONObject().put("intent", d.intent.name).put("needsBrain", d.needsBrain).put("native", d.intent in NATIVE).put("soft", d.intent in SOFT).put("page", d.intent in PAGE).put("reason", d.reason).toString()
    }

    fun parseHistory(json: String): List<Pair<String, String>> = try {
        val a = JSONArray(json.ifBlank { "[]" }); val out = ArrayList<Pair<String, String>>()
        for (i in 0 until minOf(a.length(), 40)) { val o = a.optJSONObject(i) ?: continue; val r = o.optString("role"); if (r == "user" || r == "assistant") out.add(r to o.optString("text").take(4000)) }
        out
    } catch (_: Throwable) { emptyList() }

    /** Starts one run on a background thread. Returns an error text, or null when started. [emit] is called with ("status", {"line"}) and finally ("done", outcome json). */
    fun start(app: Context, runId: String, text: String, sessionKey: String, history: List<Pair<String, String>>, emit: (String, String) -> Unit): String? {
        val t = text.trim(); if (t.isEmpty() || t.length > 6000) return "Type a message first."
        if (runs.containsKey(runId)) return "That run is already active."
        AgentSystem.ensure(app)
        val ctx = AgentCtx(seq.incrementAndGet(), System.currentTimeMillis() + 10 * 60_000L)
        runs[runId] = ctx
        var lastLine = ""
        val l: (BrainEvent) -> Unit = { e -> if (e.taskId == ctx.taskId) { val line = ExecutionMonitor.line(e.stage); if (line != lastLine && e.stage != "done") { lastLine = line; emit("status", JSONObject().put("line", line).toString()) } } }
        AgentSystem.brain.monitor.listeners.add(l)
        pool.execute {
            val o: BrainOutcome = try { AgentSystem.brain.run(ctx, t, AgentVision.linked(), sessionKey, history) }
            catch (e: Throwable) { BrainOutcome(false, "That did not work: " + (e.message ?: e.javaClass.simpleName), emptyList(), emptyList(), BrainIntent.CHAT, emptyList()) }
            val j = o.toJson()
            val imgs = JSONArray()
            for ((kind, path) in o.artifacts) if (kind == "image") try { val f = File(path); if (f.exists() && f.length() < 4_000_000) imgs.put(JSONObject().put("mime", if (path.endsWith("png")) "image/png" else if (path.endsWith("webp")) "image/webp" else "image/jpeg").put("b64", Base64.encodeToString(f.readBytes(), Base64.NO_WRAP))) } catch (_: Throwable) { }
            j.put("images", imgs).put("cancelled", ctx.cancelled)
            AgentSystem.brain.monitor.listeners.remove(l); runs.remove(runId)
            emit("done", j.toString())
        }
        return null
    }

    fun cancel(runId: String) { runs[runId]?.let { AgentSystem.runtime.cancel(it) } }
    /** Called when the chat page (re)loads, for example after an account switch: no context may survive into another account. */
    fun reset() { SharedContextManager.dropAll() }
}
