package com.a2z.ai

/**
 * Rules for live camera vision (5.1), kept free of Android classes so they are unit tested. The camera runs only while the camera screen is visible (never in the background),
 * a frame is kept only in memory and only while not paused, one AI request at a time, and in Live mode a new request starts only after the previous one ended and the interval passed.
 */
class CameraGate(var minFrameMs: Long = 400L, var liveIntervalMs: Long = 6_000L) {
    @Volatile var paused = false; private set
    @Volatile var front = false; private set
    @Volatile var live = false
    @Volatile var hasFrame = false; private set
    private var lastFrame = 0L; private var lastLive = 0L; private var busy = false

    @Synchronized fun acceptFrame(now: Long): Boolean { if (paused || now - lastFrame < minFrameMs) return false; lastFrame = now; hasFrame = true; return true }
    @Synchronized fun pause() { paused = true; hasFrame = false; live = false }          // pausing drops the frame in memory and stops Live
    @Synchronized fun resume() { paused = false }
    @Synchronized fun flip() { front = !front; hasFrame = false }
    /** True when the caller may start a request now (and must call [end] afterwards). */
    @Synchronized fun begin(now: Long, fromLive: Boolean): Boolean {
        if (busy || paused || !hasFrame) return false
        if (fromLive && (!live || now - lastLive < liveIntervalMs)) return false
        busy = true; if (fromLive) lastLive = now; return true
    }
    @Synchronized fun end() { busy = false }
    @Synchronized fun stop() { paused = true; hasFrame = false; live = false; busy = false }
}
