package com.a2z.ai

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Typeface
import android.os.Bundle
import android.util.Base64
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.io.ByteArrayOutputStream
import java.util.concurrent.Executors

/**
 * Live camera vision (5.1). CameraX preview + analysis, front or rear camera, pause / resume, and a permanent red "Camera on" banner while the camera is bound.
 * The camera is bound only while this screen is in front (released in onStop), nothing is written to disk, and a frame goes to an AI provider only when the user taps Ask
 * (or has switched Live on, which asks about once every few seconds, one request at a time). Frames go only to the user's own image-capable provider (Gemini preferred, via [ProviderRouter]);
 * if there is none the screen says so instead of guessing.
 */
class CameraVisionActivity : AppCompatActivity() {
    private val gate = CameraGate()
    private val exec = Executors.newSingleThreadExecutor()
    private lateinit var preview: PreviewView
    private lateinit var banner: TextView
    private lateinit var answer: TextView
    private lateinit var pauseBtn: Button
    private lateinit var question: EditText
    @Volatile private var jpeg: String? = null
    private var provider: ProcessCameraProvider? = null
    private val live = java.util.concurrent.atomic.AtomicBoolean(false)

    private val askPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> if (ok) bind() else say("Camera permission is off. Allow it in Android settings to use camera vision.") }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
        val root = FrameLayout(this); root.setBackgroundColor(Color.BLACK)
        preview = PreviewView(this); root.addView(preview, FrameLayout.LayoutParams(-1, -1))
        banner = TextView(this).apply { text = "●  Camera on: Zen Ai can see this view"; setTextColor(Color.WHITE); setBackgroundColor(Color.parseColor("#CC C62828".replace(" ", ""))); setPadding(dp(14), dp(8), dp(14), dp(8)); typeface = Typeface.DEFAULT_BOLD; textSize = 13f }
        root.addView(banner, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))
        val bar = LinearLayout(this); bar.orientation = LinearLayout.VERTICAL; bar.setBackgroundColor(Color.parseColor("#E6000000")); bar.setPadding(dp(12), dp(10), dp(12), dp(14))
        answer = TextView(this).apply { setTextColor(Color.WHITE); textSize = 14f; text = "Ask something about what the camera sees."; maxLines = 8 }
        val sv = ScrollView(this); sv.addView(answer); bar.addView(sv, LinearLayout.LayoutParams(-1, dp(110)))
        question = EditText(this).apply { hint = "Question (empty = describe what you see)"; setHintTextColor(Color.GRAY); setTextColor(Color.WHITE); isSingleLine = true }
        bar.addView(question, LinearLayout.LayoutParams(-1, -2))
        val row = LinearLayout(this); row.orientation = LinearLayout.HORIZONTAL
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; isAllCaps = false; setOnClickListener { f() } }.also { row.addView(it, LinearLayout.LayoutParams(0, -2, 1f)) }
        btn("Ask") { ask(false) }
        pauseBtn = btn("Pause") { togglePause() }
        btn("Flip") { gate.flip(); jpeg = null; bind() }
        val liveBtn = btn("Live: off") {}
        liveBtn.setOnClickListener { val on = !gate.live; if (on && gate.paused) return@setOnClickListener; gate.live = on; liveBtn.text = if (on) "Live: on" else "Live: off"; if (on) startLive() }
        btn("Close") { finish() }
        bar.addView(row, LinearLayout.LayoutParams(-1, -2))
        root.addView(bar, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        setContentView(root)
    }

    override fun onStart() { super.onStart(); gate.resume(); updateUi(); if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) bind() else askPermission.launch(Manifest.permission.CAMERA) }
    /** Released whenever the screen is not in front: the camera never runs in the background. */
    override fun onStop() { gate.stop(); live.set(false); jpeg = null; try { provider?.unbindAll() } catch (_: Throwable) { }; banner.visibility = View.GONE; super.onStop() }
    override fun onDestroy() { exec.shutdownNow(); super.onDestroy() }

    private fun updateUi() { pauseBtn.text = if (gate.paused) "Resume" else "Pause"; banner.visibility = if (gate.paused) View.GONE else View.VISIBLE }
    private fun say(t: String) = runOnUiThread { answer.text = t }

    private fun togglePause() {
        if (gate.paused) { gate.resume(); bind() } else { gate.pause(); jpeg = null; try { provider?.unbindAll() } catch (_: Throwable) { } }
        updateUi(); say(if (gate.paused) "Paused. The camera is off and no frame is kept." else "Camera on.")
    }

    private fun bind() {
        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({
            try {
                val p = f.get(); provider = p; p.unbindAll()
                if (gate.paused) return@addListener
                val pv = Preview.Builder().build().also { it.setSurfaceProvider(preview.surfaceProvider) }
                val an = ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
                an.setAnalyzer(exec) { img -> try { if (gate.acceptFrame(System.currentTimeMillis())) jpeg = toJpeg(img) } catch (_: Throwable) { } finally { img.close() } }
                val sel = if (gate.front) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
                p.bindToLifecycle(this, sel, pv, an); updateUi()
            } catch (e: Throwable) { say("Could not open the camera: " + (e.message ?: "unknown error")) }
        }, ContextCompat.getMainExecutor(this))
    }

    /** In-memory JPEG, rotated upright and scaled down (max 768 px): small and private. */
    private fun toJpeg(img: ImageProxy): String {
        val bmp = img.toBitmap(); val m = Matrix(); m.postRotate(img.imageInfo.rotationDegrees.toFloat())
        if (gate.front) m.postScale(-1f, 1f)
        var r = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        val s = 768f / maxOf(r.width, r.height); if (s < 1f) r = Bitmap.createScaledBitmap(r, (r.width * s).toInt(), (r.height * s).toInt(), true)
        val o = ByteArrayOutputStream(); r.compress(Bitmap.CompressFormat.JPEG, 70, o)
        return Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP)
    }

    private fun ask(fromLive: Boolean) {
        val now = System.currentTimeMillis(); val img = jpeg
        if (img == null) { if (!fromLive) say("No camera frame yet. Wait a moment, or press Resume."); return }
        if (!gate.begin(now, fromLive)) { if (!fromLive) say("Please wait for the previous answer."); return }
        val q = question.text.toString().trim().ifEmpty { "Describe briefly what you see." }.take(400)
        if (!fromLive) say("Thinking...")
        Thread {
            try {
                val ok = FloatStore.ordered().any { FloatVision.support(it) != FloatVision.S.NO }
                if (!ok) { say("No image-capable AI provider is set up. Add a Gemini (or other vision) key in Settings."); return@Thread }
                val r = AiGateway.ask(ProviderRouter.Kind.VISION, "You see a live camera image from the user's phone. Answer the question about it briefly and only from what is visible. Say when you cannot tell. Reply in the user's language.", q, listOf(img), AgentCtx(0L, System.currentTimeMillis() + 60_000L))
                if (!gate.paused) say(r)
            } catch (e: IllegalStateException) { say(e.message ?: "The AI did not answer.") } finally { gate.end() }
        }.also { it.isDaemon = true }.start()
    }

    private fun startLive() { if (!live.compareAndSet(false, true)) return; Thread { while (live.get() && gate.live) { try { Thread.sleep(1000) } catch (_: InterruptedException) { break }; ask(true) }; live.set(false) }.also { it.isDaemon = true }.start() }
}
