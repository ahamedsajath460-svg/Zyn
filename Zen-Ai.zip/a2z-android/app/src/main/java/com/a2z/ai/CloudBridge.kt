package com.a2z.ai

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.webkit.JavascriptInterface
import android.webkit.WebView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.security.KeyStore
import java.util.concurrent.Executors
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey

/**
 * JavaScript bridge "A2ZCloud" for Zen AI Cloud Studio (thin Android glue; the logic lives in CloudCore).
 *  - The GitHub token is stored encrypted (AES-256-GCM, key in the Android Keystore) and is never given back to JavaScript.
 *  - Every GitHub call goes through CloudCore.request: host + path allowlist, token added here, secrets redacted from the answer.
 *  - Generated code is never executed in the main WebView: previews open in CloudPreviewActivity (no bridges, no network).
 */
class CloudBridge(private val act: AppCompatActivity, private val webOf: () -> WebView) {
    private val pool = Executors.newFixedThreadPool(3)
    private val prefs by lazy { act.getSharedPreferences("a2z_cloud", Context.MODE_PRIVATE) }
    private val alias = "zen_cloud_token_v1"

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore"); ks.load(null)
        (ks.getKey(alias, null) as? SecretKey)?.let { return it }
        val g = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        g.init(KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).setKeySize(256).build())
        return g.generateKey()
    }

    private fun slot(ns: String): String = "tok_" + (if (Regex("^[A-Za-z0-9]{1,40}$").matches(ns)) ns else "local")
    private fun token(ns: String): String? = try { prefs.getString(slot(ns), null)?.let { CloudCore.SecretBox(key()).open(it) } } catch (_: Exception) { null }

    private fun reply(id: String, status: Int, body: String) {
        val js = "window.__cloudCb&&window.__cloudCb(" + JSONObject.quote(id) + "," + status + "," + JSONObject.quote(body) + ")"
        act.runOnUiThread { try { webOf().evaluateJavascript(js, null) } catch (_: Throwable) { } }
    }
    private fun err(m: String) = JSONObject().put("message", m).toString()
    private fun safeId(id: String) = id.take(40).replace(Regex("[^A-Za-z0-9_-]"), "_")

    // ------------------------------------------------------------------ token
    @JavascriptInterface fun hasToken(ns: String): Boolean = token(ns) != null

    /** Returns "ok" or "bad" (the shape is checked here; GitHub itself confirms it on the first call to /user). */
    @JavascriptInterface fun setToken(ns: String, t: String): String {
        val v = t.trim()
        if (!CloudCore.tokenShapeOk(v)) return "bad"
        return try { prefs.edit().putString(slot(ns), CloudCore.SecretBox(key()).seal(v)).apply(); "ok" } catch (_: Exception) { "error" }
    }

    @JavascriptInterface fun clearToken(ns: String) { prefs.edit().remove(slot(ns)).apply() }

    // ------------------------------------------------------------------ GitHub REST (async; answer arrives in window.__cloudCb)
    @JavascriptInterface fun gh(id: String, ns: String, method: String, path: String, body: String) {
        val cid = safeId(id)
        pool.execute {
            try {
                val r = CloudCore.request(method, path, body.ifEmpty { null }, token(ns))
                reply(cid, r.status, r.body)
            } catch (e: Throwable) { reply(cid, 0, err("Cloud bridge error: " + (e.message ?: "unknown"))) }
        }
    }

    // ------------------------------------------------------------------ APK download, checksum, signing information
    @JavascriptInterface fun downloadApk(id: String, ns: String, owner: String, repo: String, artifactId: String) {
        val cid = safeId(id)
        pool.execute {
            try {
                val aid = artifactId.toLongOrNull() ?: run { reply(cid, 400, err("Bad artifact id")); return@execute }
                val dir = File(act.cacheDir, "cloud_apk")
                val s = CloudCore.downloadArtifact(owner, repo, aid, token(ns), dir)
                if (s == null) { reply(cid, 404, err("No APK found in this artifact")); return@execute }
                val where = saveToDownloads(s.file, s.name)
                val j = JSONObject().put("name", s.name).put("size", s.size).put("sha256", s.sha256).put("where", where)
                apkInfo(s.file)?.let { j.put("package", it.optString("package")).put("versionName", it.optString("versionName")).put("versionCode", it.optLong("versionCode")).put("certSha256", it.optString("certSha256")) }
                reply(cid, 200, j.toString())
            } catch (e: Throwable) { reply(cid, 0, err("Download failed: " + (e.message ?: "unknown"))) }
        }
    }

    /** Emulator-test reports (screenshots, logcat, crash report): small files are returned inline (png as base64, text as text). */
    @JavascriptInterface fun downloadReports(id: String, ns: String, owner: String, repo: String, artifactId: String) {
        val cid = safeId(id)
        pool.execute {
            try {
                val aid = artifactId.toLongOrNull() ?: run { reply(cid, 400, err("Bad artifact id")); return@execute }
                val dir = File(act.cacheDir, "cloud_reports/" + aid); dir.deleteRecursively()
                val arr = org.json.JSONArray()
                for (s in CloudCore.downloadReports(owner, repo, aid, token(ns), dir)) {
                    val j = JSONObject().put("name", s.name).put("size", s.size).put("sha256", s.sha256)
                    if (s.size <= 1_500_000) {
                        if (s.name.endsWith(".png")) j.put("b64", android.util.Base64.encodeToString(s.file.readBytes(), android.util.Base64.NO_WRAP))
                        else j.put("text", CloudCore.tail(CloudCore.redact(s.file.readText(Charsets.UTF_8), null), 400_000))
                    }
                    arr.put(j)
                }
                reply(cid, 200, JSONObject().put("files", arr).toString())
            } catch (e: Throwable) { reply(cid, 0, err("Download failed: " + (e.message ?: "unknown"))) }
        }
    }

    private fun saveToDownloads(f: File, name: String): String {
        val safe = name.replace(Regex("[^A-Za-z0-9._-]"), "_")
        return if (Build.VERSION.SDK_INT >= 29) {
            val v = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, safe)
                put(MediaStore.MediaColumns.MIME_TYPE, "application/vnd.android.package-archive")
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Zen Ai/Cloud Studio")
            }
            val uri = act.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v) ?: throw java.io.IOException("Could not create the file in Downloads")
            act.contentResolver.openOutputStream(uri)?.use { o -> f.inputStream().use { it.copyTo(o) } } ?: throw java.io.IOException("Could not write to Downloads")
            "Downloads/Zen Ai/Cloud Studio/$safe"
        } else {
            val dir = act.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: act.filesDir
            f.copyTo(File(dir, safe), true); File(dir, safe).absolutePath
        }
    }

    /** Package name, version and signing certificate read by Android itself from the downloaded APK. */
    private fun apkInfo(f: File): JSONObject? {
        if (Build.VERSION.SDK_INT < 28) return null
        return try {
            val pi = act.packageManager.getPackageArchiveInfo(f.absolutePath, PackageManager.GET_SIGNING_CERTIFICATES) ?: return null
            val j = JSONObject().put("package", pi.packageName).put("versionName", pi.versionName ?: "").put("versionCode", pi.longVersionCode)
            val sigs = pi.signingInfo?.apkContentsSigners
            if (sigs != null && sigs.isNotEmpty()) {
                val md = java.security.MessageDigest.getInstance("SHA-256")
                j.put("certSha256", CloudCore.hex(md.digest(sigs[0].toByteArray())))
            }
            j
        } catch (_: Throwable) { null }
    }

    /** Opens Android's share sheet for a downloaded APK. The page asks the user first; the chooser is a second confirmation. */
    @JavascriptInterface fun shareApk(name: String): String {
        val f = File(File(act.cacheDir, "cloud_apk"), name.replace(Regex("[^A-Za-z0-9._-]"), "_"))
        if (!f.isFile) return "missing"
        return try {
            val uri = FileProvider.getUriForFile(act, act.packageName + ".fp", f)
            val i = Intent(Intent.ACTION_SEND).setType("application/vnd.android.package-archive").putExtra(Intent.EXTRA_STREAM, uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            act.runOnUiThread { try { act.startActivity(Intent.createChooser(i, "Share APK")) } catch (_: Throwable) { } }
            "ok"
        } catch (_: Throwable) { "error" }
    }

    // ------------------------------------------------------------------ isolated preview
    @JavascriptInterface fun openPreview(title: String, html: String, width: Int): String {
        if (html.length > 2_000_000) return "too_big"
        CloudPreviewActivity.pendingHtml = html
        CloudPreviewActivity.pendingTitle = title.take(60)
        CloudPreviewActivity.pendingWidth = width
        act.runOnUiThread { try { act.startActivity(Intent(act, CloudPreviewActivity::class.java)) } catch (_: Throwable) { } }
        return "ok"
    }
}
