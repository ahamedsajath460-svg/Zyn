package com.a2z.ai

import android.content.Context
import android.content.Intent
import android.webkit.JavascriptInterface
import android.webkit.WebView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors

/**
 * JavaScript bridge "A2ZCloud" for Zen AI Cloud Studio (thin Android glue; the logic lives in CloudCore).
 *  - The GitHub token is stored encrypted (AES-256-GCM, key in the Android Keystore) and is never given back to JavaScript.
 *  - Every GitHub call goes through CloudCore.request: host + path allowlist, token added here, secrets redacted from the answer.
 *  - Generated code is never executed in the main WebView: previews open in CloudPreviewActivity (no bridges, no network).
 */
class CloudBridge(private val act: AppCompatActivity, private val webOf: () -> WebView) {
    private val pool = Executors.newFixedThreadPool(3)
    private val prefs by lazy { act.getSharedPreferences("a2z_cloud", Context.MODE_PRIVATE) }

    private fun token(ns: String): String? = CloudVault.token(act, ns)

    private fun reply(id: String, status: Int, body: String) {
        val js = "window.__cloudCb&&window.__cloudCb(" + JSONObject.quote(id) + "," + status + "," + JSONObject.quote(body) + ")"
        act.runOnUiThread { try { webOf().evaluateJavascript(js, null) } catch (_: Throwable) { } }
    }
    private fun err(m: String) = JSONObject().put("message", m).toString()
    private fun safeId(id: String) = id.take(40).replace(Regex("[^A-Za-z0-9_-]"), "_")

    // ------------------------------------------------------------------ token
    @JavascriptInterface fun hasToken(ns: String): Boolean = token(ns) != null

    /** Returns "ok" or "bad" (the shape is checked here; GitHub itself confirms it on the first call to /user). */
    @JavascriptInterface fun setToken(ns: String, t: String): String {
        val v = t.trim()
        if (!CloudCore.tokenShapeOk(v)) return "bad"
        return try { prefs.edit().putString(CloudVault.slot(ns), CloudCore.SecretBox(CloudVault.key()).seal(v)).apply(); "ok" } catch (_: Exception) { "error" }
    }

    @JavascriptInterface fun clearToken(ns: String) { prefs.edit().remove(CloudVault.slot(ns)).apply() }

    // ------------------------------------------------------------------ GitHub REST (async; answer arrives in window.__cloudCb)
    @JavascriptInterface fun gh(id: String, ns: String, method: String, path: String, body: String) {
        val cid = safeId(id)
        pool.execute {
            try {
                val r = CloudCore.request(method, path, body.ifEmpty { null }, token(ns))
                reply(cid, r.status, r.body)
            } catch (e: Throwable) { reply(cid, 0, err("Cloud bridge error: " + (e.message ?: "unknown"))) }
        }
    }

    // ------------------------------------------------------------------ APK download, checksum, signing information
    @JavascriptInterface fun downloadApk(id: String, ns: String, owner: String, repo: String, artifactId: String) {
        val cid = safeId(id)
        pool.execute {
            try {
                val aid = artifactId.toLongOrNull() ?: run { reply(cid, 400, err("Bad artifact id")); return@execute }
                val dir = File(act.cacheDir, "cloud_apk")
                val s = CloudCore.downloadArtifact(owner, repo, aid, token(ns), dir)
                if (s == null) { reply(cid, 404, err("No APK found in this artifact")); return@execute }
                val where = saveToDownloads(s.file, s.name)
                val j = JSONObject().put("name", s.name).put("size", s.size).put("sha256", s.sha256).put("where", where)
                apkInfo(s.file)?.let { j.put("package", it.optString("package")).put("versionName", it.optString("versionName")).put("versionCode", it.optLong("versionCode")).put("certSha256", it.optString("certSha256")) }
                reply(cid, 200, j.toString())
            } catch (e: Throwable) { reply(cid, 0, err("Download failed: " + (e.message ?: "unknown"))) }
        }
    }

    /** Emulator-test reports (screenshots, logcat, crash report): small files are returned inline (png as base64, text as text). */
    @JavascriptInterface fun downloadReports(id: String, ns: String, owner: String, repo: String, artifactId: String) {
        val cid = safeId(id)
        pool.execute {
            try {
                val aid = artifactId.toLongOrNull() ?: run { reply(cid, 400, err("Bad artifact id")); return@execute }
                val dir = File(act.cacheDir, "cloud_reports/" + aid); dir.deleteRecursively()
                val arr = org.json.JSONArray()
                for (s in CloudCore.downloadReports(owner, repo, aid, token(ns), dir)) {
                    val j = JSONObject().put("name", s.name).put("size", s.size).put("sha256", s.sha256)
                    if (s.size <= 1_500_000) {
                        if (s.name.endsWith(".png")) j.put("b64", android.util.Base64.encodeToString(s.file.readBytes(), android.util.Base64.NO_WRAP))
                        else j.put("text", CloudCore.tail(CloudCore.redact(s.file.readText(Charsets.UTF_8), null), 400_000))
                    }
                    arr.put(j)
                }
                reply(cid, 200, JSONObject().put("files", arr).toString())
            } catch (e: Throwable) { reply(cid, 0, err("Download failed: " + (e.message ?: "unknown"))) }
        }
    }

    private fun saveToDownloads(f: File, name: String): String = CloudFiles.saveToDownloads(act, f, name)

    private fun apkInfo(f: File): JSONObject? = CloudFiles.apkInfo(act, f)

    /** Opens Android's share sheet for a downloaded APK. The page asks the user first; the chooser is a second confirmation. */
    @JavascriptInterface fun shareApk(name: String): String {
        val f = File(File(act.cacheDir, "cloud_apk"), name.replace(Regex("[^A-Za-z0-9._-]"), "_"))
        if (!f.isFile) return "missing"
        return try {
            val uri = FileProvider.getUriForFile(act, act.packageName + ".fp", f)
            val i = Intent(Intent.ACTION_SEND).setType("application/vnd.android.package-archive").putExtra(Intent.EXTRA_STREAM, uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            act.runOnUiThread { try { act.startActivity(Intent.createChooser(i, "Share APK")) } catch (_: Throwable) { } }
            "ok"
        } catch (_: Throwable) { "error" }
    }

    // ------------------------------------------------------------------ background follow-up of cloud builds (CloudWatchService)
    /** The page calls this when a build was sent to GitHub (runId 0 = not known yet; the watcher finds it) and again when the run id is known. */
    @JavascriptInterface fun watchStart(buildId: String, ns: String, owner: String, repo: String, runId: Double, branch: String, kind: String, label: String) {
        try {
            val id = safeId(buildId)
            val nameOk = Regex("^[A-Za-z0-9_.-]{1,100}$")
            if (id.isEmpty() || !nameOk.matches(owner) || !nameOk.matches(repo)) return
            val k = if (kind == "release" || kind == "test") kind else "debug"
            val b = if (branch.length <= 200 && !branch.contains("..")) branch else ""
            CloudWatchStore.put(act, CloudWatchLogic.W(id, ns.take(40), owner, repo, runId.toLong(), b, k, label.take(60), System.currentTimeMillis()))
            act.runOnUiThread { try { ContextCompat.startForegroundService(act, Intent(act, CloudWatchService::class.java)) } catch (_: Throwable) { } }
        } catch (_: Throwable) { }
    }

    /** The page finished following this build itself (result saved), so the background watcher lets go of it. */
    @JavascriptInterface fun watchStop(buildId: String) { try { CloudWatchStore.remove(act, safeId(buildId)) } catch (_: Throwable) { } }

    /** Builds that finished while the app was closed: [{build_id, run_id, status, kind, artifact_id, apk:{...}}], handed over once. */
    @JavascriptInterface fun watchTake(ns: String): String = try { CloudWatchStore.take(act, ns.take(40)) } catch (_: Throwable) { "[]" }

    // ------------------------------------------------------------------ isolated preview
    @JavascriptInterface fun openPreview(title: String, html: String, width: Int): String {
        if (html.length > 2_000_000) return "too_big"
        CloudPreviewActivity.pendingHtml = html
        CloudPreviewActivity.pendingTitle = title.take(60)
        CloudPreviewActivity.pendingWidth = width
        act.runOnUiThread { try { act.startActivity(Intent(act, CloudPreviewActivity::class.java)) } catch (_: Throwable) { } }
        return "ok"
    }
}
