package com.a2z.ai

import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import org.json.JSONObject
import java.io.File
import java.security.KeyStore
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey

/** The encrypted GitHub token, readable by CloudBridge (page calls) and CloudWatchService (background follow-up). Never given to JavaScript. */
object CloudVault {
    private const val ALIAS = "zen_cloud_token_v1"

    fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore"); ks.load(null)
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val g = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        g.init(KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).setKeySize(256).build())
        return g.generateKey()
    }

    fun slot(ns: String): String = "tok_" + (if (Regex("^[A-Za-z0-9]{1,40}$").matches(ns)) ns else "local")

    fun token(ctx: Context, ns: String): String? = try {
        ctx.getSharedPreferences("a2z_cloud", Context.MODE_PRIVATE).getString(slot(ns), null)?.let { CloudCore.SecretBox(key()).open(it) }
    } catch (_: Exception) { null }
}

/** Saving a downloaded APK for the user and reading its details (shared by CloudBridge and the background watcher). */
object CloudFiles {
    fun saveToDownloads(ctx: Context, f: File, name: String): String =
        DownloadsSaver.save(ctx, name.replace(Regex("[^A-Za-z0-9._-]"), "_"), "application/vnd.android.package-archive", "Cloud Studio") { o -> f.inputStream().use { it.copyTo(o) } }

    /** Package name, version and signing certificate read by Android itself from the downloaded APK. */
    fun apkInfo(ctx: Context, f: File): JSONObject? {
        if (Build.VERSION.SDK_INT < 28) return null
        return try {
            val pi = ctx.packageManager.getPackageArchiveInfo(f.absolutePath, PackageManager.GET_SIGNING_CERTIFICATES) ?: return null
            val j = JSONObject().put("package", pi.packageName).put("versionName", pi.versionName ?: "").put("versionCode", pi.longVersionCode)
            val sigs = pi.signingInfo?.apkContentsSigners
            if (sigs != null && sigs.isNotEmpty()) {
                val md = java.security.MessageDigest.getInstance("SHA-256")
                j.put("certSha256", CloudCore.hex(md.digest(sigs[0].toByteArray())))
            }
            j
        } catch (_: Throwable) { null }
    }
}
