package com.a2z.ai

import org.json.JSONObject
import java.io.File
import java.net.URLEncoder

/**
 * Zen AI Cloud Studio: follows a GitHub Actions build natively, so it finishes even when the app was closed
 * (CloudWatchService runs this in the background; the page re-attaches when the app opens again).
 * Pure JVM on purpose (only org.json): unit-tested against a local fake GitHub in tools/jvm-harness.
 *
 * What the phone does on its own while the app is closed:
 *   1. finds the workflow run of the build, polls it until GitHub says "completed"
 *   2. on success of a debug/release build: downloads the APK artifact and saves it to Downloads
 *   3. tells the user with a notification
 * What stays with the page (it needs the AI provider keys that only the page has): log analysis, the AI fix loop. Those continue
 * the moment the app is opened again (CloudStudio resumeAll), and the build result is already known by then.
 */
object CloudWatchLogic {
    const val GIVE_UP_MS = 70L * 60 * 1000          // the page's own timeout is 50 minutes

    class W(val id: String, val ns: String, val owner: String, val repo: String, var runId: Long, val branch: String,
            val kind: String, val label: String, val startedAt: Long, var grace: Boolean = false) {
        fun toJson(): JSONObject = JSONObject().put("id", id).put("ns", ns).put("owner", owner).put("repo", repo).put("runId", runId)
            .put("branch", branch).put("kind", kind).put("label", label).put("startedAt", startedAt).put("grace", grace)
        companion object {
            fun fromJson(j: JSONObject): W = W(j.optString("id"), j.optString("ns"), j.optString("owner"), j.optString("repo"), j.optLong("runId", 0L),
                j.optString("branch"), j.optString("kind", "debug"), j.optString("label"), j.optLong("startedAt", 0L), j.optBoolean("grace", false))
        }
    }

    /** The Android side: token, foreground state, where files go. Faked in tests. */
    interface Host {
        fun token(ns: String): String?
        fun appForeground(): Boolean
        fun cacheDir(): File
        fun now(): Long
        /** Saves the APK for the user (Downloads) and returns {name,size,sha256,where,package,versionName,versionCode,certSha256}. */
        fun saveApk(f: File, name: String): JSONObject
        /** Persist changes made to w (run id found, grace used). */
        fun update(w: W)
    }

    class Outcome(val watch: W, val result: JSONObject, val title: String, val text: String)

    fun findRunId(json: String, buildId: String): Long {
        try {
            val arr = JSONObject(json).optJSONArray("workflow_runs") ?: return 0L
            for (i in 0 until arr.length()) {
                val r = arr.optJSONObject(i) ?: continue
                if ((r.optString("display_title") + " " + r.optString("name")).contains(buildId)) return r.optLong("id", 0L)
            }
        } catch (_: Exception) { }
        return 0L
    }

    /** Same naming rule as the page: release builds prefer the signed artifact, everything else uses cloud-apk-*. Expired artifacts are skipped. */
    fun pickArtifact(json: String, kind: String): Long {
        try {
            val arr = JSONObject(json).optJSONArray("artifacts") ?: return 0L
            var apk = 0L; var signed = 0L
            for (i in 0 until arr.length()) {
                val a = arr.optJSONObject(i) ?: continue
                if (a.optBoolean("expired", false)) continue
                val n = a.optString("name"); val id = a.optLong("id", 0L)
                if (n.startsWith("cloud-signed-")) signed = id else if (n.startsWith("cloud-apk-")) apk = id
            }
            return if (kind == "release" && signed != 0L) signed else apk
        } catch (_: Exception) { return 0L }
    }

    private fun gaveUp(w: W, why: String): Outcome =
        Outcome(w, JSONObject().put("build_id", w.id).put("run_id", w.runId).put("status", "gave_up").put("kind", w.kind),
            "Zen Ai · Cloud Studio", (if (w.label.isEmpty()) "Cloud build" else w.label) + ": " + why)

    /** One look at the build. Returns null while it is still running, otherwise the final outcome (watch can then be removed). */
    fun step(w: W, h: Host): Outcome? {
        val late = h.now() - w.startedAt > GIVE_UP_MS
        val token = h.token(w.ns) ?: return if (late) gaveUp(w, "could not be followed (GitHub token missing). Open Cloud Studio.") else null
        val base = "/repos/" + w.owner + "/" + w.repo + "/actions"
        if (w.runId == 0L) {
            val q = if (w.branch.isEmpty()) "" else "&branch=" + URLEncoder.encode(w.branch, "UTF-8")
            val r = CloudCore.request("GET", "$base/runs?event=workflow_dispatch&per_page=20$q", null, token)
            if (r.status == 200) { w.runId = findRunId(r.body, w.id); if (w.runId != 0L) h.update(w) }
            if (w.runId == 0L) return if (late) gaveUp(w, "was not started by GitHub. Open Cloud Studio.") else null
        }
        val rr = CloudCore.request("GET", "$base/runs/" + w.runId, null, token)
        if (rr.status != 200) return if (late) gaveUp(w, "could not be followed any more. Open Cloud Studio.") else null
        val run = try { JSONObject(rr.body) } catch (_: Exception) { return null }
        if (run.optString("status") != "completed") return if (late) gaveUp(w, "is taking too long. Open Cloud Studio.") else null
        // the page is open and following the same run: give it one more round to finish and call watchStop itself
        if (h.appForeground() && !w.grace) { w.grace = true; h.update(w); return null }

        val status = when (run.optString("conclusion")) { "success" -> "success"; "cancelled" -> "cancelled"; else -> "failed" }
        val name = if (w.label.isEmpty()) "Cloud build" else w.label
        val res = JSONObject().put("build_id", w.id).put("run_id", w.runId).put("status", status).put("kind", w.kind)
        var text: String
        if (status == "success") {
            text = if (w.kind == "test") "$name: emulator test finished. Open Cloud Studio for the screenshots." else "$name: build succeeded. Open Cloud Studio to get the APK."
            if (w.kind != "test") {
                try {
                    val ar = CloudCore.request("GET", "$base/runs/" + w.runId + "/artifacts?per_page=30", null, token)
                    val aid = if (ar.status == 200) pickArtifact(ar.body, w.kind) else 0L
                    if (aid != 0L) {
                        val s = CloudCore.downloadArtifact(w.owner, w.repo, aid, token, File(h.cacheDir(), "cloud_apk"))
                        if (s != null) {
                            val j = h.saveApk(s.file, s.name)
                            if (!j.has("sha256")) j.put("sha256", s.sha256)
                            res.put("artifact_id", aid).put("apk", j)
                            text = "$name: build succeeded. APK saved to " + j.optString("where", "Downloads") + "."
                        }
                    }
                } catch (_: Throwable) { /* the page can still download it from APK Manager */ }
            }
        } else if (status == "cancelled") {
            text = "$name: build was cancelled."
        } else {
            text = "$name: build failed. Open Cloud Studio to see the error and let the AI fix it."
        }
        return Outcome(w, res, "Zen Ai · Cloud Studio", text)
    }
}
