package com.a2z.ai

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Where the watched builds and their finished results are kept (survives the app being closed). */
object CloudWatchStore {
    private const val P = "a2z_cloud_watch"
    private fun sp(c: Context) = c.getSharedPreferences(P, Context.MODE_PRIVATE)

    @Synchronized fun list(c: Context): List<CloudWatchLogic.W> {
        val out = ArrayList<CloudWatchLogic.W>()
        try { val a = JSONArray(sp(c).getString("watch", "[]") ?: "[]"); for (i in 0 until a.length()) a.optJSONObject(i)?.let { out.add(CloudWatchLogic.W.fromJson(it)) } } catch (_: Exception) { }
        return out
    }
    private fun saveList(c: Context, l: List<CloudWatchLogic.W>) { val a = JSONArray(); for (w in l) a.put(w.toJson()); sp(c).edit().putString("watch", a.toString()).apply() }

    /** Adds a build, or updates its run id when it is already watched. */
    @Synchronized fun put(c: Context, w: CloudWatchLogic.W) {
        val l = list(c).toMutableList(); val i = l.indexOfFirst { it.id == w.id }
        if (i >= 0) { if (w.runId != 0L) l[i].runId = w.runId } else l.add(w)
        saveList(c, l.takeLast(10))
    }
    @Synchronized fun update(c: Context, w: CloudWatchLogic.W) { val l = list(c).toMutableList(); val i = l.indexOfFirst { it.id == w.id }; if (i >= 0) { l[i] = w; saveList(c, l) } }
    @Synchronized fun remove(c: Context, id: String) { saveList(c, list(c).filter { it.id != id }) }
    @Synchronized fun any(c: Context): Boolean = list(c).isNotEmpty()

    @Synchronized fun finish(c: Context, w: CloudWatchLogic.W, result: JSONObject) {
        val a = try { JSONArray(sp(c).getString("done", "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
        a.put(result.put("ns", w.ns))
        val keep = JSONArray(); val from = maxOf(0, a.length() - 20); for (i in from until a.length()) keep.put(a.get(i))
        sp(c).edit().putString("done", keep.toString()).apply()
        remove(c, w.id)
    }

    /** Results of builds that ended while the page was not following them; handed to the page once. Only this account's. */
    @Synchronized fun take(c: Context, ns: String): String {
        val a = try { JSONArray(sp(c).getString("done", "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
        val mine = JSONArray(); val rest = JSONArray()
        for (i in 0 until a.length()) { val o = a.optJSONObject(i) ?: continue; if (o.optString("ns") == ns) mine.put(o) else rest.put(o) }
        sp(c).edit().putString("done", rest.toString()).apply()
        return mine.toString()
    }
}

/**
 * Foreground service that follows watched cloud builds. It is not tied to the app's screen (stopWithTask=false), so a build that was
 * started from Zen Ai still reaches its end, the APK is saved, and you are notified, even if the app was closed from Recents.
 * Stops itself when nothing is watched any more.
 */
class CloudWatchService : Service() {
    @Volatile private var worker: Thread? = null
    @Volatile private var stopping = false
    private var wl: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    private fun openApp(): PendingIntent = PendingIntent.getActivity(
        this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NEW_TASK),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel(CH_WORK, "Cloud builds", NotificationManager.IMPORTANCE_LOW))
            nm.createNotificationChannel(NotificationChannel(CH_DONE, "Cloud build finished", NotificationManager.IMPORTANCE_DEFAULT))
            val n = Notification.Builder(this, CH_WORK).setSmallIcon(android.R.drawable.stat_notify_sync)
                .setContentTitle("Zen Ai is following your cloud build").setContentText("It keeps going even if you close the app.")
                .setOngoing(true).setContentIntent(openApp()).build()
            if (Build.VERSION.SDK_INT >= 34) startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC) else startForeground(NID, n)
            if (wl == null) {
                val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
                wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "zyn:cloudwatch").apply { setReferenceCounted(false) }
            }
            wl?.acquire(80L * 60 * 1000)
        } catch (_: Throwable) { stopSelf(); return START_NOT_STICKY }
        if (worker?.isAlive != true) {
            stopping = false
            worker = Thread({ loop() }, "cloud-watch").also { it.isDaemon = true; it.start() }
        }
        return START_STICKY
    }

    private val host = object : CloudWatchLogic.Host {
        override fun token(ns: String): String? = CloudVault.token(this@CloudWatchService, ns)
        override fun appForeground(): Boolean = FrameStore.appForeground && FrameStore.ownActivityVisible
        override fun cacheDir(): File = this@CloudWatchService.cacheDir
        override fun now(): Long = System.currentTimeMillis()
        override fun saveApk(f: File, name: String): JSONObject {
            val where = CloudFiles.saveToDownloads(this@CloudWatchService, f, name)
            val j = JSONObject().put("name", name).put("size", f.length()).put("sha256", CloudCore.sha256(f)).put("where", where)
            CloudFiles.apkInfo(this@CloudWatchService, f)?.let { i -> for (k in listOf("package", "versionName", "versionCode", "certSha256")) if (i.has(k)) j.put(k, i.get(k)) }
            return j
        }
        override fun update(w: CloudWatchLogic.W) { CloudWatchStore.update(this@CloudWatchService, w) }
    }

    private fun loop() {
        try {
            while (!stopping) {
                var idle = 0
                while (!stopping) {
                    val list = CloudWatchStore.list(this)
                    if (list.isEmpty()) { if (++idle >= 2) break } else idle = 0
                    for (w in list) {
                        try {
                            val o = CloudWatchLogic.step(w, host) ?: continue
                            CloudWatchStore.finish(this, w, o.result)
                            notifyDone(w, o.title, o.text)
                        } catch (_: Throwable) { /* try again next round */ }
                    }
                    try { Thread.sleep(POLL_MS) } catch (_: InterruptedException) { }
                }
                if (!CloudWatchStore.any(this)) break      // a build may have been added just now: look again before stopping
            }
        } finally {
            try { wl?.let { if (it.isHeld) it.release() } } catch (_: Throwable) { }
            try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (_: Throwable) { }
            stopSelf()
        }
    }

    private fun notifyDone(w: CloudWatchLogic.W, title: String, text: String) {
        try {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val n = Notification.Builder(this, CH_DONE).setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title).setContentText(text).setStyle(Notification.BigTextStyle().bigText(text))
                .setContentIntent(openApp()).setAutoCancel(true).build()
            nm.notify(9100 + (w.id.hashCode() and 0xFFF), n)
        } catch (_: Throwable) { }
    }

    override fun onDestroy() {
        stopping = true
        try { wl?.let { if (it.isHeld) it.release() } } catch (_: Throwable) { }
        super.onDestroy()
    }

    companion object {
        private const val CH_WORK = "a2z_cloudwatch"
        private const val CH_DONE = "a2z_cloud_done"
        private const val NID = 10
        private const val POLL_MS = 15_000L
    }
}
