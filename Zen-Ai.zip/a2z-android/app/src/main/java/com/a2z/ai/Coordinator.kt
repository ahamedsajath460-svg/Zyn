package com.a2z.ai

/** One step of a plan: which agent does what. */
class PlanStep(val role: Role, val input: String) { val key get() = role.name + ":" + input.trim().lowercase().take(80) }

object PlanParser {
    private val ALLOWED = setOf(Role.RESEARCH, Role.CODING, Role.VISION, Role.SCREEN_INTERACTION, Role.TASK_EXECUTION, Role.CONVERSATION)
    private val NAMES = mapOf("research" to Role.RESEARCH, "coding" to Role.CODING, "code" to Role.CODING, "vision" to Role.VISION, "screen" to Role.SCREEN_INTERACTION,
        "screen_interaction" to Role.SCREEN_INTERACTION, "task_execution" to Role.TASK_EXECUTION, "execution" to Role.TASK_EXECUTION, "execute" to Role.TASK_EXECUTION,
        "conversation" to Role.CONVERSATION, "chat" to Role.CONVERSATION)

    /** Reads {"steps":[{"agent":"research","input":"..."}]} from model text. Unknown agents, empty inputs and more than 6 steps are dropped. Empty list = unusable. */
    fun parse(text: String): List<PlanStep> {
        val clean = text.replace("```json", "").replace("```", "")
        for (c in AgentActions.candidates(clean)) {
            val o = try { org.json.JSONObject(c) } catch (_: Throwable) { continue }
            val arr = o.optJSONArray("steps") ?: continue
            val out = ArrayList<PlanStep>()
            for (i in 0 until arr.length()) {
                val s = arr.optJSONObject(i) ?: continue
                val role = NAMES[s.optString("agent").trim().lowercase().replace(' ', '_').replace('-', '_')] ?: continue
                val input = s.optString("input").trim()
                if (role !in ALLOWED || input.isEmpty() || input.length > 1500) continue
                if (out.any { it.role == role && it.input.equals(input, true) }) continue
                out.add(PlanStep(role, input))
                if (out.size >= 6) break
            }
            if (out.isNotEmpty()) return out
        }
        return emptyList()
    }

    /** Deterministic plan from the intent when the planner is unavailable or returns nothing usable. */
    fun fallback(request: String, sel: Orchestrator.Selection, screenLinked: Boolean): List<PlanStep> = when (sel.intent) {
        Orchestrator.Intent.DEVICE_ACTION -> listOf(PlanStep(Role.TASK_EXECUTION, request))
        Orchestrator.Intent.SCREEN_QUESTION -> listOf(if (screenLinked) PlanStep(Role.VISION, request) else PlanStep(Role.SCREEN_INTERACTION, request))
        Orchestrator.Intent.RESEARCH -> listOf(PlanStep(Role.RESEARCH, request))
        Orchestrator.Intent.CODE -> listOf(PlanStep(Role.CODING, request))
        Orchestrator.Intent.CHAT -> listOf(PlanStep(Role.CONVERSATION, request))
    }
}

/**
 * Runs the workflow  Request -> Conversation -> Planning -> Research / Vision / Coding (in parallel) -> Task Execution (one at a time) -> Verification -> Final answer.
 * All steps go through [AgentRuntime] (real agent executions with timeouts, guards and a message trail). Pure Kotlin; agents are injected.
 */
class Coordinator(private val rt: AgentRuntime) {
    class Outcome(val ok: Boolean, val text: String, val sources: List<Pair<String, String>>, val issues: List<String>)

    fun run(ctx: AgentCtx, request: String, screenLinked: Boolean): Outcome {
        val sel = Orchestrator.select(request, screenLinked)
        val issues = ArrayList<String>()
        // 1) Conversation Agent answers plain conversation directly.
        if (sel.intent == Orchestrator.Intent.CHAT) {
            TaskManager.setAgent(Role.CONVERSATION.name)
            val r = rt.delegate(ctx, emptyList(), Role.CONVERSATION, request)
            return Outcome(r.ok, if (r.ok) r.text else r.error, r.sources, emptyList())
        }
        // 2) Planning Agent proposes the steps. If it fails or returns nothing usable, the intent-based plan is used (recovery).
        var steps: List<PlanStep> = emptyList()
        if (sel.complexity != Orchestrator.Complexity.SIMPLE && rt.has(Role.PLANNING)) {
            TaskManager.to(TaskState.PLANNING); TaskManager.setAgent(Role.PLANNING.name)
            val p = rt.delegate(ctx, emptyList(), Role.PLANNING, "REQUEST: $request\nSCREEN SHARING: ${if (screenLinked) "on" else "off"}")
            if (p.ok) steps = PlanParser.parse(p.text) else issues.add("Planner failed (${p.error}); used a standard plan.")
            if (ctx.cancelled) return Outcome(false, "Cancelled.", emptyList(), issues)
        }
        if (steps.isEmpty()) steps = PlanParser.fallback(request, sel, screenLinked)
        // steps for roles that are not registered are dropped, with a note
        steps = steps.filter { s -> if (rt.has(s.role)) true else { issues.add("${s.role.title} is not available."); false } }
        if (steps.isEmpty()) return Outcome(false, "No agent is available for this request.", emptyList(), issues)
        TaskManager.to(TaskState.AGENT_SELECTION)

        // 3) read-only agents together, in parallel
        val reads = steps.withIndex().filter { !it.value.role.canTouchDevice }
        val acts = steps.withIndex().filter { it.value.role.canTouchDevice }
        val results = HashMap<Int, AgentResult>()
        if (reads.isNotEmpty()) {
            TaskManager.to(TaskState.EXECUTING)
            TaskManager.setAgent(reads.joinToString("+") { it.value.role.name })
            val rr = rt.parallel(ctx, emptyList(), reads.map { it.value.role to it.value.input })
            for ((k, v) in reads.withIndex()) {
                results[v.index] = rr[k]
                if (rr[k].ok) ctx.blackboard["step${v.index + 1}"] = rr[k].text
                TaskManager.checkpoint("read:" + v.value.key, rr[k].ok, if (rr[k].ok) "" else rr[k].error)
            }
        }
        // 4) agents that act on the phone: one after another, stop at the first failure
        val act = TaskManager.active
        for (v in acts) {
            if (ctx.cancelled) return Outcome(false, "Cancelled.", emptyList(), issues)
            val key = "act:" + v.value.key
            if (act != null && key in act.resumeDone) { results[v.index] = AgentResult(true, "Already done before the app stopped (verified): ${v.value.input.take(80)}"); issues.add("Skipped a step that was already verified."); continue }
            if (act != null && key in act.resumeUnsure) {
                results[v.index] = AgentResult.fail("This step may already have been done before the app stopped, so it was not repeated. Check the phone, then retry the task.")
                break
            }
            // data from earlier agents can be used in the device step: {{step1}}
            var input = v.value.input
            for ((k, t) in ctx.blackboard) input = input.replace("{{$k}}", t.take(500))
            TaskManager.to(TaskState.EXECUTING); TaskManager.setAgent(v.value.role.name)
            TaskManager.checkpoint(key, false, "started")
            val r = rt.delegate(ctx, emptyList(), v.value.role, input, 5 * 60_000L)
            results[v.index] = r
            TaskManager.to(TaskState.VERIFYING)
            if (r.ok) TaskManager.checkpoint(key, true, "verified") else { break }
        }
        if (ctx.cancelled) return Outcome(false, "Cancelled.", emptyList(), issues)

        // 5) verification
        TaskManager.to(TaskState.VERIFYING)
        val ordered = steps.indices.mapNotNull { i -> results[i]?.let { i to it } }
        issues.addAll(verify(steps, results))
        val allOk = ordered.isNotEmpty() && ordered.all { it.second.ok } && ordered.size == steps.size
        val srcs = LinkedHashMap<String, String>()
        for ((_, r) in ordered) for ((t, u) in r.sources) srcs.putIfAbsent(u, t)
        val sourceList = srcs.map { it.value to it.key }

        // 6) final answer: one result is returned as it is; several are combined by the Conversation Agent (plain join if that fails)
        val okTexts = ordered.filter { it.second.ok }.map { it.second.text }
        val body = when {
            okTexts.isEmpty() -> ordered.firstOrNull { !it.second.ok }?.second?.error ?: "Nothing was done."
            okTexts.size == 1 && allOk -> okTexts[0]
            else -> {
                var composed: String? = null
                if (rt.has(Role.CONVERSATION) && okTexts.size > 1 && !ctx.cancelled) {
                    TaskManager.setAgent(Role.CONVERSATION.name)
                    val c = rt.delegate(ctx, emptyList(), Role.CONVERSATION, "COMBINE these results into one clear answer for the user. Keep source numbers.\nREQUEST: $request\n\n" + okTexts.mapIndexed { i, t -> "RESULT ${i + 1}:\n$t" }.joinToString("\n\n"))
                    if (c.ok) composed = c.text else issues.add("Could not combine the results (${c.error}); showing them one after another.")
                }
                val failMsg = ordered.firstOrNull { !it.second.ok }?.second?.error
                (composed ?: okTexts.joinToString("\n\n")) + (if (failMsg != null) "\n\nNot completed: $failMsg" else "")
            }
        }
        return Outcome(allOk, body, sourceList, issues)
    }

    /** Result verification: every result must be non-empty, research needs sources, a failed step is reported. Returns the problems found. */
    fun verify(steps: List<PlanStep>, results: Map<Int, AgentResult>): List<String> {
        val out = ArrayList<String>()
        for ((i, s) in steps.withIndex()) {
            val r = results[i]
            if (r == null) { out.add("${s.role.title}: not run (an earlier step failed)"); continue }
            if (!r.ok) { out.add("${s.role.title}: ${r.error}"); continue }
            if (s.role == Role.RESEARCH && r.sources.isEmpty()) out.add("Research has no sources: treat the answer as unverified.")
        }
        return out
    }
}
