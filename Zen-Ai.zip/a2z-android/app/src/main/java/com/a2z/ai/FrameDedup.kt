package com.a2z.ai

/**
 * Frame deduplication for screen sharing (5.1). Works on two small grayscale grids that the capture code makes from the frame (no Android classes here):
 *  - a 9x8 grid -> 64-bit difference hash (dHash) for "is this basically the same screen?" (Hamming distance, configurable threshold);
 *  - a 32x32 grid compared cell by cell to catch LOCAL changes such as one changed line of text, which a global hash misses. If at least [minChangedCells] cells changed, the frame is kept.
 * Rules: never skip the first frame, a rotation / size change, a frame whose hash differs by more than the threshold, a frame with a local change (text), a frame whose OCR text signature
 * changed (when the caller has one), or any frame after [maxSkipMs] without a kept frame (so the model never works from a stale screen). Everything else is dropped.
 * Limit: a change smaller than a few grid cells (for example one blinking cursor) can be missed; the text signature check covers it when OCR text is available.
 */
class FrameDedup(var threshold: Int = 5, var minChangedCells: Int = 3, var cellDelta: Int = 24, var maxSkipMs: Long = 5_000L) {
    enum class Decision { KEEP_FIRST, KEEP_ROTATED, KEEP_CHANGED, KEEP_TEXT, KEEP_REFRESH, SKIP }
    private var lastHash = 0L; private var lastGrid: IntArray? = null; private var lastW = 0; private var lastH = 0; private var lastText: String? = null; private var lastKept = 0L
    var kept = 0; private set
    var skipped = 0; private set

    @Synchronized fun reset() { lastGrid = null; lastText = null; lastW = 0; lastH = 0; lastHash = 0L; lastKept = 0L; kept = 0; skipped = 0 }

    @Synchronized fun decide(w: Int, h: Int, hash: Long, grid: IntArray, textSig: String?, now: Long): Decision {
        val prev = lastGrid
        val d: Decision = when {
            prev == null -> Decision.KEEP_FIRST
            w != lastW || h != lastH -> Decision.KEEP_ROTATED
            textSig != null && lastText != null && textSig != lastText -> Decision.KEEP_TEXT
            hamming(hash, lastHash) > threshold -> Decision.KEEP_CHANGED
            changedCells(prev, grid) >= minChangedCells -> Decision.KEEP_TEXT
            now - lastKept >= maxSkipMs -> Decision.KEEP_REFRESH
            else -> Decision.SKIP
        }
        if (d == Decision.SKIP) { skipped++; return d }
        kept++; lastHash = hash; lastGrid = grid; lastW = w; lastH = h; lastKept = now; if (textSig != null) lastText = textSig
        return d
    }

    private fun changedCells(a: IntArray, b: IntArray): Int { if (a.size != b.size) return a.size; var n = 0; for (i in a.indices) if (Math.abs(a[i] - b[i]) > cellDelta) n++; return n }

    companion object {
        fun hamming(a: Long, b: Long) = java.lang.Long.bitCount(a xor b)
        /** dHash from a 9 wide x 8 high grayscale grid (row-major, 72 values 0..255): bit = left pixel brighter than its right neighbour. */
        fun dHash(g: IntArray): Long { require(g.size == 72) { "need 9x8 grid" }; var h = 0L; var bit = 0; for (y in 0 until 8) for (x in 0 until 8) { if (g[y * 9 + x] > g[y * 9 + x + 1]) h = h or (1L shl bit); bit++ }; return h }
    }
}
