package com.a2z.ai

import java.security.MessageDigest

/**
 * Several API keys for ONE provider, rotated round-robin (5.1). Extends [ProviderRouter]: the router decides WHICH provider, this decides which KEY of it.
 *  - 429 / quota: the key is cooled down (60 s x consecutive rate limits, max 4x) and the next key is used; it recovers by itself when the cooldown ends.
 *  - 401 / 403 / invalid key: the key is marked INVALID and is skipped until the user edits or re-enables it. It is never retried automatically (no key hammering).
 *  - Network / 5xx errors are not the key's fault: short cooldown only, and they do not count against the key's health.
 *  - Manual mode: always the first enabled key (the user chooses the order); auto mode: round-robin.
 * Rate limits are respected, never bypassed: when every key is cooling, [next] returns null and the caller must wait or fall back to another provider.
 * Key values stay in memory in this object and are never returned by [statusJson] (only "Key N" and a fingerprint); no logging. Pure Kotlin, JVM testable.
 */
object KeyPool {
    class Entry(val key: String) {
        val fp: String = fingerprint(key)
        var enabled = true; var invalid = false
        var ok = 0; var fail = 0; var rateHits = 0; var streak = 0
        var coolUntil = 0L; var lastMs = 0L; var lastUsed = 0L; var lastErr = ProviderRouter.Err.NONE
    }
    private class Pool { val keys = ArrayList<Entry>(); var cursor = 0 }

    private val pools = HashMap<String, Pool>()
    @Volatile var auto = true

    fun fingerprint(k: String): String { val d = MessageDigest.getInstance("SHA-256").digest(k.toByteArray()); return d.take(3).joinToString("") { "%02x".format(it) } }

    /** Replace the key list of a provider. Stats of keys that are still present are kept (matched by value). Blank and duplicate keys are dropped. */
    @Synchronized fun set(providerId: String, keys: List<String>) {
        val p = pools.getOrPut(providerId) { Pool() }
        val old = p.keys.associateBy { it.key }
        val next = ArrayList<Entry>()
        for (k in keys.map { it.trim() }.filter { it.isNotEmpty() }.distinct()) next.add(old[k] ?: Entry(k))
        p.keys.clear(); p.keys.addAll(next); if (p.cursor >= next.size) p.cursor = 0
    }

    @Synchronized fun size(providerId: String): Int = pools[providerId]?.keys?.size ?: 0
    @Synchronized fun setEnabled(providerId: String, index: Int, on: Boolean) { pools[providerId]?.keys?.getOrNull(index)?.let { it.enabled = on; if (on) { it.invalid = false; it.coolUntil = 0L; it.streak = 0 } } }
    @Synchronized fun remove(providerId: String, index: Int) { pools[providerId]?.let { if (index in it.keys.indices) { it.keys.removeAt(index); if (it.cursor >= it.keys.size) it.cursor = 0 } } }
    @Synchronized fun edit(providerId: String, index: Int, newKey: String) { val p = pools[providerId] ?: return; if (index in p.keys.indices && newKey.isNotBlank()) p.keys[index] = Entry(newKey.trim()) }
    @Synchronized fun reset() { pools.clear() }

    private fun usable(e: Entry, now: Long) = e.enabled && !e.invalid && e.coolUntil <= now

    /** The key to use now, or null when every key is disabled, invalid or cooling (do not retry: wait or use another provider). */
    @Synchronized fun next(providerId: String, now: Long): Entry? {
        val p = pools[providerId] ?: return null
        val n = p.keys.size; if (n == 0) return null
        if (!auto) return p.keys.firstOrNull { usable(it, now) }?.also { it.lastUsed = now }
        for (i in 0 until n) {
            val e = p.keys[(p.cursor + i) % n]
            if (usable(e, now)) { p.cursor = (p.cursor + i + 1) % n; e.lastUsed = now; return e }
        }
        return null
    }

    /** Seconds until some key is usable again (0 = one is usable now, -1 = none will recover without user action). */
    @Synchronized fun waitMs(providerId: String, now: Long): Long {
        val p = pools[providerId] ?: return -1
        val c = p.keys.filter { it.enabled && !it.invalid }
        if (c.isEmpty()) return -1
        return maxOf(0L, c.minOf { it.coolUntil } - now)
    }

    @Synchronized fun success(providerId: String, e: Entry, ms: Long) { if (pools[providerId]?.keys?.contains(e) != true) return; e.ok++; e.streak = 0; e.lastMs = ms; e.lastErr = ProviderRouter.Err.NONE; e.coolUntil = 0L }

    /** Records a failed call for this key. Returns the error class. */
    @Synchronized fun failure(providerId: String, e: Entry, msg: String?, now: Long): ProviderRouter.Err {
        val c = ProviderRouter.classify(msg)
        if (pools[providerId]?.keys?.contains(e) != true) return c
        e.lastErr = c
        when (c) {
            ProviderRouter.Err.AUTH -> { e.fail++; e.invalid = true }
            ProviderRouter.Err.RATE_LIMIT -> { e.fail++; e.rateHits++; e.streak++; e.coolUntil = now + 60_000L * e.streak.coerceIn(1, 4) }
            ProviderRouter.Err.TRANSIENT -> { e.coolUntil = now + 5_000L }
            else -> { e.fail++; e.coolUntil = now + 10_000L }
        }
        return c
    }

    /** Per-key status for the UI. Never contains the key itself. */
    @Synchronized fun statusJson(providerId: String, now: Long): org.json.JSONArray {
        val a = org.json.JSONArray()
        pools[providerId]?.keys?.forEachIndexed { i, e ->
            val st = when { !e.enabled -> "disabled"; e.invalid -> "invalid"; e.coolUntil > now -> "cooling"; else -> "ready" }
            a.put(org.json.JSONObject().put("name", "Key ${i + 1}").put("fp", e.fp).put("state", st).put("ok", e.ok).put("fail", e.fail).put("rate", e.rateHits)
                .put("coolSec", maxOf(0L, (e.coolUntil - now) / 1000)).put("lastMs", e.lastMs))
        }
        return a
    }

    /** Provider copy that carries the chosen key, so [FloatAi] is used unchanged. Null = no key of this provider is usable now. A provider with no pool keeps its single key. */
    fun pick(p: FProvider, now: Long): Pair<FProvider, Entry?>? {
        if (size(p.id) == 0) return p to null
        val e = next(p.id, now) ?: return null
        return FProvider(p.id, p.name, p.type, p.base, p.model, e.key) to e
    }

    /**
     * Runs [block] with a copy of [p] that carries a pooled key. A rate-limited or rejected key is marked and the next key is tried (at most one try per key, no loops);
     * other errors are not the key's fault and are thrown as they are. When every key is cooling or invalid it throws a readable error instead of retrying.
     */
    fun <T> call(p: FProvider, block: (FProvider) -> T): T {
        val tries = maxOf(1, size(p.id)); var last: IllegalStateException? = null
        for (i in 0 until tries) {
            val now = System.currentTimeMillis()
            val pk = pick(p, now) ?: throw (last ?: IllegalStateException("All API keys of this provider are cooling down or invalid. Wait a moment or add another key."))
            val e = pk.second
            try { val r = block(pk.first); if (e != null) success(p.id, e, System.currentTimeMillis() - now); return r }
            catch (x: IllegalStateException) {
                if (e == null) throw x
                val c = failure(p.id, e, x.message, System.currentTimeMillis()); last = x
                if (c != ProviderRouter.Err.RATE_LIMIT && c != ProviderRouter.Err.AUTH) throw x
            }
        }
        throw last ?: IllegalStateException("The AI did not answer.")
    }
}
