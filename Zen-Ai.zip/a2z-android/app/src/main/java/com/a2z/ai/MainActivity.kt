package com.a2z.ai
import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.content.ActivityNotFoundException
import android.net.Uri
import android.provider.Settings
import android.provider.CalendarContract
import android.content.ContentValues
import androidx.appcompat.app.AlertDialog
import android.os.Build
import android.os.Bundle
import android.speech.SpeechRecognizer
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.ConnectionResult
import com.google.android.gms.common.GoogleApiAvailability
import com.google.android.gms.common.api.ApiException
import android.webkit.*
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.webkit.WebViewAssetLoader
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private var printWv: WebView? = null   // keeps the off-screen print WebView alive while the Android print dialog is open
    private var pendingInterval = 1000; private var pendingQuality = 75
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private var awaitingOverlay = false
    // ---- Google sign-in (additive): native account picker -> ID token -> Firebase JS Auth in the page ----
    private var gsc: GoogleSignInClient? = null
    private fun authEmit(type: String, data: String) {
        if (!::web.isInitialized) return
        web.post { web.evaluateJavascript("window.__fba&&window.__fba(" + JSONObject.quote(type) + "," + JSONObject.quote(data) + ")", null) }
    }
    private val signInLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        try {
            val t = GoogleSignIn.getSignedInAccountFromIntent(r.data).getResult(ApiException::class.java).idToken
            if (t.isNullOrEmpty()) authEmit("error", "Google did not return an ID token. Check the Web client ID in firebase-config.js.") else authEmit("token", t)
        } catch (e: ApiException) {
            when (e.statusCode) {
                12501 -> authEmit("cancelled", "")
                7 -> authEmit("error", "Network error during Google sign-in. Check your connection.")
                10 -> authEmit("error", "Developer error (code 10): the app's SHA-1/SHA-256 or the Web client ID in firebase-config.js does not match your Firebase project.")
                else -> authEmit("error", "Google sign-in failed (code ${e.statusCode}).")
            }
        } catch (e: Exception) { authEmit("error", "Google sign-in failed: ${e.message}") }
    }
    private fun googleClient(webClientId: String): GoogleSignInClient {
        val b = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN).requestEmail().requestProfile()
        if (webClientId.isNotBlank()) b.requestIdToken(webClientId)
        return GoogleSignIn.getClient(this, b.build()).also { gsc = it }
    }
    // ---- Native speech recognition (additive) ----
    private var speech: NativeSpeech? = null
    private var pendingSttLang = "en-US"
    private var pendingSttFast = false   // voice conversation: ask the recognizer to decide you finished sooner
    private fun speechEmit(type: String, data: String) {
        if (!::web.isInitialized) return
        web.post { web.evaluateJavascript("window.__nsr&&window.__nsr(" + JSONObject.quote(type) + "," + JSONObject.quote(data) + ")", null) }
    }
    private fun ns(): NativeSpeech = speech ?: NativeSpeech(this) { t, d -> speechEmit(t, d) }.also { speech = it }
    private val micPermLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        permChanged()
        if (ok) ns().start(pendingSttLang, pendingSttFast)
        else speechEmit("perm_denied", if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.RECORD_AUDIO)) "ask" else "settings")
    }

    // ---- Native TextToSpeech + screen vision (additive) ----
    private var tts: NativeTts? = null
    private fun ttsEmit(type: String, data: String) {
        if (!::web.isInitialized) return
        web.post { web.evaluateJavascript("window.__ntts&&window.__ntts(" + JSONObject.quote(type) + "," + JSONObject.quote(data) + ")", null) }
    }
    private fun nt(): NativeTts = tts ?: NativeTts(this) { t, d -> ttsEmit(t, d) }.also { tts = it }

    private val projectionLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK && r.data != null) {
            ContextCompat.startForegroundService(this, Intent(this, ScreenCaptureService::class.java).apply {
                action = ScreenCaptureService.START
                putExtra(ScreenCaptureService.CODE, r.resultCode); putExtra(ScreenCaptureService.DATA, r.data)
                putExtra(ScreenCaptureService.INTERVAL, pendingInterval); putExtra(ScreenCaptureService.QUALITY, pendingQuality)
            })
        } else Toast.makeText(this, "Screen sharing permission was declined", Toast.LENGTH_SHORT).show()
    }
    private val fileLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data)); fileCb = null
    }

    // ---- Location (WebView geolocation) + Calendar (read/write through CalendarContract) ----
    private var geoCb: GeolocationPermissions.Callback? = null
    private var geoOrigin: String = ""
    private val locLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        val ok = r.values.any { it }
        try { geoCb?.invoke(geoOrigin, ok, false) } catch (_: Exception) { }
        geoCb = null
        permChanged()
    }
    private val calLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        val ok = r.isNotEmpty() && r.values.all { it }
        if (::web.isInitialized) web.post { web.evaluateJavascript("window.__calPerm&&window.__calPerm(" + ok + ")", null) }
        permChanged()
    }
    private fun permOk(p: String) = ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    // ---- Real device location for the AI: newest last-known fix, else one fresh fix. The answer goes back to the page through window.__locDone(id, json) ----
    private fun locSend(id: String, json: String) {
        if (!::web.isInitialized) return
        val safeId = id.replace(Regex("[^A-Za-z0-9_]"), "")
        web.post { web.evaluateJavascript("window.__locDone&&window.__locDone('" + safeId + "'," + JSONObject.quote(json) + ")", null) }
    }

    @Suppress("DEPRECATION")
    @SuppressLint("MissingPermission")
    private fun locFetch(id: String) {
        if (!(permOk(Manifest.permission.ACCESS_FINE_LOCATION) || permOk(Manifest.permission.ACCESS_COARSE_LOCATION))) {
            locSend(id, "{\"ok\":false,\"err\":\"denied\"}"); return
        }
        val lm = getSystemService(android.content.Context.LOCATION_SERVICE) as? android.location.LocationManager
        val enabled: List<String> = if (lm == null) emptyList() else lm.getProviders(true)
        if (lm == null || enabled.isEmpty()) { locSend(id, "{\"ok\":false,\"err\":\"off\"}"); return }
        fun pack(l: android.location.Location): String =
            JSONObject().put("ok", true).put("lat", l.latitude).put("lon", l.longitude)
                .put("acc", l.accuracy.toDouble()).put("age", System.currentTimeMillis() - l.time).toString()
        val last: android.location.Location? = enabled
            .mapNotNull { p -> try { lm.getLastKnownLocation(p) } catch (_: Throwable) { null } }
            .maxByOrNull { it.time }
        if (last != null && System.currentTimeMillis() - last.time < 120000L) { locSend(id, pack(last)); return }
        var done = false
        fun deliver(l: android.location.Location?) {
            if (done) return
            done = true
            val r = l ?: last
            locSend(id, if (r != null) pack(r) else "{\"ok\":false,\"err\":\"timeout\"}")
        }
        val prov: String = when {
            enabled.contains(android.location.LocationManager.NETWORK_PROVIDER) -> android.location.LocationManager.NETWORK_PROVIDER
            enabled.contains(android.location.LocationManager.GPS_PROVIDER) && permOk(Manifest.permission.ACCESS_FINE_LOCATION) -> android.location.LocationManager.GPS_PROVIDER
            else -> enabled[0]
        }
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({ deliver(null) }, 12000L)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                lm.getCurrentLocation(prov, null, ContextCompat.getMainExecutor(this)) { l -> deliver(l) }
            } else {
                lm.requestSingleUpdate(prov, object : android.location.LocationListener {
                    override fun onLocationChanged(location: android.location.Location) { deliver(location) }
                    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
                    override fun onProviderEnabled(provider: String) {}
                    override fun onProviderDisabled(provider: String) {}
                }, android.os.Looper.getMainLooper())
            }
        } catch (_: Throwable) { deliver(null) }
    }

    // ---- Real permission state + requests: the ONLY source the Permissions page reads (nothing is assumed or faked) ----
    private val permPrefs by lazy { getSharedPreferences("a2z_perm", android.content.Context.MODE_PRIVATE) }
    private fun permAsked(k: String) = permPrefs.edit().putBoolean("asked_$k", true).apply()
    /** Tells the page that some permission changed, so every status on screen is re-read from Android. */
    private fun permChanged() { if (::web.isInitialized) web.post { web.evaluateJavascript("window.__permChanged&&window.__permChanged()", null) } }
    private fun permList(k: String): Array<String> = when (k) {
        "mic" -> arrayOf(Manifest.permission.RECORD_AUDIO)
        "cam" -> arrayOf(Manifest.permission.CAMERA)
        "loc" -> arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
        "calr" -> arrayOf(Manifest.permission.READ_CALENDAR)
        "calw" -> arrayOf(Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR)
        "notif" -> if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.POST_NOTIFICATIONS) else emptyArray()
        else -> emptyArray()
    }
    private fun permGranted(k: String): Boolean = when (k) {
        "mic" -> permOk(Manifest.permission.RECORD_AUDIO)
        "cam" -> permOk(Manifest.permission.CAMERA)
        "loc" -> permOk(Manifest.permission.ACCESS_FINE_LOCATION) || permOk(Manifest.permission.ACCESS_COARSE_LOCATION)
        "calr" -> permOk(Manifest.permission.READ_CALENDAR)
        "calw" -> permOk(Manifest.permission.READ_CALENDAR) && permOk(Manifest.permission.WRITE_CALENDAR)
        "notif" -> androidx.core.app.NotificationManagerCompat.from(this).areNotificationsEnabled()
        "overlay" -> FloatPerm.has(this)
        "acc" -> AIAccessibilityService.connected()
        else -> false
    }
    /** granted | ask (Android can still show its pop-up, or the user must switch it on in Settings) | blocked (only phone Settings can change it). */
    private fun permState(k: String): String {
        if (permGranted(k)) return "granted"
        if (k == "overlay" || k == "acc") return "ask"
        if (k == "notif" && (Build.VERSION.SDK_INT < 33 || permOk(Manifest.permission.POST_NOTIFICATIONS))) return "blocked"
        val canAsk = permList(k).any { ActivityCompat.shouldShowRequestPermissionRationale(this, it) }
        return if (!permPrefs.getBoolean("asked_$k", false) || canAsk) "ask" else "blocked"
    }
    private fun openAppSettings(k: String) {
        try {
            if (k == "notif" && Build.VERSION.SDK_INT >= 26) startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName))
            else startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        } catch (_: Exception) { try { startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (_: Exception) { } }
    }
    private val genPermLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { permChanged() }

    // WebView camera / microphone requests (getUserMedia): granted ONLY for what Android really allows
    private var webReq: PermissionRequest? = null
    private val webPermLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        val r = webReq; webReq = null
        if (r != null) answerWebReq(r)
        permChanged()
    }
    private fun answerWebReq(req: PermissionRequest) {
        val ok = req.resources.filter {
            when (it) {
                PermissionRequest.RESOURCE_AUDIO_CAPTURE -> permOk(Manifest.permission.RECORD_AUDIO)
                PermissionRequest.RESOURCE_VIDEO_CAPTURE -> permOk(Manifest.permission.CAMERA)
                else -> false
            }
        }.toTypedArray()
        try { if (ok.isEmpty()) req.deny() else req.grant(ok) } catch (_: Exception) { }
    }
    private fun calEventsJson(days: Int): String {
        val out = JSONArray()
        if (!permOk(Manifest.permission.READ_CALENDAR)) return out.toString()
        try {
            val now = System.currentTimeMillis()
            val end = now + days.coerceIn(1, 90) * 86400000L
            val proj = arrayOf(CalendarContract.Instances.TITLE, CalendarContract.Instances.BEGIN, CalendarContract.Instances.END, CalendarContract.Instances.EVENT_LOCATION, CalendarContract.Instances.ALL_DAY)
            val c = CalendarContract.Instances.query(contentResolver, proj, now, end)
            if (c != null) {
                try {
                    while (c.moveToNext() && out.length() < 40) {
                        out.put(JSONObject().put("title", c.getString(0) ?: "").put("start", c.getLong(1)).put("end", c.getLong(2)).put("loc", c.getString(3) ?: "").put("allDay", c.getInt(4) == 1))
                    }
                } finally { c.close() }
            }
        } catch (_: Exception) { }
        return out.toString()
    }
    private fun calAddEvent(title: String, startMs: Long, endMs: Long, desc: String, loc: String): String {
        if (!permOk(Manifest.permission.READ_CALENDAR) || !permOk(Manifest.permission.WRITE_CALENDAR)) return "Calendar permission is not allowed"
        try {
            var calId = -1L
            val c = contentResolver.query(CalendarContract.Calendars.CONTENT_URI, arrayOf(CalendarContract.Calendars._ID), CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL + " >= ?", arrayOf("500"), null)
            if (c != null) { try { if (c.moveToFirst()) calId = c.getLong(0) } finally { c.close() } }
            if (calId < 0) return "No calendar on this phone can save events"
            val v = ContentValues()
            v.put(CalendarContract.Events.DTSTART, startMs)
            v.put(CalendarContract.Events.DTEND, endMs)
            v.put(CalendarContract.Events.TITLE, title)
            v.put(CalendarContract.Events.DESCRIPTION, desc)
            v.put(CalendarContract.Events.EVENT_LOCATION, loc)
            v.put(CalendarContract.Events.CALENDAR_ID, calId)
            v.put(CalendarContract.Events.EVENT_TIMEZONE, java.util.TimeZone.getDefault().id)
            return if (contentResolver.insert(CalendarContract.Events.CONTENT_URI, v) != null) "ok" else "Could not save the event"
        } catch (e: Exception) { return "Calendar error: " + (e.message ?: "unknown") }
    }


    // ---- Full calendar tools for the AI: list calendars, search, add (reminders / repeat / attendees), edit, delete ----
    private fun calErr(m: String): String = JSONObject().put("ok", false).put("err", m).toString()
    private fun calCanRead() = permOk(Manifest.permission.READ_CALENDAR)
    private fun calCanWrite() = permOk(Manifest.permission.READ_CALENDAR) && permOk(Manifest.permission.WRITE_CALENDAR)

    private fun calListJson(): String {
        if (!calCanRead()) return calErr("denied")
        val arr = JSONArray()
        try {
            val proj = arrayOf(CalendarContract.Calendars._ID, CalendarContract.Calendars.CALENDAR_DISPLAY_NAME, CalendarContract.Calendars.ACCOUNT_NAME,
                CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL, CalendarContract.Calendars.VISIBLE, CalendarContract.Calendars.IS_PRIMARY)
            val c = contentResolver.query(CalendarContract.Calendars.CONTENT_URI, proj, null, null, null)
            if (c != null) {
                try {
                    while (c.moveToNext()) {
                        arr.put(JSONObject().put("id", c.getLong(0)).put("name", c.getString(1) ?: "").put("account", c.getString(2) ?: "")
                            .put("writable", c.getInt(3) >= CalendarContract.Calendars.CAL_ACCESS_CONTRIBUTOR).put("visible", c.getInt(4) == 1).put("primary", c.getInt(5) == 1))
                    }
                } finally { c.close() }
            }
        } catch (e: Exception) { return calErr(e.message ?: "unknown") }
        return JSONObject().put("ok", true).put("calendars", arr).toString()
    }

    private fun calDefaultId(): Long {
        var best = -1L; var bestScore = -1
        try {
            val j = JSONObject(calListJson()); val a = j.optJSONArray("calendars") ?: return -1L
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i); if (!o.optBoolean("writable")) continue
                val sc = (if (o.optBoolean("primary")) 2 else 0) + (if (o.optBoolean("visible")) 1 else 0)
                if (sc > bestScore) { bestScore = sc; best = o.getLong("id") }
            }
        } catch (_: Exception) { }
        return best
    }

    private fun calSearchJson(fromMs: Long, toMs: Long, q: String, limit: Int): String {
        if (!calCanRead()) return calErr("denied")
        val arr = JSONArray()
        try {
            val a = fromMs.coerceAtMost(toMs); val b = toMs.coerceAtLeast(fromMs).coerceAtMost(a + 400L * 86400000L)
            val proj = arrayOf(CalendarContract.Instances.EVENT_ID, CalendarContract.Instances.TITLE, CalendarContract.Instances.BEGIN, CalendarContract.Instances.END,
                CalendarContract.Instances.EVENT_LOCATION, CalendarContract.Instances.ALL_DAY, CalendarContract.Instances.CALENDAR_ID, CalendarContract.Instances.RRULE,
                CalendarContract.Instances.DESCRIPTION, CalendarContract.Instances.CALENDAR_DISPLAY_NAME)
            val c = CalendarContract.Instances.query(contentResolver, proj, a, b)
            val needle = q.trim().lowercase()
            val max = limit.coerceIn(1, 300)
            if (c != null) {
                try {
                    while (c.moveToNext() && arr.length() < max) {
                        val title = c.getString(1) ?: ""; val loc = c.getString(4) ?: ""; val desc = c.getString(8) ?: ""
                        if (needle.isNotEmpty() && !(title.lowercase().contains(needle) || loc.lowercase().contains(needle) || desc.lowercase().contains(needle))) continue
                        arr.put(JSONObject().put("id", c.getLong(0)).put("title", title).put("start", c.getLong(2)).put("end", c.getLong(3)).put("loc", loc)
                            .put("allDay", c.getInt(5) == 1).put("calId", c.getLong(6)).put("repeats", !(c.getString(7).isNullOrEmpty()))
                            .put("notes", desc.take(160)).put("cal", c.getString(9) ?: ""))
                    }
                } finally { c.close() }
            }
        } catch (e: Exception) { return calErr(e.message ?: "unknown") }
        return JSONObject().put("ok", true).put("events", arr).toString()
    }

    private fun calDuration(ms: Long, allDay: Boolean): String =
        if (allDay) "P" + (ms / 86400000L).coerceAtLeast(1L) + "D" else "P" + (ms / 1000L).coerceAtLeast(60L) + "S"

    private fun calPutReminders(eventId: Long, mins: JSONArray) {
        for (i in 0 until mins.length()) {
            val m = mins.optInt(i, -1); if (m < 0) continue
            val r = ContentValues()
            r.put(CalendarContract.Reminders.EVENT_ID, eventId); r.put(CalendarContract.Reminders.MINUTES, m)
            r.put(CalendarContract.Reminders.METHOD, CalendarContract.Reminders.METHOD_ALERT)
            contentResolver.insert(CalendarContract.Reminders.CONTENT_URI, r)
        }
    }

    private fun calCreateJson(j: JSONObject): String {
        if (!calCanWrite()) return calErr("denied")
        try {
            val allDay = j.optBoolean("allDay", false)
            val start = j.optLong("start", -1L); if (start < 0) return calErr("Bad start time")
            val dflt = if (allDay) 86400000L else 3600000L
            var end = j.optLong("end", start + dflt); if (end <= start) end = start + dflt
            var calId = j.optLong("calendarId", -1L)
            if (calId < 0) calId = calDefaultId()
            if (calId < 0) return calErr("No calendar on this phone can save events")
            val v = ContentValues()
            v.put(CalendarContract.Events.CALENDAR_ID, calId)
            v.put(CalendarContract.Events.TITLE, j.optString("title", "Event").ifBlank { "Event" })
            v.put(CalendarContract.Events.DESCRIPTION, j.optString("notes", ""))
            v.put(CalendarContract.Events.EVENT_LOCATION, j.optString("location", ""))
            v.put(CalendarContract.Events.DTSTART, start)
            v.put(CalendarContract.Events.ALL_DAY, if (allDay) 1 else 0)
            v.put(CalendarContract.Events.EVENT_TIMEZONE, if (allDay) "UTC" else java.util.TimeZone.getDefault().id)
            val rr = j.optString("rrule", "").removePrefix("RRULE:").trim()
            if (rr.isNotEmpty()) { v.put(CalendarContract.Events.RRULE, rr); v.put(CalendarContract.Events.DURATION, calDuration(end - start, allDay)) }
            else v.put(CalendarContract.Events.DTEND, end)
            val uri = contentResolver.insert(CalendarContract.Events.CONTENT_URI, v) ?: return calErr("Could not save the event")
            val id = android.content.ContentUris.parseId(uri)
            val mins = j.optJSONArray("reminders") ?: JSONArray().put(10)
            calPutReminders(id, mins)
            val at = j.optJSONArray("attendees")
            if (at != null) for (i in 0 until at.length()) {
                val em = at.optString(i, "").trim(); if (!em.contains("@")) continue
                val a = ContentValues()
                a.put(CalendarContract.Attendees.EVENT_ID, id); a.put(CalendarContract.Attendees.ATTENDEE_EMAIL, em); a.put(CalendarContract.Attendees.ATTENDEE_NAME, em.substringBefore("@"))
                a.put(CalendarContract.Attendees.ATTENDEE_TYPE, CalendarContract.Attendees.TYPE_REQUIRED)
                a.put(CalendarContract.Attendees.ATTENDEE_RELATIONSHIP, CalendarContract.Attendees.RELATIONSHIP_ATTENDEE)
                a.put(CalendarContract.Attendees.ATTENDEE_STATUS, CalendarContract.Attendees.ATTENDEE_STATUS_INVITED)
                try { contentResolver.insert(CalendarContract.Attendees.CONTENT_URI, a) } catch (_: Exception) { }
            }
            return JSONObject().put("ok", true).put("id", id).toString()
        } catch (e: Exception) { return calErr("Calendar error: " + (e.message ?: "unknown")) }
    }

    private fun calUpdateJson(id: Long, j: JSONObject): String {
        if (!calCanWrite()) return calErr("denied")
        try {
            val uri = android.content.ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI, id)
            var oStart = -1L; var oEnd = -1L; var oRule = ""; var oAll = false
            val c = contentResolver.query(uri, arrayOf(CalendarContract.Events.DTSTART, CalendarContract.Events.DTEND, CalendarContract.Events.RRULE, CalendarContract.Events.ALL_DAY, CalendarContract.Events.DURATION), null, null, null)
            var found = false
            if (c != null) { try { if (c.moveToFirst()) { found = true; oStart = c.getLong(0); oEnd = if (c.isNull(1)) -1L else c.getLong(1); oRule = c.getString(2) ?: ""; oAll = c.getInt(3) == 1 } } finally { c.close() } }
            if (!found) return calErr("Event not found")
            val v = ContentValues()
            if (j.has("title")) v.put(CalendarContract.Events.TITLE, j.optString("title"))
            if (j.has("notes")) v.put(CalendarContract.Events.DESCRIPTION, j.optString("notes"))
            if (j.has("location")) v.put(CalendarContract.Events.EVENT_LOCATION, j.optString("location"))
            val newAll = if (j.has("allDay")) j.optBoolean("allDay") else oAll
            if (j.has("allDay")) { v.put(CalendarContract.Events.ALL_DAY, if (newAll) 1 else 0); v.put(CalendarContract.Events.EVENT_TIMEZONE, if (newAll) "UTC" else java.util.TimeZone.getDefault().id) }
            val newRule = if (j.has("rrule")) j.optString("rrule", "").removePrefix("RRULE:").trim() else oRule
            if (j.has("rrule")) { if (newRule.isEmpty()) v.putNull(CalendarContract.Events.RRULE) else v.put(CalendarContract.Events.RRULE, newRule) }
            if (j.has("start") || j.has("end") || j.has("allDay") || j.has("rrule")) {
                val oldLen = if (oEnd > oStart) oEnd - oStart else if (newAll) 86400000L else 3600000L
                val ns = if (j.has("start")) j.optLong("start", oStart) else oStart
                var ne = if (j.has("end")) j.optLong("end", ns + oldLen) else ns + oldLen
                if (ne <= ns) ne = ns + (if (newAll) 86400000L else 3600000L)
                v.put(CalendarContract.Events.DTSTART, ns)
                if (newRule.isNotEmpty()) { v.put(CalendarContract.Events.DURATION, calDuration(ne - ns, newAll)); v.putNull(CalendarContract.Events.DTEND) }
                else { v.put(CalendarContract.Events.DTEND, ne); v.putNull(CalendarContract.Events.DURATION) }
            }
            if (v.size() > 0 && contentResolver.update(uri, v, null, null) < 1) return calErr("Could not update the event")
            val mins = j.optJSONArray("reminders")
            if (mins != null) {
                contentResolver.delete(CalendarContract.Reminders.CONTENT_URI, CalendarContract.Reminders.EVENT_ID + "=?", arrayOf(id.toString()))
                calPutReminders(id, mins)
            }
            return JSONObject().put("ok", true).put("id", id).toString()
        } catch (e: Exception) { return calErr("Calendar error: " + (e.message ?: "unknown")) }
    }

    private fun calDeleteJson(id: Long): String {
        if (!calCanWrite()) return calErr("denied")
        return try {
            val n = contentResolver.delete(android.content.ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI, id), null, null)
            if (n > 0) JSONObject().put("ok", true).toString() else calErr("Event not found")
        } catch (e: Exception) { calErr("Calendar error: " + (e.message ?: "unknown")) }
    }

    inner class Bridge {
        // Text select (long-press card > Select): replay a real long press at this CSS-pixel point so the WebView shows its normal selection handles and Copy / Select all / Share toolbar
        @JavascriptInterface fun selectAt(xCss: Float, yCss: Float) {
            runOnUiThread {
                try {
                    val d = resources.displayMetrics.density
                    val x = xCss * d; val y = yCss * d
                    val t0 = android.os.SystemClock.uptimeMillis()
                    val down = android.view.MotionEvent.obtain(t0, t0, android.view.MotionEvent.ACTION_DOWN, x, y, 0)
                    web.dispatchTouchEvent(down); down.recycle()
                    val hold = android.view.ViewConfiguration.getLongPressTimeout().toLong() + 160L
                    android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                        try {
                            val t1 = android.os.SystemClock.uptimeMillis()
                            val up = android.view.MotionEvent.obtain(t0, t1, android.view.MotionEvent.ACTION_UP, x, y, 0)
                            web.dispatchTouchEvent(up); up.recycle()
                        } catch (e: Throwable) {}
                    }, hold)
                } catch (e: Throwable) {}
            }
        }
        @JavascriptInterface fun calStatus(): String = if (permOk(Manifest.permission.READ_CALENDAR) && permOk(Manifest.permission.WRITE_CALENDAR)) "granted" else "denied"
        @JavascriptInterface fun calAsk() = runOnUiThread { permAsked("calw"); calLauncher.launch(arrayOf(Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR)) }
        @JavascriptInterface fun calEvents(days: Int): String = calEventsJson(days)
        @JavascriptInterface fun calList(): String = calListJson()
        @JavascriptInterface fun calSearch(fromMs: String, toMs: String, q: String, limit: Int): String =
            calSearchJson(fromMs.toLongOrNull() ?: System.currentTimeMillis(), toMs.toLongOrNull() ?: (System.currentTimeMillis() + 14 * 86400000L), q, limit)
        @JavascriptInterface fun calCreate(json: String): String = try { calCreateJson(JSONObject(json)) } catch (e: Exception) { calErr("Bad event data") }
        @JavascriptInterface fun calUpdate(id: String, json: String): String { val i = id.toLongOrNull() ?: return calErr("Bad event id"); return try { calUpdateJson(i, JSONObject(json)) } catch (e: Exception) { calErr("Bad event data") } }
        @JavascriptInterface fun calDelete(id: String): String { val i = id.toLongOrNull() ?: return calErr("Bad event id"); return calDeleteJson(i) }
        @JavascriptInterface fun calAdd(title: String, startMs: String, endMs: String, desc: String, loc: String): String {
            val s = startMs.toLongOrNull() ?: return "Bad start time"
            val e = endMs.toLongOrNull() ?: (s + 3600000L)
            return calAddEvent(title, s, if (e > s) e else s + 3600000L, desc, loc)
        }
        @JavascriptInterface fun locStatus(): String = if (permOk(Manifest.permission.ACCESS_FINE_LOCATION) || permOk(Manifest.permission.ACCESS_COARSE_LOCATION)) "granted" else "denied"
        /** Asks Android for the phone's real position; the result arrives in the page as window.__locDone(id, json). */
        @JavascriptInterface fun locRequest(id: String) { runOnUiThread { try { locFetch(id) } catch (_: Throwable) { locSend(id, "{\"ok\":false,\"err\":\"fail\"}") } } }
        // ---- launcher icon choice (activity-alias switch): "default" | "black" | "white" | "clearwhite" | "clearblack" (glyph only, transparent background)
        private val iconAliases = linkedMapOf("default" to "com.a2z.ai.IconDefault", "black" to "com.a2z.ai.IconBlack", "white" to "com.a2z.ai.IconWhite", "clearwhite" to "com.a2z.ai.IconClearWhite", "clearblack" to "com.a2z.ai.IconClearBlack")
        @JavascriptInterface fun appIcon(): String = try {
            val pm = this@MainActivity.packageManager
            iconAliases.entries.firstOrNull { (key, cls) ->
                val st = pm.getComponentEnabledSetting(android.content.ComponentName(this@MainActivity, cls))
                st == PackageManager.COMPONENT_ENABLED_STATE_ENABLED || (st == PackageManager.COMPONENT_ENABLED_STATE_DEFAULT && key == "default")
            }?.key ?: "default"
        } catch (_: Throwable) { "default" }
        @JavascriptInterface fun setAppIcon(k: String): Boolean {
            val want = iconAliases[k] ?: return false
            return try {
                val pm = this@MainActivity.packageManager
                // enable the new one first so the app never has zero launcher entries, then disable the others
                pm.setComponentEnabledSetting(android.content.ComponentName(this@MainActivity, want), PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP)
                iconAliases.values.filter { it != want }.forEach { cls ->
                    pm.setComponentEnabledSetting(android.content.ComponentName(this@MainActivity, cls), PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP)
                }
                true
            } catch (_: Throwable) { false }
        }
        @JavascriptInterface fun available() = true
        @JavascriptInterface fun metered(): Boolean = NetInfo.metered(this@MainActivity)   // used by the Data saver (assets/datasave.js)
        // ---- real permission bridge ----
        /** JSON {mic,cam,notif,loc,calr,calw,overlay,acc}: each granted | ask | blocked, read live from Android. */
        @JavascriptInterface fun permStatus(): String {
            val o = JSONObject()
            for (k in arrayOf("mic", "cam", "notif", "loc", "calr", "calw", "overlay", "acc")) o.put(k, permState(k))
            return o.toString()
        }
        /** Asks Android for the permission (or opens the right Settings page when Android will no longer show a pop-up). */
        @JavascriptInterface fun permRequest(k: String) = runOnUiThread {
            when (k) {
                "overlay" -> overlayAsk()
                "acc" -> AccessibilityDisclosure.show(this@MainActivity) { AgentController.openAccessibilitySettings(this@MainActivity) }
                else -> {
                    if (permGranted(k)) { permChanged(); return@runOnUiThread }
                    val ps = permList(k)
                    if (ps.isEmpty() || permState(k) == "blocked") { openAppSettings(k); return@runOnUiThread }
                    permAsked(k)
                    genPermLauncher.launch(ps)
                }
            }
        }
        /** Opens an http(s) link in the phone's browser (used by the "Get API key" buttons). */
        @JavascriptInterface fun openUrl(u: String): Boolean = try {
            val uri = Uri.parse(u.trim())
            if (uri.scheme == "https" || uri.scheme == "http") { runOnUiThread { try { startActivity(Intent(Intent.ACTION_VIEW, uri)) } catch (_: Throwable) { } }; true } else false
        } catch (_: Throwable) { false }
        @JavascriptInterface fun appSettings(k: String) = runOnUiThread { openAppSettings(k) }
        /** Real state of one of our notification channels: on | off (silenced in Android) | new (not created yet, defaults apply). */
        @JavascriptInterface fun notifChannelState(id: String): String {
            if (Build.VERSION.SDK_INT < 26) return "on"
            return try {
                val ch = (getSystemService(NOTIFICATION_SERVICE) as android.app.NotificationManager).getNotificationChannel(id)
                if (ch == null) "new" else if (ch.importance == android.app.NotificationManager.IMPORTANCE_NONE) "off" else "on"
            } catch (_: Throwable) { "on" }
        }
        /** Opens Android's own settings page for one notification channel (created first so the page is never empty). */
        @JavascriptInterface fun notifChannel(id: String) = runOnUiThread {
            try {
                if (Build.VERSION.SDK_INT >= 26) {
                    val nm = getSystemService(NOTIFICATION_SERVICE) as android.app.NotificationManager
                    val name = when (id) { "a2z_reply" -> "Reply ready"; "a2z_share" -> "Screen sharing"; else -> "Floating assistant" }
                    val imp = if (id == "a2z_reply") android.app.NotificationManager.IMPORTANCE_DEFAULT else android.app.NotificationManager.IMPORTANCE_LOW
                    nm.createNotificationChannel(android.app.NotificationChannel(id, name, imp))
                    startActivity(Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName).putExtra(Settings.EXTRA_CHANNEL_ID, id))
                } else openAppSettings("notif")
            } catch (_: Exception) { openAppSettings("notif") }
        }
        /** Shows a real Android notification. Returns false (and shows nothing) unless notifications are allowed. */
        @JavascriptInterface fun notifShow(title: String, body: String): Boolean {
            if (!permGranted("notif")) return false
            return try {
                val nm = getSystemService(NOTIFICATION_SERVICE) as android.app.NotificationManager
                if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(android.app.NotificationChannel("a2z_reply", "Reply ready", android.app.NotificationManager.IMPORTANCE_DEFAULT))
                val pi = android.app.PendingIntent.getActivity(this@MainActivity, 0, Intent(this@MainActivity, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NEW_TASK), android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT)
                val n = android.app.Notification.Builder(this@MainActivity, "a2z_reply").setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title).setContentText(body).setContentIntent(pi).setAutoCancel(true).build()
                nm.notify(7101, n); true
            } catch (_: Throwable) { false }
        }
        /** Keeps the app alive while a tool is working (foreground service). JS calls keepAlive(true) when a tool starts and keepAlive(false) when all tools are idle. */
        @JavascriptInterface fun keepAlive(on: Boolean) = runOnUiThread {
            try {
                val i = Intent(this@MainActivity, KeepAliveService::class.java)
                if (on) ContextCompat.startForegroundService(this@MainActivity, i) else stopService(i)
            } catch (_: Throwable) { }
            Unit
        }
        @JavascriptInterface fun bootColor(c: String) { try { this@MainActivity.getSharedPreferences("a2z_boot", android.content.Context.MODE_PRIVATE).edit().putInt("bg", Color.parseColor(c.trim())).apply() } catch (_: Throwable) { } }
        @JavascriptInterface fun start(intervalMs: Int, quality: Int, keep: Int) = runOnUiThread { requestShare(intervalMs, quality, keep) }
        @JavascriptInterface fun pause() = cmd(ScreenCaptureService.PAUSE)
        @JavascriptInterface fun resume() = cmd(ScreenCaptureService.RESUME)
        @JavascriptInterface fun stop() = cmd(ScreenCaptureService.STOP)
        @JavascriptInterface fun status() = FrameStore.state + "|" + FrameStore.count()
        @JavascriptInterface fun latestFrames(n: Int): String = JSONArray(FrameStore.latest(n)).toString()
        // ---- AI Agent bridge (additive) ----
        @JavascriptInterface fun agentStatus(): String = AgentController.status(this@MainActivity)
        @JavascriptInterface fun agentConfig(json: String) { try { AgentController.config(json) } catch (_: Exception) { } }
        /** Returns "" when started, otherwise the reason it did not start. */
        @JavascriptInterface fun agentStart(task: String): String = AgentRunner.start(this@MainActivity, task) ?: ""
        /** Voice command: a stop phrase (English or Tamil) stops the agent; anything else starts a task. */
        @JavascriptInterface fun agentVoice(text: String): String { val c = AgentController.voiceControl(text); if (c.isNotEmpty()) return c; return AgentRunner.start(this@MainActivity, text) ?: "" }
        /** "Ask about my screen" by voice or text: always an explanation, never a UI action. Stop / Pause / Resume phrases still work. */
        @JavascriptInterface fun agentAsk(text: String): String { val c = AgentController.voiceControl(text); if (c.isNotEmpty()) return c; return AgentRunner.start(this@MainActivity, text, true) ?: "" }
        /** Persistent agent history as JSON (newest first). Contains no screenshots, screen text or typed text. */
        @JavascriptInterface fun agentHistory(): String = AgentHistory.toJson()
        @JavascriptInterface fun agentPanel(on: Boolean) = runOnUiThread {
            if (on && (!FloatPerm.has(this@MainActivity) || !AgentController.enabled)) { Toast.makeText(this@MainActivity, "Turn on AI Agent and allow overlay first", Toast.LENGTH_LONG).show(); if (!FloatPerm.has(this@MainActivity)) overlayAsk(); return@runOnUiThread }
            AgentController.panel = on; if (on) AgentOverlay.showBar(applicationContext) else AgentOverlay.hideAll(false)
        }
        /** Floating panel page: which buttons, top/bottom, start minimized, opacity. Rebuilds the bar if it is showing. */
        @JavascriptInterface fun agentPanelConfig(json: String) { try { AgentOverlay.configure(json); AgentOverlay.reload(applicationContext) } catch (_: Exception) { } }
        @JavascriptInterface fun agentPause() { AgentController.pause() }
        @JavascriptInterface fun agentResume() { AgentController.resume() }
        @JavascriptInterface fun agentStop() { AgentController.hardStop("You pressed Stop.") }
        @JavascriptInterface fun agentClearHistory() { AgentHistory.clear() }
        // ---- Zen AI 5.0 task queue (all values are validated in TaskQueue / TaskManager) ----
        @JavascriptInterface fun taskSubmit(text: String, priority: Int): String = TaskQueue.submit(this@MainActivity, text, priority) ?: ""
        @JavascriptInterface fun taskCancel(id: String): String = if (id.toLongOrNull()?.let { TaskQueue.cancel(it) } == true) "" else "Nothing to cancel."
        @JavascriptInterface fun taskRetry(id: String): String = id.toLongOrNull()?.let { TaskQueue.retry(this@MainActivity, it) } ?: "Invalid task."
        @JavascriptInterface fun taskResume(id: String): String = id.toLongOrNull()?.let { TaskQueue.resume(this@MainActivity, it) } ?: "Invalid task."
        @JavascriptInterface fun taskQueuePause(on: Boolean) { TaskQueue.pause(on) }
        @JavascriptInterface fun taskResult(id: String): String = id.toLongOrNull()?.let { TaskManager.resultJson(it).toString() } ?: "{}"
        // ---- Zen AI 6.0: unified brain for the chat page (classification is instant; native intents run in the background and report back through window.__zenBrain) ----
        @JavascriptInterface fun brainClassify(text: String, sessionKey: String): String = try { BrainBridge.classifyJson(text, sessionKey) } catch (_: Throwable) { "{\"needsBrain\":false,\"native\":false,\"intent\":\"CHAT\"}" }
        @JavascriptInterface fun brainRun(runId: String, text: String, sessionKey: String, historyJson: String): String =
            try { BrainBridge.start(this@MainActivity, runId, text, sessionKey, BrainBridge.parseHistory(historyJson)) { type, data -> web.post { web.evaluateJavascript("window.__zenBrain&&window.__zenBrain(" + JSONObject.quote(runId) + "," + JSONObject.quote(type) + "," + JSONObject.quote(data) + ")", null) } } ?: "" }
            catch (e: Throwable) { e.message ?: "Could not start" }
        @JavascriptInterface fun brainCancel(runId: String) { BrainBridge.cancel(runId) }
        @JavascriptInterface fun brainReset() { BrainBridge.reset() }
        @JavascriptInterface fun brainTeam(): String = try { AgentSystem.ensure(this@MainActivity); AgentSystem.teamJson().toString() } catch (_: Throwable) { "{}" }
        // ---- Zen AI 5.1: provider health, usage, settings (values validated in AiConfig / UsageTracker; keys are never returned) ----
        @JavascriptInterface fun aiHealth(): String = JSONObject().put("providers", ProviderRouter.statusJson(System.currentTimeMillis())).put("offline", ProviderRouter.deviceOffline).toString()
        @JavascriptInterface fun aiHealthCheck(id: String) { if (id.length in 1..64) Thread { AiGateway.probe(id) }.also { it.isDaemon = true }.start() }
        @JavascriptInterface fun aiConfig(json: String): String = try { AiConfig.apply(JSONObject(json)); FrameStore.dedupOn = AiConfig.dedupOn; "" } catch (e: Throwable) { "Invalid settings." }
        @JavascriptInterface fun aiUsage(): String = UsageTracker.summaryJson(System.currentTimeMillis(), java.util.TimeZone.getDefault().getOffset(System.currentTimeMillis()).toLong()).toString()
        @JavascriptInterface fun aiUsageCsv(): String = UsageTracker.csv()
        @JavascriptInterface fun cameraVisionOpen() = runOnUiThread { startActivity(android.content.Intent(this@MainActivity, CameraVisionActivity::class.java)) }
        @JavascriptInterface fun aiUsageClear() { UsageTracker.reset() }
        @JavascriptInterface fun aiCaptureStatus(): String = JSONObject().put("net", FrameStore.netState).put("kept", FrameStore.dedupKept).put("skipped", FrameStore.dedupSkipped).toString()
        @JavascriptInterface fun taskAgents(): String = AgentSystem.runtime.statusJson().toString()
        @JavascriptInterface fun agentOpenAccessibility() = runOnUiThread { AccessibilityDisclosure.show(this@MainActivity) { AgentController.openAccessibilitySettings(this@MainActivity) } }
        /** Screen Share OFF: current accessible UI as JSON (read only, password fields blank). */
        @JavascriptInterface fun agentUiSnapshot(): String = AIAccessibilityService.instance?.snapshotJson() ?: JSONObject().put("ok", false).put("error", "Accessibility is not connected.").toString()
        // ---- Advanced Vision bridge (additive) ----
        /** JSON: state|frames|privacy|protectedHits|autoOcr|changed|overlay */
        @JavascriptInterface fun statusEx(): String = JSONObject().put("state", FrameStore.state).put("count", FrameStore.count()).put("privacy", FrameStore.privacy)
            .put("protected", FrameStore.protectedHits).put("auto", FrameStore.autoOcr).put("changed", ScreenOcr.changedSinceRead).put("overlay", HighlightOverlay.showing).toString()
        @JavascriptInterface fun setAuto(on: Boolean) { FrameStore.autoOcr = on }
        @JavascriptInterface fun setPrivacy(on: Boolean) = runOnUiThread {
            FrameStore.privacy = on
            if (on) { cmd(ScreenCaptureService.PAUSE); FrameStore.clear(); HighlightOverlay.hide() }   // never resumes by itself
        }
        /** Runs OCR on the newest stored frame (blocking, cached by frame hash). script: auto|latin|devanagari. Returns JSON. */
        @JavascriptInterface fun ocrLatest(script: String, redact: Boolean): String {
            val f = FrameStore.latest(1).lastOrNull() ?: return JSONObject().put("ok", false).put("error", "No frame yet. Switch to another app for a moment, then come back.").toString()
            ScreenOcr.changedSinceRead = false
            return ScreenOcr.analyze(f, script, redact)
        }
        /** Sync: [json frames] with sensitive lines blacked out (when redact) for the newest n frames. */
        @JavascriptInterface fun safeFrames(n: Int, redact: Boolean): String {
            val out = JSONArray()
            for (f in FrameStore.latest(n)) {
                if (!redact) { out.put(f); continue }
                val r = JSONObject(ScreenOcr.analyze(f, "auto", true)); out.put(if (r.has("jpeg")) r.getString("jpeg") else f)
            }
            return out.toString()
        }
        @JavascriptInterface fun visionSupport(type: String, model: String): String = FloatVision.support(FProvider("x", "x", type, "", model, "")).name
        @JavascriptInterface fun copyText(t: String) = runOnUiThread {
            (getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager).setPrimaryClip(android.content.ClipData.newPlainText("Zen Ai", t)); Toast.makeText(this@MainActivity, "Copied", Toast.LENGTH_SHORT).show()
        }
        @JavascriptInterface fun shareText(t: String) = runOnUiThread {
            try { startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, t), "Share")) } catch (_: Exception) { }
        }
        // Tools > Translate: opens the Sky Translate screen (com.a2z.ai.sky.SkyTranslateActivity)
        @JavascriptInterface fun skyTranslate(): Boolean = true
        @JavascriptInterface fun openSkyTranslate(): String {
            runOnUiThread { try { startActivity(Intent(this@MainActivity, com.a2z.ai.sky.SkyTranslateActivity::class.java)) } catch (_: Exception) { Toast.makeText(this@MainActivity, "Could not open Translate", Toast.LENGTH_SHORT).show() } }
            return "ok"
        }
        // file viewer (assets/a2z.html, "zyn-claude-viewer"): Print / Save as PDF through the Android print dialog
        @JavascriptInterface fun printHtml(html: String, title: String): String {
            runOnUiThread {
                try {
                    val wv = WebView(this@MainActivity)
                    printWv = wv
                    var started = false
                    wv.webViewClient = object : WebViewClient() {
                        override fun onPageFinished(view: WebView, url: String?) {
                            if (started) return
                            started = true
                            try {
                                val job = title.ifBlank { "Zen Ai" }
                                val pm = getSystemService(PRINT_SERVICE) as android.print.PrintManager
                                pm.print(job, view.createPrintDocumentAdapter(job), android.print.PrintAttributes.Builder().build())
                            } catch (_: Exception) { Toast.makeText(this@MainActivity, "Could not open print", Toast.LENGTH_SHORT).show() }
                        }
                    }
                    wv.loadDataWithBaseURL(null, html, "text/html", "utf-8", null)
                } catch (_: Exception) { Toast.makeText(this@MainActivity, "Could not open print", Toast.LENGTH_SHORT).show() }
            }
            return "ok"
        }
        // file viewer: share a file (from base64) with any app, e.g. "Share as PDF"
        @JavascriptInterface fun shareFile(name: String, mime: String, b64: String): String {
            return try {
                val bytes = android.util.Base64.decode(b64, android.util.Base64.DEFAULT)
                val safe = name.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().ifBlank { "file" }
                val f = java.io.File(this@MainActivity.cacheDir, safe)
                f.writeBytes(bytes)
                val uri = androidx.core.content.FileProvider.getUriForFile(this@MainActivity, this@MainActivity.packageName + ".fp", f)
                val shIntent = Intent(Intent.ACTION_SEND).setType(if (mime.isBlank()) "application/octet-stream" else mime)
                    .putExtra(Intent.EXTRA_STREAM, uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                runOnUiThread { try { startActivity(Intent.createChooser(shIntent, "Share")) } catch (_: Exception) { } }
                "ok"
            } catch (e: Exception) { "error" }
        }
        // save a file (from base64) into Downloads/Zen Ai so Download buttons really work inside the app
        @JavascriptInterface fun saveFile(name: String, mime: String, b64: String): String {
            return try {
                val bytes = android.util.Base64.decode(b64, android.util.Base64.DEFAULT)
                if (DownloadsSaver.needsPermission(this@MainActivity)) {   // Android 6-9 only: ask once, the user taps Download again
                    runOnUiThread { ActivityCompat.requestPermissions(this@MainActivity, arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 7) ; Toast.makeText(this@MainActivity, "Allow storage permission, then tap Download again", Toast.LENGTH_LONG).show() }
                    return "error"
                }
                val where = DownloadsSaver.save(this@MainActivity, name, mime) { it.write(bytes) }
                runOnUiThread { Toast.makeText(this@MainActivity, "Saved: $where", Toast.LENGTH_LONG).show() }
                "ok"
            } catch (e: Exception) { runOnUiThread { Toast.makeText(this@MainActivity, e.message ?: "Could not save the file", Toast.LENGTH_LONG).show() }; "error" }
        }
        // highlight overlay
        @JavascriptInterface fun overlayAllowed() = FloatPerm.has(this@MainActivity)
        @JavascriptInterface fun overlayAsk() = runOnUiThread {
            AlertDialog.Builder(this@MainActivity).setTitle("Allow display over other apps")
                .setMessage("The floating assistant, screen highlights and the agent status bar are drawn on top of other apps, and Android needs \"Display over other apps\" for that. This permission only lets Zen Ai draw; it does not let it tap or control anything. Tap Open settings, switch Zen Ai ON, then come back.")
                .setPositiveButton("Open settings") { _, _ -> try { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) } catch (_: Exception) { } }
                .setNegativeButton("Cancel", null).show()
        }
        @JavascriptInterface fun overlayShow(regionsJson: String, w: Int, h: Int) = runOnUiThread {
            if (!FloatPerm.has(this@MainActivity)) { overlayAsk(); return@runOnUiThread }
            HighlightOverlay.onSelect = { i -> web.post { web.evaluateJavascript("window.__hl&&window.__hl(" + i + ")", null) } }
            try { HighlightOverlay.show(applicationContext, regionsJson, w, h) } catch (e: Exception) { Toast.makeText(this@MainActivity, "Overlay failed: " + e.message, Toast.LENGTH_LONG).show() }
        }
        @JavascriptInterface fun overlayHide() = runOnUiThread { HighlightOverlay.hide() }
        // native TextToSpeech
        @JavascriptInterface fun ttsSpeak(text: String, lang: String, rate: Float, pitch: Float) = runOnUiThread { if (ns().active) ttsEmit("error", JSONObject().put("kind", "mic").put("msg", "Wait for voice input to finish.").toString()) else nt().speak(text, lang, rate, pitch) }
        // voice choice + installed voice list for the Voice settings page
        @JavascriptInterface fun ttsSpeakEx(text: String, lang: String, rate: Float, pitch: Float, voice: String) = runOnUiThread { if (ns().active) ttsEmit("error", JSONObject().put("kind", "mic").put("msg", "Wait for voice input to finish.").toString()) else nt().speak(text, lang, rate, pitch, voice) }
        @JavascriptInterface fun ttsVoices(lang: String) = runOnUiThread { nt().voices(lang) }
        // Privacy: block screenshots and hide the app preview in the recent-apps list (FLAG_SECURE); remembered across restarts
        @JavascriptInterface fun setSecureScreen(on: Boolean) = runOnUiThread {
            try { this@MainActivity.getSharedPreferences("a2z_priv", android.content.Context.MODE_PRIVATE).edit().putBoolean("secure", on).apply() } catch (_: Exception) { }
            applySecure(on)
        }
        @JavascriptInterface fun secureScreen(): Boolean = this@MainActivity.getSharedPreferences("a2z_priv", android.content.Context.MODE_PRIVATE).getBoolean("secure", false)
        @JavascriptInterface fun ttsPause() = runOnUiThread { nt().pause() }
        @JavascriptInterface fun ttsResume() = runOnUiThread { nt().resume() }
        @JavascriptInterface fun ttsStop() = runOnUiThread { tts?.stop(); Unit }
        @JavascriptInterface fun ttsMute(on: Boolean) = runOnUiThread { nt().mute(on) }
        @JavascriptInterface fun ttsInfo() = runOnUiThread { nt().info(listOf("en-US", "ta-IN", "si-LK", "hi-IN")) }
        @JavascriptInterface fun ttsSettings() = runOnUiThread {
            try { startActivity(Intent("com.android.settings.TTS_SETTINGS")) } catch (_: Exception) { try { startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (_: Exception) { } }
        }
        // ---- Floating assistant bridge (additive) ----
        @JavascriptInterface fun floatAvailable() = true
        @JavascriptInterface fun floatSync(json: String) = FloatStore.applySync(json)
        @JavascriptInterface fun floatStart() = runOnUiThread { startFloating() }
        /** Asks Android to pin the home-screen widget. Returns a message to show, or "" when the system dialog was opened. */
        @JavascriptInterface fun pinWidget(): String {
            return try {
                val m = android.appwidget.AppWidgetManager.getInstance(this@MainActivity)
                if (Build.VERSION.SDK_INT >= 26 && m.isRequestPinAppWidgetSupported) {
                    m.requestPinAppWidget(android.content.ComponentName(this@MainActivity, ZynWidget::class.java), null, null); ""
                } else "Long-press an empty spot on the home screen, tap Widgets, then pick Zen Ai."
            } catch (_: Throwable) { "Long-press an empty spot on the home screen, tap Widgets, then pick Zen Ai." }
        }
        /** Asks Android (13+) to add the "Zen Float" tile to the notification panel. Returns a message to show, or "" when the system dialog was opened. */
        @JavascriptInterface fun addTile(): String {
            val how = "Swipe down twice, tap the pencil (Edit), then drag \"Zen Float\" into the panel."
            return try {
                if (Build.VERSION.SDK_INT >= 33) {
                    val sb = getSystemService(android.app.StatusBarManager::class.java)
                    sb.requestAddTileService(android.content.ComponentName(this@MainActivity, FloatTileService::class.java), "Zen Float",
                        android.graphics.drawable.Icon.createWithResource(this@MainActivity, R.drawable.ic_zw_bubble), ContextCompat.getMainExecutor(this@MainActivity)) { _ -> }
                    ""
                } else how
            } catch (_: Throwable) { how }
        }
        @JavascriptInterface fun floatStop() = runOnUiThread { stopService(Intent(this@MainActivity, FloatingAssistantService::class.java)); Unit }
        @JavascriptInterface fun floatStatus() = (if (FloatingAssistantService.running) "running" else "stopped") + "|" + (if (FloatPerm.has(this@MainActivity)) "granted" else "denied")
        @JavascriptInterface fun floatPeekChats(): String = FloatStore.peekJson()
        @JavascriptInterface fun floatAckChats(json: String) = FloatStore.ackJson(json)
        @JavascriptInterface fun floatPeekFpx(): String = FloatStore.peekFpx()
        @JavascriptInterface fun floatAckFpx(json: String) = FloatStore.ackFpx(json)
        // ---- Google sign-in bridge (additive) ----
        @JavascriptInterface fun authAvailable(): Boolean = try { GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(this@MainActivity) == ConnectionResult.SUCCESS } catch (_: Exception) { false }
        @JavascriptInterface fun authSignIn(webClientId: String) = runOnUiThread {
            try {
                val c = googleClient(webClientId)
                c.signOut().addOnCompleteListener { signInLauncher.launch(c.signInIntent) }   // sign out first so the account chooser always shows
            } catch (e: Exception) { authEmit("error", "Could not start Google sign-in: ${e.message}") }
        }
        @JavascriptInterface fun authSignOut() = runOnUiThread { try { (gsc ?: googleClient("")).signOut() } catch (_: Exception) {}; Unit }
        // ---- Native SpeechRecognizer bridge (additive) ----
        @JavascriptInterface fun sttAvailable(): Boolean = try { SpeechRecognizer.isRecognitionAvailable(this@MainActivity) } catch (_: Exception) { false }
        @JavascriptInterface fun sttStart(lang: String) = runOnUiThread { sttGo(lang, false) }
        // Voice conversation (main chat): same as sttStart but with the shorter end-of-speech times
        @JavascriptInterface fun sttStartFast(lang: String) = runOnUiThread { sttGo(lang, true) }
        // Voice conversation (main chat): adds text to the speech queue WITHOUT flushing, so a streamed answer is spoken sentence by sentence while it is still being written
        @JavascriptInterface fun ttsAppend(text: String, lang: String, rate: Float, pitch: Float, voice: String) = runOnUiThread {
            try { nt().append(text, lang, rate, pitch, voice) } catch (_: Throwable) { }
        }
        @JavascriptInterface fun sttStop() = runOnUiThread { speech?.stop(); Unit }
        @JavascriptInterface fun sttCancel() = runOnUiThread { speech?.cancel(); Unit }
        @JavascriptInterface fun sttSettings() = runOnUiThread {
            try { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) } catch (_: Exception) {}
        }
        private fun cmd(a: String) = startService(Intent(this@MainActivity, ScreenCaptureService::class.java).setAction(a)).let { }
    }

    // shared by sttStart (normal) and sttStartFast (voice conversation)
    private fun sttGo(lang: String, fast: Boolean) {
        if (ns().active) { speechEmit("error", JSONObject().put("kind", "busy").put("msg", "Voice input is already running.").toString()); return }
        pendingSttLang = lang; pendingSttFast = fast; tts?.stop()   // never listen while speaking
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) ns().start(lang, fast)
        else { permAsked("mic"); micPermLauncher.launch(Manifest.permission.RECORD_AUDIO) }
    }

    private fun applySecure(on: Boolean) {
        try {
            if (on) window.setFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE, android.view.WindowManager.LayoutParams.FLAG_SECURE)
            else window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)
        } catch (_: Exception) { }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        applySecure(getSharedPreferences("a2z_priv", android.content.Context.MODE_PRIVATE).getBoolean("secure", false))
        FloatStore.init(applicationContext)
        AgentHistory.init(applicationContext)
        UiActions.startShare = { runOnUiThread { requestShare(1500, 60, 2) } }
        UiActions.stopShare = { runOnUiThread { try { startService(Intent(this, ScreenCaptureService::class.java).setAction(ScreenCaptureService.STOP)) } catch (_: Throwable) { } } }
        UiActions.openFloating = { runOnUiThread { startFloating() } }
        VoiceOut.speaker = { t -> runOnUiThread { try { nt().speak(t.take(3000), AgentController.lang, 1f, 1f) } catch (_: Throwable) { } }; true }
        AgentController.onSpeak = { t -> runOnUiThread { try { if (!ns().active) nt().speak(t, AgentController.lang, 1f, 1f) } catch (_: Throwable) { } } }
        AgentController.onSpeakStop = { runOnUiThread { try { tts?.stop() } catch (_: Throwable) { } } }
        AgentController.onEvent = { t, d -> if (::web.isInitialized) web.post { web.evaluateJavascript("window.__agent&&window.__agent(" + JSONObject.quote(t) + "," + JSONObject.quote(d) + ")", null) } }
        val loader = WebViewAssetLoader.Builder().addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this)).build()
        val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        val bootBg = getSharedPreferences("a2z_boot", android.content.Context.MODE_PRIVATE).getInt("bg", 0xFFFFFFFF.toInt())
        window.setBackgroundDrawable(ColorDrawable(bootBg))
        web = WebView(this); web.setBackgroundColor(bootBg); setContentView(web)
        web.settings.apply { javaScriptEnabled = true; domStorageEnabled = true; mediaPlaybackRequiresUserGesture = false; allowFileAccess = false }
        // links the page asks the browser to download (http/https): the system DownloadManager puts them into Downloads/Zen Ai. blob:/data: downloads are routed to saveFile() by the page itself.
        web.setDownloadListener { url, ua, cd, mime, _ ->
            try {
                if (!(url.startsWith("https://") || url.startsWith("http://"))) return@setDownloadListener
                if (DownloadsSaver.needsPermission(this)) { ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 7); Toast.makeText(this, "Allow storage permission, then try again", Toast.LENGTH_LONG).show(); return@setDownloadListener }
                val fn = DownloadsSaver.safeName(android.webkit.URLUtil.guessFileName(url, cd, mime))
                val rq = android.app.DownloadManager.Request(Uri.parse(url)).setMimeType(mime).addRequestHeader("User-Agent", ua)
                    .setNotificationVisibility(android.app.DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    .setDestinationInExternalPublicDir(android.os.Environment.DIRECTORY_DOWNLOADS, DownloadsSaver.ROOT + "/" + fn)
                (getSystemService(DOWNLOAD_SERVICE) as android.app.DownloadManager).enqueue(rq)
                Toast.makeText(this, "Downloading to Downloads/" + DownloadsSaver.ROOT + "/" + fn, Toast.LENGTH_LONG).show()
            } catch (e: Exception) { Toast.makeText(this, "Could not start the download", Toast.LENGTH_SHORT).show() }
        }
        web.addJavascriptInterface(Bridge(), "A2ZNative")
        web.addJavascriptInterface(CloudBridge(this) { web }, "A2ZCloud")   // Cloud Studio: GitHub token + builds + isolated preview (see CloudBridge.kt)
        watchKeyboard()
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest) = loader.shouldInterceptRequest(r.url)
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                if (r.url.host == "appassets.androidplatform.net") return false
                // Only hand ordinary web / mail / phone links to Android. Never intent:, file:, content: or custom schemes.
                val sc = r.url.scheme?.lowercase()
                if (sc == "https" || sc == "http" || sc == "mailto" || sc == "tel") { try { startActivity(Intent(Intent.ACTION_VIEW, r.url)) } catch (_: Throwable) { } }
                return true
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onGeolocationPermissionsShowPrompt(origin: String?, callback: GeolocationPermissions.Callback?) {
                val o = origin ?: ""
                if (permOk(Manifest.permission.ACCESS_FINE_LOCATION) || permOk(Manifest.permission.ACCESS_COARSE_LOCATION)) { callback?.invoke(o, true, false); return }
                geoCb = callback; geoOrigin = o; permAsked("loc")
                locLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
            }
            override fun onPermissionRequest(req: PermissionRequest) {
                runOnUiThread {
                    // Never grant blindly: ask Android first, then pass on ONLY what the user really allowed.
                    val need = ArrayList<String>()
                    for (r in req.resources) {
                        if (r == PermissionRequest.RESOURCE_AUDIO_CAPTURE && !permOk(Manifest.permission.RECORD_AUDIO)) { need.add(Manifest.permission.RECORD_AUDIO); permAsked("mic") }
                        if (r == PermissionRequest.RESOURCE_VIDEO_CAPTURE && !permOk(Manifest.permission.CAMERA)) { need.add(Manifest.permission.CAMERA); permAsked("cam") }
                    }
                    if (need.isEmpty()) { answerWebReq(req); return@runOnUiThread }
                    webReq?.let { try { it.deny() } catch (_: Exception) { } }
                    webReq = req
                    webPermLauncher.launch(need.toTypedArray())
                }
            }
            override fun onShowFileChooser(v: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
                fileCb?.onReceiveValue(null); fileCb = cb
                fileLauncher.launch(p.createIntent()); return true
            }
        }
        web.loadUrl("https://appassets.androidplatform.net/assets/a2z.html")
    }

    // ---------------- Floating assistant: permission flow ----------------
    /** Asks Android for screen-capture consent (the user must tap Start now). Used by the page and by the brain's screen.share.start tool. */
    private fun requestShare(intervalMs: Int, quality: Int, keep: Int) {
        pendingInterval = intervalMs; pendingQuality = quality; FrameStore.maxFrames = keep.coerceIn(1, 3)
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            { permAsked("notif"); ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1) }
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projectionLauncher.launch(mpm.createScreenCaptureIntent())   // system consent dialog
    }
    private fun startFloating() {
        if (FloatPerm.has(this)) { launchFloating(); return }
        AlertDialog.Builder(this)
            .setTitle("Allow display over other apps")
            .setMessage("The floating assistant draws a chat bubble and panel on top of other apps. Android needs the \"Display over other apps\" permission for that.\n\nTap Open settings, switch Zen Ai ON, then press Back to return here. This permission is only used to show the bubble and panel.")
            .setPositiveButton("Open settings") { _, _ -> openOverlaySettings() }
            .setNegativeButton("Cancel", null).show()
    }
    private fun openOverlaySettings() {
        awaitingOverlay = true
        try { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }
        catch (e: ActivityNotFoundException) {
            try { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) }
            catch (_: Exception) { awaitingOverlay = false; showOverlayDenied() }
        }
    }
    private fun showOverlayDenied() {
        AlertDialog.Builder(this)
            .setTitle("Permission is still off")
            .setMessage("The floating assistant cannot appear without \"Display over other apps\". To turn it on:\n\n1. Open Android Settings > Apps (\"Apps & notifications\" on Android 8).\n2. Open Zen Ai > Advanced > Display over other apps, and switch it ON.\n\nHuawei / EMUI: Settings > Apps > Apps > tap the gear icon (top right) > Special access > Draw over other apps > Zen Ai > ON.\n\nThen come back and tap Start again.")
            .setPositiveButton("Open settings") { _, _ -> openOverlaySettings() }
            .setNegativeButton("Close", null).show()
    }
    private fun launchFloating() {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        ContextCompat.startForegroundService(this, Intent(this, FloatingAssistantService::class.java).setAction(FloatingAssistantService.ACT_START))
        Toast.makeText(this, "Floating assistant started. Switch to any app to use the bubble.", Toast.LENGTH_LONG).show()
    }
    private var kbShown = false
    /** Tells the page when the on-screen keyboard is really open, so the chat box is compact whenever the keyboard is closed. */
    private fun watchKeyboard() {
        val root = window.decorView
        root.viewTreeObserver.addOnGlobalLayoutListener {
            try {
                val r = android.graphics.Rect()
                root.getWindowVisibleDisplayFrame(r)
                val total = root.rootView.height
                val open = total > 0 && (total - r.bottom) > total * 0.15
                if (open != kbShown) {
                    kbShown = open
                    if (::web.isInitialized) web.post { web.evaluateJavascript("window.__zynKb&&window.__zynKb(" + open + ")", null) }
                }
            } catch (_: Throwable) { }
        }
    }
    override fun onResume() {
        super.onResume(); agentVoiceIntent(); permChanged()
        if (awaitingOverlay) { awaitingOverlay = false; if (FloatPerm.has(this)) launchFloating() else showOverlayDenied() }
    }
    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); setIntent(intent); agentVoiceIntent() }
    private fun agentVoiceIntent() {
        val ix = intent ?: return
        if (ix.getBooleanExtra("a2z_float_start", false)) { ix.removeExtra("a2z_float_start"); startFloating(); return }
        val widget = ix.getStringExtra("a2z_widget")
        if (widget != null) {
            ix.removeExtra("a2z_widget")
            val act = when (widget) {
                "new" -> "var e=document.getElementById('nc');e&&e.click()"
                "voice" -> "var e=document.getElementById('mic');e&&e.click()"
                "agent" -> "window.A2ZAgent&&A2ZAgent.open&&A2ZAgent.open()"
                else -> "var e=document.getElementById('in');e&&e.focus()"
            }
            // on a cold start the page is still loading, so retry for a few seconds until it is ready
            val js = "(function t(n){var ok=document.getElementById('nc')&&(window.A2ZAgent||'" + widget + "'!=='agent');if(ok){try{" + act + "}catch(e){}}else if(n>0)setTimeout(function(){t(n-1)},300)})(20)"
            if (::web.isInitialized) web.postDelayed({ web.evaluateJavascript(js, null) }, 300)
            return
        }
        val js = when {
            ix.getBooleanExtra("a2z_agent_voice", false) -> { ix.removeExtra("a2z_agent_voice"); "window.A2ZAgent&&A2ZAgent.listen()" }
            ix.getBooleanExtra("a2z_agent_ask", false) -> { ix.removeExtra("a2z_agent_ask"); "window.A2ZAgent&&A2ZAgent.listen(true)" }
            ix.getBooleanExtra("a2z_agent_open", false) -> { ix.removeExtra("a2z_agent_open"); "window.A2ZAgent&&A2ZAgent.open()" }
            ix.getBooleanExtra("a2z_panel_features", false) -> { ix.removeExtra("a2z_panel_features"); "window.A2ZFloatPanel&&A2ZFloatPanel.features&&A2ZFloatPanel.features()" }
            else -> return
        }
        if (::web.isInitialized) web.postDelayed({ web.evaluateJavascript(js, null) }, 400)
    }
    override fun onStart() { super.onStart(); FrameStore.appForeground = true; FrameStore.ownActivityVisible = true }
    override fun onStop() { FrameStore.appForeground = false; FrameStore.ownActivityVisible = false; tts?.stop(); speech?.interrupted(); super.onStop() }
    override fun onDestroy() { try { stopService(Intent(this, KeepAliveService::class.java)) } catch (_: Throwable) { }; AgentController.onEvent = null; AgentController.onSpeak = null; AgentController.onSpeakStop = null; speech?.destroy(); speech = null; tts?.destroy(); tts = null; super.onDestroy() }
    /** Back on the first page normally closes the app (and its page, and every job in it). While a tool or a cloud build is working, only move the app to the background so the work finishes. */
    @Deprecated("") override fun onBackPressed() {
        if (web.canGoBack()) web.goBack()
        else if (KeepAliveService.running || CloudWatchStore.any(this)) moveTaskToBack(true)
        else @Suppress("DEPRECATION") super.onBackPressed()
    }
}
