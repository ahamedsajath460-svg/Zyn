package com.a2z.ai

/**
 * Network recovery policy for screen sharing (5.1). A state machine only; the Android side feeds it ConnectivityManager callbacks.
 *  - Connection lost -> OFFLINE: frames are not sent and stale frames are dropped ([fresh]); screen capture itself keeps running.
 *  - Connection back -> RECONNECTING: the next request after an exponential backoff (1 s, 2 s, 4 s ... max 30 s, [maxAttempts] attempts), then ONLINE on the first success.
 *  - After [maxAttempts] failures the state is GAVE_UP (no infinite retry); the user can retry by hand.
 *  - If the MediaProjection itself ended (the system revoked it), the state is NEEDS_CONSENT. This class NEVER starts a new projection: Android requires the user's consent every time, and
 *    the app must show a "tap to share screen again" prompt instead.
 */
class NetRecovery(val baseMs: Long = 1_000L, val maxMs: Long = 30_000L, val maxAttempts: Int = 6, val maxFrameAgeMs: Long = 3_000L) {
    enum class State { ONLINE, OFFLINE, RECONNECTING, GAVE_UP, NEEDS_CONSENT }
    @Volatile var state = State.ONLINE; private set
    var attempts = 0; private set
    private var nextAt = 0L

    @Synchronized fun onLost() { if (state != State.NEEDS_CONSENT) { state = State.OFFLINE; attempts = 0 } }
    @Synchronized fun onAvailable(now: Long) { if (state == State.OFFLINE || state == State.GAVE_UP) { state = State.RECONNECTING; attempts = 0; nextAt = now } }
    @Synchronized fun onProjectionEnded() { state = State.NEEDS_CONSENT }
    @Synchronized fun onUserRestarted() { state = State.ONLINE; attempts = 0 }

    /** True when a request may be made now. */
    @Synchronized fun mayRequest(now: Long): Boolean = when (state) { State.ONLINE -> true; State.RECONNECTING -> now >= nextAt; else -> false }

    fun delayFor(attempt: Int): Long = minOf(maxMs, baseMs shl (attempt - 1).coerceIn(0, 20))

    @Synchronized fun onRequestFailed(now: Long) {
        if (state == State.ONLINE) { state = State.RECONNECTING; attempts = 0 }
        if (state != State.RECONNECTING) return
        attempts++
        if (attempts >= maxAttempts) { state = State.GAVE_UP; return }
        nextAt = now + delayFor(attempts)
    }
    @Synchronized fun onRequestOk() { if (state == State.RECONNECTING || state == State.ONLINE) { state = State.ONLINE; attempts = 0 } }

    /** A frame older than [maxFrameAgeMs] is stale and must be dropped, never queued and sent late. */
    fun fresh(frameTs: Long, now: Long): Boolean = now - frameTs <= maxFrameAgeMs
}
