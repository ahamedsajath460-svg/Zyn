package com.a2z.ai

/**
 * OCR language support (5.1): script detection and the OCR-versus-translation boundary. Pure Kotlin.
 * Honest limits: the on-device engine in the app (ML Kit Latin + Devanagari) does NOT read Tamil or Sinhala (not verified here, no network). Tamil and Sinhala OCR therefore only exist as an
 * ONLINE vision fallback ([OnlineOcr]) that sends the frame to the user's image-capable provider, and only after the user turns the consent switch on. There is no offline Tamil / Sinhala engine yet.
 * OCR returns the text exactly as read; translation is a separate, optional second step that is always labelled as AI translation, never as OCR.
 */
object OcrLang {
    enum class Lang { AUTO, ENGLISH, TAMIL, SINHALA }
    enum class Script { LATIN, TAMIL, SINHALA, DEVANAGARI, OTHER }
    @Volatile var language = Lang.AUTO
    @Volatile var onlineConsent = false   // frame leaves the device only when true

    fun scriptOf(cp: Int): Script = when (cp) {
        in 0x0B80..0x0BFF -> Script.TAMIL
        in 0x0D80..0x0DFF -> Script.SINHALA
        in 0x0900..0x097F -> Script.DEVANAGARI
        in 0x41..0x5A, in 0x61..0x7A, in 0xC0..0x24F -> Script.LATIN
        else -> Script.OTHER
    }

    /** Count of letters per script in [s]. */
    fun histogram(s: String): Map<Script, Int> {
        val m = HashMap<Script, Int>(); var i = 0
        while (i < s.length) { val cp = s.codePointAt(i); i += Character.charCount(cp); if (!Character.isLetter(cp)) continue; val sc = scriptOf(cp); m[sc] = (m[sc] ?: 0) + 1 }
        return m
    }

    /** Dominant Tamil / Sinhala script in a text (e.g. the answer of the online OCR), or null. Needs at least [min] such letters and >= 30 % of all letters. */
    fun dominant(s: String, min: Int = 3): Script? {
        val h = histogram(s); val total = h.values.sum(); if (total == 0) return null
        for (sc in listOf(Script.TAMIL, Script.SINHALA)) { val n = h[sc] ?: 0; if (n >= min && n * 10 >= total * 3) return sc }
        return null
    }

    /** Which engine to use for the chosen language. */
    enum class Engine { ONDEVICE, ONLINE_VISION, UNAVAILABLE }
    fun engineFor(lang: Lang, hasImageProvider: Boolean): Engine = when (lang) {
        Lang.AUTO, Lang.ENGLISH -> Engine.ONDEVICE
        Lang.TAMIL, Lang.SINHALA -> if (onlineConsent && hasImageProvider) Engine.ONLINE_VISION else Engine.UNAVAILABLE
    }

    class Result(val text: String, val lang: Lang, val engine: Engine, val verified: Boolean)
}

/** Online OCR through the user's image-capable provider ([AiGateway], VISION kind). The model is told to transcribe only; its output is still model output, so it is marked unverified. */
object OnlineOcr {
    fun prompt(lang: OcrLang.Lang): String {
        val name = when (lang) { OcrLang.Lang.TAMIL -> "Tamil"; OcrLang.Lang.SINHALA -> "Sinhala"; else -> "any language" }
        return "You are an OCR engine. Transcribe ALL visible text of the image exactly as written ($name script where present), line by line. " +
            "Do not translate, summarise, explain or correct anything. If there is no text reply with an empty string. Output only the transcription."
    }
    /** True when the reply really contains the requested script (a cheap sanity check that the model did not answer in English instead). */
    fun looksRight(text: String, lang: OcrLang.Lang): Boolean = when (lang) {
        OcrLang.Lang.TAMIL -> OcrLang.dominant(text) == OcrLang.Script.TAMIL
        OcrLang.Lang.SINHALA -> OcrLang.dominant(text) == OcrLang.Script.SINHALA
        else -> text.isNotBlank()
    }
}
