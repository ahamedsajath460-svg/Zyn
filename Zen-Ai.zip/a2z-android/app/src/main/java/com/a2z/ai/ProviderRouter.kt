package com.a2z.ai

/**
 * Adaptive provider routing for NATIVE AI calls (the agent loop). It does not add a provider, an HTTP client or a key store:
 * it only orders and filters the providers the user already configured ([FloatStore.ordered], same [FProvider] objects, same [FloatAi] client).
 *
 * Rules:
 *  - VISION requests (a screenshot is attached) go only to providers [FloatVision] does not mark as text-only. Image-capable models come first and
 *    Gemini-type providers are preferred among them. If no provider can take images the caller sends text and OCR only. A screenshot is NEVER sent to a
 *    provider that is not configured by the user, and never to one known to be text-only.
 *  - Every other kind keeps the user's own order (selected provider first).
 *  - A provider that just failed is put on a cooldown (rate limit, bad key, network error) and tried last, so the next provider answers.
 *
 * Health is in memory only. No key is stored or logged here (only provider ids).
 * Pure Kotlin: no Android classes, so it can be unit tested on the JVM.
 */
object ProviderRouter {
    enum class Kind { CHAT, VISION, RESEARCH, CODE }
    enum class Err { NONE, RATE_LIMIT, AUTH, TRANSIENT, OTHER }

    class Health {
        var fails = 0; var ok = 0; var coolUntil = 0L; var lastMs = 0L; var lastErr = Err.NONE
        var totalFail = 0; var checkedAt = 0L
        val hist = ArrayDeque<Triple<Long, Boolean, Long>>()   // (time, ok, ms), last 20 results: real calls and manual checks
        fun add(ts: Long, ok: Boolean, ms: Long) { hist.addLast(Triple(ts, ok, ms)); while (hist.size > 20) hist.removeFirst() }
    }

    /** 5.1 health states. AVAILABLE is only reported after a verified successful call; with no data the state is UNKNOWN. */
    enum class State { AVAILABLE, DEGRADED, RATE_LIMITED, AUTH_ERROR, UNAVAILABLE, OFFLINE, UNKNOWN }
    @Volatile var deviceOffline = false

    @Synchronized fun stateOf(id: String, now: Long): State {
        if (deviceOffline) return State.OFFLINE
        val h = health[id] ?: return State.UNKNOWN
        if (h.hist.isEmpty()) return State.UNKNOWN
        if (h.fails > 0) return when (h.lastErr) {
            Err.RATE_LIMIT -> State.RATE_LIMITED
            Err.AUTH -> State.AUTH_ERROR
            else -> if (h.fails >= 3) State.UNAVAILABLE else State.DEGRADED
        }
        val rate = successRate(id)
        return if (h.lastMs > 15_000L || (rate in 0.0..0.79)) State.DEGRADED else State.AVAILABLE
    }

    /** Share of the last (up to 20) results that succeeded, or -1.0 when there is no data. */
    @Synchronized fun successRate(id: String): Double { val h = health[id]?.hist ?: return -1.0; if (h.isEmpty()) return -1.0; return h.count { it.second }.toDouble() / h.size }

    /** Manual or scheduled health check result (a real tiny request made by the caller). Counts in history like a normal call. */
    @Synchronized fun noteCheck(id: String, ok: Boolean, ms: Long, msg: String?, now: Long) {
        if (ok) noteSuccess(id, ms) else noteFailure(id, msg, now)
        health[id]?.checkedAt = now
    }
    /** True when an automatic check is due (interval in ms, 0 = automatic checks off). */
    @Synchronized fun checkDue(id: String, now: Long, intervalMs: Long): Boolean = intervalMs > 0 && now - (health[id]?.checkedAt ?: 0L) >= intervalMs

    private val health = HashMap<String, Health>()
    private val RATE = Regex("(?i)429|rate.?limit|quota|too many|limit reached")
    private val AUTH = Regex("(?i)\\b401\\b|\\b403\\b|api key|unauthori[sz]ed|invalid key|forbidden|permission denied|credentials")
    private val TRANSIENT = Regex("(?i)timeout|timed out|network|resolve|connection|reset|\\b5\\d\\d\\b|overload|unavailable|could not reach")

    fun classify(msg: String?): Err {
        val m = msg ?: return Err.OTHER
        return when {
            RATE.containsMatchIn(m) -> Err.RATE_LIMIT
            AUTH.containsMatchIn(m) -> Err.AUTH
            TRANSIENT.containsMatchIn(m) -> Err.TRANSIENT
            else -> Err.OTHER
        }
    }

    private fun cooldownMs(e: Err, fails: Int): Long {
        val n = fails.coerceIn(1, 4)
        return when (e) {
            Err.RATE_LIMIT -> 60_000L * n
            Err.AUTH -> 10 * 60_000L
            Err.TRANSIENT -> 15_000L * n
            else -> 30_000L
        }
    }

    @Synchronized fun noteSuccess(id: String, ms: Long) {
        val h = health.getOrPut(id) { Health() }
        h.fails = 0; h.ok++; h.coolUntil = 0L; h.lastMs = ms; h.lastErr = Err.NONE; h.add(System.currentTimeMillis(), true, ms)
    }

    @Synchronized fun noteFailure(id: String, msg: String?, now: Long): Err {
        val h = health.getOrPut(id) { Health() }
        val e = classify(msg)
        h.fails++; h.totalFail++; h.lastErr = e; h.coolUntil = now + cooldownMs(e, h.fails); h.add(now, false, 0L)
        return e
    }

    @Synchronized private fun coolUntil(id: String): Long = health[id]?.coolUntil ?: 0L

    @Synchronized fun reset() { health.clear() }

    /** Providers to try, best first. Cooling providers come last (still usable if nothing else is left). Empty = nothing suitable for [kind]. */
    fun candidates(kind: Kind, all: List<FProvider>, now: Long): List<FProvider> {
        var list = all
        if (kind == Kind.VISION) {
            list = all.filter { FloatVision.support(it) != FloatVision.S.NO }
                .sortedWith(compareBy<FProvider>({ if (FloatVision.support(it) == FloatVision.S.YES) 0 else 1 }, { if (it.type == "gemini") 0 else 1 }))
        }
        val ready = list.filter { coolUntil(it.id) <= now }
        val cooling = list.filter { coolUntil(it.id) > now }.sortedBy { coolUntil(it.id) }
        return ready + cooling
    }

    @Synchronized fun statusJson(now: Long): org.json.JSONArray {
        val a = org.json.JSONArray()
        for ((id, h) in health) a.put(org.json.JSONObject().put("id", id).put("fails", h.fails).put("ok", h.ok)
            .put("coolSec", maxOf(0L, (h.coolUntil - now) / 1000)).put("lastMs", h.lastMs).put("err", h.lastErr.name)
            .put("state", stateOf(id, now).name).put("successRate", successRate(id)).put("checkedAt", h.checkedAt)
            .put("history", org.json.JSONArray().also { a2 -> h.hist.forEach { x -> a2.put(org.json.JSONObject().put("t", x.first).put("ok", x.second).put("ms", x.third)) } })
            .put("keys", KeyPool.statusJson(id, now)))
        return a
    }
}
