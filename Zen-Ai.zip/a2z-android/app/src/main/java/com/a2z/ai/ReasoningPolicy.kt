package com.a2z.ai

import org.json.JSONObject

/**
 * Reasoning depth (5.1): Quick, Balanced, Deep. Only controls that the provider API really has are sent; for everything else the depth is ignored
 * (see [supported]) and the UI must say "not adjustable for this model". Nothing here invents a request parameter.
 *  - Gemini 3 models: generationConfig.thinkingConfig.thinkingLevel ("low" / "high").
 *  - Gemini 2.5 Flash: thinkingBudget (0 = off, -1 = dynamic, or a token count).
 *  - Gemini 2.5 Pro cannot switch thinking off: Quick is not sent for it (default dynamic thinking is used).
 *  - Other providers and models: no control is sent.
 * Selection order: per-call override > per-agent setting > default mode; "auto" picks from task complexity. Pure Kotlin.
 */
object ReasoningPolicy {
    enum class Depth { QUICK, BALANCED, DEEP }
    @Volatile var defaultDepth: Depth? = null          // null = keep the app's old behaviour (Quick for Gemini)
    @Volatile var auto = false                          // pick by complexity when no explicit depth is set
    private val perAgent = java.util.concurrent.ConcurrentHashMap<Role, Depth>()

    fun setAgent(r: Role, d: Depth?) { if (d == null) perAgent.remove(r) else perAgent[r] = d }
    fun agent(r: Role): Depth? = perAgent[r]

    fun supported(model: String): Boolean { val m = model.lowercase().removePrefix("models/"); return m.startsWith("gemini-3") || m.startsWith("gemini-2.5-flash") }

    fun parse(s: String?): Depth? = when (s?.lowercase()) { "quick" -> Depth.QUICK; "balanced" -> Depth.BALANCED; "deep" -> Depth.DEEP; else -> null }

    fun forComplexity(c: Orchestrator.Complexity): Depth = when (c) { Orchestrator.Complexity.SIMPLE -> Depth.QUICK; Orchestrator.Complexity.MODERATE -> Depth.BALANCED; Orchestrator.Complexity.COMPLEX -> Depth.DEEP }

    /** override > agent > default > (auto from complexity) > null (old behaviour). */
    fun resolve(override: Depth?, role: Role?, complexity: Orchestrator.Complexity?): Depth? =
        override ?: role?.let { perAgent[it] } ?: defaultDepth ?: if (auto && complexity != null) forComplexity(complexity) else null

    /** thinkingConfig for a Gemini model, or null when the model has no such control (or Quick is impossible). depth == null keeps the legacy Quick setting. */
    fun gemini(model: String, depth: Depth?): JSONObject? {
        val m = model.lowercase().removePrefix("models/")
        val d = depth ?: Depth.QUICK
        return when {
            m.startsWith("gemini-3") -> JSONObject().put("thinkingLevel", if (d == Depth.DEEP) "high" else "low")
            m.startsWith("gemini-2.5-flash") -> JSONObject().put("thinkingBudget", when (d) { Depth.QUICK -> 0; Depth.BALANCED -> 1024; Depth.DEEP -> -1 })
            else -> null
        }
    }
}
