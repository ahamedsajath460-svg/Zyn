package com.a2z.ai

import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** The 11 task states of the unified task system. [AgentController.state] (idle/planning/waiting/running/paused) is kept unchanged for the existing UI. A queued task that has not started is IDLE. */
enum class TaskState(val label: String) {
    IDLE("Idle"), UNDERSTANDING("Understanding"), PLANNING("Planning"), AGENT_SELECTION("Agent selection"), WAITING_FOR_APPROVAL("Waiting for approval"),
    EXECUTING("Executing"), VERIFYING("Verifying"), COMPLETED("Completed"), FAILED("Failed"), PAUSED("Paused"), CANCELLED("Cancelled");
    val terminal get() = this == COMPLETED || this == FAILED || this == CANCELLED
}

/** A step of a task. [verified] = the result was checked after the step ran. A started-but-unverified step may already have happened, so it is never repeated automatically. */
class Checkpoint(val step: String, val verified: Boolean, val note: String, val at: Long)

class TaskRecord(val id: Long, val text: String, val startedAt: Long) {
    @Volatile var state = TaskState.UNDERSTANDING
    @Volatile var endedAt = 0L
    @Volatile var result = ""
    @Volatile var roles: List<Role> = emptyList()
    @Volatile var retries = 0
    @Volatile var priority = 5                       // 1 (low) .. 9 (high)
    @Volatile var dependsOn: List<Long> = emptyList()  // ids of tasks that must be COMPLETED first
    @Volatile var managed = false                    // true = started by the task queue (the queue, not AgentRunner, decides when it ends)
    @Volatile var timeoutMs = 10 * 60_000L
    @Volatile var sources: List<Pair<String, String>> = emptyList()   // (title, url) of the final answer
    @Volatile var currentAgent = ""                  // role name of the agent working now
    @Volatile var queuedAt = startedAt
    @Volatile var resumeDone: Set<String> = emptySet()    // device steps verified before an interruption: not repeated
    @Volatile var resumeUnsure: Set<String> = emptySet()  // device steps that had started but were never verified: need the user's confirmation
    val checkpoints = java.util.concurrent.CopyOnWriteArrayList<Checkpoint>()
}

/**
 * Central task record: a queue of pending tasks (priority, dependencies), one active task, a bounded history of finished ones, duplicate detection,
 * retry, step checkpoints and optional persistence. It RECORDS and SCHEDULES; [TaskQueue] and [AgentRunner] do the work.
 * Persistence (only when "keep history" is on): task text and result are redacted with [AgentPolicy.redact] before they are written.
 * A task still running when the app died is shown as Failed "Interrupted"; its verified checkpoints can be used by [requeueInterrupted] so verified steps are not repeated.
 */
object TaskManager {
    private const val MAX = 50
    private const val MAX_PENDING = 30
    private const val MAX_RETRIES = 3
    private var seq = 0L
    @Volatile var active: TaskRecord? = null; private set
    private val finished = ArrayList<TaskRecord>()
    private val pending = ArrayList<TaskRecord>()
    @Volatile var queuePaused = false
    private var file: File? = null
    @Volatile var persist = true   // follows the agent's "keep history" setting

    fun keyOf(t: String) = t.lowercase().replace(Regex("\\s+"), " ").trim()

    /** True when a task with the same text is already running or waiting in the queue. */
    @Synchronized fun isDuplicate(text: String): Boolean {
        val k = keyOf(text); val a = active
        return (a != null && !a.state.terminal && keyOf(a.text) == k) || pending.any { keyOf(it.text) == k }
    }

    /**
     * Starts a record for a task that [AgentRunner] runs on its own. If the queue already started a managed task, that task stays the active one
     * (the device step is part of it). Any other unfinished record is closed as Failed "Interrupted" (the caller checked that no task thread is alive).
     */
    @Synchronized fun begin(text: String, now: Long = System.currentTimeMillis()): TaskRecord {
        val a = active
        if (a != null && !a.state.terminal) { if (a.managed) return a; closeLocked(a, TaskState.FAILED, "Interrupted", now) }
        val r = TaskRecord(++seq, text, now)
        active = r
        return r
    }

    // ---------- queue ----------
    /** Adds a task to the queue. Null when it is a duplicate, the queue is full, or a dependency id is unknown. */
    @Synchronized fun enqueue(text: String, priority: Int = 5, dependsOn: List<Long> = emptyList(), now: Long = System.currentTimeMillis()): TaskRecord? {
        val t = text.trim()
        if (t.isEmpty() || isDuplicate(t) || pending.size >= MAX_PENDING) return null
        if (dependsOn.any { d -> pending.none { it.id == d } && active?.id != d && finished.none { it.id == d } }) return null
        val r = TaskRecord(++seq, t, now)
        r.state = TaskState.IDLE; r.priority = priority.coerceIn(1, 9); r.dependsOn = dependsOn; r.queuedAt = now
        pending.add(r)
        save()
        return r
    }

    /** The next task that may start: highest priority first, oldest first among equals, all dependencies COMPLETED. Tasks whose dependency failed or was cancelled are cancelled here. */
    @Synchronized fun nextRunnable(now: Long = System.currentTimeMillis()): TaskRecord? {
        if (queuePaused) return null
        val a = active; if (a != null && !a.state.terminal) return null
        val ready = ArrayList<TaskRecord>()
        val dead = ArrayList<TaskRecord>()
        for (p in pending) {
            var wait = false; var broken = false
            for (d in p.dependsOn) {
                val f = finished.lastOrNull { it.id == d }
                if (f != null) { if (f.state != TaskState.COMPLETED) broken = true }
                else if (pending.any { it.id == d } || active?.id == d) wait = true
                else broken = true
            }
            if (broken) dead.add(p) else if (!wait) ready.add(p)
        }
        for (p in dead) { pending.remove(p); closeLocked(p, TaskState.CANCELLED, "A task it depends on did not complete", now) }
        return ready.sortedWith(compareByDescending<TaskRecord> { it.priority }.thenBy { it.queuedAt }.thenBy { it.id }).firstOrNull()
    }

    /** Moves a queued task to active. */
    @Synchronized fun activate(r: TaskRecord, now: Long = System.currentTimeMillis()): Boolean {
        val a = active; if (a != null && !a.state.terminal) return false
        if (!pending.remove(r)) return false
        r.managed = true; r.state = TaskState.UNDERSTANDING; r.queuedAt = now
        active = r
        return true
    }

    @Synchronized fun pendingList(): List<TaskRecord> = pending.toList()

    /** Cancels a queued task. For the active task it returns false: stop it with [AgentController.hardStop] or [TaskQueue.cancel]. */
    @Synchronized fun cancelPending(id: Long, now: Long = System.currentTimeMillis()): Boolean {
        val p = pending.firstOrNull { it.id == id } ?: return false
        pending.remove(p); closeLocked(p, TaskState.CANCELLED, "Cancelled before it started", now)
        return true
    }

    /** Puts a failed or cancelled task back in the queue with the same text (max 3 retries). Null when not possible. */
    @Synchronized fun retry(id: Long, now: Long = System.currentTimeMillis()): TaskRecord? {
        val f = finished.lastOrNull { it.id == id && (it.state == TaskState.FAILED || it.state == TaskState.CANCELLED) } ?: return null
        if (f.retries >= MAX_RETRIES) return null
        val r = enqueue(f.text, f.priority, emptyList(), now) ?: return null
        r.retries = f.retries + 1
        return r
    }

    /**
     * Re-queues an interrupted task (it had checkpoints). Steps that were verified are marked done and are skipped; steps that had started but were never verified are
     * marked unsure: the coordinator will not repeat them without the user. Returns null when there is nothing to resume.
     */
    @Synchronized fun requeueInterrupted(id: Long, now: Long = System.currentTimeMillis()): TaskRecord? {
        val f = finished.lastOrNull { it.id == id && it.state == TaskState.FAILED && it.checkpoints.isNotEmpty() } ?: return null
        val r = retry(id, now) ?: return null
        val ok = f.checkpoints.filter { it.verified }.map { it.step }.toSet()
        r.resumeDone = ok
        r.resumeUnsure = f.checkpoints.map { it.step }.toSet() - ok
        return r
    }

    @Synchronized fun pauseQueue(p: Boolean) { queuePaused = p }

    @Synchronized fun overdue(now: Long = System.currentTimeMillis()): Boolean { val a = active ?: return false; return !a.state.terminal && a.managed && now - a.queuedAt > a.timeoutMs }

    // ---------- checkpoints ----------
    @Synchronized fun checkpoint(step: String, verified: Boolean, note: String = "", now: Long = System.currentTimeMillis()) {
        val a = active ?: return
        if (a.state.terminal) return
        a.checkpoints.add(Checkpoint(step.take(120), verified, note.take(200), now))
        while (a.checkpoints.size > 40) a.checkpoints.removeAt(0)
        save()
    }

    @Synchronized fun to(s: TaskState): Boolean {
        val a = active ?: return false
        if (a.state.terminal) return false
        a.state = s
        return true
    }

    @Synchronized fun setRoles(r: List<Role>) { active?.roles = r }
    @Synchronized fun setAgent(r: String) { active?.currentAgent = r }

    /** Maps the existing agent state strings onto the unified states. */
    fun onAgentState(s: String) {
        when (s) {
            "planning" -> to(TaskState.PLANNING)
            "waiting" -> to(TaskState.WAITING_FOR_APPROVAL)
            "running" -> to(TaskState.EXECUTING)
            "paused" -> to(TaskState.PAUSED)
        }
    }

    private fun closeLocked(a: TaskRecord, s: TaskState, result: String, now: Long) {
        a.state = s; a.endedAt = now; a.result = result
        finished.add(a)
        while (finished.size > MAX) finished.removeAt(0)
    }

    /**
     * [status] is the runner's finish status ("cancelled", "stopped", "failed", "answered" ...). A task started by the queue is only ended here by a user stop
     * ("stopped"); its normal end is [endManaged], called by the queue after verification.
     */
    @Synchronized fun end(status: String, ok: Boolean, text: String, now: Long = System.currentTimeMillis()) {
        val a = active ?: return
        if (a.state.terminal) return
        if (a.managed && status != "stopped") return
        val s = when { status == "cancelled" || status == "stopped" -> TaskState.CANCELLED; ok -> TaskState.COMPLETED; else -> TaskState.FAILED }
        closeLocked(a, s, text.take(300), now)
    }

    /** Ends the queue's own task. */
    @Synchronized fun endManaged(ok: Boolean, cancelled: Boolean, text: String, sources: List<Pair<String, String>> = emptyList(), now: Long = System.currentTimeMillis()) {
        val a = active ?: return
        if (a.state.terminal) return
        a.sources = sources.take(10)
        closeLocked(a, if (cancelled) TaskState.CANCELLED else if (ok) TaskState.COMPLETED else TaskState.FAILED, text.take(4000), now)
    }

    /** Safety net: closes a record the runner left open (not a queue task: the queue closes its own). */
    @Synchronized fun closeIfOpen(now: Long = System.currentTimeMillis()) {
        val a = active ?: return
        if (!a.state.terminal && !a.managed) closeLocked(a, TaskState.FAILED, "Ended without a result", now)
    }

    @Synchronized fun completed(): List<TaskRecord> = finished.filter { it.state == TaskState.COMPLETED }
    @Synchronized fun failed(): List<TaskRecord> = finished.filter { it.state == TaskState.FAILED || it.state == TaskState.CANCELLED }
    @Synchronized fun finishedById(id: Long): TaskRecord? = finished.lastOrNull { it.id == id }

    /** Full answer of a finished task (kept in memory only) as JSON {text, sources}; the saved copy is short and redacted. */
    @Synchronized fun resultJson(id: Long): JSONObject {
        val r = finished.lastOrNull { it.id == id } ?: return JSONObject().put("ok", false)
        return JSONObject().put("ok", true).put("state", r.state.name).put("text", r.result).put("sources", JSONArray(r.sources.map { JSONObject().put("title", it.first).put("url", it.second) }))
    }

    /** Text of the newest failed or cancelled task (for a Retry button). Null when there is none. */
    @Synchronized fun retryText(): String? = finished.lastOrNull { it.state == TaskState.FAILED || it.state == TaskState.CANCELLED }?.text

    @Synchronized fun clearHistory() { finished.clear() }

    @Synchronized fun toJson(): JSONObject {
        fun rec(r: TaskRecord) = JSONObject().put("id", r.id).put("task", AgentPolicy.redact(r.text, 120)).put("state", r.state.name).put("result", AgentPolicy.redact(r.result, 160)).put("retries", r.retries)
            .put("canResume", r.state == TaskState.FAILED && r.checkpoints.isNotEmpty())
        val a = active
        return JSONObject().put("state", (a?.state ?: TaskState.IDLE).name).put("label", (a?.state ?: TaskState.IDLE).label)
            .put("task", a?.let { AgentPolicy.redact(it.text, 120) } ?: "")
            .put("id", a?.id ?: 0L).put("agent", a?.currentAgent ?: "").put("steps", a?.checkpoints?.size ?: 0).put("queuePaused", queuePaused)
            .put("roles", JSONArray((a?.roles ?: emptyList()).map { it.name }))
            .put("owner", Orchestrator.deviceOwner?.name ?: "")
            .put("pending", JSONArray(pending.map { JSONObject().put("id", it.id).put("task", AgentPolicy.redact(it.text, 120)).put("priority", it.priority).put("dependsOn", JSONArray(it.dependsOn)) }))
            .put("completed", JSONArray(finished.filter { it.state == TaskState.COMPLETED }.takeLast(10).map { rec(it) }))
            .put("failed", JSONArray(finished.filter { it.state == TaskState.FAILED || it.state == TaskState.CANCELLED }.takeLast(10).map { rec(it) }))
    }

    // ---------- optional persistence ----------
    private fun recJson(r: TaskRecord): JSONObject = JSONObject().put("id", r.id).put("task", AgentPolicy.redact(r.text, 200)).put("state", r.state.name)
        .put("result", AgentPolicy.redact(r.result, 200)).put("started", r.startedAt).put("ended", r.endedAt).put("priority", r.priority).put("retries", r.retries)
        .put("deps", JSONArray(r.dependsOn)).put("queued", r.queuedAt)
        .put("cp", JSONArray(r.checkpoints.map { JSONObject().put("s", it.step).put("v", it.verified).put("n", it.note).put("t", it.at) }))

    private fun recFrom(o: JSONObject): TaskRecord {
        val id = o.optLong("id", 0L).let { if (it > 0L) it else ++seq }
        if (id > seq) seq = id
        val r = TaskRecord(id, o.optString("task"), o.optLong("started"))
        r.state = try { TaskState.valueOf(o.optString("state")) } catch (_: Throwable) { TaskState.FAILED }
        r.result = o.optString("result"); r.endedAt = o.optLong("ended"); r.priority = o.optInt("priority", 5); r.retries = o.optInt("retries", 0); r.queuedAt = o.optLong("queued", r.startedAt)
        o.optJSONArray("deps")?.let { a -> r.dependsOn = (0 until a.length()).map { i -> (a.opt(i) as? Number)?.toLong() ?: 0L }.filter { it > 0L } }
        o.optJSONArray("cp")?.let { a -> for (i in 0 until a.length()) a.optJSONObject(i)?.let { c -> r.checkpoints.add(Checkpoint(c.optString("s"), c.optBoolean("v", false), c.optString("n"), c.optLong("t"))) } }
        return r
    }

    @Synchronized fun init(f: File) {
        if (file != null) return
        file = f
        try {
            if (!f.exists()) return
            val root = JSONObject(f.readText())
            root.optJSONArray("finished")?.let { arr ->
                for (i in 0 until arr.length()) {
                    val r = recFrom(arr.optJSONObject(i) ?: continue)
                    if (!r.state.terminal) { r.state = TaskState.FAILED; r.result = "Interrupted (app closed)" }
                    finished.add(r)
                }
            }
            // the task that was running when the app died: Failed "Interrupted", keeps its checkpoints so it can be resumed
            root.optJSONObject("active")?.let { o -> val r = recFrom(o); r.state = TaskState.FAILED; r.result = "Interrupted (app closed)"; if (r.endedAt == 0L) r.endedAt = r.startedAt; finished.add(r) }
            // tasks that were still waiting in the queue stay queued
            root.optJSONArray("pending")?.let { arr ->
                for (i in 0 until arr.length()) { val r = recFrom(arr.optJSONObject(i) ?: continue); r.state = TaskState.IDLE; pending.add(r) }
            }
            while (finished.size > MAX) finished.removeAt(0)
        } catch (_: Throwable) { }
    }

    @Synchronized fun save() {
        val f = file ?: return
        if (!persist) return
        try {
            val root = JSONObject()
            root.put("finished", JSONArray(finished.map { recJson(it) }))
            root.put("pending", JSONArray(pending.map { recJson(it) }))
            active?.let { if (!it.state.terminal) root.put("active", recJson(it)) }
            f.writeText(root.toString())
        } catch (_: Throwable) { }
    }

    /** For tests only. */
    @Synchronized fun resetForTest() { active = null; finished.clear(); pending.clear(); file = null; seq = 0L; queuePaused = false }
}
