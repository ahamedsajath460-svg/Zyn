package com.a2z.ai

import android.content.Context

/**
 * Runs the queue kept by [TaskManager]: one task at a time, highest priority first, dependencies respected, each task through [Coordinator].
 * One worker thread exists only while there is work. Pause stops new tasks from starting (and pauses a running phone task); Cancel stops the running task everywhere
 * ([AgentRuntime.cancel]: agents, phone, AI calls); a task that runs longer than its timeout is failed and stopped.
 * Nothing here touches the phone directly: that stays in [AgentRunner] behind [AgentPolicy] and the user's confirmations.
 */
object TaskQueue {
    private const val MAX_TEXT = 1500
    @Volatile private var worker: Thread? = null
    @Volatile private var curCtx: AgentCtx? = null

    private fun clean(text: String): String = text.trim().take(MAX_TEXT)

    /** Adds a task. Returns an error text, or null when queued. */
    fun submit(app: Context, text: String, priority: Int = 5, dependsOn: List<Long> = emptyList()): String? {
        val t = clean(text); if (t.isEmpty()) return "Type a task first."
        TaskManager.init(java.io.File(app.applicationContext.filesDir, "zyn_tasks.json"))
        if (FloatStore.ordered().isEmpty()) return "No AI provider is ready. Add an API key and model in Settings, then open the app once so providers sync."
        if (TaskManager.isDuplicate(t)) return "That task is already running or waiting."
        TaskManager.enqueue(t, priority, dependsOn) ?: return "The task could not be queued (queue full or unknown dependency)."
        AgentSystem.ensure(app); ensureWorker(app)
        return null
    }

    fun retry(app: Context, id: Long): String? { TaskManager.init(java.io.File(app.applicationContext.filesDir, "zyn_tasks.json")); TaskManager.retry(id) ?: return "This task cannot be retried (already retried 3 times, duplicate, or not found)."; AgentSystem.ensure(app); ensureWorker(app); return null }

    /** Resume an interrupted task: steps already verified are skipped, steps that may have been done are not repeated without you. */
    fun resume(app: Context, id: Long): String? { TaskManager.init(java.io.File(app.applicationContext.filesDir, "zyn_tasks.json")); TaskManager.requeueInterrupted(id) ?: return "This task cannot be resumed."; AgentSystem.ensure(app); ensureWorker(app); return null }

    /** Cancels a waiting task, or stops the running one. */
    fun cancel(id: Long): Boolean {
        if (TaskManager.cancelPending(id)) return true
        val a = TaskManager.active
        if (a != null && a.id == id && !a.state.terminal) {
            curCtx?.let { AgentSystem.runtime.cancel(it) }
            AgentController.hardStop("Task cancelled.")     // ends the record as Cancelled and stops the phone
            TaskManager.endManaged(false, true, "Cancelled by you.")
            return true
        }
        return false
    }

    /** Pauses or resumes the whole queue: no new task starts while paused, and a running phone task is paused with it. */
    fun pause(p: Boolean) {
        TaskManager.pauseQueue(p)
        if (p) AgentController.pause() else AgentController.resume()
    }

    @Synchronized private fun ensureWorker(app: Context) {
        if (worker?.isAlive == true) return
        val t = Thread({ loop(app.applicationContext) }, "zyn-task-queue")
        t.isDaemon = true; worker = t; t.start()
    }

    private fun loop(app: Context) {
        try {
            while (true) {
                if (TaskManager.queuePaused) { if (TaskManager.pendingList().isEmpty()) break; Thread.sleep(500); continue }
                val n = TaskManager.nextRunnable()
                if (n == null) { if (TaskManager.pendingList().isEmpty()) break; Thread.sleep(500); continue }
                if (!TaskManager.activate(n)) { Thread.sleep(500); continue }
                runOne(app, n)
            }
        } catch (_: InterruptedException) {
        } finally {
            worker = null
            if (TaskManager.pendingList().isNotEmpty() && !TaskManager.queuePaused) ensureWorker(app)   // a task arrived while the worker was leaving
        }
    }

    private fun runOne(app: Context, n: TaskRecord) {
        val ctx = AgentCtx(n.id, System.currentTimeMillis() + n.timeoutMs)
        curCtx = ctx
        val rt = AgentSystem.runtime
        val timedOut = BooleanArray(1)
        val watch = Thread {
            while (!Thread.currentThread().isInterrupted) {
                val a = TaskManager.active
                if (a == null || a.id != n.id || a.state.terminal) { rt.cancel(ctx); return@Thread }              // cancelled or stopped by the user
                if (TaskManager.overdue()) {
                    timedOut[0] = true
                    TaskManager.endManaged(false, false, "Timed out after ${n.timeoutMs / 60_000} min.")
                    rt.cancel(ctx); AgentController.hardStop("Task timed out."); return@Thread
                }
                try { Thread.sleep(500) } catch (_: InterruptedException) { return@Thread }
            }
        }
        watch.isDaemon = true; watch.start()
        var out: Coordinator.Outcome
        try {
            // 6.0: every queued task goes through the unified brain (phone tasks still use the Coordinator path inside it)
            val b = AgentSystem.brain.run(ctx, n.text, AgentVision.linked(), "task-" + n.id)   // each queued job is independent: its own context, dropped afterwards
            out = Coordinator.Outcome(b.ok, b.text, b.sources, b.issues)
        }
        catch (t: Throwable) { out = Coordinator.Outcome(false, "The task failed: " + (t.message ?: t.javaClass.simpleName), emptyList(), emptyList()) }
        finally { watch.interrupt(); curCtx = null; SharedContextManager.drop("task-" + n.id) }
        if (!timedOut[0]) {
            val a = TaskManager.active
            if (a != null && a.id == n.id && !a.state.terminal) TaskManager.endManaged(out.ok, ctx.cancelled, out.text, out.sources)
        }
        Orchestrator.releaseDevice()
        if (AgentController.keepHistory) TaskManager.save()
    }
}
