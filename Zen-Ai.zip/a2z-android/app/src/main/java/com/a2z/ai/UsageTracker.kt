package com.a2z.ai

import org.json.JSONArray
import org.json.JSONObject

/**
 * Token and cost monitoring (5.1). Rules:
 *  - Token counts come ONLY from the provider's own response (Gemini usageMetadata, OpenAI-style usage, Anthropic usage). If a response has no usage block the call is counted
 *    in "unreported" and no number is invented. Nothing is estimated from text length.
 *  - Cost is computed only when the user entered a price for that model (per 1M tokens): tokens (confirmed by the provider) x price (entered by the user) = ESTIMATED cost.
 *    No provider returns a bill in these APIs, so no cost is ever labelled "confirmed". Calls on models with no price are shown as "no price set".
 *  - Budgets (daily / weekly / monthly, in the user's currency units) warn at 80 % and 100 % of the ESTIMATED cost. A budget is a warning, not a hard stop.
 * Pure Kotlin. Persistence is by [toJson] / [load]; the caller decides where (and honours the "keep history" switch).
 */
object UsageTracker {
    class Price(val inPerM: Double, val outPerM: Double)
    class Rec(val ts: Long, val provider: String, val model: String, val inTok: Long, val outTok: Long, val reported: Boolean, val ok: Boolean)

    private val recs = ArrayList<Rec>()
    private val prices = HashMap<String, Price>()
    var dailyBudget = 0.0; var weeklyBudget = 0.0; var monthlyBudget = 0.0
    var currency = "USD"
    private const val MAX = 5000

    @Synchronized fun reset() { recs.clear(); prices.clear(); dailyBudget = 0.0; weeklyBudget = 0.0; monthlyBudget = 0.0; currency = "USD" }
    @Synchronized fun setPrice(model: String, inPerM: Double, outPerM: Double) { if (inPerM >= 0 && outPerM >= 0) prices[model.lowercase().removePrefix("models/")] = Price(inPerM, outPerM) }
    @Synchronized fun price(model: String): Price? = prices[model.lowercase().removePrefix("models/")]

    /** A call with provider-reported usage (inTok/outTok >= 0), or with no usage at all (null). */
    @Synchronized fun record(now: Long, provider: String, model: String, inTok: Long?, outTok: Long?, ok: Boolean = true) {
        val rep = inTok != null || outTok != null
        recs.add(Rec(now, provider, model.lowercase().removePrefix("models/"), maxOf(0L, inTok ?: 0L), maxOf(0L, outTok ?: 0L), rep, ok))
        if (recs.size > MAX) recs.removeAt(0)
    }

    class Stat(val calls: Int, val unreported: Int, val inTok: Long, val outTok: Long, val estCost: Double, val unpriced: Int)

    private fun costOf(r: Rec): Double? { if (!r.reported) return null; val p = prices[r.model] ?: return null; return r.inTok * p.inPerM / 1e6 + r.outTok * p.outPerM / 1e6 }

    @Synchronized fun stat(from: Long, to: Long, provider: String? = null): Stat {
        var c = 0; var un = 0; var i = 0L; var o = 0L; var cost = 0.0; var np = 0
        for (r in recs) {
            if (r.ts < from || r.ts >= to || (provider != null && r.provider != provider)) continue
            c++
            if (!r.reported) { un++; continue }
            i += r.inTok; o += r.outTok
            val k = costOf(r); if (k == null) np++ else cost += k
        }
        return Stat(c, un, i, o, cost, np)
    }

    private const val DAY = 86_400_000L
    /** Day boundaries use the device time zone offset given by the caller (ms). */
    fun dayStart(now: Long, tzOffsetMs: Long): Long = Math.floorDiv(now + tzOffsetMs, DAY) * DAY - tzOffsetMs
    fun weekStart(now: Long, tzOffsetMs: Long): Long { val d = dayStart(now, tzOffsetMs); val dow = ((Math.floorDiv(d + tzOffsetMs, DAY) + 3) % 7 + 7) % 7; return d - dow * DAY } // Monday
    fun monthStart(now: Long, tzOffsetMs: Long): Long {
        val cal = java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC")); cal.timeInMillis = now + tzOffsetMs
        cal.set(java.util.Calendar.DAY_OF_MONTH, 1); cal.set(java.util.Calendar.HOUR_OF_DAY, 0); cal.set(java.util.Calendar.MINUTE, 0); cal.set(java.util.Calendar.SECOND, 0); cal.set(java.util.Calendar.MILLISECOND, 0)
        return cal.timeInMillis - tzOffsetMs
    }

    /** Warnings such as "Daily budget 80 % used (estimated)". Empty when no budget is set or none is near. */
    fun warnings(now: Long, tz: Long): List<String> {
        val out = ArrayList<String>()
        fun chk(name: String, budget: Double, from: Long) {
            if (budget <= 0) return
            val used = stat(from, Long.MAX_VALUE).estCost
            when { used >= budget -> out.add("$name budget reached: ${fmt(used)} of ${fmt(budget)} $currency (estimated)"); used >= budget * 0.8 -> out.add("$name budget 80% used: ${fmt(used)} of ${fmt(budget)} $currency (estimated)") }
        }
        chk("Daily", dailyBudget, dayStart(now, tz)); chk("Weekly", weeklyBudget, weekStart(now, tz)); chk("Monthly", monthlyBudget, monthStart(now, tz))
        return out
    }
    private fun fmt(d: Double) = String.format(java.util.Locale.US, "%.4f", d)

    @Synchronized fun summaryJson(now: Long, tz: Long): JSONObject {
        fun one(s: Stat) = JSONObject().put("calls", s.calls).put("unreportedCalls", s.unreported).put("inTokens", s.inTok).put("outTokens", s.outTok)
            .put("estimatedCost", s.estCost).put("costKind", "estimated from your price table").put("callsWithoutPrice", s.unpriced)
        val prov = recs.map { it.provider }.distinct()
        val byP = JSONObject(); for (p in prov) byP.put(p, one(stat(0, Long.MAX_VALUE, p)))
        return JSONObject().put("currency", currency).put("today", one(stat(dayStart(now, tz), Long.MAX_VALUE))).put("week", one(stat(weekStart(now, tz), Long.MAX_VALUE)))
            .put("month", one(stat(monthStart(now, tz), Long.MAX_VALUE))).put("all", one(stat(0, Long.MAX_VALUE))).put("byProvider", byP)
            .put("warnings", JSONArray(warnings(now, tz)))
    }

    /** CSV export. Columns say plainly which numbers are provider-reported and which cost is estimated. */
    @Synchronized fun csv(): String {
        val sb = StringBuilder("time_ms,provider,model,input_tokens_reported,output_tokens_reported,usage_reported,ok,estimated_cost_${currency}\n")
        for (r in recs) {
            val k = costOf(r)
            sb.append(r.ts).append(',').append(q(r.provider)).append(',').append(q(r.model)).append(',').append(if (r.reported) r.inTok.toString() else "").append(',')
                .append(if (r.reported) r.outTok.toString() else "").append(',').append(r.reported).append(',').append(r.ok).append(',').append(if (k == null) "" else fmt(k)).append('\n')
        }
        return sb.toString()
    }
    private fun q(s: String) = "\"" + s.replace("\"", "\"\"") + "\""

    @Synchronized fun toJson(): JSONObject {
        val a = JSONArray(); for (r in recs) a.put(JSONObject().put("t", r.ts).put("p", r.provider).put("m", r.model).put("i", r.inTok).put("o", r.outTok).put("r", r.reported).put("k", r.ok))
        val pr = JSONObject(); for ((m, p) in prices) pr.put(m, JSONObject().put("in", p.inPerM).put("out", p.outPerM))
        return JSONObject().put("recs", a).put("prices", pr).put("bd", dailyBudget).put("bw", weeklyBudget).put("bm", monthlyBudget).put("cur", currency)
    }
    @Synchronized fun load(o: JSONObject) {
        reset()
        o.optJSONArray("recs")?.let { for (i in 0 until it.length()) { val r = it.optJSONObject(i) ?: continue; recs.add(Rec(r.optLong("t"), r.optString("p"), r.optString("m"), r.optLong("i"), r.optLong("o"), r.optBoolean("r"), r.optBoolean("k", true))) } }
        o.optJSONObject("prices")?.let { for (k in it.keys()) { val p = it.optJSONObject(k) ?: continue; prices[k] = Price(p.optDouble("in"), p.optDouble("out")) } }
        dailyBudget = o.optDouble("bd", 0.0); weeklyBudget = o.optDouble("bw", 0.0); monthlyBudget = o.optDouble("bm", 0.0); currency = o.optString("cur", "USD")
    }
}
