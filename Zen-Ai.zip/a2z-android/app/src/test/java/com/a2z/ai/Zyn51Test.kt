package com.a2z.ai

import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

class KeyPoolTest {
    private val p = FProvider("p", "P", "openai", "https://x", "m", "k1")
    @Before fun clean() { KeyPool.reset(); KeyPool.auto = true; ProviderRouter.reset() }

    @Test fun roundRobinRotates() {
        KeyPool.set("p", listOf("k1", "k2", "k3"))
        val used = (0 until 6).map { KeyPool.next("p", 1000L)!!.key }
        assertEquals(listOf("k1", "k2", "k3", "k1", "k2", "k3"), used)
    }
    @Test fun blankAndDuplicateKeysDropped() { KeyPool.set("p", listOf("a", " ", "a", "b")); assertEquals(2, KeyPool.size("p")) }
    @Test fun rateLimitCoolsKeyAndRecovers() {
        KeyPool.set("p", listOf("k1", "k2"))
        val e = KeyPool.next("p", 0L)!!
        assertEquals(ProviderRouter.Err.RATE_LIMIT, KeyPool.failure("p", e, "HTTP 429: quota", 0L))
        assertEquals("k2", KeyPool.next("p", 1L)!!.key); assertEquals("k2", KeyPool.next("p", 2L)!!.key)   // k1 skipped
        assertEquals("k1", KeyPool.next("p", 61_000L)!!.key)                                                // recovered
    }
    @Test fun invalidKeyNeverRetriedUntilReenabled() {
        KeyPool.set("p", listOf("k1", "k2")); val e = KeyPool.next("p", 0L)!!
        assertEquals(ProviderRouter.Err.AUTH, KeyPool.failure("p", e, "HTTP 401 invalid api key", 0L))
        repeat(5) { assertEquals("k2", KeyPool.next("p", 10_000_000L)!!.key) }
        KeyPool.setEnabled("p", 0, true)
        assertNotNull(KeyPool.next("p", 10_000_001L)); assertEquals(2, (0 until 4).map { KeyPool.next("p", 10_000_002L)!!.key }.distinct().size)
    }
    @Test fun allKeysCoolingReturnsNullNotLoop() {
        KeyPool.set("p", listOf("k1", "k2"))
        for (i in 0 until 2) KeyPool.failure("p", KeyPool.next("p", 0L)!!, "429", 0L)
        assertNull(KeyPool.next("p", 100L)); assertTrue(KeyPool.waitMs("p", 100L) > 0)
    }
    @Test fun networkErrorIsNotKeyFailure() {
        KeyPool.set("p", listOf("k1")); val e = KeyPool.next("p", 0L)!!
        KeyPool.failure("p", e, "connection reset", 0L); assertEquals(0, e.fail); assertFalse(e.invalid)
    }
    @Test fun disabledKeySkippedAndManualModeUsesFirstEnabled() {
        KeyPool.set("p", listOf("k1", "k2", "k3")); KeyPool.setEnabled("p", 0, false)
        assertEquals("k2", KeyPool.next("p", 0L)!!.key)
        KeyPool.auto = false; repeat(3) { assertEquals("k2", KeyPool.next("p", 0L)!!.key) }
    }
    @Test fun statsKeptWhenListUpdatedAndEditResets() {
        KeyPool.set("p", listOf("k1", "k2")); KeyPool.success("p", KeyPool.next("p", 0L)!!, 5L)
        KeyPool.set("p", listOf("k1", "k2", "k3")); assertEquals(1, org.json.JSONArray(KeyPool.statusJson("p", 0L).toString()).getJSONObject(0).getInt("ok"))
        KeyPool.edit("p", 0, "new"); assertEquals(0, KeyPool.statusJson("p", 0L).getJSONObject(0).getInt("ok"))
        KeyPool.remove("p", 0); assertEquals(2, KeyPool.size("p"))
    }
    @Test fun statusNeverContainsKeyValue() {
        KeyPool.set("p", listOf("SECRET-KEY-VALUE-1", "SECRET-KEY-VALUE-2")); KeyPool.failure("p", KeyPool.next("p", 0L)!!, "429", 0L)
        assertFalse(KeyPool.statusJson("p", 1L).toString().contains("SECRET")); assertFalse(ProviderRouter.statusJson(1L).toString().contains("SECRET"))
    }
    @Test fun callRotatesOnRateLimitAndStopsOnOtherErrors() {
        KeyPool.set("p", listOf("k1", "k2", "k3")); val seen = ArrayList<String>()
        val r = KeyPool.call(p) { pk -> seen.add(pk.key); if (pk.key != "k3") throw IllegalStateException("HTTP 429 rate limit"); "ok" }
        assertEquals("ok", r); assertEquals(listOf("k1", "k2", "k3"), seen)
        KeyPool.reset(); KeyPool.set("p", listOf("k1", "k2")); seen.clear()
        try { KeyPool.call(p) { pk -> seen.add(pk.key); throw IllegalStateException("server unavailable 503") }; fail() } catch (e: IllegalStateException) { assertEquals(1, seen.size) }
    }
    @Test fun callWithAllKeysBadGivesReadableErrorAndTriesEachOnce() {
        KeyPool.set("p", listOf("k1", "k2")); var n = 0
        try { KeyPool.call(p) { n++; throw IllegalStateException("401 invalid api key") }; fail() } catch (e: IllegalStateException) { assertEquals(2, n) }
        try { KeyPool.call(p) { n++; "x" }; fail() } catch (e: IllegalStateException) { assertEquals(2, n); assertTrue(e.message!!.contains("keys")) }
    }
    @Test fun singleKeyProviderUnchanged() { assertEquals("ok", KeyPool.call(p) { assertEquals("k1", it.key); "ok" }) }
}

class HealthStateTest {
    @Before fun clean() { ProviderRouter.reset(); ProviderRouter.deviceOffline = false }
    @Test fun unknownUntilVerified() { assertEquals(ProviderRouter.State.UNKNOWN, ProviderRouter.stateOf("a", 0L)) }
    @Test fun availableAfterSuccess() { ProviderRouter.noteSuccess("a", 300L); assertEquals(ProviderRouter.State.AVAILABLE, ProviderRouter.stateOf("a", 0L)) }
    @Test fun rateAuthDegradedUnavailable() {
        ProviderRouter.noteFailure("r", "429 quota", 0L); assertEquals(ProviderRouter.State.RATE_LIMITED, ProviderRouter.stateOf("r", 0L))
        ProviderRouter.noteFailure("u", "401 invalid key", 0L); assertEquals(ProviderRouter.State.AUTH_ERROR, ProviderRouter.stateOf("u", 0L))
        ProviderRouter.noteFailure("t", "timeout", 0L); assertEquals(ProviderRouter.State.DEGRADED, ProviderRouter.stateOf("t", 0L))
        repeat(2) { ProviderRouter.noteFailure("t", "timeout", 0L) }; assertEquals(ProviderRouter.State.UNAVAILABLE, ProviderRouter.stateOf("t", 0L))
    }
    @Test fun slowOrFlakyIsDegraded() {
        ProviderRouter.noteSuccess("s", 20_000L); assertEquals(ProviderRouter.State.DEGRADED, ProviderRouter.stateOf("s", 0L))
        ProviderRouter.reset(); repeat(3) { ProviderRouter.noteFailure("f", "timeout", 0L) }; repeat(2) { ProviderRouter.noteSuccess("f", 100L) }
        assertEquals(0.4, ProviderRouter.successRate("f"), 0.001); assertEquals(ProviderRouter.State.DEGRADED, ProviderRouter.stateOf("f", 0L))
    }
    @Test fun offlineOverridesAndHistoryIsBounded() {
        repeat(30) { ProviderRouter.noteSuccess("a", 10L) }
        assertEquals(20, ProviderRouter.statusJson(0L).getJSONObject(0).getJSONArray("history").length())
        ProviderRouter.deviceOffline = true; assertEquals(ProviderRouter.State.OFFLINE, ProviderRouter.stateOf("a", 0L))
    }
    @Test fun checksAndAutoDue() {
        ProviderRouter.noteCheck("a", true, 120L, null, 1000L); assertEquals(ProviderRouter.State.AVAILABLE, ProviderRouter.stateOf("a", 1000L))
        assertFalse(ProviderRouter.checkDue("a", 2000L, 60_000L)); assertTrue(ProviderRouter.checkDue("a", 61_001L, 60_000L)); assertFalse(ProviderRouter.checkDue("a", 999_999L, 0L))
    }
}

class ReasoningPolicyTest {
    @Before fun clean() { ReasoningPolicy.defaultDepth = null; ReasoningPolicy.auto = false; Role.values().forEach { ReasoningPolicy.setAgent(it, null) } }
    @Test fun onlyRealControlsAreProduced() {
        assertNull(ReasoningPolicy.gemini("gpt-4o", ReasoningPolicy.Depth.DEEP)); assertNull(ReasoningPolicy.gemini("deepseek-chat", null)); assertNull(ReasoningPolicy.gemini("gemini-2.0-flash", ReasoningPolicy.Depth.DEEP))
        assertFalse(ReasoningPolicy.supported("llama-3")); assertTrue(ReasoningPolicy.supported("models/gemini-3-flash"))
    }
    @Test fun geminiMapping() {
        assertEquals("low", ReasoningPolicy.gemini("gemini-3-pro", ReasoningPolicy.Depth.QUICK)!!.getString("thinkingLevel"))
        assertEquals("high", ReasoningPolicy.gemini("gemini-3-pro", ReasoningPolicy.Depth.DEEP)!!.getString("thinkingLevel"))
        assertEquals(0, ReasoningPolicy.gemini("gemini-2.5-flash", ReasoningPolicy.Depth.QUICK)!!.getInt("thinkingBudget"))
        assertEquals(-1, ReasoningPolicy.gemini("gemini-2.5-flash", ReasoningPolicy.Depth.DEEP)!!.getInt("thinkingBudget"))
        assertNull(ReasoningPolicy.gemini("gemini-2.5-pro", ReasoningPolicy.Depth.QUICK))   // cannot be switched off
    }
    @Test fun legacyBehaviourWhenUnset() { assertEquals("low", ReasoningPolicy.gemini("gemini-3-flash", null)!!.getString("thinkingLevel")); assertEquals(0, ReasoningPolicy.gemini("gemini-2.5-flash", null)!!.getInt("thinkingBudget")) }
    @Test fun priorityOverrideAgentDefaultAuto() {
        assertNull(ReasoningPolicy.resolve(null, null, null))
        ReasoningPolicy.auto = true; assertEquals(ReasoningPolicy.Depth.DEEP, ReasoningPolicy.resolve(null, null, Orchestrator.Complexity.COMPLEX))
        ReasoningPolicy.defaultDepth = ReasoningPolicy.Depth.BALANCED; assertEquals(ReasoningPolicy.Depth.BALANCED, ReasoningPolicy.resolve(null, null, Orchestrator.Complexity.COMPLEX))
        ReasoningPolicy.setAgent(Role.CODING, ReasoningPolicy.Depth.DEEP); assertEquals(ReasoningPolicy.Depth.DEEP, ReasoningPolicy.resolve(null, Role.CODING, null))
        assertEquals(ReasoningPolicy.Depth.QUICK, ReasoningPolicy.resolve(ReasoningPolicy.Depth.QUICK, Role.CODING, null))
        assertNull(ReasoningPolicy.parse("x")); assertEquals(ReasoningPolicy.Depth.DEEP, ReasoningPolicy.parse("Deep"))
    }
}

class UsageTrackerTest {
    private val H = 3_600_000L
    @Before fun clean() { UsageTracker.reset() }
    @Test fun unreportedCallsAreNotInventedAsTokens() {
        UsageTracker.record(1000L, "p", "m", null, null); UsageTracker.record(1001L, "p", "m", 100L, 50L)
        val s = UsageTracker.stat(0, Long.MAX_VALUE); assertEquals(2, s.calls); assertEquals(1, s.unreported); assertEquals(100L, s.inTok); assertEquals(50L, s.outTok)
    }
    @Test fun costOnlyWithUserPrice() {
        UsageTracker.record(1L, "p", "m1", 1_000_000L, 500_000L)
        var s = UsageTracker.stat(0, Long.MAX_VALUE); assertEquals(0.0, s.estCost, 0.0); assertEquals(1, s.unpriced)
        UsageTracker.setPrice("M1", 2.0, 8.0); s = UsageTracker.stat(0, Long.MAX_VALUE); assertEquals(6.0, s.estCost, 1e-9); assertEquals(0, s.unpriced)
        assertTrue(UsageTracker.summaryJson(10L, 0L).getJSONObject("all").getString("costKind").contains("estimated"))
    }
    @Test fun periodsAndByProvider() {
        val now = 10 * 86_400_000L + 12 * H   // a Sunday 12:00 UTC (day 10 since epoch = Sunday Jan 11 1970)
        UsageTracker.record(now - 2 * 86_400_000L, "a", "m", 10L, 1L); UsageTracker.record(now - H, "a", "m", 20L, 2L); UsageTracker.record(now - H, "b", "m", 5L, 5L)
        assertEquals(25L, UsageTracker.stat(UsageTracker.dayStart(now, 0), Long.MAX_VALUE).inTok)
        assertEquals(20L, UsageTracker.stat(UsageTracker.dayStart(now, 0), Long.MAX_VALUE, "a").inTok)
        assertEquals(30L, UsageTracker.stat(0, Long.MAX_VALUE, "a").inTok)
        assertEquals(UsageTracker.dayStart(now, 0) - 6 * 86_400_000L, UsageTracker.weekStart(now, 0))   // Monday before a Sunday
        assertEquals(2, UsageTracker.summaryJson(now, 0L).getJSONObject("byProvider").length())
    }
    @Test fun timezoneOffsetShiftsDayStart() {
        val colombo = 5 * 3_600_000L + 1_800_000L   // UTC+05:30
        val now = 5 * 86_400_000L + 20 * H           // 20:00 UTC = 01:30 next day in Colombo
        assertEquals(5 * 86_400_000L, UsageTracker.dayStart(now, 0))
        assertEquals(5 * 86_400_000L + 18 * H + 1_800_000L, UsageTracker.dayStart(now, colombo))   // local midnight = 18:30 UTC
    }
    @Test fun budgetWarnings() {
        UsageTracker.setPrice("m", 1.0, 0.0); UsageTracker.dailyBudget = 10.0; val now = 86_400_000L * 3 + H
        UsageTracker.record(now, "p", "m", 7_000_000L, 0L); assertTrue(UsageTracker.warnings(now, 0L).isEmpty())
        UsageTracker.record(now, "p", "m", 1_500_000L, 0L); assertTrue(UsageTracker.warnings(now, 0L)[0].contains("80%"))
        UsageTracker.record(now, "p", "m", 2_000_000L, 0L); assertTrue(UsageTracker.warnings(now, 0L)[0].contains("reached"))
        assertTrue(UsageTracker.warnings(now + 2 * 86_400_000L, 0L).isEmpty())   // a new day starts clean
    }
    @Test fun csvAndPersistenceRoundTrip() {
        UsageTracker.setPrice("m", 1.0, 2.0); UsageTracker.record(5L, "p\"x", "m", 1000L, 500L); UsageTracker.record(6L, "p", "m", null, null)
        val c = UsageTracker.csv().trim().lines(); assertEquals(3, c.size); assertTrue(c[1].contains("\"p\"\"x\"")); assertTrue(c[2].contains(",,,false"))
        val j = UsageTracker.toJson(); UsageTracker.reset(); UsageTracker.load(j)
        assertEquals(2, UsageTracker.stat(0, Long.MAX_VALUE).calls); assertNotNull(UsageTracker.price("m"))
    }
}

class FrameDedupTest {
    private fun flat(v: Int, n: Int) = IntArray(n) { v }
    private fun grid9(v: Int = 100) = IntArray(72) { v + (it % 9) * 3 }
    @Test fun hashAndHamming() { assertEquals(0, FrameDedup.hamming(FrameDedup.dHash(grid9()), FrameDedup.dHash(grid9()))); assertTrue(FrameDedup.hamming(FrameDedup.dHash(grid9()), FrameDedup.dHash(IntArray(72) { 255 - (it % 9) * 3 })) > 40) }
    @Test fun firstKeptSameSkippedChangeKept() {
        val d = FrameDedup(); val g = flat(100, 1024); val h = FrameDedup.dHash(grid9())
        assertEquals(FrameDedup.Decision.KEEP_FIRST, d.decide(100, 200, h, g, null, 0L))
        assertEquals(FrameDedup.Decision.SKIP, d.decide(100, 200, h, g.clone(), null, 100L))
        assertEquals(FrameDedup.Decision.KEEP_CHANGED, d.decide(100, 200, FrameDedup.dHash(IntArray(72) { 255 - (it % 9) * 30 }), g, null, 200L))
        assertEquals(1, d.skipped); assertEquals(2, d.kept)
    }
    @Test fun smallLocalTextChangeIsNotDiscarded() {
        val d = FrameDedup(); val g = flat(240, 1024); val h = FrameDedup.dHash(grid9()); d.decide(100, 200, h, g, null, 0L)
        val g2 = g.clone(); for (i in 100..103) g2[i] = 20   // one dark line of text appears: 4 cells
        assertEquals(FrameDedup.Decision.KEEP_TEXT, d.decide(100, 200, h, g2, null, 50L))
        val g3 = g2.clone(); g3[500] = 200   // tiny noise: 1 cell
        assertEquals(FrameDedup.Decision.SKIP, d.decide(100, 200, h, g3, null, 60L))
    }
    @Test fun textSignatureAndRotationAndRefresh() {
        val d = FrameDedup(); val g = flat(100, 1024); val h = FrameDedup.dHash(grid9()); d.decide(100, 200, h, g, "hello", 0L)
        assertEquals(FrameDedup.Decision.KEEP_TEXT, d.decide(100, 200, h, g, "hello world", 10L))
        assertEquals(FrameDedup.Decision.KEEP_ROTATED, d.decide(200, 100, h, g, "hello world", 20L))
        assertEquals(FrameDedup.Decision.SKIP, d.decide(200, 100, h, g, "hello world", 30L))
        assertEquals(FrameDedup.Decision.KEEP_REFRESH, d.decide(200, 100, h, g, "hello world", 5_100L))
    }
    @Test fun thresholdIsConfigurable() {
        val g = flat(100, 1024); val a = FrameDedup.dHash(grid9()); val b = a xor 0x3FL   // 6 bits differ
        val strict = FrameDedup(threshold = 5); strict.decide(1, 1, a, g, null, 0L); assertEquals(FrameDedup.Decision.KEEP_CHANGED, strict.decide(1, 1, b, g, null, 1L))
        val loose = FrameDedup(threshold = 8); loose.decide(1, 1, a, g, null, 0L); assertEquals(FrameDedup.Decision.SKIP, loose.decide(1, 1, b, g, null, 1L))
    }
}

class NetRecoveryTest {
    @Test fun backoffDoublesAndCaps() { val n = NetRecovery(); assertEquals(listOf(1000L, 2000L, 4000L, 8000L, 16000L, 30000L, 30000L), (1..7).map { n.delayFor(it) }) }
    @Test fun lostThenRecoverWithBackoff() {
        val n = NetRecovery(); assertTrue(n.mayRequest(0L)); n.onLost(); assertEquals(NetRecovery.State.OFFLINE, n.state); assertFalse(n.mayRequest(1L))
        n.onAvailable(100L); assertEquals(NetRecovery.State.RECONNECTING, n.state); assertTrue(n.mayRequest(100L))
        n.onRequestFailed(100L); assertFalse(n.mayRequest(500L)); assertTrue(n.mayRequest(1100L))
        n.onRequestOk(); assertEquals(NetRecovery.State.ONLINE, n.state)
    }
    @Test fun givesUpAfterMaxAttempts() {
        val n = NetRecovery(maxAttempts = 3); n.onLost(); n.onAvailable(0L); repeat(3) { n.onRequestFailed(0L) }
        assertEquals(NetRecovery.State.GAVE_UP, n.state); assertFalse(n.mayRequest(10_000_000L))
        n.onAvailable(5L); assertTrue(n.mayRequest(5L))   // a new connection event restarts it, user-visible, not an endless loop
    }
    @Test fun neverRestartsProjectionByItself() {
        val n = NetRecovery(); n.onProjectionEnded(); assertEquals(NetRecovery.State.NEEDS_CONSENT, n.state)
        n.onAvailable(0L); n.onLost(); n.onRequestOk(); assertEquals(NetRecovery.State.NEEDS_CONSENT, n.state); assertFalse(n.mayRequest(1L))
        n.onUserRestarted(); assertTrue(n.mayRequest(2L))
    }
    @Test fun staleFramesDropped() { val n = NetRecovery(); assertTrue(n.fresh(1000L, 3000L)); assertFalse(n.fresh(1000L, 4500L)) }
}

class OcrLangTest {
    @Before fun clean() { OcrLang.onlineConsent = false; OcrLang.language = OcrLang.Lang.AUTO }
    private val tamil = "வணக்கம் உலகம்"; private val sinhala = "ආයුබෝවන් ලෝකය"
    @Test fun detectsScripts() {
        assertEquals(OcrLang.Script.TAMIL, OcrLang.dominant(tamil)); assertEquals(OcrLang.Script.SINHALA, OcrLang.dominant(sinhala))
        assertNull(OcrLang.dominant("Hello world")); assertNull(OcrLang.dominant("")); assertEquals(OcrLang.Script.TAMIL, OcrLang.dominant("Wi-Fi $tamil"))
        assertNull(OcrLang.dominant("This is a long english sentence with one letter இ"))
    }
    @Test fun noOnlineEngineWithoutConsent() {
        assertEquals(OcrLang.Engine.UNAVAILABLE, OcrLang.engineFor(OcrLang.Lang.TAMIL, true))
        OcrLang.onlineConsent = true; assertEquals(OcrLang.Engine.ONLINE_VISION, OcrLang.engineFor(OcrLang.Lang.SINHALA, true)); assertEquals(OcrLang.Engine.UNAVAILABLE, OcrLang.engineFor(OcrLang.Lang.TAMIL, false))
        assertEquals(OcrLang.Engine.ONDEVICE, OcrLang.engineFor(OcrLang.Lang.ENGLISH, false))
    }
    @Test fun promptForbidsTranslationAndReplyIsChecked() {
        assertTrue(OnlineOcr.prompt(OcrLang.Lang.TAMIL).contains("Do not translate")); assertTrue(OnlineOcr.looksRight(tamil, OcrLang.Lang.TAMIL))
        assertFalse(OnlineOcr.looksRight("Hello", OcrLang.Lang.TAMIL)); assertFalse(OnlineOcr.looksRight(tamil, OcrLang.Lang.SINHALA))
    }
}

class AiConfigTest {
    @Before fun clean() { UsageTracker.reset(); KeyPool.auto = true; OcrLang.onlineConsent = false; ReasoningPolicy.defaultDepth = null; ReasoningPolicy.auto = false; Role.values().forEach { ReasoningPolicy.setAgent(it, null) } }
    @Test fun appliesSettings() {
        AiConfig.apply(org.json.JSONObject("""{"depth":"deep","auto":true,"agents":{"CODING":"quick"},"keyAuto":false,"prices":{"M":{"in":1.5,"out":3}},"budget":{"d":5,"w":20,"m":60},"currency":"LKR","ocrLang":"tamil","ocrConsent":true,"dedup":{"on":false,"threshold":9},"healthMin":10}"""))
        assertEquals(ReasoningPolicy.Depth.DEEP, ReasoningPolicy.defaultDepth); assertEquals(ReasoningPolicy.Depth.QUICK, ReasoningPolicy.agent(Role.CODING)); assertFalse(KeyPool.auto)
        assertEquals(3.0, UsageTracker.price("m")!!.outPerM, 0.0); assertEquals(5.0, UsageTracker.dailyBudget, 0.0); assertEquals("LKR", UsageTracker.currency)
        assertEquals(OcrLang.Lang.TAMIL, OcrLang.language); assertTrue(OcrLang.onlineConsent); assertFalse(AiConfig.dedupOn); assertEquals(9, AiConfig.dedupThreshold); assertEquals(600_000L, AiConfig.healthIntervalMs)
    }
    @Test fun invalidValuesIgnoredOrClamped() {
        AiConfig.apply(org.json.JSONObject("""{"depth":"bogus","prices":{"x":{"in":-5,"out":1}},"budget":{"d":-3},"dedup":{"threshold":999},"healthMin":-4}"""))
        assertNull(ReasoningPolicy.defaultDepth); assertNull(UsageTracker.price("x")); assertEquals(0.0, UsageTracker.dailyBudget, 0.0); assertEquals(20, AiConfig.dedupThreshold); assertEquals(0L, AiConfig.healthIntervalMs)
    }
}

class CameraGateTest {
    @Test fun framesThrottledAndDroppedWhilePaused() {
        val g = CameraGate(minFrameMs = 400L); assertTrue(g.acceptFrame(1000L)); assertFalse(g.acceptFrame(1200L)); assertTrue(g.acceptFrame(1500L))
        g.pause(); assertFalse(g.hasFrame); assertFalse(g.acceptFrame(5000L)); g.resume(); assertTrue(g.acceptFrame(5001L))
    }
    @Test fun noRequestWithoutFrameOrWhilePausedOrBusy() {
        val g = CameraGate(); assertFalse(g.begin(0L, false))          // no frame yet
        g.acceptFrame(1000L); assertTrue(g.begin(1020L, false)); assertFalse(g.begin(1030L, false)); g.end(); assertTrue(g.begin(1040L, false)); g.end()
        g.pause(); assertFalse(g.begin(50L, false))
    }
    @Test fun liveMode_needsSwitchIntervalAndOneAtATime() {
        val g = CameraGate(liveIntervalMs = 6000L); g.acceptFrame(1000L)
        assertFalse(g.begin(1L, true))                                 // Live is off
        g.live = true; assertTrue(g.begin(10_000L, true)); assertFalse(g.begin(10_001L, true)); g.end()
        assertFalse(g.begin(12_000L, true)); assertTrue(g.begin(16_001L, true)); g.end()
        g.pause(); assertFalse(g.live)                                  // pausing stops Live
    }
    @Test fun flipDropsFrameAndStopClearsEverything() {
        val g = CameraGate(); g.acceptFrame(0L); assertFalse(g.front); g.flip(); assertTrue(g.front); assertFalse(g.hasFrame)
        g.acceptFrame(1000L); g.live = true; g.stop(); assertTrue(g.paused); assertFalse(g.hasFrame); assertFalse(g.live); assertFalse(g.begin(9999L, false))
    }
}
