package com.a2z.ai

import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import java.io.File
import java.util.concurrent.atomic.AtomicInteger

/** Pure JVM tests: fake agents, no Android. Run: ./gradlew testDebugUnitTest */
class FakeAgent(override val role: Role, val body: (AgentCall, String) -> AgentResult) : Agent {
    val runs = AtomicInteger(); val cancels = AtomicInteger()
    override fun run(call: AgentCall, input: String): AgentResult { runs.incrementAndGet(); return body(call, input) }
    override fun onCancel(ctx: AgentCtx) { cancels.incrementAndGet() }
}
private fun ok(t: String, src: List<Pair<String, String>> = emptyList()) = AgentResult(true, t, src)
private fun ctx(id: Long = 1L, ms: Long = 60_000L) = AgentCtx(id, System.currentTimeMillis() + ms)

class AgentRuntimeTest {
    private fun rt() = AgentRuntime(3, 3)

    @Test fun delegationReturnsResultAndLogsMessages() {
        val r = rt(); r.register(FakeAgent(Role.CODING) { _, i -> ok("code for $i") })
        val c = ctx(); val res = r.delegate(c, emptyList(), Role.CODING, "sort a list")
        assertTrue(res.ok); assertEquals("code for sort a list", res.text)
        assertEquals(listOf("request", "result"), c.trail.map { it.kind }); assertEquals(1L, c.trail[0].taskId)
        assertEquals("CODING", c.trail[1].from)
    }
    @Test fun agentCanDelegateToAnotherAgent() {
        val r = rt()
        r.register(FakeAgent(Role.CONVERSATION) { call, i -> val x = call.delegate(Role.RESEARCH, "facts about $i"); ok("answer: " + x.text) })
        r.register(FakeAgent(Role.RESEARCH) { _, i -> ok("[$i]") })
        assertEquals("answer: [facts about moon]", r.delegate(ctx(), emptyList(), Role.CONVERSATION, "moon").text)
    }
    @Test fun parallelAgentsReallyRunAtTheSameTime() {
        val r = rt()
        r.register(FakeAgent(Role.RESEARCH) { _, _ -> Thread.sleep(400); ok("a") })
        r.register(FakeAgent(Role.CODING) { _, _ -> Thread.sleep(400); ok("b") })
        val t0 = System.currentTimeMillis()
        val out = r.parallel(ctx(), emptyList(), listOf(Role.RESEARCH to "x", Role.CODING to "y"))
        val dt = System.currentTimeMillis() - t0
        assertTrue(out.all { it.ok }); assertTrue("took $dt ms", dt < 750)
    }
    @Test fun concurrencyIsBounded() {
        val r = AgentRuntime(1, 3)
        val now = AtomicInteger(); val peak = AtomicInteger()
        val body = { _: AgentCall, _: String -> val n = now.incrementAndGet(); peak.updateAndGet { maxOf(it, n) }; Thread.sleep(150); now.decrementAndGet(); ok("x") }
        r.register(FakeAgent(Role.RESEARCH, body)); r.register(FakeAgent(Role.CODING, body))
        r.parallel(ctx(), emptyList(), listOf(Role.RESEARCH to "a", Role.CODING to "b"))
        assertEquals(1, peak.get())
    }
    @Test fun circularDelegationIsBlocked() {
        val r = rt()
        r.register(FakeAgent(Role.RESEARCH) { call, _ -> call.delegate(Role.CODING, "back") })
        r.register(FakeAgent(Role.CODING) { call, _ -> call.delegate(Role.RESEARCH, "again") })
        val res = r.delegate(ctx(), emptyList(), Role.RESEARCH, "go")
        assertFalse(res.ok); assertTrue(res.error, res.error.contains("circular"))
    }
    @Test fun delegationDepthIsLimited() {
        val r = AgentRuntime(3, 2)
        r.register(FakeAgent(Role.RESEARCH) { call, _ -> call.delegate(Role.CODING, "1") })
        r.register(FakeAgent(Role.CODING) { call, _ -> call.delegate(Role.VISION, "2") })
        r.register(FakeAgent(Role.VISION) { _, _ -> ok("deep") })
        val res = r.delegate(ctx(), emptyList(), Role.RESEARCH, "go")
        assertFalse(res.ok); assertTrue(res.error, res.error.contains("too deep"))
    }
    @Test fun sameWorkIsNotExecutedTwice() {
        val r = rt(); val a = FakeAgent(Role.CODING) { _, _ -> ok("done") }; r.register(a)
        val c = ctx(); r.delegate(c, emptyList(), Role.CODING, "Same Task"); r.delegate(c, emptyList(), Role.CODING, "same task")
        assertEquals(1, a.runs.get())
    }
    @Test fun timeoutIsRecoverableAndRetriedOnce() {
        val r = rt(); val a = FakeAgent(Role.RESEARCH) { _, _ -> Thread.sleep(3000); ok("late") }; r.register(a)
        val res = r.delegate(ctx(), emptyList(), Role.RESEARCH, "slow", 200L)
        assertFalse(res.ok); assertTrue(res.error.contains("timed out")); assertEquals(2, a.runs.get())
    }
    @Test fun crashThenSuccessRecovers() {
        val r = rt(); val n = AtomicInteger()
        r.register(FakeAgent(Role.RESEARCH) { _, _ -> if (n.incrementAndGet() == 1) throw IllegalStateException("boom") else ok("fine") })
        val res = r.delegate(ctx(), emptyList(), Role.RESEARCH, "q")
        assertTrue(res.ok); assertEquals(2, n.get())
    }
    @Test fun deviceAgentIsNeverRetried() {
        val r = rt(); val a = FakeAgent(Role.TASK_EXECUTION) { _, _ -> throw IllegalStateException("x") }; r.register(a)
        assertFalse(r.delegate(ctx(), emptyList(), Role.TASK_EXECUTION, "tap").ok); assertEquals(1, a.runs.get())
    }
    @Test fun onlyOneAgentMayControlThePhone() {
        val r = rt()
        r.register(FakeAgent(Role.TASK_EXECUTION) { _, _ -> Thread.sleep(500); ok("done") })
        val out = arrayOfNulls<AgentResult>(2)
        val t1 = Thread { out[0] = r.delegate(ctx(1), emptyList(), Role.TASK_EXECUTION, "a") }
        t1.start(); Thread.sleep(150)
        out[1] = r.delegate(ctx(2), emptyList(), Role.TASK_EXECUTION, "b"); t1.join()
        assertTrue(out[0]!!.ok); assertFalse(out[1]!!.ok); assertTrue(out[1]!!.error.contains("already being controlled"))
        assertNull(r.deviceHolder())
    }
    @Test fun deviceAgentsCannotRunInParallel() {
        val r = rt(); r.register(FakeAgent(Role.TASK_EXECUTION) { _, _ -> ok("x") })
        assertFalse(r.parallel(ctx(), emptyList(), listOf(Role.TASK_EXECUTION to "a"))[0].ok)
    }
    @Test fun cancellationStopsRunningAgentAndCallsOnCancel() {
        val r = rt(); val a = FakeAgent(Role.RESEARCH) { _, _ -> Thread.sleep(5000); ok("never") }; r.register(a)
        val c = ctx(); var res: AgentResult? = null
        val t = Thread { res = r.delegate(c, emptyList(), Role.RESEARCH, "long") }
        t.start(); Thread.sleep(200); val t0 = System.currentTimeMillis(); r.cancel(c); t.join(3000)
        assertFalse(res!!.ok); assertTrue(System.currentTimeMillis() - t0 < 2500); assertTrue(a.cancels.get() >= 1)
        assertFalse(r.delegate(c, emptyList(), Role.RESEARCH, "after").ok)
    }
    @Test fun badOutputAndBadInputAreRejected() {
        val r = rt(); r.register(FakeAgent(Role.CODING) { _, _ -> AgentResult(true, "  ") })
        assertTrue(r.delegate(ctx(), emptyList(), Role.CODING, "x").error.contains("rejected"))
        assertTrue(r.delegate(ctx(), emptyList(), Role.CODING, "   ").error.contains("input rejected"))
        assertFalse(r.delegate(ctx(), emptyList(), Role.VISION, "x").ok)
    }
    @Test fun historyIsKeptPerAgent() {
        val r = rt(); r.register(FakeAgent(Role.CODING) { _, i -> if (i == "bad") AgentResult.fail("no") else ok("y") })
        r.delegate(ctx(), emptyList(), Role.CODING, "good"); r.delegate(ctx(), emptyList(), Role.CODING, "bad")
        val h = r.history(Role.CODING); assertEquals(listOf("done", "failed"), h.map { it.state })
    }
}

class CoordinatorTest {
    @Before fun clean() { TaskManager.resetForTest(); Orchestrator.releaseDevice() }
    private val deviceInputs = java.util.concurrent.CopyOnWriteArrayList<String>()
    private fun setup(planner: (String) -> AgentResult): Pair<AgentRuntime, Coordinator> {
        val r = AgentRuntime(3, 3)
        r.register(FakeAgent(Role.PLANNING) { _, i -> planner(i) })
        r.register(FakeAgent(Role.RESEARCH) { _, i -> ok("research on $i", listOf("Moon" to "https://x/moon")) })
        r.register(FakeAgent(Role.VISION) { _, i -> ok("screen shows settings for $i") })
        r.register(FakeAgent(Role.CONVERSATION) { _, i -> ok(if (i.startsWith("COMBINE")) "combined answer" else "hello there") })
        r.register(FakeAgent(Role.TASK_EXECUTION) { _, i -> deviceInputs.add(i); ok("did: $i") })
        return r to Coordinator(r)
    }
    private val plan = """{"steps":[{"agent":"research","input":"moon facts"},{"agent":"vision","input":"what is on screen"},{"agent":"task_execution","input":"open notes and write {{step1}}"}]}"""

    @Test fun planDelegatesToAgentsAndAggregatesResults() {
        val (_, co) = setup { ok(plan) }
        TaskManager.enqueue("research the moon and then open notes and write it", 5)!!.let { TaskManager.activate(it) }
        val out = co.run(ctx(), "research the moon and then open notes and write it down", true)
        assertTrue(out.issues.toString(), out.ok)
        assertEquals(listOf("https://x/moon"), out.sources.map { it.second })
        assertEquals("combined answer", out.text)                                        // three results were combined by the Conversation Agent
        assertEquals(listOf("open notes and write research on moon facts"), deviceInputs)  // the research result was passed to the device step
        assertTrue(TaskManager.active!!.checkpoints.any { it.step.startsWith("act:") && it.verified })
    }
    @Test fun chatGoesToConversationAgentOnly() {
        val (rt, co) = setup { ok(plan) }
        val out = co.run(ctx(), "hello", false)
        assertEquals("hello there", out.text); assertEquals(0, rt.history(Role.PLANNING).size)
    }
    @Test fun plannerFailureFallsBackToStandardPlan() {
        val (_, co) = setup { AgentResult.fail("no provider") }
        val out = co.run(ctx(), "open settings then scroll down and then tap about phone", false)
        assertTrue(out.text, out.ok); assertTrue(out.issues.any { it.contains("Planner failed") }); assertTrue(out.text.startsWith("did:"))
    }
    @Test fun garbagePlanFallsBack() {
        val (_, co) = setup { ok("I think you should relax") }
        assertTrue(co.run(ctx(), "open settings then scroll down and then tap about phone", false).ok)
    }
    @Test fun failedDeviceStepStopsAndIsReported() {
        val r = AgentRuntime(3, 3)
        r.register(FakeAgent(Role.TASK_EXECUTION) { _, _ -> AgentResult.fail("screen not found") })
        val out = Coordinator(r).run(ctx(), "open settings", false)
        assertFalse(out.ok); assertTrue(out.text.contains("screen not found"))
    }
    @Test fun researchWithoutSourcesIsFlagged() {
        val steps = listOf(PlanStep(Role.RESEARCH, "x")); val res = mapOf(0 to ok("answer"))
        assertTrue(Coordinator(AgentRuntime()).verify(steps, res)[0].contains("no sources"))
    }
    @Test fun verifiedStepIsSkippedAndUnsureStepIsNotRepeatedAfterRestart() {
        val r = AgentRuntime(3, 3); val dev = FakeAgent(Role.TASK_EXECUTION) { _, i -> ok("did $i") }; r.register(dev)
        val key = PlanStep(Role.TASK_EXECUTION, "open settings").key
        TaskManager.enqueue("open settings", 5)!!.let { TaskManager.activate(it)!!; it.resumeDone = setOf("act:$key") }
        val out1 = Coordinator(r).run(ctx(), "open settings", false)
        assertTrue(out1.ok); assertEquals(0, dev.runs.get()); assertTrue(out1.issues.any { it.contains("already verified") })
        TaskManager.resetForTest()
        TaskManager.enqueue("open settings", 5)!!.let { TaskManager.activate(it)!!; it.resumeUnsure = setOf("act:$key") }
        val out2 = Coordinator(r).run(ctx(2), "open settings", false)
        assertFalse(out2.ok); assertEquals(0, dev.runs.get()); assertTrue(out2.text.contains("may already have been done"))
    }
}

class PlanParserTest {
    @Test fun parsesFencedPlanAndDropsUnknownAgents() {
        val p = PlanParser.parse("```json\n{\"steps\":[{\"agent\":\"Research\",\"input\":\"a\"},{\"agent\":\"hacker\",\"input\":\"b\"},{\"agent\":\"coding\",\"input\":\"\"},{\"agent\":\"research\",\"input\":\"A\"}]}\n```")
        assertEquals(listOf(Role.RESEARCH), p.map { it.role })
    }
    @Test fun limitsStepsAndRejectsPlanningAgentAsAStep() {
        val steps = (1..9).joinToString(",") { "{\"agent\":\"research\",\"input\":\"q$it\"}" }
        assertEquals(6, PlanParser.parse("{\"steps\":[$steps]}").size)
        assertTrue(PlanParser.parse("{\"steps\":[{\"agent\":\"planning\",\"input\":\"x\"}]}").isEmpty())
    }
    @Test fun garbageIsEmpty() { assertTrue(PlanParser.parse("hello").isEmpty()); assertTrue(PlanParser.parse("{\"steps\":\"x\"}").isEmpty()) }
}

class TaskQueueTest {
    @Before fun clean() { TaskManager.resetForTest() }

    @Test fun priorityThenFifo() {
        TaskManager.enqueue("low", 2, now = 1L); TaskManager.enqueue("high", 9, now = 2L); TaskManager.enqueue("mid a", 5, now = 3L); TaskManager.enqueue("mid b", 5, now = 4L)
        val order = ArrayList<String>()
        while (true) { val n = TaskManager.nextRunnable(10L) ?: break; TaskManager.activate(n); order.add(n.text); TaskManager.endManaged(true, false, "ok") }
        assertEquals(listOf("high", "mid a", "mid b", "low"), order)
    }
    @Test fun onlyOneTaskRunsAtATime() {
        TaskManager.enqueue("a"); TaskManager.enqueue("b")
        TaskManager.activate(TaskManager.nextRunnable()!!)
        assertNull(TaskManager.nextRunnable())
    }
    @Test fun dependencyWaitsAndFailureCancelsDependents() {
        val a = TaskManager.enqueue("first", 1, now = 1L)!!
        val b = TaskManager.enqueue("second", 9, listOf(a.id), now = 2L)!!
        assertEquals("first", TaskManager.nextRunnable()!!.text)       // second has higher priority but must wait
        TaskManager.activate(a); TaskManager.endManaged(false, false, "failed")
        assertNull(TaskManager.nextRunnable())
        assertEquals(TaskState.CANCELLED, TaskManager.finishedById(b.id)!!.state)
    }
    @Test fun unknownDependencyIsRejected() { assertNull(TaskManager.enqueue("x", 5, listOf(999L))) }
    @Test fun duplicatesAreRejectedInQueueAndWhileRunning() {
        assertNotNull(TaskManager.enqueue("Open  Settings")); assertNull(TaskManager.enqueue("open settings"))
        TaskManager.activate(TaskManager.nextRunnable()!!); assertNull(TaskManager.enqueue("OPEN SETTINGS"))
    }
    @Test fun pauseStopsStartingAndResumeContinues() {
        TaskManager.enqueue("a"); TaskManager.pauseQueue(true); assertNull(TaskManager.nextRunnable())
        TaskManager.pauseQueue(false); assertNotNull(TaskManager.nextRunnable())
    }
    @Test fun cancelPendingMovesToFailedHistory() {
        val a = TaskManager.enqueue("a")!!; assertTrue(TaskManager.cancelPending(a.id))
        assertEquals(TaskState.CANCELLED, TaskManager.finishedById(a.id)!!.state); assertFalse(TaskManager.cancelPending(a.id))
    }
    @Test fun retryIsLimited() {
        var cur = TaskManager.enqueue("flaky")!!
        for (i in 1..3) { TaskManager.activate(cur); TaskManager.endManaged(false, false, "x"); cur = TaskManager.retry(cur.id)!!; assertEquals(i, cur.retries) }
        TaskManager.activate(cur); TaskManager.endManaged(false, false, "x"); assertNull(TaskManager.retry(cur.id))
    }
    @Test fun queueTaskIsNotEndedByRunnerButStopEndsIt() {
        TaskManager.activate(TaskManager.enqueue("t")!!)
        TaskManager.end("answered", true, "runner done")            // the device step finished: the queue task stays open
        assertEquals(TaskState.UNDERSTANDING, TaskManager.active!!.state)
        TaskManager.closeIfOpen(); assertFalse(TaskManager.active!!.state.terminal)
        assertSame(TaskManager.active, TaskManager.begin("step text"))
        TaskManager.end("stopped", false, "user stop"); assertEquals(TaskState.CANCELLED, TaskManager.active!!.state)
    }
    @Test fun timeoutDetection() {
        val r = TaskManager.enqueue("t", now = 1000L)!!; r.timeoutMs = 5000L; TaskManager.activate(r, 1000L)
        assertFalse(TaskManager.overdue(5000L)); assertTrue(TaskManager.overdue(6500L))
    }
    @Test fun checkpointsSurviveRestartAndAreRecovered() {
        val f = File.createTempFile("zyn", ".json")
        TaskManager.init(f)
        val a = TaskManager.enqueue("do two things", 7)!!; TaskManager.activate(a)
        TaskManager.checkpoint("act:one", true, "verified"); TaskManager.checkpoint("act:two", false, "started")
        // app dies here: file holds the active task and its checkpoints; a second task still waits
        TaskManager.enqueue("waiting task", 3)
        val saved = f.readText()
        TaskManager.resetForTest(); f.writeText(saved); TaskManager.init(f)
        assertEquals(1, TaskManager.pendingList().size); assertEquals("waiting task", TaskManager.pendingList()[0].text)
        val old = TaskManager.failed().single(); assertEquals("Interrupted (app closed)", old.result); assertEquals(2, old.checkpoints.size)
        val r = TaskManager.requeueInterrupted(old.id)!!
        assertEquals(setOf("act:one"), r.resumeDone); assertEquals(setOf("act:two"), r.resumeUnsure); assertEquals(1, r.retries)
        f.delete()
    }
    @Test fun persistenceRedactsSecretsAndRespectsKeepHistoryOff() {
        val f = File.createTempFile("zyn", ".json"); f.delete()
        TaskManager.init(f); TaskManager.persist = false; TaskManager.enqueue("type password hunter2 now")
        assertFalse(f.exists())
        TaskManager.persist = true; TaskManager.enqueue("another task"); assertFalse(f.readText().contains("hunter2")); f.delete()
        TaskManager.persist = true
    }
    @Test fun jsonShowsQueueAndAgent() {
        TaskManager.enqueue("later", 3); TaskManager.activate(TaskManager.enqueue("now", 9)!!); TaskManager.setAgent("RESEARCH")
        val j = TaskManager.toJson()
        assertEquals("RESEARCH", j.getString("agent")); assertEquals(1, j.optJSONArray("pending")!!.length()); assertEquals("now", j.getString("task"))
    }
}
