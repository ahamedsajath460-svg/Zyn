package com.a2z.ai

import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

/** Pure JVM tests for the Zyn AI 5.0 layer. NOT RUN in the authoring environment (no Kotlin compiler / Android SDK). Run: ./gradlew testDebugUnitTest */
class ProviderRouterTest {
    private val gem = FProvider("g", "Gemini", "gemini", "https://x", "gemini-2.0-flash", "k")
    private val txt = FProvider("d", "DeepSeek", "openai", "https://x", "deepseek-chat", "k")
    private val llama = FProvider("l", "Groq", "openai", "https://x", "llama-3.3-70b-versatile", "k")
    @Before fun clean() { ProviderRouter.reset() }

    @Test fun chatKeepsUserOrder() {
        assertEquals(listOf("d", "g"), ProviderRouter.candidates(ProviderRouter.Kind.CHAT, listOf(txt, gem), 0L).map { it.id })
    }
    @Test fun visionNeverUsesTextOnlyProviders() {
        assertEquals(listOf("g"), ProviderRouter.candidates(ProviderRouter.Kind.VISION, listOf(txt, llama, gem), 0L).map { it.id })
        assertTrue(ProviderRouter.candidates(ProviderRouter.Kind.VISION, listOf(txt, llama), 0L).isEmpty())
    }
    @Test fun failedProviderGoesLastThenRecovers() {
        ProviderRouter.noteFailure("d", "HTTP 429 rate limit", 1000L)
        assertEquals(listOf("g", "d"), ProviderRouter.candidates(ProviderRouter.Kind.CHAT, listOf(txt, gem), 2000L).map { it.id })
        assertEquals(listOf("d", "g"), ProviderRouter.candidates(ProviderRouter.Kind.CHAT, listOf(txt, gem), 1000L + 61_000L).map { it.id })
    }
    @Test fun successClearsCooldown() {
        ProviderRouter.noteFailure("d", "timeout", 0L); ProviderRouter.noteSuccess("d", 120L)
        assertEquals("d", ProviderRouter.candidates(ProviderRouter.Kind.CHAT, listOf(txt, gem), 1L).first().id)
    }
    @Test fun errorKinds() {
        assertEquals(ProviderRouter.Err.RATE_LIMIT, ProviderRouter.classify("Rate or quota limit reached for this key/model."))
        assertEquals(ProviderRouter.Err.AUTH, ProviderRouter.classify("HTTP 401 unauthorized"))
        assertEquals(ProviderRouter.Err.TRANSIENT, ProviderRouter.classify("The AI request timed out"))
        assertEquals(ProviderRouter.Err.OTHER, ProviderRouter.classify("Model or endpoint not found."))
    }
}

class TaskManagerTest {
    @Before fun clean() { TaskManager.resetForTest() }

    @Test fun lifecycleCompleted() {
        TaskManager.begin("open settings", 1L)
        assertEquals(TaskState.UNDERSTANDING, TaskManager.active!!.state)
        TaskManager.to(TaskState.EXECUTING); TaskManager.to(TaskState.VERIFYING)
        TaskManager.end("answered", true, "done", 5L)
        assertEquals(TaskState.COMPLETED, TaskManager.active!!.state)
        assertEquals(1, TaskManager.completed().size); assertTrue(TaskManager.failed().isEmpty())
    }
    @Test fun finishedTaskCannotChangeState() {
        TaskManager.begin("a", 1L); TaskManager.end("failed", false, "x", 2L)
        assertFalse(TaskManager.to(TaskState.EXECUTING)); assertEquals(TaskState.FAILED, TaskManager.active!!.state)
    }
    @Test fun cancelAndRetry() {
        TaskManager.begin("scroll down", 1L); TaskManager.end("stopped", false, "Voice stop", 2L)
        assertEquals(TaskState.CANCELLED, TaskManager.active!!.state)
        assertEquals("scroll down", TaskManager.retryText())
    }
    @Test fun duplicateDetectionOnlyWhileRunning() {
        TaskManager.begin("Open  Settings", 1L)
        assertTrue(TaskManager.isDuplicate("open settings"))
        TaskManager.end("answered", true, "ok", 2L)
        assertFalse(TaskManager.isDuplicate("open settings"))
    }
    @Test fun staleActiveIsClosedAsInterrupted() {
        TaskManager.begin("first", 1L); TaskManager.begin("second", 2L)
        assertEquals(1, TaskManager.failed().size); assertEquals("Interrupted", TaskManager.failed()[0].result)
    }
    @Test fun agentStatesMapToTaskStates() {
        TaskManager.begin("x", 1L)
        TaskManager.onAgentState("waiting"); assertEquals(TaskState.WAITING_FOR_APPROVAL, TaskManager.active!!.state)
        TaskManager.onAgentState("paused"); assertEquals(TaskState.PAUSED, TaskManager.active!!.state)
        TaskManager.onAgentState("running"); assertEquals(TaskState.EXECUTING, TaskManager.active!!.state)
    }
    @Test fun historyIsBounded() {
        for (i in 1..60) { TaskManager.begin("t$i", i.toLong()); TaskManager.end("failed", false, "x", i.toLong()) }
        assertEquals(50, TaskManager.failed().size)
    }
    @Test fun jsonHasStateAndRedactsSecrets() {
        TaskManager.begin("type password hunter2 into the box", 1L)
        val j = TaskManager.toJson()
        assertEquals("UNDERSTANDING", j.getString("state")); assertFalse(j.getString("task").contains("hunter2"))
    }
}

class OrchestratorTest {
    @Test fun intents() {
        assertEquals(Orchestrator.Intent.DEVICE_ACTION, Orchestrator.intentOf("open settings"))
        assertEquals(Orchestrator.Intent.DEVICE_ACTION, Orchestrator.intentOf("Settings open pannu"))
        assertEquals(Orchestrator.Intent.SCREEN_QUESTION, Orchestrator.intentOf("what is on this screen"))
        assertEquals(Orchestrator.Intent.CODE, Orchestrator.intentOf("fix this kotlin bug"))
        assertEquals(Orchestrator.Intent.CHAT, Orchestrator.intentOf("hello"))
    }
    @Test fun complexity() {
        assertEquals(Orchestrator.Complexity.SIMPLE, Orchestrator.complexityOf("open settings"))
        assertEquals(Orchestrator.Complexity.COMPLEX, Orchestrator.complexityOf("open chrome then search news and then open the first link"))
    }
    @Test fun selectionAddsVisionOnlyWhenScreenIsShared() {
        assertFalse(Orchestrator.select("open settings", false).roles.contains(Role.VISION))
        assertTrue(Orchestrator.select("open settings", true).roles.contains(Role.VISION))
    }
    @Test fun onlyDeviceRolesCanOwnThePhone() {
        Orchestrator.releaseDevice()
        assertFalse(Orchestrator.claimDevice(Role.VISION))
        assertTrue(Orchestrator.claimDevice(Role.TASK_EXECUTION))
        assertFalse(Orchestrator.claimDevice(Role.SCREEN_INTERACTION))
        Orchestrator.releaseDevice(); assertNull(Orchestrator.deviceOwner)
    }
}
