package com.a2z.ai

import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicInteger

/** Zen AI 6.0 brain: pure-Kotlin tests with scripted agents (no Android). Integration with the real agents is in tools/jvm-harness/it/BrainIntegrationTest.kt. */
class Zyn6BrainTest {
    class Scripted(override val role: Role, val log: CopyOnWriteArrayList<String>, val fn: (String) -> AgentResult) : Agent {
        override fun run(call: AgentCall, input: String): AgentResult { log.add(role.name + ":" + input.take(60).replace("\n", " ")); return fn(input) }
    }
    private val log = CopyOnWriteArrayList<String>()
    private lateinit var rt: AgentRuntime
    private lateinit var brain: MasterOrchestrator
    private var ctxSeq = 100L
    private fun ctx() = AgentCtx(ctxSeq++, System.currentTimeMillis() + 60_000L)
    private fun reg(role: Role, fn: (String) -> AgentResult) = rt.register(Scripted(role, log, fn))
    private fun ok(t: String, s: List<Pair<String, String>> = emptyList()) = AgentResult(true, t, s)

    @Before fun setup() {
        TaskManager.resetForTest(); SharedContextManager.dropAll(); log.clear()
        rt = AgentRuntime(3, 3)
        brain = MasterOrchestrator(rt, Coordinator(rt), ToolRegistry(), PermissionManager(deviceAllowed = { null }, screenShared = { true }))
        reg(Role.CONVERSATION) { ok("chat:" + it.takeLast(20)) }
        reg(Role.RESEARCH) { ok("researched [1]. It was released in 2026 [1].", listOf("Doc" to "https://d/$it".take(30))) }
        reg(Role.ANALYSIS) { ok("analysis of: " + it.take(40)) }
        reg(Role.VERIFICATION, { VerificationAgent().run(AgentCall(rt, ctx(), listOf(Role.VERIFICATION)), it) })
        reg(Role.CODING) { ok("code") }
        reg(Role.VISION) { ok("screen text") }
    }

    // ---------------- A/B: conversation and tool selection
    @Test fun greetingsInEnglishTamilAndTanglishUseNoTool() {
        for (m in listOf("Hi, how are you?", "hello", "vanakkam", "epdi irukka", "நீங்கள் எப்படி இருக்கிறீர்கள்?", "nandri bro", "tell me a joke"))
            assertEquals(m, BrainIntent.CHAT, brain.classify(m, false).intent)
    }
    @Test fun selectionMatchesTheSpecExamples() {
        assertEquals(BrainIntent.RESEARCH, brain.classify("Find the latest information about Android 17.", false).intent)
        assertEquals("image words never start media creation", BrainIntent.CHAT, brain.classify("Generate an image of a futuristic city.", false).intent)
        assertEquals(BrainIntent.SCREEN_QUESTION, brain.classify("What is happening on my screen?", true).intent)
        assertEquals(BrainIntent.DEVICE_ACTION, brain.classify("Open Settings and find the Wi-Fi option.", true).intent)
        assertEquals(BrainIntent.RESEARCH_COMPARE, brain.classify("Research this topic, compare the results and prepare a summary.", false).intent)
        assertEquals(BrainIntent.CHAT, brain.classify("oru futuristic city padam generate pannu", false).intent)
        assertEquals(BrainIntent.DEVICE_ACTION, brain.classify("settings open pannu", true).intent)
        assertEquals(BrainIntent.CODE, brain.classify("fix this kotlin bug in my function", false).intent)
        assertEquals(BrainIntent.RESEARCH_COMPARE, brain.classify("iPhone 17 vs Pixel 10 comparison", false).intent)
    }
    @Test fun imageAndVideoWordsNeverStartMediaCreation() {
        for (m in listOf("describe this image for me", "make a short clip of a running horse", "draw a logo for my shop"))
            assertEquals(m, BrainIntent.CHAT, brain.classify(m, false).intent)
    }
    @Test fun normalChatCallsOnlyTheConversationAgent() {
        val o = brain.run(ctx(), "Hi, how are you?", false)
        assertTrue(o.ok); assertEquals(listOf("CONVERSATION"), log.map { it.substringBefore(":") })
    }

    // ---------------- C: collaboration
    @Test fun researchFlowsResearchThenVerificationAndReturnsSources() {
        val o = brain.run(ctx(), "Find the latest information about Android 17", false)
        assertTrue(o.ok); assertEquals(listOf("RESEARCH", "VERIFICATION"), log.map { it.substringBefore(":") })
        assertTrue(o.text.contains("researched")); assertEquals(1, o.sources.size)
    }
    @Test fun verificationResultIsPassedAndUnverifiedClaimsAreFlagged() {
        reg(Role.RESEARCH) { ok("It sold 5 million units in 2025.", listOf("Doc" to "https://d/1")) }       // no [n] citation
        val o = brain.run(ctx(), "Find the latest sales numbers", false)
        assertTrue(o.ok); assertTrue(o.text.contains("Not fully verified"))
    }
    @Test fun compareFlowHandsResultsFromAgentToAgent() {
        val o = brain.run(ctx(), "Research this topic, compare the results and prepare a summary.", false)
        assertEquals(listOf("RESEARCH", "ANALYSIS", "VERIFICATION", "CONVERSATION"), log.map { it.substringBefore(":") })
        assertTrue("analysis got the research text", log[1].contains("TASK"))
        assertTrue(o.ok && o.text.startsWith("chat:"))
    }
    @Test fun twoSubjectsAreResearchedAtTheSameTime() {
        val running = AtomicInteger(0); val peak = AtomicInteger(0)
        reg(Role.RESEARCH) { running.incrementAndGet().also { n -> peak.updateAndGet { maxOf(it, n) } }; Thread.sleep(300); running.decrementAndGet(); ok("r [1]", listOf("S" to "https://s/$it".take(30))) }
        val o = brain.run(ctx(), "iPhone 17 vs Pixel 10 comparison", false)
        assertTrue(o.ok); assertEquals("both researches overlapped", 2, peak.get())
        assertEquals(listOf("RESEARCH", "RESEARCH", "ANALYSIS"), log.map { it.substringBefore(":") }.let { l -> listOf(l[0], l[1], l[2]) })
    }
    @Test fun dependentStepIsSkippedWhenItsInputFailed() {
        reg(Role.RESEARCH) { AgentResult.fail("search down") }
        reg(Role.CONVERSATION) { AgentResult.fail("also down") }       // no degraded fallback either
        val o = brain.run(ctx(), "Research this topic, compare the results and prepare a summary.", false)
        assertFalse(o.ok); assertTrue(o.steps.any { it.role == "ANALYSIS" && it.status == "skipped" })
        assertFalse("never claims success", o.text.isBlank())
    }
    @Test fun failedSearchFallsBackToMarkedGeneralKnowledge() {
        reg(Role.RESEARCH) { AgentResult.fail("No web results", true) }
        val o = brain.run(ctx(), "Find the latest information about Android 17", false)
        assertTrue(o.ok); assertTrue(o.text.contains("general knowledge")); assertTrue(o.steps.any { it.status == "degraded" })
    }
    @Test fun partialSuccessKeepsGoodResultsAndReportsTheFailure() {
        reg(Role.CONVERSATION) { AgentResult.fail("chat model down") }
        val o = brain.run(ctx(), "Research this topic, compare the results and prepare a summary.", false)
        assertTrue("analysis is kept", o.text.contains("analysis of")); assertFalse(o.ok); assertTrue(o.partial); assertTrue(o.text.contains("Not completed"))
    }

    // ---------------- shared context / follow-ups / isolation
    @Test fun followUpResolvesTheFirstTwoResults() {
        reg(Role.RESEARCH) { ok("Top resources [1][2][3]", listOf("Android Docs" to "https://developer.android.com", "Codelabs" to "https://codelabs", "Kotlin Docs" to "https://kotlinlang.org")) }
        brain.run(ctx(), "Search for the best Android development resources", false, "u1")
        log.clear()
        val o = brain.run(ctx(), "Compare the first two", false, "u1")
        assertEquals(listOf("ANALYSIS"), log.map { it.substringBefore(":") })
        val s = SharedContextManager.forSession("u1")
        assertEquals(listOf("Android Docs", "Codelabs"), SharedContextManager.resolve("Compare the first two", s).map { it.title })
        assertTrue(o.ok)
    }
    @Test fun sessionsAreIsolated() {
        reg(Role.RESEARCH) { ok("x [1]", listOf("Only A" to "https://a")) }
        brain.run(ctx(), "Search for something latest", false, "accountA")
        assertEquals(1, SharedContextManager.forSession("accountA").items.size)
        assertTrue(SharedContextManager.forSession("accountB").items.isEmpty())
        assertTrue(SharedContextManager.forSession("accountB").turns().isEmpty())
        assertEquals(BrainIntent.CHAT, brain.classify("Compare the first two", false, "accountB").intent)
    }
    @Test fun chatPageHistoryIsMirroredForContext() {
        brain.run(ctx(), "and what about the second one?", false, "u9", listOf("user" to "tell me about kotlin", "assistant" to "Kotlin is a language"))
        assertTrue(log.single().contains("CONVERSATION")); assertTrue(SharedContextManager.forSession("u9").turns().size >= 3)
    }

    // ---------------- permissions
    @Test fun screenQuestionWithoutShareOrAccessibilityIsDeniedBeforeAnythingRuns() {
        reg(Role.SCREEN_INTERACTION) { ok("explained") }
        val b = MasterOrchestrator(rt, Coordinator(rt), ToolRegistry(), PermissionManager(deviceAllowed = { "Accessibility access is not enabled." }, screenShared = { false }))
        val o = b.run(ctx(), "What is happening on my screen?", false)
        assertFalse(o.ok); assertTrue(o.text.contains("Accessibility")); assertTrue(log.isEmpty())
    }
    @Test fun visionStepNeedsScreenShare() {
        val b = MasterOrchestrator(rt, Coordinator(rt), ToolRegistry(), PermissionManager(screenShared = { false }))
        val o = b.run(ctx(), "What is happening on my screen?", true)     // the caller thinks the screen is shared, the permission check knows better
        assertFalse(o.ok); assertTrue(o.text.contains("Screen sharing is off")); assertTrue(log.isEmpty())
    }
    @Test fun phoneActionIsDeniedWhenAgentIsOff() {
        val b = MasterOrchestrator(rt, Coordinator(rt), ToolRegistry(), PermissionManager(deviceAllowed = { "The AI Agent switch is off." }))
        reg(Role.TASK_EXECUTION) { ok("done") }
        val o = b.run(ctx(), "Open Settings and find the Wi-Fi option.", true)
        assertFalse(o.ok); assertTrue(o.text.contains("switch is off")); assertTrue(log.none { it.startsWith("TASK_EXECUTION") })
    }
    @Test fun duplicateRunningRequestIsRefused() {
        reg(Role.CONVERSATION) { Thread.sleep(400); ok("slow") }
        val t = Thread { brain.run(ctx(), "hello there friend", false, "d") }; t.start(); Thread.sleep(100)
        val o = brain.run(ctx(), "hello there friend", false, "d")
        assertFalse(o.ok); assertTrue(o.text.contains("already running")); t.join()
    }
    @Test fun cancellationStopsTheRun() {
        reg(Role.RESEARCH) { Thread.sleep(300); ok("late [1]", listOf("S" to "https://s")) }
        val c = ctx(); val t = Thread { Thread.sleep(80); rt.cancel(c) }; t.start()
        val o = brain.run(c, "Find the latest information about Android 17", false)
        assertFalse(o.ok); t.join()
    }


    @Test fun everyToolCategoryHasAnIntent() {
        fun i(m: String) = brain.classify(m, false).intent
        assertEquals(BrainIntent.SCREEN_TEXT, i("read the text on my screen"))
        assertEquals(BrainIntent.SHARE_STATUS, i("is my screen sharing on?"))
        assertEquals(BrainIntent.SHARE_CONTROL, i("start screen share")); assertEquals(BrainIntent.SHARE_CONTROL, i("turn off screen sharing"))
        assertEquals(BrainIntent.FLOATING, i("open the floating assistant"))
        assertEquals(BrainIntent.WEB_LINKS, i("give me links for kotlin coroutines"))
        assertEquals(BrainIntent.TRANSFORM, i("translate this to Tamil: the meeting is moved to Friday afternoon because of the holiday"))
        assertEquals("a research summary request is research, not a transform", BrainIntent.RESEARCH_COMPARE, i("summarize the latest news about Android 17 and compare sources"))
        assertEquals(BrainIntent.SCREEN_QUESTION, i("what is happening on my screen?")); assertEquals(BrainIntent.DEVICE_ACTION, i("open Settings"))
    }
    @Test fun toolStepsRunTheRegisteredToolAndKeepItsSources() {
        val reg = ToolRegistry(); val seen = CopyOnWriteArrayList<String>()
        reg.register(object : Tool {
            override val spec = ToolSpec("web.search", "search", setOf("search"), mapOf("query" to Field("string", true)), mapOf("hits" to "array"))
            override fun execute(args: JSONObject, ctx: AgentCtx): ToolResult { seen.add(args.getString("query")); return ToolResult.ok("[1] A (https://a)", JSONObject().put("hits", org.json.JSONArray().put(JSONObject().put("title", "A").put("url", "https://a")))) }
        })
        val b = MasterOrchestrator(rt, Coordinator(rt), reg, PermissionManager())
        val o = b.run(ctx(), "give me links for kotlin coroutines", false)
        assertTrue(o.ok); assertEquals(listOf("kotlin coroutines"), seen); assertEquals(listOf("A" to "https://a"), o.sources); assertTrue("no agent ran", log.isEmpty())
        val none = MasterOrchestrator(rt, Coordinator(rt), ToolRegistry(), PermissionManager()).run(ctx(), "give me links for x y", false)
        assertFalse(none.ok); assertTrue(none.text.contains("not available"))
    }

    // ---------------- tools
    private class T(id: String, val avail: String? = null, val body: (JSONObject) -> ToolResult = { ToolResult.ok("ran") }, dev: Boolean = false) : Tool {
        override val spec = ToolSpec(id, id, setOf("cap.$id"), mapOf("q" to Field("string", true)), mapOf("text" to "string"), dev)
        override fun unavailableReason() = avail
        override fun execute(args: JSONObject, ctx: AgentCtx) = body(args)
    }
    @Test fun registryRejectsDuplicatesAndBadIds() {
        val r = ToolRegistry(); r.register(T("web.search"))
        try { r.register(T("web.search")); fail() } catch (_: IllegalArgumentException) { }
        try { r.register(T("Bad Id")); fail() } catch (_: IllegalArgumentException) { }
        assertEquals(listOf("web.search"), r.ids()); assertEquals(1, r.withCapability("cap.web.search").size)
        val d = r.describe().getJSONObject(0); assertTrue(d.has("input") && d.has("output") && d.has("capabilities") && d.getBoolean("available"))
    }
    @Test fun executorReturnsStructuredResultsForEveryFailure() {
        val r = ToolRegistry(); r.register(T("a.ok")); r.register(T("a.off", avail = "no key")); r.register(T("a.boom", body = { throw RuntimeException("x") }))
        r.register(T("a.slow", body = { Thread.sleep(2000); ToolResult.ok("late") })); r.register(T("a.dev", dev = true))
        val ex = ToolExecutor(r, PermissionManager(deviceAllowed = { "agent off" }), ExecutionMonitor()); val c = ctx(); val q = JSONObject().put("q", "x")
        assertEquals(ToolStatus.OK, ex.call("a.ok", q, c).status); assertTrue(c.blackboard.containsKey("tool:a.ok"))
        assertEquals(ToolStatus.FAILED, ex.call("a.ok", JSONObject(), c).status)
        assertEquals(ToolStatus.UNAVAILABLE, ex.call("a.off", q, c).status)
        assertEquals(ToolStatus.UNAVAILABLE, ex.call("nope", q, c).status)
        assertEquals(ToolStatus.FAILED, ex.call("a.boom", q, c).status)
        assertEquals(ToolStatus.TIMEOUT, ex.call("a.slow", q, c, 200).status)
        assertEquals(ToolStatus.DENIED, ex.call("a.dev", q, c).status)
    }
    @Test fun planDetectsCyclesAndUnknownDependencies() {
        val p = Plan(BrainIntent.CHAT, listOf(PlanNode("a", Role.CONVERSATION, "x", listOf("b")), PlanNode("b", Role.CODING, "x", listOf("a"))), listOf("a"))
        try { p.waves(); fail() } catch (_: IllegalArgumentException) { }
        try { Plan(BrainIntent.CHAT, listOf(PlanNode("a", Role.CODING, "x", listOf("zz"))), listOf("a")).waves(); fail() } catch (_: IllegalArgumentException) { }
    }
    @Test fun monitorReportsReadableStages() {
        val m = ExecutionMonitor(); val seen = CopyOnWriteArrayList<String>(); m.listeners.add { seen.add(ExecutionMonitor.line(it.stage)) }
        val b = MasterOrchestrator(rt, Coordinator(rt), ToolRegistry(), PermissionManager(screenShared = { true }), m)
        b.run(ctx(), "Find the latest information about Android 17", false)
        assertTrue(seen.contains("Understanding request")); assertTrue(seen.contains("Searching information")); assertTrue(seen.contains("Verifying information")); assertTrue(seen.contains("Preparing response"))
    }
    @Test fun verificationAgentChecksCitationsAgainstSources() {
        val v = VerificationAgent(); val c = AgentCall(rt, ctx(), listOf(Role.VERIFICATION))
        assertTrue(v.run(c, "ANSWER:\nIt is fast [1].\n\nSOURCES:\n[1] A (https://a)").text.startsWith("VERIFIED"))
        assertTrue(v.run(c, "ANSWER:\nIt is fast [3].\n\nSOURCES:\n[1] A (https://a)").text.contains("do not exist"))
        assertTrue(v.run(c, "ANSWER:\nIt is fast.\n\nSOURCES:\n(none)").text.startsWith("UNVERIFIED"))
    }

    @Test fun creativeToolsAreRoutedToThePage() {
        fun i(t: String) = IntentClassifier.classify(t, SharedSession("t"), false).intent
        assertEquals(BrainIntent.LINK_UPLOAD, i("make a link for this photo"))
        assertEquals(BrainIntent.LINK_UPLOAD, i("upload this video to a link"))
        assertEquals(BrainIntent.CHAT, i("generate an image of a red car"))
        assertEquals(BrainIntent.CHAT, i("generate a video of a sunset over the sea"))
        assertTrue(BrainIntent.LINK_UPLOAD in BrainBridge.PAGE && BrainIntent.LINK_UPLOAD !in BrainBridge.NATIVE)
        assertNotNull(MasterOrchestrator.PAGE_ONLY[BrainIntent.LINK_UPLOAD])
    }
}
