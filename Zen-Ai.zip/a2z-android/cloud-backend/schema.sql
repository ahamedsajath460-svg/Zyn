-- Zen AI Cloud Studio data model. Used TODAY on the phone (cloudstudio-core.js, IndexedDB/localStorage, one namespace per signed-in account,
-- every query filtered by user_id). This SQL is the same model for an OPTIONAL external backend; no such backend is deployed or required.
-- Source of truth for files is GitHub (branch cloud/<slug>, folder cloud-projects/<slug>/); builds and artifacts live in GitHub Actions.
CREATE TABLE users     (user_id TEXT PRIMARY KEY, account_status TEXT NOT NULL DEFAULT 'active', created_at BIGINT NOT NULL);
CREATE TABLE projects  (project_id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(user_id), project_name TEXT NOT NULL, package_name TEXT NOT NULL,
                        project_type TEXT NOT NULL DEFAULT 'android-kotlin', slug TEXT NOT NULL, branch TEXT NOT NULL, created_at BIGINT NOT NULL, updated_at BIGINT NOT NULL,
                        UNIQUE (user_id, slug));
CREATE TABLE builds    (build_id TEXT PRIMARY KEY, project_id TEXT NOT NULL REFERENCES projects(project_id) ON DELETE CASCADE, user_id TEXT NOT NULL REFERENCES users(user_id),
                        build_type TEXT NOT NULL CHECK (build_type IN ('debug','release','test')), build_status TEXT NOT NULL, build_logs TEXT, run_id BIGINT, started_at BIGINT NOT NULL, completed_at BIGINT);
CREATE TABLE artifacts (artifact_id TEXT PRIMARY KEY, build_id TEXT NOT NULL REFERENCES builds(build_id) ON DELETE CASCADE, user_id TEXT NOT NULL REFERENCES users(user_id),
                        file_name TEXT NOT NULL, file_size BIGINT, checksum TEXT, storage_location TEXT, expiration_time BIGINT, github_artifact_id BIGINT);
-- user-level access restriction: every read/write must include "WHERE user_id = :current_user"
CREATE INDEX idx_projects_user ON projects(user_id); CREATE INDEX idx_builds_user ON builds(user_id, started_at DESC); CREATE INDEX idx_artifacts_build ON artifacts(build_id);
