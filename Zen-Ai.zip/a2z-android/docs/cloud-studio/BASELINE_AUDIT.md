# Baseline audit of the supplied Zen AI ZIP (before changes)
- Project: `a2z-android`, namespace and applicationId `com.a2z.ai`, minSdk 26, compile/target 34, AGP 8.5.2, Kotlin 1.9.24, Gradle 8.7, JDK 17, versionCode from GITHUB_RUN_NUMBER.
- Architecture: single `MainActivity` hosting a WebView (`assets/a2z.html`, 1.5 MB) with the JS bridge `A2ZNative`; ~70 Kotlin files (brain, agents, floating assistant, screen capture, accessibility, TTS/STT, OCR, key pool, provider router), Sky Translate activity, widget, tile.
- Auth: Firebase (JS) + native Google Sign-In; per-account data separation (`a2z.*` keys + IndexedDB `a2z`).
- AI: provider router with keys from user settings and `default-keys.json` from the `AI_API` secret. Existing Creative Design Studio = JS modules registered into the page's tool list (`ALL`).
- CI: `.github/workflows/release-apk.yml` builds a signed release on push to main/master or dispatch; signing from secrets; keeps certificate stable.
- Tests present: JUnit (`app/src/test`), JVM harness, Chromium studio tests. Not re-run in this task except as noted in TESTING_REPORT.
- Integration point chosen: same pattern as Creative Design Studio (new JS modules + tool registration), plus one new bridge object.
