# Status and known limitations

## Fully implemented and tested (against local fakes / Chromium / JVM, see TESTING_REPORT)
Secure GitHub bridge, path and host allowlists, redaction, atomic commits and branches, dispatch and run following, progress, cancel, retry, log and annotation capture, artifact list, APK extraction + SHA-256, usage and concurrency guards, project store with per-user scoping and snapshots, scaffold, lint, error classifier, fix engine with approval and rollback, AI App Creator flow (stub AI), code workspace, XML preview, validator, UI.

## Implemented but NOT executed in the real world (needs your GitHub / phone)
- The 5 workflows (YAML parses; never run on GitHub). Expect to fix small things on first run: action versions, runner paths. Build failures will show up in Build History with the log.
- Gradle APK builds of the sample and of AI projects (sample not compiled here).
- `CloudBridge.kt`, `CloudPreviewActivity.kt`, Keystore storage, MediaStore save, share sheet, APK signature info: written against the Android API but never compiled or run.
- Real AI output quality (only stub AI tested). Generated apps may fail to build; the fix loop helps but is not magic.

## Awaiting credentials
GitHub token and repository (Cloud Settings); release signing secrets `CLOUD_*`; optional `CLOUD_EXPECTED_CERT_SHA256`.

## Requires external infrastructure
- **Live, touchable, streamed virtual device**: not possible on GitHub Actions. The emulator test is a batch run (install, launch, random UI test, restart, screenshots, logcat, crash report) and needs KVM. A streaming service can be entered in Cloud Settings and is opened in the browser only.
- **Expiring private download links**: need a small server (for example a Worker) holding a GitHub token. Not built. Today: authenticated download in the app, approved share sheet, GitHub artifact expiry (1-30 days).
- **Per-domain network egress blocking on the runner**: needs a third-party action or self-hosted runner; not enabled.

## Not implemented
- Java source generation is not special-cased (the AI is told to use Kotlin; Java files are edited and highlighted but the scaffold is Kotlin).
- Compose projects, binary assets (PNG icons) in the editor, multi-module projects beyond the template.
- Gradle dependency verification metadata generation (a project's own `verification-metadata.xml` is honoured by Gradle).
- Billing-exact Actions usage (GitHub has no simple per-repo API): the app shows an estimate from run durations.
- Auto-install of APKs (no install permission requested on purpose).
- Account data separation covers settings, projects and builds; the GitHub token slot is per account but device-level secure storage is not wiped on logout.

## Costs
Free first. Public repos: free runners. Private: ~2000 min and 500 MB per month on Free; emulator tests are expensive in minutes. The app blocks builds above your configured limits; it never enables paid services.
