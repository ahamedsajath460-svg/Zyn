# Cloud Studio security model

| Threat | Control (where) | Verified how |
|---|---|---|
| Token theft by page JS / generated code | Token only in Android Keystore (AES-256-GCM); JS never receives it; calls go through `A2ZCloud.gh` (CloudBridge.kt / CloudCore.kt) | JVM test: seal/open, tamper, wrong key |
| Bridge abused to reach other GitHub areas | Host allowlist (api.github.com, github.com, *.githubusercontent.com, *.blob.core.windows.net), https only; path allowlist (repos only; no secrets, variables, keys, hooks, collaborators, repo deletion, workflow edits; only `.../workflows/<f>/dispatches` may be written) | 12 JVM tests; JS client cross-checked against the same rules |
| Token leaks via redirect | Redirects followed by hand; Authorization dropped on the pre-signed hop; unlisted hosts refused | JVM test (fake server records headers) |
| Secrets in logs | Redaction in the phone (CloudCore.redact), in the runner (`cloud_tools.py redact`, streamed), and in annotations | JVM + Python runs |
| Generated code stealing secrets in CI | Build job has NO secrets, read-only token, `persist-credentials: false`; signing is a separate job; Gradle never sees the keystore; separate CLOUD_* key | Workflow design (not run on GitHub here) |
| Malicious Gradle script | Static guard `validate_project.py` (env, processes, network, home dir, non-allowlisted or http repositories, symlinks, `.github`, size limits); project's own gradle-wrapper.jar is ignored (pinned Gradle used) | 12 Python tests. A text scan cannot prove safety: real isolation = ephemeral runner + no secrets |
| App writes workflows / escapes project folder | App commits only under `cloud-projects/<slug>/`; `.github`, `..`, absolute paths, wrapper jar, `.yml` refused | Node tests |
| Generated HTML/JS runs inside Zen AI | Never. Preview runs in `CloudPreviewActivity`: no JS interfaces, network blocked (3 layers), no file access, navigation blocked. XML preview = script-free HTML in an iframe with `sandbox=""` | Browser test for XML; Activity not run on a device |
| Public distribution | APKs are never published. Download needs the token; Share asks for confirmation, then Android's share sheet | UI test of dialogs (mocked native) |
| Cross-account data | All records scoped by user_id and stored under `a2z.*` keys covered by the app's per-account separation; token slot per account | Node test |
| Runaway cost | Concurrency group (1 build), limits checked before each dispatch, job timeouts (45 min), artifact retention 1-30 days, cleanup workflow | Node tests (limits); workflows not run |

Network egress: the build runner has full internet (needed for SDK, Gradle, Maven). Limiting egress per domain on a GitHub-hosted runner needs a third-party action (for example step-security/harden-runner in block mode) and an allowlist tuned from its audit report. It is NOT enabled here because it could not be tested; the repository allowlist in `validate_project.py` limits where dependencies may come from.
