# Zen AI Cloud Studio: setup from an Android phone (no PC)

Everything below is done in the phone's browser (github.com) and inside Zen AI.

## A. Put the files in your repository (one time)
Your repository is the one that already builds Zen AI (it holds the project ZIP / source and `.github/workflows/release-apk.yml`).

1. Unzip nothing on the phone. Open `github.com/<you>/<repo>` in Chrome > menu > "Desktop site" (easier file upload).
2. **Workflow files** (must be uploaded by hand: GitHub does not let the existing workflow change workflow files). Go to `.github/workflows/` > Add file > Upload files, and add these 5 files from the ZIP's `.github/workflows/`:
   `cloud-android-build.yml`, `cloud-android-debug.yml`, `cloud-android-release.yml`, `cloud-android-test.yml`, `cloud-android-cleanup.yml`. Commit to your default branch.
3. **Repository-root files** the workflows need: folder `tools/cloud/` with `validate_project.py`, `cloud_tools.py`, `emulator-smoke.sh`. Upload them at `tools/cloud/` in the repo root (Add file > Upload files, type the folder name in the path box). The `repo-root-files.zip` mechanism of the existing workflow also unpacks them if you include the `tools/cloud` folder in that ZIP.
4. The new app version is built by your existing `release-apk.yml` as usual: upload the new project ZIP. Install the new APK over the old one (same signing key, same package `com.a2z.ai`).

## B. Create a GitHub token (one time)
GitHub > profile photo > Settings > Developer settings > Personal access tokens > **Fine-grained tokens** > Generate.
- Repository access: **Only select repositories** > your repo.
- Permissions: **Contents: Read and write**, **Actions: Read and write**, **Metadata: Read-only**. Nothing else.
- Expiration: 30-90 days. Copy the token (`github_pat_...`).

## C. Connect in Zen AI
Tools > Create > **Zen AI Cloud Studio** > Cloud Settings: paste the token > "Save and test token"; enter `owner/repo` > "Save and test repository". It must show all 5 workflow files with a tick.
The token is stored encrypted with an Android Keystore key and is never shown again or given to JavaScript.

## D. First build
AI App Creator > "Create sample project (no AI)" > Build Center > Build debug APK. Watch the progress; then APK Manager > Download. Open the file from your Files app (Downloads/Zen Ai/Cloud Studio) and allow installs from that app when Android asks.

## E. Release signing (optional)
Use a NEW key for generated apps (not the Zen AI key). GitHub > repo > Settings > Secrets and variables > Actions:
- Secrets: `CLOUD_KEYSTORE_BASE64` (the .jks file as base64), `CLOUD_KEYSTORE_PASSWORD`, `CLOUD_KEY_ALIAS`, `CLOUD_KEY_PASSWORD`.
- Variable (recommended): `CLOUD_EXPECTED_CERT_SHA256` = the certificate SHA-256 printed by the first signed build. Later builds fail if the signing identity changes.
Then Build Center > Build release APK. The build runs with no secrets; a separate job signs, aligns and verifies.

## F. Emulator test
Virtual Device > Run emulator test. Needs a runner with KVM (public repositories work; private 2-core runners may not). The workflow fails with a clear message if there is no `/dev/kvm`.

## Costs
Public repo: free standard runners. Private repo: Free plan about 2000 minutes and 500 MB artifact storage per month. Cloud Settings lets you set limits; the app refuses to start builds beyond them. Nothing paid is ever switched on by Zen AI.
