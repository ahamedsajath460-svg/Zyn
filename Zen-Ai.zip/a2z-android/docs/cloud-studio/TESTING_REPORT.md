# Testing report (what was actually executed)

Environment: Linux container, JDK 17, Kotlin 2.0.21 compiler, Node 22, Python 3, headless Chromium. **No Android SDK, no access to dl.google.com / maven.google.com, no GitHub account.** So nothing could be built into an APK here and nothing ran on GitHub or a phone.

| Suite | Command | Result |
|---|---|---|
| Kotlin CloudCore vs local fake GitHub (allowlists, redirect without token, redaction, zip-slip safe extraction, checksums, expired artifact, AES-GCM) | `tools/cloud/run-jvm-tests.sh` | 12/12 pass |
| JS core + generation vs local fake GitHub (commit, branch, dispatch, follow run, logs, artifacts, concurrency and minutes limits, missing workflow, cancel, cleanup, user scoping, classifier, AI creator with stub AI, auto-fix loop incl. approval, rollback, rejection cases; every call checked against the phone allowlist) | `node tools/cloud/tests/run-tests.js` | 22/22 pass |
| Project validator (accepts sample; rejects env, process, network, home dir, token names, bad/http repositories, `.github`, symlinks, missing settings, big files) | `python3 tools/cloud/tests/test_validate.py` | 12/12 pass |
| Real `a2z.html` in Chromium 412x860: tool registered, 11 sections, token and repo setup, sample project, editor + highlighting + error markers, debug build through UI, APK metadata, build log, sandboxed XML preview, emulator-test flow with screenshots, dark theme, no page errors | `tools/cloud/tests/ui-test.js` | 19/19 pass (proxy / `file://` console noise filtered, it comes from the container and the existing page) |
| YAML syntax of all 6 workflows | python yaml | parses |
| Sample project XML | python minidom | 8 files well-formed |

"Fake GitHub" = `tools/cloud/tests/fake-github.js`: it imitates the endpoints and "builds" by running the real validator and failing on a marker. It proves our client logic, not GitHub's behaviour.

## Your 20 checks
| # | Check | Status |
|---|---|---|
| 1 | Existing app builds | NOT RUN (no SDK here). Kotlin changes are 3 new files + 1 line; `CloudBridge.kt` and `CloudPreviewActivity.kt` were not compiled (no android.jar). Your next GitHub build is the test. |
| 2-9 | Login, chat, providers, settings, screen share, voice, history, backup | NOT RUN on a device. Their code was not modified (only `addJavascriptInterface` line added). Page loads in Chromium with no new errors. |
| 10 | Cloud Studio opens | Done in Chromium; not on Android |
| 11 | Workflow can be dispatched | Done against fake GitHub only |
| 12 | SDK installation succeeds | NOT RUN (happens on GitHub) |
| 13 | Sample project generated | Done; passes validator and lint; **not compiled** |
| 14 | Debug APK builds | NOT RUN |
| 15 | Build logs accessible | Done against fake GitHub |
| 16 | Preview works | XML + HTML combination in Chromium; isolated Activity not run |
| 17 | APK download | Zip-to-APK + SHA-256 JVM-tested; MediaStore save not run |
| 18 | Release signing | NOT RUN (workflow written; needs your secrets) |
| 19 | Private artifact access | Token required for every call (JVM test); not tested on GitHub |
| 20 | No regressions | Not proven on device |
