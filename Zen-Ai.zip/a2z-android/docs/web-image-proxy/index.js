// OPTIONAL, UNTESTED example: Firebase Cloud Function that keeps Pexels/Unsplash keys on the server.
// Deploy, set secrets PEXELS_KEY / UNSPLASH_KEY, then set cfg.proxy (localStorage key zen_wimg_cfg) to the function URL (HTTPS).
// The app calls GET <proxy>?provider=pexels|unsplash&q=...&n=... and expects {items:[{img,full,raw,page,title,site,creator,license,licUrl,w,h}]}.
const {onRequest}=require('firebase-functions/v2/https');
exports.webimages=onRequest({secrets:['PEXELS_KEY','UNSPLASH_KEY'],cors:true},async(req,res)=>{
  const q=String(req.query.q||'').slice(0,100),n=Math.min(+req.query.n||6,12),p=String(req.query.provider||'');
  try{
    if(p==='pexels'){const r=await fetch('https://api.pexels.com/v1/search?query='+encodeURIComponent(q)+'&per_page='+n,{headers:{Authorization:process.env.PEXELS_KEY}});
      if(!r.ok)return res.status(r.status).json({items:[]});const j=await r.json();
      return res.json({items:(j.photos||[]).map(x=>({img:x.src.large,full:x.src.large2x,raw:x.src.original,page:x.url,title:x.alt,site:'Pexels',creator:x.photographer,license:'Pexels License',licUrl:'https://www.pexels.com/license/',w:x.width,h:x.height}))})}
    if(p==='unsplash'){const r=await fetch('https://api.unsplash.com/search/photos?query='+encodeURIComponent(q)+'&per_page='+n+'&content_filter=high',{headers:{Authorization:'Client-ID '+process.env.UNSPLASH_KEY}});
      if(!r.ok)return res.status(r.status).json({items:[]});const j=await r.json();
      return res.json({items:(j.results||[]).map(x=>({img:x.urls.small,full:x.urls.regular,raw:x.urls.raw,page:x.links.html,title:x.alt_description,site:'Unsplash',creator:x.user&&x.user.name,license:'Unsplash License',licUrl:'https://unsplash.com/license',w:x.width,h:x.height}))})}
    res.json({items:[]});
  }catch(e){res.status(502).json({items:[]})}
});
