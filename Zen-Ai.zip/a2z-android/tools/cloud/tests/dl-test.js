/* Real a2z.html: any <a download> blob/data link, detached or clicked, must go to the native saveFile (Downloads/Zen Ai), never to the WebView. */
const { chromium } = require('playwright'); const path = require('path');
(async () => {
  const b = await chromium.launch(), pg = await b.newPage(); const saved = []; let bad = 0;
  await pg.exposeFunction('__saved', (n, m, t) => { saved.push({ n, m, t: Buffer.from(t, 'base64').toString() }); });
  await pg.addInitScript(() => { window.A2ZNative = { saveFile(n, m, b64) { window.__saved(n, m, b64); return 'ok'; } }; });
  await pg.goto('file://' + path.resolve(__dirname, '../../../app/src/main/assets/a2z.html')); await pg.waitForTimeout(2000);
  await pg.evaluate(() => { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob(['hello detached'], { type: 'text/plain' })); a.download = 'one.txt'; a.click(); }); await pg.waitForTimeout(500);
  await pg.evaluate(() => { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob(['hello attached'], { type: 'application/json' })); a.download = 'two.json'; document.body.appendChild(a); a.click(); a.remove(); }); await pg.waitForTimeout(500);
  await pg.evaluate(() => { const a = document.createElement('a'); a.href = 'data:text/plain;base64,aGk='; a.download = 'three.txt'; a.click(); }); await pg.waitForTimeout(500);
  const ok = (n, c) => { console.log((c ? 'ok   ' : 'FAIL ') + n); if (!c) process.exitCode = 1; };
  ok('detached blob link saved natively', saved.some(x => x.n === 'one.txt' && x.t === 'hello detached'));
  ok('attached blob link saved natively', saved.some(x => x.n === 'two.json' && x.t === 'hello attached'));
  ok('data: link saved natively', saved.some(x => x.n === 'three.txt' && x.t === 'hi'));
  await b.close();
})();
