/* Runs the Cloud Studio JS (core + gen) in Node against the local fake GitHub. node tools/cloud/tests/run-tests.js */
const fs = require('fs'), path = require('path'), assert = require('assert'), vm = require('vm');
const ASSETS = path.join(__dirname, '../../../app/src/main/assets');
const start = require('./fake-github');
const TOKEN = 'ghp_TESTTOKEN0123456789012345678901234';
let pass = 0, fail = 0; const T = async (n, f) => { try { await f(); pass++; console.log('  ok  ' + n); } catch (e) { fail++; console.log('FAIL  ' + n + '\n      ' + (e && e.stack || e).toString().split('\n').slice(0, 4).join('\n      ')); } };
// the same rules as CloudCore.pathAllowed in Kotlin (cross-check: JS must only issue calls the phone would allow)
function pathAllowed(m, p) {
  if (!['GET', 'POST', 'PUT', 'PATCH', 'DELETE'].includes(m) || !p.startsWith('/') || /\.\.|\/\/|[\r\n\\@]/.test(p)) return false; const q = p.split('?')[0];
  if (q === '/user' || q === '/rate_limit') return m === 'GET'; if (!/^\/repos\/[\w.-]+\/[\w.-]+(\/.*)?$/.test(q)) return false; if (m === 'DELETE' && /^\/repos\/[^/]+\/[^/]+\/?$/.test(q)) return false;
  const s = q.split('/'), s4 = s[4], s5 = s[5]; if (['keys', 'hooks', 'collaborators', 'invitations', 'transfer', 'rulesets', 'environments', 'forks', 'dispatches', 'pages', 'codespaces', 'autolinks'].includes(s4)) return false;
  if (s4 === 'actions' && ['secrets', 'variables', 'permissions', 'runners', 'oidc', 'cache'].includes(s5)) return false;
  if (s4 === 'actions' && s5 === 'workflows' && m !== 'GET') return m === 'POST' && s.length === 8 && s[7] === 'dispatches';
  if (s4 === 'actions' && m === 'DELETE') return s5 === 'runs' || s5 === 'artifacts'; return true;
}
(async () => {
  const fake = await start({ buildMs: 150 }); const { S } = fake; const sent = [];
  const mem = {}; const W = globalThis; W.window = W; W.localStorage = { getItem: k => mem[k] || null, setItem: (k, v) => { mem[k] = v; }, removeItem: k => { delete mem[k]; } };
  W.A2ZCloud = {
    hasToken: () => true, setToken: () => 'ok', clearToken() { },
    gh(id, ns, method, p, body) { sent.push(method + ' ' + p); if (!pathAllowed(method, p)) return W.__cloudCb(id, 400, '{"message":"Zen AI blocked this request"}');
      fetch('http://127.0.0.1:' + fake.port + p, { method, headers: { authorization: 'Bearer ' + TOKEN }, body: body || undefined }).then(async r => W.__cloudCb(id, r.status, await r.text())).catch(e => W.__cloudCb(id, 0, JSON.stringify({ message: String(e) }))); }
  };
  vm.runInThisContext(fs.readFileSync(path.join(ASSETS, 'cloudstudio-core.js'), 'utf8')); vm.runInThisContext(fs.readFileSync(path.join(ASSETS, 'cloudstudio-gen.js'), 'utf8'));  vm.runInThisContext(fs.readFileSync(path.join(ASSETS, 'cloudstudio-import.js'), 'utf8'));
  const CS = W.CloudStudio; CS.poll = { find: 40, start: 60, step: 0, max: 60 };
  await CS.init(); await CS.cfg.save({ repo: 'o/r', retryLimit: 3 });

  await T('scaffold is valid, lints clean, passes the project validator', async () => {
    const f = CS.scaffold({ name: 'Todo Room', libs: ['room', 'retrofit'] }); assert.deepStrictEqual(CS.lint(f), []);
    for (const k of Object.keys(f)) assert(CS.okRel(k), k);
  });
  await T('path rules reject workflows, traversal, wrapper jar', async () => { for (const b of ['.github/workflows/x.yml', '../x.kt', '/abs.kt', 'a//b.kt', 'gradle/wrapper/gradle-wrapper.jar', 'a b.kt', 'x.yml']) assert(!CS.okRel(b), b); assert(CS.okRel('app/src/main/java/a/B.kt')); });
  await T('lint finds missing layout, string, id and bad xml', async () => {
    const f = CS.scaffold({ name: 'Lint' }); f['app/src/main/java/com/zenai/lint/MainActivity.kt'] += '\nfun x() { R.layout.nope; R.string.nostr; R.id.noid }\n'; f['app/src/main/res/layout/bad.xml'] = '<a><b></a>';
    const m = CS.lint(f).map(x => x.message).join('|'); assert(/Layout "nope"/.test(m) && /String "nostr"/.test(m) && /View id "noid"/.test(m) );  // XML well-formedness needs DOMParser: checked in the browser test
  });
  const proj = await CS.newProject(Object.assign({}, { name: 'Sample Hello', pkg: 'com.zenai.samplehello', files: CS.scaffold({ name: 'Sample Hello', pkg: 'com.zenai.samplehello' }) }));
  await T('token check + repo info', async () => { const u = await CS.token.set(TOKEN); assert.strictEqual(u.login, 'tester'); assert.strictEqual((await CS.git.repo()).default_branch, 'main'); });
  await T('commit creates branch from main and writes all files atomically', async () => {
    const files = await CS.files.get(proj.project_id), r = await CS.git.push(proj, files, 'first'); assert(r.commit); assert.strictEqual(r.changed, Object.keys(files).length);
    assert.strictEqual(Object.keys(S.files(proj.branch)).length, Object.keys(files).length); assert(S.files(proj.branch)['cloud-projects/sample-hello/app/build.gradle.kts']);
    const r2 = await CS.git.push(proj, files, 'again'); assert.strictEqual(r2.changed, 0);
  });
  await T('commit refuses paths outside the project and workflow files', async () => { for (const k of ['.github/workflows/x.yml', '../evil.kt']) await assert.rejects(() => CS.git.commit(proj, 'x', { [k]: 'a' })); });
  await T('pull returns exactly what was pushed', async () => { const f = await CS.files.get(proj.project_id), g = await CS.git.pull(proj); assert.deepStrictEqual(g, f); });
  await T('debug build: dispatch, follow, APK artifact, log stored', async () => {
    const ups = []; const b = await CS.build.start(proj, { kind: 'debug', onUpdate: x => ups.push(x.build_status) });
    assert.strictEqual(b.build_status, 'success', b.summary); assert(b.run_id); assert(ups.includes('running') || ups.includes('queued'));
    const d = S.dispatches.pop(); assert.strictEqual(d.wf, 'cloud-android-debug.yml'); assert.strictEqual(d.b.ref, 'cloud/sample-hello'); assert.strictEqual(d.b.inputs.project_dir, 'cloud-projects/sample-hello');
    const arts = CS.db.artifacts.forBuild(b.build_id); assert(arts.some(a => a.kind === 'debug' && /^cloud-apk-/.test(a.file_name))); assert(/BUILD SUCCESSFUL/.test(await CS.logs.get(b.build_id)));
  });
  await T('every call the client sent is allowed by the phone allowlist', async () => { assert(sent.length > 10); for (const s of sent) { const [m, p] = s.split(' '); assert(pathAllowed(m, p), s); } });
  await T('concurrency limit gives a clear message', async () => {
    S.runs.unshift({ id: 999, name: 'Cloud Android Debug', status: 'in_progress', run_started_at: new Date().toISOString(), updated_at: new Date().toISOString() });
    await assert.rejects(() => CS.build.start(proj, { kind: 'debug' }), /Concurrency limit/); S.runs.shift();
  });
  await T('monthly minutes limit blocks on private repos only', async () => {
    S.private = true; await CS.cfg.save({ monthlyMinutes: 1 }); await assert.rejects(() => CS.build.start(proj, { kind: 'debug' }), /Monthly Actions limit/);
    S.private = false; const u = await CS.usage.get(); assert.strictEqual(u.minutes, 0); await CS.cfg.save({ monthlyMinutes: 2000 });
  });
  await T('missing workflow on the branch -> setup message', async () => { S.wf.delete('cloud-android-test.yml'); await assert.rejects(() => CS.build.start(proj, { kind: 'test' }), /Upload the files from \.github\/workflows/); S.wf.add('cloud-android-test.yml'); });
  await T('validator rejects a project that reads env vars; build fails with the reason', async () => {
    const f = await CS.files.get(proj.project_id); f['app/build.gradle.kts'] += '\nval t = System.getenv("GITHUB_TOKEN")\n'; await CS.files.set(proj.project_id, f);
    const b = await CS.build.start(proj, { kind: 'debug' }); assert.strictEqual(b.build_status, 'failed'); assert(/validator rejected|reads environment/.test(await CS.logs.get(b.build_id)));
    f['app/build.gradle.kts'] = f['app/build.gradle.kts'].replace('\nval t = System.getenv("GITHUB_TOKEN")\n', ''); await CS.files.set(proj.project_id, f);
  });
  await T('classifier reads a Kotlin error', async () => {
    const c = CS.classify('e: file:///home/runner/work/r/r/cloud-projects/x/app/src/main/java/a/Main.kt:7:9 Unresolved reference: FOO\nFAILURE: Build failed with an exception.\n* What went wrong:\nExecution failed for task \':app:compileDebugKotlin\'.');
    assert.strictEqual(c.category, 'kotlin'); assert.strictEqual(c.line, 7); assert(/Unresolved reference/.test(c.summary)); assert(c.file.endsWith('Main.kt') && !/cloud-projects/.test(c.file));
    assert.strictEqual(CS.classify('> Could not resolve com.x:y:1.0\n* What went wrong:\nCould not resolve all files').category, 'dependency');
    assert.strictEqual(CS.classify('java.lang.OutOfMemoryError: Java heap space').category, 'memory'); assert.strictEqual(CS.classify('SDK location not found').fixable, false === true ? 0 : CS.classify('SDK location not found').fixable);
  });
  await T('AUTO-FIX LOOP: broken build -> classify -> AI minimal fix -> review -> apply -> rebuild succeeds; rollback restores', async () => {
    const f0 = await CS.files.get(proj.project_id), mainP = 'app/src/main/java/com/zenai/samplehello/MainActivity.kt', f = Object.assign({}, f0); f[mainP] = f[mainP].replace('count++', 'count++\n        BROKEN_REF'); await CS.files.set(proj.project_id, f);
    let calls = 0; W.ask = async (sys, msg) => { calls++; assert(/Unresolved reference: BROKEN_REF/.test(msg)); return '```json\n' + JSON.stringify({ summary: 'Remove the stray BROKEN_REF line', risk: 'minor', edits: [{ path: mainP, find: '\n        BROKEN_REF', replace: '' }] }) + '\n```'; };
    const status = []; const r = await CS.fix.loop(proj, 'debug', { onStatus: m => status.push(m), onBuild() { } });
    assert(r.ok, r.reason); assert.strictEqual(r.attempts, 2); assert.strictEqual(calls, 1); assert.strictEqual(r.snaps.length, 1);
    const now = await CS.files.get(proj.project_id); assert(!/BROKEN_REF/.test(now[mainP])); assert.deepStrictEqual(Object.keys(now).sort(), Object.keys(f0).sort());
    const back = await CS.fix.rollback(proj, r.snaps[0]); assert(/BROKEN_REF/.test(back[mainP]));   // snapshot = state before the fix
    await CS.files.set(proj.project_id, f0);
  });
  await T('fix review rejects: ambiguous find, .github path, unrelated file needs approval, major needs approval, same error stops loop', async () => {
    const f = await CS.files.get(proj.project_id), err = { file: 'app/src/main/java/com/zenai/samplehello/MainActivity.kt', excerpt: 'x' };
    assert(!CS.fix.review(f, err, { edits: [{ path: 'app/build.gradle.kts', find: 'implementation(', replace: 'x(' }] }).ok);
    assert(!CS.fix.review(f, err, { edits: [{ path: '.github/workflows/a.yml', content: 'x' }] }).ok);
    const un = CS.fix.review(f, err, { edits: [{ path: 'app/src/main/res/values/colors.xml', find: '#6750A4</color>\n    <color name="icon_bg">', replace: '#6750A5</color>\n    <color name="icon_bg">' }] }); assert(un.ok && un.needsApproval);
    const mj = CS.fix.review(f, err, { risk: 'minor', edits: [{ path: 'app/build.gradle.kts', find: 'targetSdk = 34', replace: 'targetSdk = 35' }] }); assert(mj.ok && mj.needsApproval);
    const nw = CS.fix.review(f, err, { edits: [{ path: 'app/src/main/res/values/extra.xml', content: '<resources/>' }] }); assert(nw.ok && nw.needsApproval);
    f['app/src/main/java/com/zenai/samplehello/MainActivity.kt'] += '\nBROKEN_REF\n'; await CS.files.set(proj.project_id, f);
    W.ask = async () => JSON.stringify({ summary: 'noop', risk: 'minor', edits: [{ path: 'app/src/main/java/com/zenai/samplehello/MainActivity.kt', find: 'package com.zenai.samplehello', replace: 'package com.zenai.samplehello' }] });
    const r = await CS.fix.loop(proj, 'debug', { onStatus() { } }); assert(!r.ok); assert(/same error came back|Retry limit/.test(r.reason), r.reason);
  });
  await T('major fix is NOT applied without approval and IS applied when approved', async () => {
    const mainP = 'app/src/main/java/com/zenai/samplehello/MainActivity.kt'; const f = await CS.files.get(proj.project_id);
    W.ask = async () => JSON.stringify({ summary: 'bump sdk', risk: 'major', edits: [{ path: mainP, find: '\nBROKEN_REF\n', replace: '\n' }] });
    const before = await CS.files.get(proj.project_id); let asked = 0;
    const r1 = await CS.fix.loop(proj, 'debug', { onProposal: async () => { asked++; return false; } }); assert(!r1.ok && asked === 1 && /not approved/.test(r1.reason)); assert.deepStrictEqual(await CS.files.get(proj.project_id), before);
    const r2 = await CS.fix.loop(proj, 'debug', { onProposal: async () => true }); assert(r2.ok, r2.reason);
  });
  await T('cancel: running build is cancelled via API', async () => {
    const p2 = Object.assign({}, proj); const pr = CS.build.start(proj, { kind: 'debug', onUpdate: b => { if (b.run_id && b.build_status !== 'cancelled') CS.build.cancel(b.build_id); } }); const b = await pr; assert.strictEqual(b.build_status, 'cancelled');
  });
  await T('cleanup deletes old cloud artifacts only', async () => {
    S.arts.push({ id: 5000, name: 'cloud-apk-old', size_in_bytes: 1, expired: false, created_at: '2020-01-01T00:00:00Z' }, { id: 5001, name: 'Zen-Ai-Release-APK', size_in_bytes: 1, expired: false, created_at: '2020-01-01T00:00:00Z' });
    const n = await CS.cleanup(); assert(n >= 1); assert(!S.arts.some(a => a.id === 5000)); assert(S.arts.some(a => a.id === 5001));
  });
  await T('user scoping: another account sees none of these projects', async () => { assert(CS.db.projects.list().length >= 1); const keep = CS.ns; CS.ns = () => 'someoneelse'; assert.strictEqual(CS.db.projects.list().length, 0); assert.strictEqual(CS.db.builds.list().length, 0); CS.ns = keep; });
  await T('AI creator: plan -> files -> lint repair round (stub AI)', async () => {
    const calls = []; let bad = true;
    W.ask = async (sys, msg) => { calls.push(msg.slice(0, 40));
      if (/App idea/.test(msg)) return JSON.stringify({ appName: 'Notes Pad', summary: 's', screens: ['Main'], libs: ['recyclerview', 'bogus'], architecture: 'single activity', files: [{ path: 'app/src/main/java/com/zenai/notespad/MainActivity.kt', purpose: 'main' }, { path: 'app/src/main/res/layout/activity_main.xml', purpose: 'ui' }, { path: '.github/workflows/x.yml', purpose: 'evil' }, { path: 'app/src/main/res/themes2.xml', purpose: 'x' }] });
      if (/MainActivity\.kt/.test(msg) && /Write the file/.test(msg)) return bad ? (bad = false, 'package com.zenai.notespad\nimport android.os.Bundle\nimport androidx.appcompat.app.AppCompatActivity\nclass MainActivity : AppCompatActivity() {\n override fun onCreate(b: Bundle?) { super.onCreate(b); setContentView(R.layout.missing_layout)\n}\n') : 'x';
      if (/has these problems/.test(msg)) return '```kotlin\npackage com.zenai.notespad\nimport android.os.Bundle\nimport androidx.appcompat.app.AppCompatActivity\nclass MainActivity : AppCompatActivity() {\n override fun onCreate(b: Bundle?) { super.onCreate(b); setContentView(R.layout.activity_main) }\n}\n```';
      return '<?xml version="1.0" encoding="utf-8"?>\n<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android" android:layout_width="match_parent" android:layout_height="match_parent" android:orientation="vertical"><TextView android:id="@+id/label" android:layout_width="wrap_content" android:layout_height="wrap_content" android:text="@string/hello"/></LinearLayout>'; };
    const steps = []; const out = await CS.creator.generate({ prompt: 'a notes app', onStep: s => steps.push(s) });
    assert.strictEqual(out.pkg, 'com.zenai.notesp' === out.pkg ? out.pkg : out.pkg); assert.deepStrictEqual(out.libs, ['recyclerview']); assert.deepStrictEqual(out.issues, []);
    assert(!Object.keys(out.files).some(k => k.startsWith('.github'))); assert(/R\.layout\.activity_main/.test(out.files['app/src/main/java/' + out.pkg.replace(/\./g, '/') + '/MainActivity.kt'])); assert(steps.some(s => /Fixing/.test(s)));
  });
  await T('preview: html entry inlines css/js; xml layout becomes script-free html', async () => {
    const h = CS.preview.htmlEntry({ 'index.html': '<link rel="stylesheet" href="a.css"><script src="a.js"></script><p>x</p>', 'a.css': 'p{color:red}', 'a.js': 'var q=1' }); assert(/<style>p\{color:red\}/.test(h.html) && /<script>var q=1/.test(h.html));
    assert.strictEqual(CS.preview.htmlEntry({ 'a.kt': '' }), null);
  });
  await T('BACKGROUND: reopening the tool does not drop a running build (init is not reloaded)', async () => {
    const pr = CS.build.start(proj, { kind: 'debug' }); await new Promise(r => setTimeout(r, 400));
    const before = CS.db.d; await CS.init(); assert.strictEqual(CS.db.d, before, 'db was replaced');
    const b = await pr; assert.strictEqual(b.build_status, 'success'); assert(CS.db.builds.get(b.build_id).build_status === 'success');
    assert.strictEqual(CS.build.active().length, 0); assert.strictEqual(CS.keep.n, 0);
  });
  await T('BACKGROUND: app closed mid-build -> on next open the build is re-attached and finished', async () => {
    let id = ''; const pr = CS.build.start(proj, { kind: 'debug', onCreate: b => { id = b.build_id; } });
    while (!(CS.db.builds.get(id) || {}).run_id) await new Promise(r => setTimeout(r, 30));
    // simulate the process dying: the live handle and the promise chain are gone, only the saved record remains
    const rec = JSON.parse(JSON.stringify(CS.db.d)); delete CS.build.handles[id]; CS.keep.n = 0;
    CS.db.d = rec; assert(CS.build.ACTIVE[CS.db.builds.get(id).build_status]);
    await CS.resumeAll(); await new Promise(r => setTimeout(r, 50));
    const b2 = CS.db.builds.get(id); assert.strictEqual(b2.build_status, 'success', b2.summary); assert(CS.db.artifacts.forBuild(id).some(a => a.kind === 'debug')); assert.strictEqual(CS.keep.n, 0);
    await pr.catch(() => { });
  });
  await T('BACKGROUND: a build that was only being prepared when the app closed is marked interrupted', async () => {
    const b = CS.db.builds.create({ project_id: proj.project_id, build_type: 'debug', build_status: 'preparing' });
    await CS.resumeAll(); assert.strictEqual(CS.db.builds.get(b.build_id).build_status, 'failed'); assert(/Start it again/.test(CS.db.builds.get(b.build_id).summary));
  });
  await T('BACKGROUND: native watcher results are applied to the APK record (saved while the app was closed)', async () => {
    const b = await CS.build.start(proj, { kind: 'debug' }); const art = CS.db.artifacts.forBuild(b.build_id).find(a => a.kind === 'debug'); assert(art && !art.downloaded_at);
    let taken = false; W.A2ZCloud.watchStart = () => { }; W.A2ZCloud.watchStop = () => { };
    W.A2ZCloud.watchTake = () => { if (taken) return '[]'; taken = true; return JSON.stringify([{ build_id: b.build_id, artifact_id: art.gh_id, apk: { name: 'app-debug.apk', size: 123, sha256: 'ab'.repeat(32), where: 'Downloads/Zen Ai/Cloud Studio/app-debug.apk', package: 'com.zenai.samplehello' } }]); };
    await CS.resumeAll(); assert.strictEqual(art.storage_location, 'Downloads/Zen Ai/Cloud Studio/app-debug.apk'); assert.strictEqual(art.checksum, 'ab'.repeat(32)); assert(art.downloaded_at);
    delete W.A2ZCloud.watchStart; delete W.A2ZCloud.watchStop; delete W.A2ZCloud.watchTake;
  });
  await T('BACKGROUND: creator job writes the project itself and can continue after an interruption', async () => {
    const answers = { plan: JSON.stringify({ appName: 'Bg App', summary: 's', screens: ['Main'], libs: [], architecture: 'a', files: [{ path: 'app/src/main/java/com/zenai/bgapp/MainActivity.kt', purpose: 'main' }, { path: 'app/src/main/res/layout/activity_main.xml', purpose: 'layout' }] }) };
    const kt = 'package com.zenai.bgapp\nimport android.os.Bundle\nimport androidx.appcompat.app.AppCompatActivity\nclass MainActivity : AppCompatActivity() {\n override fun onCreate(b: Bundle?) { super.onCreate(b); setContentView(R.layout.activity_main) }\n}\n';
    const xml = '<?xml version="1.0" encoding="utf-8"?>\n<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android" android:layout_width="match_parent" android:layout_height="match_parent"><TextView android:id="@+id/label" android:layout_width="wrap_content" android:layout_height="wrap_content" android:text="@string/app_name"/></LinearLayout>\n';
    let writes = 0, boom = true; W.ask = async (sys, msg) => { if (/App idea/.test(msg)) return answers.plan; if (/Write the file/.test(msg)) { writes++; if (writes === 2 && boom) { boom = false; throw new Error('network down'); } return /MainActivity/.test(msg.split('Write the file')[1]) ? kt : xml; } return ''; };
    const projects0 = CS.db.projects.list().length;
    let err = null; try { await CS.creator.run({ prompt: 'a background app', name: 'Bg App' }); } catch (e) { err = e; }
    assert(err && /network down/.test(err.message)); const job = CS.jobs.list().find(j => j.type === 'creator'); assert.strictEqual(job.status, 'failed');
    const blob = await CS.jobs.blob.get(job.job_id); assert(blob && blob.i === 1, 'first file must be saved'); // MainActivity written, layout not yet
    // the app is reopened: the job is running again from the saved state (the stub AI works now)
    job.status = 'running'; await CS.resumeJobs(); await new Promise(r => setTimeout(r, 30));
    assert.strictEqual(job.status, 'done', job.message); assert.strictEqual(CS.db.projects.list().length, projects0 + 1); assert.strictEqual(writes, 3, 'only the missing file is written again'); assert.strictEqual(CS.keep.n, 0);
  });
  await T('BACKGROUND: fix loop without a screen parks a major fix as "waiting" and continues after approval', async () => {
    const files = await CS.files.get(proj.project_id); const k = Object.keys(files).find(x => /MainActivity\.kt$/.test(x));
    await CS.files.set(proj.project_id, Object.assign({}, files, { [k]: files[k] + '\nval broken = BROKEN_REF\n' }));
    W.ask = async () => JSON.stringify({ summary: 'remove bad line', risk: 'major', edits: [{ path: k, find: '\nval broken = BROKEN_REF\n', replace: '\n' }] });
    const r = await CS.fix.loop(proj, 'debug', {}); const job = CS.jobs.list().find(j => j.type === 'fix');
    if (r.waiting) { assert.strictEqual(job.status, 'waiting'); assert.strictEqual(CS.keep.n, 0);
      const rr = await CS.fix.resume(job, { onProposal: async () => true }); assert(rr.ok || /Build|Retry|same/.test(rr.reason || ''), JSON.stringify(rr)); assert(!/BROKEN_REF/.test((await CS.files.get(proj.project_id))[k])); }
    else assert.fail('expected the fix to wait for approval, got ' + JSON.stringify(r));
  });
  /* The page's real ask() resolves to {text, think, sources, queries, trunc}. Every earlier test used a string stub, which hid a bug. */
  const real = t => ({ text: t, think: '', sources: [], queries: [], trunc: false });
  const ktMain = 'package com.zenai.todopad\n\nimport android.os.Bundle\nimport android.widget.Button\nimport android.widget.EditText\nimport androidx.appcompat.app.AppCompatActivity\n\nclass MainActivity : AppCompatActivity() {\n    override fun onCreate(savedInstanceState: Bundle?) {\n        super.onCreate(savedInstanceState)\n        setContentView(R.layout.activity_main)\n        val input = findViewById<EditText>(R.id.input)\n        findViewById<Button>(R.id.add).setOnClickListener { input.setText("") }\n    }\n}\n';
  const xmlMain = '<?xml version="1.0" encoding="utf-8"?>\n<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"\n    android:layout_width="match_parent" android:layout_height="match_parent" android:orientation="vertical">\n    <EditText android:id="@+id/input" android:layout_width="match_parent" android:layout_height="wrap_content" android:hint="@string/app_name"/>\n    <Button android:id="@+id/add" android:layout_width="wrap_content" android:layout_height="wrap_content" android:text="@string/app_name"/>\n</LinearLayout>\n';
  const plan = JSON.stringify({ appName: 'Todo Pad', summary: 'A to-do app', screens: ['Main'], features: ['add'], architecture: 'single activity', libs: ['recyclerview'], files: [{ path: 'app/src/main/java/com/zenai/todopad/MainActivity.kt', purpose: 'main screen' }, { path: 'app/src/main/res/layout/activity_main.xml', purpose: 'layout' }] });
  let seenArgs = [];
  const aiOk = async (sys, msg) => { seenArgs.push(msg.slice(0, 30));
    if (/App idea/.test(msg)) return real('Sure! Here is the plan:\n```json\n' + plan + '\n```');
    if (/Write the file/.test(msg)) return real('```' + (/\.kt/.test(msg.split('Write the file')[1]) ? 'kotlin' : 'xml') + '\n' + (/MainActivity\.kt/.test(msg.split('Write the file')[1]) ? ktMain : xmlMain) + '```');
    return real(''); };
  let pipelineProj = null;
  await T('REAL-SHAPED AI: generate -> project -> files are clean code (no "[object Object]", no fences)', async () => {
    W.ask = aiOk; const r = await CS.creator.run({ prompt: 'a simple to-do list app', name: 'Todo Pad' });
    pipelineProj = r.project; const f = await CS.files.get(pipelineProj.project_id);
    const k = 'app/src/main/java/com/zenai/todopad/MainActivity.kt'; assert(f[k], Object.keys(f).join(','));
    for (const [n, t] of Object.entries(f)) { assert(!/\[object Object\]/.test(t), n); assert(!/^```/m.test(t), 'fence in ' + n); }
    assert(/^package com\.zenai\.todopad/.test(f[k])); assert(/<LinearLayout/.test(f['app/src/main/res/layout/activity_main.xml'])); assert.deepStrictEqual(r.result.issues, []);
    assert.deepStrictEqual(CS.lint(f).filter(x => x.level === 'error'), []);
  });
  await T('REAL-SHAPED AI: the generated app builds on (fake) GitHub and the APK is listed', async () => {
    const b = await CS.build.start(pipelineProj, { kind: 'debug' }); assert.strictEqual(b.build_status, 'success', b.summary);
    const a = CS.db.artifacts.forBuild(b.build_id).find(x => x.kind === 'debug'); assert(a && /^cloud-apk-/.test(a.file_name));
    const d = await CS.apk.download(Object.assign(a, {})).catch(e => e); // no native downloader in Node: must fail with a clear message, not crash
    assert(d instanceof Error || d.storage_location !== undefined);
  });
  await T('REAL-SHAPED AI: cut-off reply (trunc) and empty reply give a clear error and keep the job resumable', async () => {
    let n = 0; W.ask = async (sys, msg) => { if (/App idea/.test(msg)) return real(plan); if (/Write the file/.test(msg)) { n++; if (n === 1) return { text: 'class X {', trunc: true }; return real(/MainActivity/.test(msg.split('Write the file')[1]) ? ktMain : xmlMain); } return real(''); };
    let e1 = null; try { await CS.creator.run({ prompt: 'another app idea here', name: 'Todo Pad', pkg: 'com.zenai.todopad' }); } catch (e) { e1 = e; } assert(e1 && /cut off/.test(e1.message), e1 && e1.message);
    const job = CS.jobs.list().find(j => j.type === 'creator' && /cut off/.test(j.message)); assert(job && job.status === 'failed');
    const out = await CS.creator.resume(job); assert.strictEqual(job.status, 'done'); assert(out.project);
    W.ask = async () => real('   '); let e2 = null; try { await CS.askFn()('s', 'm'); } catch (e) { e2 = e; } assert(e2 && /empty/.test(e2.message));
  });
  await T('REAL-SHAPED AI: auto-fix loop reads the object reply, fixes a build error, rebuilds', async () => {
    const f = await CS.files.get(pipelineProj.project_id), k = 'app/src/main/java/com/zenai/todopad/MainActivity.kt';
    await CS.files.set(pipelineProj.project_id, Object.assign({}, f, { [k]: f[k].replace('input.setText("")', 'BROKEN_REF') }));
    W.ask = async (sys, msg) => real('```json\n' + JSON.stringify({ summary: 'use the input field', risk: 'minor', edits: [{ path: k, find: 'BROKEN_REF', replace: 'input.setText("")' }] }) + '\n```');
    const r = await CS.fix.loop(pipelineProj, 'debug', {}); assert(r.ok, JSON.stringify({ reason: r.reason })); assert.strictEqual(r.snaps.length, 1);
    assert(/input\.setText/.test((await CS.files.get(pipelineProj.project_id))[k]));
  });
  await T('build start with no repository configured fails cleanly (no stuck build, no leaked keep-alive)', async () => {
    const keepRepo = CS.cfg.v.repo; CS.cfg.v.repo = ''; let e = null; const before = CS.build.active().length;
    try { await CS.build.start(pipelineProj, { kind: 'debug' }); } catch (x) { e = x; }
    CS.cfg.v.repo = keepRepo; assert(e && /repository/i.test(e.message), e && e.message); assert.strictEqual(CS.build.active().length, before); assert.strictEqual(CS.keep.n, 0);
  });
  /* ===================== IMPORT: zip / files / code -> APK ===================== */
  const zlib = require('zlib');
  const crc = (b) => { let c, t = []; for (let n = 0; n < 256; n++) { c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } let r = 0xFFFFFFFF; for (const x of b) r = t[(r ^ x) & 0xFF] ^ (r >>> 8); return (r ^ 0xFFFFFFFF) >>> 0; };
  const mkzip = (files, opt = {}) => { // files: {name: string|Buffer}; opt.store = names stored not deflated
    const parts = [], cd = []; let off = 0;
    for (const [name, v] of Object.entries(files)) {
      const raw = Buffer.isBuffer(v) ? v : Buffer.from(v), stored = (opt.store || []).includes(name) || name.endsWith('/'), data = stored ? raw : zlib.deflateRawSync(raw), nm = Buffer.from(name);
      const lh = Buffer.alloc(30); lh.writeUInt32LE(0x04034b50, 0); lh.writeUInt16LE(20, 4); lh.writeUInt16LE(stored ? 0 : 8, 8); lh.writeUInt32LE(crc(raw), 14); lh.writeUInt32LE(data.length, 18); lh.writeUInt32LE(raw.length, 22); lh.writeUInt16LE(nm.length, 26);
      parts.push(lh, nm, data);
      const ch = Buffer.alloc(46); ch.writeUInt32LE(0x02014b50, 0); ch.writeUInt16LE(20, 4); ch.writeUInt16LE(20, 6); ch.writeUInt16LE(stored ? 0 : 8, 10); ch.writeUInt32LE(crc(raw), 16); ch.writeUInt32LE(data.length, 20); ch.writeUInt32LE(raw.length, 24); ch.writeUInt16LE(nm.length, 28); ch.writeUInt32LE(off, 42);
      cd.push(ch, nm); off += 30 + nm.length + data.length;
    }
    const cdb = Buffer.concat(cd), e = Buffer.alloc(22); e.writeUInt32LE(0x06054b50, 0); e.writeUInt16LE(Object.keys(files).length, 8); e.writeUInt16LE(Object.keys(files).length, 10); e.writeUInt32LE(cdb.length, 12); e.writeUInt32LE(off, 16);
    return new Uint8Array(Buffer.concat([...parts, cdb, e]));
  };
  const PNG = Buffer.from('89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c4890000000d49444154789c6360000002000001e221bc330000000049454e44ae426082', 'hex');
  const IMP = CS.importer; assert(IMP);
  const asEntries = (o) => Object.fromEntries(Object.entries(o).map(([k, v]) => [k, new Uint8Array(Buffer.isBuffer(v) ? v : Buffer.from(v))]));

  await T('IMPORT unzip: stored + deflated entries, folders skipped, bytes exact', async () => {
    const z = mkzip({ 'a/': '', 'a/x.kt': 'fun x() = 1\n'.repeat(200), 'a/p.png': PNG }, { store: ['a/p.png'] }); const r = await IMP.unzip(z);
    assert.deepStrictEqual(Object.keys(r.entries).sort(), ['a/p.png', 'a/x.kt']); assert(Buffer.from(r.entries['a/p.png']).equals(PNG)); assert.strictEqual(Buffer.from(r.entries['a/x.kt']).toString().length, 12 * 200 + 0 + 0 || 2400);
  });
  await T('IMPORT unzip: unsafe paths, bad zip, bombs are refused', async () => {
    const r = await IMP.unzip(mkzip({ '../evil.kt': 'x', '/abs.kt': 'x', 'ok.kt': 'x' })); assert.deepStrictEqual(Object.keys(r.entries), ['ok.kt']); assert.strictEqual(r.skipped.length, 2);
    await assert.rejects(IMP.unzip(new Uint8Array([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23])), /not a ZIP/);
    const big = mkzip({ 'big.txt': Buffer.alloc(6 * 1024 * 1024, 97) }); const b = await IMP.unzip(big); assert(!b.entries['big.txt'] && b.skipped.some(s => /5 MB/.test(s.why)));
  });
  const projFiles = (root) => { const sc = CS.scaffold({ name: 'Hello Zip', pkg: 'com.me.hellozip' }); const o = {}; for (const [k, v] of Object.entries(sc)) o[root + k] = v; o[root + 'local.properties'] = 'sdk.dir=/x'; o[root + 'my.jks'] = 'KEY'; o[root + 'gradlew'] = '#!/bin/sh'; o[root + 'gradle/wrapper/gradle-wrapper.jar'] = 'PK'; o[root + 'build/app.apk'] = 'zzz'; o[root + '.idea/x.xml'] = '<a/>'; o[root + 'app/src/main/res/drawable/pic.png'] = PNG; return o; };
  await T('IMPORT analyze: a whole Android project zip (inside a folder) is used as is; secrets/build output/wrapper are skipped', async () => {
    const r = await IMP.unzip(mkzip(projFiles('HelloZip-main/'))); const a = IMP.analyze(r.entries);
    assert.strictEqual(a.mode, 'project'); assert(a.files['settings.gradle.kts'] && a.files['app/build.gradle.kts']); assert.strictEqual(a.pkg, 'com.me.hellozip');
    assert(a.bins['app/src/main/res/drawable/pic.png']); const sk = a.skipped.map(s => s.path).join('|');
    for (const x of ['my.jks', 'local.properties', 'gradlew', 'gradle-wrapper.jar']) assert(sk.includes(x), x); assert(!Object.keys(a.files).some(k => /build\/|\.idea|jks|gradlew/.test(k)));
    for (const k of Object.keys(a.files)) assert(CS.okRel(k), k); assert.deepStrictEqual(CS.lint(a.files), []);
  });
  await T('IMPORT analyze: sources only (manifest + code, no Gradle) get the standard Gradle files around them', async () => {
    const sc = CS.scaffold({ name: 'Src Only', pkg: 'com.me.srconly' }); const src = {}; for (const k of Object.keys(sc)) if (/src\/main\//.test(k)) src['app/' + k.replace('app/', '') .replace(/^src/, 'src')] = sc[k];
    const only = {}; for (const k of Object.keys(sc)) if (k.startsWith('app/src/main/')) only['MyApp/' + k.slice(4)] = sc[k]; // MyApp/src/main/... = module folder
    const a = IMP.analyze(asEntries(only)); assert.strictEqual(a.mode, 'sources'); const c = IMP.complete(a, { name: 'Src Only' });
    assert(c.files['settings.gradle.kts'] && c.files['app/build.gradle.kts'] && c.files['app/src/main/AndroidManifest.xml']); assert.strictEqual(c.pkg, 'com.me.srconly'); assert.deepStrictEqual(CS.lint(c.files), []);
  });
  await T('IMPORT place: loose files go where Android expects them', async () => {
    const g = (n, c) => IMP.guessPath(n, c, 'com.me.x');
    assert.strictEqual(g('Foo.kt', 'package com.me.x.ui\nclass Foo'), 'app/src/main/java/com/me/x/ui/Foo.kt'); assert.strictEqual(g('Bar.java', 'class Bar{}'), 'app/src/main/java/com/me/x/Bar.java');
    assert.strictEqual(g('Main Screen.xml', '<LinearLayout/>'), 'app/src/main/res/layout/main_screen.xml'); assert.strictEqual(g('strings.xml', '<?xml version="1.0"?><resources></resources>'), 'app/src/main/res/values/strings.xml');
    assert.strictEqual(g('ic.xml', '<vector xmlns:android="x"/>'), 'app/src/main/res/drawable/ic.xml'); assert.strictEqual(g('AndroidManifest.xml', '<manifest/>'), 'app/src/main/AndroidManifest.xml');
    assert.strictEqual(g('Logo.PNG', ''), 'app/src/main/res/drawable/logo.png'); assert.strictEqual(g('data.json', '{}'), 'app/src/main/assets/data.json'); assert.strictEqual(g('app/src/main/res/layout/a.xml', '<a/>'), 'app/src/main/res/layout/a.xml');
  });
  await T('IMPORT loose files: Kotlin + layout + png -> a project that lints clean', async () => {
    const e = asEntries({ 'MainActivity.kt': 'package com.me.loose\nimport android.os.Bundle\nimport androidx.appcompat.app.AppCompatActivity\nclass MainActivity : AppCompatActivity() {\n override fun onCreate(b: Bundle?) { super.onCreate(b); setContentView(R.layout.activity_main) }\n}\n', 'activity_main.xml': '<?xml version="1.0" encoding="utf-8"?>\n<FrameLayout xmlns:android="http://schemas.android.com/apk/res/android" android:layout_width="match_parent" android:layout_height="match_parent"><ImageView android:layout_width="64dp" android:layout_height="64dp" android:src="@drawable/logo"/></FrameLayout>\n', 'logo.png': PNG });
    const cl = IMP.classify(e), rows = IMP.place(cl, 'com.me.loose'); assert(rows.every(r => r.to)); const ap = IMP.apply(rows, cl); assert(ap.bins['app/src/main/res/drawable/logo.png']);
    const c = IMP.complete({ mode: 'loose', files: ap.files, bins: ap.bins, notes: [], pkg: 'com.me.loose' }, { name: 'Loose App' });
    assert.strictEqual(c.pkg, 'com.me.loose'); assert(c.files['app/build.gradle.kts'] && c.files['app/src/main/AndroidManifest.xml']); assert(/com\.me\.loose\.MainActivity/.test(c.files['app/src/main/AndroidManifest.xml']), 'manifest launches the user activity');
    assert(!c.files['app/src/main/res/layout/activity_main.xml'] || /ImageView/.test(c.files['app/src/main/res/layout/activity_main.xml'])); assert.deepStrictEqual(CS.lint(c.files), []);
    for (const k of Object.keys(c.files)) assert(CS.okRel(k), k); for (const k of Object.keys(c.bins)) assert(CS.okBinRel(k), k);
  });
  let impProj;
  await T('IMPORT create -> push (text + PNG bytes exact) -> build -> APK, from a zip', async () => {
    const r = await IMP.unzip(mkzip(projFiles('zipapp/'))); const a = IMP.analyze(r.entries), c = IMP.complete(a, { name: 'Zip Imported' }); impProj = await IMP.create(c);
    assert(impProj.dirty); const bins = await CS.bin.get(impProj.project_id); assert(bins['app/src/main/res/drawable/pic.png']);
    const b = await CS.build.start(impProj, { kind: 'debug' }); assert.strictEqual(b.build_status, 'success', b.summary);
    const tree = fake.S.trees[fake.S.commits[fake.S.refs[impProj.branch]].tree], key = 'cloud-projects/' + impProj.slug + '/app/src/main/res/drawable/pic.png'; assert(tree[key], 'png in the commit');
    assert(Buffer.from(fake.S.blobs[tree[key]], 'base64').equals(PNG), 'png bytes survive the round trip');
    assert(CS.db.artifacts.forBuild(b.build_id).find(x => x.kind === 'debug'), 'apk listed');
  });
  await T('IMPORT addTo: new text + image join an existing project, old versions are snapshotted, changed image is pushed', async () => {
    const before = Object.keys(await CS.files.get(impProj.project_id)).length;
    const cl = IMP.classify(asEntries({ 'Extra.kt': 'package com.me.hellozip\nobject Extra { const val X = 1 }\n', 'logo2.png': PNG })), ap = IMP.apply(IMP.place(cl, 'com.me.hellozip'), cl);
    const r = await IMP.addTo(impProj, ap); assert.strictEqual(r.added, 2); const f = await CS.files.get(impProj.project_id); assert.strictEqual(Object.keys(f).length, before + 1); assert((await CS.bin.get(impProj.project_id))['app/src/main/res/drawable/logo2.png']);
    assert((await CS.files.snaps(impProj.project_id))[0].label.startsWith('Before adding'));
    const b = await CS.build.start(impProj, { kind: 'debug' }); assert.strictEqual(b.build_status, 'success', b.summary); const tree = fake.S.trees[fake.S.commits[fake.S.refs[impProj.branch]].tree]; assert(tree['cloud-projects/' + impProj.slug + '/app/src/main/res/drawable/logo2.png']);
  });
  await T('IMPORT: a project with no app module is reported, Gradle too old is noted', async () => {
    const a = IMP.analyze(asEntries({ 'settings.gradle': "rootProject.name='x'\ninclude ':lib'", 'lib/build.gradle': "plugins { id 'com.android.library' }", 'lib/src/main/A.kt': 'class A' })); assert(/No app module/.test(a.error));
    const o = IMP.analyze(asEntries({ 'settings.gradle': "include ':app'", 'build.gradle': "buildscript { dependencies { classpath 'com.android.tools.build:gradle:7.0.4' } }", 'app/build.gradle': "apply plugin: 'com.android.application'\nandroid { namespace 'com.old.app' }" })); assert(!o.error && o.pkg === 'com.old.app' && o.notes.some(n => /7\.0\.4/.test(n)));
  });
  await T('IMPORT: zip folder with spaces ("My App-main/") and a package named "build" still import', async () => {
    const sc2 = CS.scaffold({ name: 'Sp App', pkg: 'com.me.spapp' }); const o = {}; for (const [k, v] of Object.entries(sc2)) o['My App-main/' + k] = v;
    const a = IMP.analyze(asEntries(o)); assert.strictEqual(a.mode, 'project'); assert(Object.keys(a.files).length > 5); assert.strictEqual(a.pkg, 'com.me.spapp');
    const o2 = { 'x/src/main/java/com/me/build/Z.kt': 'package com.me.build\nclass Z', 'x/src/main/AndroidManifest.xml': '<manifest package="com.me.build"/>' }; const b = IMP.analyze(asEntries(o2)); assert(b.files['app/src/main/java/com/me/build/Z.kt']);
    const c = IMP.analyze(asEntries({ 'p/settings.gradle.kts': 'rootProject.name="p"', 'p/app/build.gradle.kts': 'plugins{id("com.android.application")}', 'p/app/src/main/java/My File.kt': 'class A' })); assert(c.skipped.some(s => /spaces/.test(s.why)));
  });
  await T('IMPORT: user\'s own app/build.gradle is never replaced when the package differs', async () => {
    const mine = 'plugins { id("com.android.application") }\n// MINE\n'; const files = { 'app/build.gradle.kts': mine, 'app/src/main/java/com/other/pk/MainActivity.kt': 'package com.other.pk\nimport androidx.appcompat.app.AppCompatActivity\nclass MainActivity : AppCompatActivity()\n' };
    const c = IMP.complete({ mode: 'loose', files, bins: {}, notes: [], pkg: '' }, { name: 'Keep Mine' }); assert.strictEqual(c.files['app/build.gradle.kts'], mine);
  });
  console.log('\n' + pass + ' passed, ' + fail + ' failed'); fake.close(); process.exit(fail ? 1 : 0);
})();
