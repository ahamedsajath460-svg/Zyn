/* Opens the REAL a2z.html in headless Chromium (412x860), opens Cloud Studio, and drives every section against the local fake GitHub. */
const { chromium } = require('playwright'); const path = require('path'); const start = require('./fake-github');
const TOKEN = 'ghp_TESTTOKEN0123456789012345678901234';
(async () => {
  const fake = await start({ buildMs: 200 }), errs = [], out = []; let hasTok = false, previews = [];
  const b = await chromium.launch(), pg = await b.newPage({ viewport: { width: 412, height: 860 } });
  pg.on('pageerror', e => errs.push(e.message)); pg.on('console', m => { if (m.type() === 'error') errs.push('console:' + m.text()); });
  await pg.exposeFunction('__fetchFake', async (method, p, body) => { const r = await fetch('http://127.0.0.1:' + fake.port + p, { method, headers: { authorization: 'Bearer ' + TOKEN }, body: body || undefined }); return { s: r.status, t: await r.text() }; });
  await pg.exposeFunction('__prev', (t, h, w) => { previews.push({ t, len: h.length, w }); });
  await pg.addInitScript(() => {
    window.A2ZCloud = { _tok: false, hasToken() { return this._tok; }, setToken() { this._tok = true; return 'ok'; }, clearToken() { this._tok = false; },
      gh(id, ns, m, p, body) { window.__fetchFake(m, p, body).then(r => window.__cloudCb(id, r.s, r.t)); }, openPreview(t, h, w) { window.__prev(t, h, w); return 'ok'; }, shareApk() { return 'ok'; },
      downloadApk(id) { setTimeout(() => window.__cloudCb(id, 200, JSON.stringify({ name: 'app-debug.apk', size: 4000000, sha256: 'ab'.repeat(32), where: 'Downloads/Zen Ai/Cloud Studio/app-debug.apk', package: 'com.zenai.samplehello', versionName: '1.0', versionCode: 1 })), 20); },
      downloadReports(id) { const px = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=='; setTimeout(() => window.__cloudCb(id, 200, JSON.stringify({ files: [{ name: '01-launch.png', size: 70, b64: px }, { name: 'crash-report.txt', size: 0, text: '' }, { name: 'logcat.txt', size: 9, text: 'I/ok line' }] })), 20); } };
  });
  await pg.goto('file://' + path.resolve(__dirname, '../../../app/src/main/assets/a2z.html')); await pg.waitForTimeout(2500);
  await pg.evaluate(() => { location.hash = 'tools'; window.A2ZAuth = null; }); await pg.waitForTimeout(150);
  await pg.evaluate(() => { const x = [...document.querySelectorAll('button')].find(q => /^\s*Skip/.test(q.textContent)); if (x) x.click(); }); await pg.waitForTimeout(500);
  const ok = (n, c, d) => { out.push((c ? 'ok   ' : 'FAIL ') + n + (c ? '' : '  ' + (d || ''))); if (!c) process.exitCode = 1; };
  const reg = await pg.evaluate(() => !!ALL.find(x => x.id === 'cloudstudio')); ok('tool registered in ALL (Create category)', reg);
  await pg.evaluate(() => { tool = 'cloudstudio'; drawTools(); document.querySelectorAll('.n-gate').forEach(e => e.classList.remove('n-gate')); }); await pg.waitForTimeout(800);
  const navs = await pg.$$eval('.cs-nav button', a => a.map(x => x.textContent)); ok('11 sections in navigation', navs.length === 11, navs.join(','));
  const txt = () => pg.evaluate(() => document.querySelector('.cs').innerText);
  ok('overview shows setup-required (no token yet)', /Setup required/.test(await txt()));
  await pg.screenshot({ path: 'cs-overview.png' });
  const nav = async n => { await pg.evaluate(n => [...document.querySelectorAll('.cs-nav button')].find(x => x.textContent === n).click(), n); await pg.waitForTimeout(400); };
  // settings: save token, repo
  await nav('Cloud Settings'); await pg.fill('.cs input[type=password]', TOKEN); await pg.evaluate(() => [...document.querySelectorAll('.cs-b')].find(x => /Save and test token/.test(x.textContent)).click()); await pg.waitForTimeout(700);
  ok('token accepted (Connected as tester)', await pg.evaluate(() => A2ZCloud._tok === true));
  await pg.fill('.cs input[placeholder="owner/name"]', 'o/r'); await pg.evaluate(() => [...document.querySelectorAll('.cs-b')].find(x => /Save and test repository/.test(x.textContent)).click()); await pg.waitForTimeout(900);
  ok('repo test lists all 5 workflow files', /Repository o\/r/.test(await txt()) && (await txt()).split('✓').length === 6, (await txt()).split('2 · REPOSITORY')[1].slice(0, 500));
  // ---- REAL PAGE: AI App Creator with a real-shaped ask(), leave the tool for Chat, come back ----
  await pg.evaluate(() => {
    const plan = JSON.stringify({ appName: 'Todo Pad', summary: 's', screens: ['Main'], libs: [], architecture: 'a', files: [{ path: 'app/src/main/java/com/zenai/todopad/MainActivity.kt', purpose: 'main' }, { path: 'app/src/main/res/layout/activity_main.xml', purpose: 'layout' }] });
    const kt = 'package com.zenai.todopad\nimport android.os.Bundle\nimport androidx.appcompat.app.AppCompatActivity\nclass MainActivity : AppCompatActivity() {\n override fun onCreate(b: Bundle?) { super.onCreate(b); setContentView(R.layout.activity_main) }\n}\n';
    const xml = '<?xml version="1.0" encoding="utf-8"?>\n<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android" android:layout_width="match_parent" android:layout_height="match_parent"><TextView android:id="@+id/label" android:layout_width="wrap_content" android:layout_height="wrap_content" android:text="@string/app_name"/></LinearLayout>\n';
    window.__aiCalls = 0; window.ask = async (sys, msg) => { window.__aiCalls++; await new Promise(r => setTimeout(r, 700)); const r = t => ({ text: t, think: '', sources: [], queries: [], trunc: false });
      if (/App idea/.test(msg)) return r('```json\n' + plan + '\n```'); if (/Write the file/.test(msg)) return r('```\n' + (/MainActivity\.kt/.test(msg.split('Write the file')[1]) ? kt : xml) + '```'); return r(''); };
    window.__hold = []; window.A2ZNative = Object.assign(window.A2ZNative || {}, { keepAlive(on) { window.__hold.push(on); }, notifShow() { return true; } });
  });
  await nav('AI App Creator');
  await pg.fill('.cs textarea', 'a simple todo list app for daily tasks'); await pg.evaluate(() => [...document.querySelectorAll('.cs-b')].find(x => /Generate with AI/.test(x.textContent)).click()); await pg.waitForTimeout(500);
  ok('creator shows the background-job card while the AI writes', /keeps going/.test(await txt()), (await txt()).slice(0, 300));
  ok('keep-alive requested while the job runs', await pg.evaluate(() => window.__hold.includes(true)), await pg.evaluate(() => JSON.stringify(window.__hold)));
  // leave the tool: go to the chat page, then back to Tools
  await pg.evaluate(() => { location.hash = 'chat'; }); await pg.waitForTimeout(300);
  await pg.evaluate(() => { try { go('chat'); } catch (e) { } }).catch(() => { }); await pg.waitForTimeout(2600);
  const jobsDone = await pg.evaluate(() => { const j = CloudStudio.jobs.list().find(x => x.type === 'creator'); return j ? j.status + '|' + CloudStudio.db.projects.list().length : 'nojob'; });
  ok('job finished and project exists while the user was away', /^done\|1$/.test(jobsDone), jobsDone);
  ok('no leftover keep-alive hold after finishing', await pg.evaluate(() => (window.__zynCsHold | 0) === 0));
  await pg.evaluate(() => { location.hash = 'tools'; tool = 'cloudstudio'; drawTools(); }); await pg.waitForTimeout(900);
  await nav('AI App Creator'); ok('returning shows "Project created" card with Open project', /Project created: Todo Pad/.test(await txt()) && /Open project/.test(await txt()), (await txt()).slice(0, 300));
  await pg.evaluate(() => [...document.querySelectorAll('.cs-b')].find(x => /Open project/.test(x.textContent)).click()); await pg.waitForTimeout(700);
  ok('workspace opens with the generated MainActivity.kt', /MainActivity\.kt/.test(await txt()) && !/\[object Object\]/.test(await txt()), (await txt()).slice(0, 200));
  // build from the real page, leave the tool during the build, result must be saved
  await nav('Build Center'); await pg.evaluate(() => [...document.querySelectorAll('.cs-b')].find(x => /Build debug APK/.test(x.textContent)).click()); await pg.waitForTimeout(500);
  await pg.evaluate(() => { location.hash = 'chat'; }); await pg.waitForTimeout(11000);
  const bs = await pg.evaluate(() => CloudStudio.db.builds.list().map(b => b.build_status).join(','));
  ok('build started from the page finished while the tool was closed', /success/.test(bs), bs);
  await pg.evaluate(() => { location.hash = 'tools'; tool = 'cloudstudio'; drawTools(); }); await pg.waitForTimeout(900); await nav('APK Manager');
  ok('APK Manager lists the APK of that build', /cloud-apk-b/.test(await txt()), (await txt()).slice(0, 300));
  ok('no page errors', errs.filter(e => !/file:|proxy|ERR_/i.test(e)).length === 0, errs.join(' | ').slice(0, 400));
  console.log(out.join('\n')); await b.close(); fake.close();
})();
