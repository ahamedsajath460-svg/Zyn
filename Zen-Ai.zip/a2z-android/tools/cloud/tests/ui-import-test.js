/* Opens the REAL a2z.html in headless Chromium (412x860), opens Cloud Studio, and drives every section against the local fake GitHub. */
const { chromium } = require('playwright'); const path = require('path'); const start = require('./fake-github');
const TOKEN = 'ghp_TESTTOKEN0123456789012345678901234';
(async () => {
  const fake = await start({ buildMs: 200 }), errs = [], out = []; let hasTok = false, previews = [];
  const b = await chromium.launch(), pg = await b.newPage({ viewport: { width: 412, height: 860 } });
  pg.on('pageerror', e => errs.push(e.message)); pg.on('console', m => { if (m.type() === 'error') errs.push('console:' + m.text()); });
  await pg.exposeFunction('__fetchFake', async (method, p, body) => { const r = await fetch('http://127.0.0.1:' + fake.port + p, { method, headers: { authorization: 'Bearer ' + TOKEN }, body: body || undefined }); return { s: r.status, t: await r.text() }; });
  await pg.exposeFunction('__prev', (t, h, w) => { previews.push({ t, len: h.length, w }); });
  await pg.addInitScript(() => {
    window.A2ZCloud = { _tok: false, hasToken() { return this._tok; }, setToken() { this._tok = true; return 'ok'; }, clearToken() { this._tok = false; },
      gh(id, ns, m, p, body) { window.__fetchFake(m, p, body).then(r => window.__cloudCb(id, r.s, r.t)); }, openPreview(t, h, w) { window.__prev(t, h, w); return 'ok'; }, shareApk() { return 'ok'; },
      downloadApk(id) { setTimeout(() => window.__cloudCb(id, 200, JSON.stringify({ name: 'app-debug.apk', size: 4000000, sha256: 'ab'.repeat(32), where: 'Downloads/Zen Ai/Cloud Studio/app-debug.apk', package: 'com.zenai.samplehello', versionName: '1.0', versionCode: 1 })), 20); },
      downloadReports(id) { const px = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=='; setTimeout(() => window.__cloudCb(id, 200, JSON.stringify({ files: [{ name: '01-launch.png', size: 70, b64: px }, { name: 'crash-report.txt', size: 0, text: '' }, { name: 'logcat.txt', size: 9, text: 'I/ok line' }] })), 20); } };
  });
  await pg.goto('file://' + path.resolve(__dirname, '../../../app/src/main/assets/a2z.html')); await pg.waitForTimeout(2500);
  await pg.evaluate(() => { location.hash = 'tools'; window.A2ZAuth = null; }); await pg.waitForTimeout(150);
  await pg.evaluate(() => { const x = [...document.querySelectorAll('button')].find(q => /^\s*Skip/.test(q.textContent)); if (x) x.click(); }); await pg.waitForTimeout(500);
  const ok = (n, c, d) => { out.push((c ? 'ok   ' : 'FAIL ') + n + (c ? '' : '  ' + (d || ''))); if (!c) process.exitCode = 1; };
  const reg = await pg.evaluate(() => !!ALL.find(x => x.id === 'cloudstudio')); ok('tool registered in ALL (Create category)', reg);
  await pg.evaluate(() => { tool = 'cloudstudio'; drawTools(); document.querySelectorAll('.n-gate').forEach(e => e.classList.remove('n-gate')); }); await pg.waitForTimeout(800);
  const navs = await pg.$$eval('.cs-nav button', a => a.map(x => x.textContent)); ok('11 sections in navigation', navs.length === 11, navs.join(','));
  const txt = () => pg.evaluate(() => document.querySelector('.cs').innerText);
  ok('overview shows setup-required (no token yet)', /Setup required/.test(await txt()));
  await pg.screenshot({ path: 'cs-overview.png' });
  const nav = async n => { await pg.evaluate(n => [...document.querySelectorAll('.cs-nav button')].find(x => x.textContent === n).click(), n); await pg.waitForTimeout(400); };
  // settings: save token, repo
  await nav('Cloud Settings'); await pg.fill('.cs input[type=password]', TOKEN); await pg.evaluate(() => [...document.querySelectorAll('.cs-b')].find(x => /Save and test token/.test(x.textContent)).click()); await pg.waitForTimeout(700);
  ok('token accepted (Connected as tester)', await pg.evaluate(() => A2ZCloud._tok === true));
  await pg.fill('.cs input[placeholder="owner/name"]', 'o/r'); await pg.evaluate(() => [...document.querySelectorAll('.cs-b')].find(x => /Save and test repository/.test(x.textContent)).click()); await pg.waitForTimeout(900);
  // ---- import a ZIP through the real UI ----
  const zlib = require('zlib'); const crcT = (() => { const t = []; for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
  const crc = b => { let r = 0xFFFFFFFF; for (const x of b) r = crcT[(r ^ x) & 255] ^ (r >>> 8); return (r ^ 0xFFFFFFFF) >>> 0; };
  const mkzip = files => { const parts = [], cd = []; let off = 0; for (const [name, v] of Object.entries(files)) { const raw = Buffer.from(v), d = zlib.deflateRawSync(raw), nm = Buffer.from(name); const lh = Buffer.alloc(30); lh.writeUInt32LE(0x04034b50, 0); lh.writeUInt16LE(20, 4); lh.writeUInt16LE(8, 8); lh.writeUInt32LE(crc(raw), 14); lh.writeUInt32LE(d.length, 18); lh.writeUInt32LE(raw.length, 22); lh.writeUInt16LE(nm.length, 26); parts.push(lh, nm, d); const ch = Buffer.alloc(46); ch.writeUInt32LE(0x02014b50, 0); ch.writeUInt16LE(20, 4); ch.writeUInt16LE(20, 6); ch.writeUInt16LE(8, 10); ch.writeUInt32LE(crc(raw), 16); ch.writeUInt32LE(d.length, 20); ch.writeUInt32LE(raw.length, 24); ch.writeUInt16LE(nm.length, 28); ch.writeUInt32LE(off, 42); cd.push(ch, nm); off += 30 + nm.length + d.length; } const c = Buffer.concat(cd), e = Buffer.alloc(22); e.writeUInt32LE(0x06054b50, 0); e.writeUInt16LE(Object.keys(files).length, 8); e.writeUInt16LE(Object.keys(files).length, 10); e.writeUInt32LE(c.length, 12); e.writeUInt32LE(off, 16); return Buffer.concat([...parts, c, e]); };
  const PNG = Buffer.from('89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c4890000000d49444154789c6360000002000001e221bc330000000049454e44ae426082', 'hex');
  const sc = await pg.evaluate(() => CloudStudio.scaffold({ name: 'Ui Zip', pkg: 'com.me.uizip' })); const zf = {}; for (const [k, v] of Object.entries(sc)) zf['UiZip/' + k] = v; zf['UiZip/app/src/main/res/drawable/pic.png'] = PNG; zf['UiZip/my.jks'] = 'KEY'; zf['UiZip/local.properties'] = 'sdk.dir=/x';
  await nav('My Projects');
  const [fc] = await Promise.all([pg.waitForEvent('filechooser'), pg.evaluate(() => [...document.querySelectorAll('.cs-b')].find(x => /Choose ZIP or files/.test(x.textContent)).click())]);
  await fc.setFiles({ name: 'UiZip.zip', mimeType: 'application/zip', buffer: mkzip(zf) }); await pg.waitForTimeout(1200);
  const md = await pg.evaluate(() => (document.querySelector('.cs-md') || {}).innerText || '');
  ok('plan dialog says Android project found, lists skipped keystore', /Android project found/.test(md) && /not imported/.test(md) && /1 image/.test(md), md.slice(0, 300));
  await pg.screenshot({ path: 'cs-import.png' });
  await pg.evaluate(() => [...document.querySelectorAll('.cs-md .cs-b')].find(x => /Create project/.test(x.textContent)).click()); await pg.waitForTimeout(1200);
  ok('project created and Build Center opened', /Build/.test(await txt()) && await pg.evaluate(() => CloudStudio.db.projects.list().some(p => p.package_name === 'com.me.uizip' && p.dirty)));
  ok('png stored as a binary resource, not as text', await pg.evaluate(async () => { const p = CloudStudio.db.projects.list().find(x => x.package_name === 'com.me.uizip'); const b = await CloudStudio.bin.get(p.project_id), f = await CloudStudio.files.get(p.project_id); return !!b['app/src/main/res/drawable/pic.png'] && !f['app/src/main/res/drawable/pic.png'] && !f['my.jks']; }));
  await pg.evaluate(() => { const p = CloudStudio.db.projects.list().find(x => x.package_name === 'com.me.uizip'); window.__ip = p; return CloudStudio.build.start(p, { kind: 'debug' }).then(b => { window.__ib = b; }); }); await pg.waitForTimeout(500);
  ok('imported zip builds to an APK', await pg.evaluate(() => window.__ib && window.__ib.build_status === 'success'), await pg.evaluate(() => window.__ib && window.__ib.summary));
  const tree = Object.entries(fake.S.trees).map(([k, t]) => t).flatMap(t => Object.keys(t)).filter(k => /pic\.png$/.test(k)); ok('png reached the GitHub commit', tree.length > 0);
  // loose file through the workspace "Add files"
  await nav('Code Workspace'); const hasBtn = await pg.evaluate(() => [...document.querySelectorAll('.cs-b')].some(x => x.textContent === 'Add files')); ok('workspace has an Add files button', hasBtn);
  const [fc2] = await Promise.all([pg.waitForEvent('filechooser'), pg.evaluate(() => [...document.querySelectorAll('.cs-b')].find(x => x.textContent === 'Add files').click())]);
  await fc2.setFiles([{ name: 'Helper.kt', mimeType: 'text/plain', buffer: Buffer.from('package com.me.uizip\nobject Helper { const val A = 1 }\n') }, { name: 'extra.png', mimeType: 'image/png', buffer: PNG }]); await pg.waitForTimeout(900);
  const md2 = await pg.evaluate(() => (document.querySelector('.cs-md') || {}).innerText || ''); ok('add-files dialog shows target folders', /java\/com\/me\/uizip/.test(await pg.evaluate(() => [...document.querySelectorAll('.cs-md input')].map(i => i.value).join('|'))), md2.slice(0, 200));
  await pg.evaluate(() => [...document.querySelectorAll('.cs-md .cs-b')].find(x => /^Add$/.test(x.textContent)).click()); await pg.waitForTimeout(900);
  ok('files were added to the project', await pg.evaluate(async () => { const f = await CloudStudio.files.get(window.__ip.project_id), b = await CloudStudio.bin.get(window.__ip.project_id); return !!f['app/src/main/java/com/me/uizip/Helper.kt'] && !!b['app/src/main/res/drawable/extra.png']; }));
  errs.splice(0, errs.length, ...errs.filter(e => !/ERR_TUNNEL|default-keys\.json/.test(e))); ok('no page errors (proxy/file:// noise filtered)', errs.length === 0, errs.join(' | ')); console.log(out.join('\n')); await b.close(); fake.close();
})();
