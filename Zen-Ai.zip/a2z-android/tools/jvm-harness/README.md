# JVM test harness (development aid only, not part of the app)
Compiles the pure-Kotlin parts of the app with the Kotlin compiler that ships inside Gradle and runs the JUnit tests, without the Android SDK.
- `shim/Json.kt`: a small org.json stand-in. `shim/Stubs.kt`: stand-ins for `FProvider` and `AgentPolicy.redact`.
- `it/`: functional stand-ins for the Android-bound services (`FloatAi`, `FloatStore`, `FloatSearch`, `AgentVision`, `AgentController`, `AgentRunner`) plus `QueueIntegrationTest`, which runs `TaskQueue` + `AgentImpls` + `Coordinator` + `TaskManager` end to end against fake providers.
- `srcs.txt` lists the files compiled (paths are from the authoring machine; edit them). `run.sh` expects Gradle in /opt/gradle-8.14.3. Usage: `./run.sh com.a2z.ai.AgentRuntimeTest ...`
These results do NOT replace `./gradlew testDebugUnitTest` on a real Android build.
