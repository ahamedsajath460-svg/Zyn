package com.a2z.ai

import android.content.Context
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** The path the chat page uses: classify (instant) then start (background run, status events, one final result). */
class BrainBridgeTest {
    private val app = Context()
    @Before fun setup() {
        TaskManager.resetForTest(); ProviderRouter.reset(); SharedContextManager.dropAll(); Fake.seenTurns.clear(); Orchestrator.releaseDevice()
        Fake.providers = listOf(FProvider("g", "G", "gemini", "https://x", "m", "SECRET-KEY"))
        Fake.llm = { _, sys, _ -> if (sys.contains("Rewrite")) "a city" else "chat reply" }
        Fake.search = { _ -> emptyList() }
        AgentSystem.ensure(app)
    }
    private fun runAndWait(id: String, text: String, key: String = "k", hist: List<Pair<String, String>> = emptyList()): Pair<List<String>, JSONObject> {
        val st = CopyOnWriteArrayList<String>(); var done: JSONObject? = null; val l = CountDownLatch(1)
        val err = BrainBridge.start(app, id, text, key, hist) { t, d -> if (t == "status") st.add(JSONObject(d).getString("line")) else { done = JSONObject(d); l.countDown() } }
        assertNull(err); assertTrue("finished", l.await(20, TimeUnit.SECONDS)); return st to done!!
    }
    @Test fun classifyIsInstantAndSaysWhichPathRuns() {
        val img = JSONObject(BrainBridge.classifyJson("Generate an image of a futuristic city.", "k")); assertFalse("image words never start media creation", img.getBoolean("native")); assertEquals("CHAT", img.getString("intent"))
        val vid = JSONObject(BrainBridge.classifyJson("make a video of a sunset", "k")); assertFalse(vid.getBoolean("native")); assertEquals("CHAT", vid.getString("intent"))
        val chat = JSONObject(BrainBridge.classifyJson("Hi, how are you?", "k")); assertFalse(chat.getBoolean("native")); assertFalse(chat.getBoolean("needsBrain"))
        val res = JSONObject(BrainBridge.classifyJson("Find the latest information about Android 17", "k")); assertTrue(res.getBoolean("native")); assertTrue("research may fall back to the chat pipeline", res.getBoolean("soft")); assertFalse(img.getBoolean("soft"))
    }
    @Test fun historyFromThePageGivesFollowUpContextAndSessionsStaySeparate() {
        runAndWait("r3", "which provider are you using right now?", "chatA", listOf("user" to "hello", "assistant" to "hi"))
        assertEquals(4, SharedContextManager.forSession("chatA").turns().size)
        assertTrue(SharedContextManager.forSession("chatB").turns().isEmpty())
        BrainBridge.reset(); assertTrue(SharedContextManager.forSession("chatA").turns().isEmpty())
        assertEquals(2, BrainBridge.parseHistory("[{\"role\":\"user\",\"text\":\"a\"},{\"role\":\"system\",\"text\":\"x\"},{\"role\":\"assistant\",\"text\":\"b\"}]").size)
        assertTrue(BrainBridge.parseHistory("not json").isEmpty())
    }
    @Test fun cancelStopsARunningBrainRun() {
        Fake.search = { _ -> Thread.sleep(3000); emptyList() }
        val l = CountDownLatch(1); var done: JSONObject? = null
        assertNull(BrainBridge.start(app, "r4", "Find the latest information about Android 17", "k", emptyList()) { t, d -> if (t == "done") { done = JSONObject(d); l.countDown() } })
        Thread.sleep(200); BrainBridge.cancel("r4"); assertTrue(l.await(10, TimeUnit.SECONDS)); assertFalse(done!!.getBoolean("ok"))
    }
    @Test fun emptyOrDuplicateRunIdsAreRefused() {
        assertNotNull(BrainBridge.start(app, "r5", "   ", "k", emptyList()) { _, _ -> })
    }
}
