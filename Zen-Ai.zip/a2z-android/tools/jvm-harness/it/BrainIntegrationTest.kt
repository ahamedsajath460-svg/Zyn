package com.a2z.ai

import android.content.Context
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

/**
 * 6.0 integration: the REAL agents (AgentImpls, BrainAgents), the real ToolRegistry, the real MasterOrchestrator, AgentRuntime, ProviderRouter, KeyPool and TaskQueue,
 * with fake providers / search / screen stand-ins (see Stubs3.kt). Nothing in the orchestration is mocked.
 */
class BrainIntegrationTest {
    private val app = Context()
    private var seq = 500L
    private fun ctx() = AgentCtx(seq++, System.currentTimeMillis() + 60_000L)
    private val calls = java.util.concurrent.CopyOnWriteArrayList<String>()   // "kind:text" of every AI call the fake provider got

    @Before fun setup() {
        TaskManager.resetForTest(); ProviderRouter.reset(); SharedContextManager.dropAll(); Fake.seenTurns.clear(); calls.clear(); Orchestrator.releaseDevice()
        Fake.providers = listOf(FProvider("g", "G", "gemini", "https://x", "gemini-2.0-flash", "SECRET-KEY-123"))
        Fake.linked = false; UiActions.startShare = null; UiActions.stopShare = null; UiActions.openFloating = null; AIAccessibilityService.on = true; AgentController.enabled = true; VoiceOut.speaker = null; HistorySource.recent = null
        Fake.llm = { _, sys, t ->
            calls.add((if (sys.contains("analysis agent")) "analysis" else if (sys.startsWith("Answer the QUESTION")) "research" else if (sys.contains("search queries")) "queries" else "chat") + ":" + t.text.take(40))
            when {
                sys.startsWith("Answer the QUESTION") -> "Android 17 is the next release [1]."
                sys.contains("analysis agent") -> "Comparison: first is official docs [1], second is hands-on [2]."
                sys.contains("Rewrite the idea") -> "a futuristic city at dusk, neon, ultra detailed"
                else -> "chat reply"
            }
        }
        Fake.search = { _ -> listOf(FloatSearch.Hit("Android Docs", "https://developer.android.com", "official docs"), FloatSearch.Hit("Codelabs", "https://codelabs", "hands-on")) }
        AgentSystem.ensure(app)
    }
    @org.junit.After fun restore() { UiActions.startShare = null; UiActions.stopShare = null; UiActions.openFloating = null; AIAccessibilityService.on = true; AgentController.enabled = true; VoiceOut.speaker = null; HistorySource.recent = null; Fake.linked = false; Fake.runner = { t, _ -> true to "done $t" }; Fake.search = { _ -> listOf(FloatSearch.Hit("Paris", "https://x/paris", "Paris is the capital of France")) } }
    private val brain get() = AgentSystem.brain

    @Test fun allAgentsAndRealToolsAreRegisteredTogether() {
        for (r in Role.values()) assertTrue("${r.title} registered", AgentSystem.runtime.has(r))
        val ids = AgentSystem.tools.ids()
        for (id in listOf("ai.chat", "web.search", "research.deep", "vision.screen", "vision.ocr", "screen.explain", "screen.act", "screen.share.status", "voice.speak", "memory.recall", "task.queue", "task.status", "provider.status", "screen.share.start", "screen.share.stop", "floating.open"))
            assertTrue("tool $id", id in ids)
        val d = AgentSystem.tools.describe(); for (i in 0 until d.length()) { val t = d.getJSONObject(i); assertTrue(t.getString("id"), t.has("input") && t.has("output") && t.getJSONArray("capabilities").length() > 0) }
        assertEquals("agents + tools reported", 2, AgentSystem.teamJson().length())
    }
    @Test fun greetingUsesOneAiCallAndNoSearchOrTools() {
        var searched = false; Fake.search = { searched = true; emptyList() }
        val o = brain.run(ctx(), "Hi, how are you?", false)
        assertTrue(o.ok); assertFalse(searched); assertEquals(1, calls.size); assertTrue(calls[0].startsWith("chat"))
    }
    @Test fun tanglishChatStaysOnTheConversationAgent() {
        var searched = false; Fake.search = { searched = true; emptyList() }
        val o = brain.run(ctx(), "vanakkam bro, epdi irukka?", false)
        assertTrue(o.ok); assertFalse(searched); assertEquals(1, calls.size)
    }
    @Test fun searchRequestRunsRealSearchAnswersWithSourcesAndVerifies() {
        val o = brain.run(ctx(), "Find the latest information about Android 17", false)
        assertTrue(o.text, o.ok); assertEquals(2, o.sources.size); assertTrue(o.text.contains("Android 17"))
        assertEquals(listOf("RESEARCH", "VERIFICATION"), o.steps.map { it.role }); assertFalse(o.text.contains("Not fully verified"))
    }
    @Test fun researchCompareUsesFourAgentsAndOneAnswer() {
        val o = brain.run(ctx(), "Research this topic, compare the results and prepare a summary.", false)
        assertEquals(listOf("RESEARCH", "ANALYSIS", "VERIFICATION", "CONVERSATION"), o.steps.map { it.role }); assertTrue(o.ok)
        assertTrue(calls.any { it.startsWith("analysis") })
    }
    @Test fun followUpCompareTheFirstTwoUsesTheEarlierResults() {
        brain.run(ctx(), "Search for the best Android development resources", false, "uf")
        calls.clear(); var searched = false; Fake.search = { searched = true; emptyList() }
        val o = brain.run(ctx(), "Compare the first two", false, "uf")
        assertTrue(o.text, o.ok); assertFalse("no new search for a follow-up", searched)
        assertTrue(calls.single().startsWith("analysis")); assertTrue(Fake.seenTurns.last().second.text.contains("Android Docs") && Fake.seenTurns.last().second.text.contains("Codelabs"))
    }
    @Test fun imageAndVideoWordsNeverStartMediaCreation() {
        for (m in listOf("Generate an image of a futuristic city.", "oru futuristic city padam generate pannu", "make a short clip of a running horse", "draw a logo for my shop"))
            assertEquals(m, BrainIntent.CHAT, brain.classify(m, false).intent)
        assertFalse("image.generate" in AgentSystem.tools.ids())
    }
    @Test fun screenQuestionUsesVisionAndOcrWhenSharedOtherwiseTheReadOnlyAccessibilityPath() {
        AIAccessibilityService.on = false
        val denied = brain.run(ctx(), "What is happening on my screen?", false)
        assertFalse(denied.ok); assertTrue(denied.text.contains("Accessibility"))
        AIAccessibilityService.on = true
        var explainOnly: Boolean? = null; Fake.runner = { _, e -> explainOnly = e; true to "Settings screen with Wi-Fi" }
        val acc = brain.run(ctx(), "What is happening on my screen?", false)
        assertTrue(acc.text, acc.ok); assertEquals("read-only mode, never taps", true, explainOnly)
        Fake.linked = true
        val o = brain.run(ctx(), "What is happening on my screen?", true)
        assertTrue(o.text, o.ok); assertTrue(Fake.seenTurns.last().second.text.contains("Wi-Fi"))     // OCR text reached the model
        assertTrue(Fake.seenTurns.last().second.images.isNotEmpty())
    }
    @Test fun phoneTaskGoesThroughTheRunnerAndIsReported() {
        Fake.runner = { t, _ -> true to "Opened Settings and found Wi-Fi" }
        val o = brain.run(ctx(), "Open Settings and find the Wi-Fi option.", true)
        assertTrue(o.text, o.ok); assertTrue(o.text.contains("Wi-Fi"))
        Fake.runner = { _, _ -> false to "Wi-Fi option not found" }
        val bad = brain.run(ctx(), "Open Settings and find the Bluetooth option.", true)
        assertFalse("a failed phone action is never reported as done", bad.ok)
        AIAccessibilityService.on = false
        val off = brain.run(ctx(), "Open Settings and tap Display", true)
        assertFalse(off.ok); assertTrue(off.text.contains("Accessibility"))
    }
    @Test fun searchDownFallsBackAndSaysSo() {
        Fake.search = { emptyList() }
        val o = brain.run(ctx(), "Find the latest information about Android 17", false)
        assertTrue(o.text, o.ok); assertTrue(o.text.contains("general knowledge")); assertEquals("degraded", o.steps.first().status)
    }
    @Test fun providerFallbackAndHealthWorkThroughTheBrain() {
        Fake.providers = listOf(FProvider("a", "A", "openai", "https://x", "m1", "KEY-A"), FProvider("b", "B", "openai", "https://x", "m2", "KEY-B"))
        Fake.llm = { p, _, _ -> if (p.id == "a") throw IllegalStateException("429 rate limit") else "from B" }
        val o = brain.run(ctx(), "hello there", false)
        assertTrue(o.text, o.ok); assertTrue(o.text.contains("from B")); assertEquals(ProviderRouter.State.RATE_LIMITED, ProviderRouter.stateOf("a", System.currentTimeMillis()))
    }
    @Test fun providerStatusNeverLeaksKeys() {
        Fake.providers = listOf(FProvider("a", "A", "openai", "https://x", "m1", "SECRET-KEY-123"))
        val o = brain.run(ctx(), "which provider are you using right now?", false)
        assertTrue(o.text, o.ok); assertFalse(o.text.contains("SECRET")); assertFalse(o.toJson().toString().contains("SECRET"))
    }
    @Test fun memoryRecallUsesHistorySourceAndVoiceNeedsASpeaker() {
        HistorySource.recent = { listOf("user" to "my favourite language is kotlin", "assistant" to "noted") }
        val m = brain.run(ctx(), "what did we talk about kotlin earlier?", false)
        assertTrue(m.text, m.ok && m.text.contains("kotlin"))
        val none = brain.run(ctx(), "read it aloud", false); assertFalse(none.ok)
        val said = java.util.concurrent.CopyOnWriteArrayList<String>(); VoiceOut.speaker = { said.add(it); true }
        brain.run(ctx(), "hello again my friend", false, "vs"); val v = brain.run(ctx(), "read it aloud", false, "vs")
        assertTrue(v.ok); assertEquals("chat reply", said.single())
    }
    @Test fun taskQueueRequestUsesTheRealQueue() {
        val o = brain.run(ctx(), "add a task to find the latest Android news", false)
        assertTrue(o.text, o.ok && o.text.contains("queued"))
    }
    @Test fun queuedTasksNowRunThroughTheBrain() {
        TaskManager.resetForTest()
        assertNull(TaskQueue.submit(app, "hello from the queue friend", 5))
        val e = System.currentTimeMillis() + 8000; while ((TaskManager.pendingList().isNotEmpty() || TaskManager.active?.state?.terminal == false) && System.currentTimeMillis() < e) Thread.sleep(25)
        assertTrue(TaskManager.completed().any { it.text.contains("queue friend") })
    }
    @Test fun directToolCallsReturnStructuredResults() {
        val c = ctx()
        val r = brain.callTool("web.search", JSONObject().put("query", "android 17"), c); assertTrue(r.ok); assertEquals(2, r.data.getJSONArray("hits").length())
        assertEquals(ToolStatus.FAILED, brain.callTool("web.search", JSONObject(), c).status)
        assertEquals(ToolStatus.UNAVAILABLE, brain.callTool("vision.ocr", JSONObject(), c).status.let { if (it == ToolStatus.DENIED) ToolStatus.UNAVAILABLE else it })
        Fake.providers = emptyList(); assertEquals(ToolStatus.UNAVAILABLE, brain.callTool("ai.chat", JSONObject().put("prompt", "x"), c).status)
    }
    @Test fun cancelStopsTheBrainEverywhere() {
        Fake.llm = { _, _, _ -> Thread.sleep(3000); "late" }
        val c = ctx(); val t = Thread { Thread.sleep(150); AgentSystem.runtime.cancel(c) }; t.start()
        val t0 = System.currentTimeMillis(); val o = brain.run(c, "hello there slow friend", false)
        assertFalse(o.ok); assertTrue(System.currentTimeMillis() - t0 < 2500); t.join()
    }

    // ---- every tool category is reachable from a chat message
    @Test fun linksRequestRunsTheWebSearchToolAndReturnsLinks() {
        val o = brain.run(ctx(), "give me links for kotlin coroutines", false)
        assertTrue(o.text, o.ok); assertTrue(o.text.contains("https://developer.android.com")); assertEquals(2, o.sources.size)
        assertTrue("no AI call was needed", calls.isEmpty()); assertEquals(BrainIntent.WEB_LINKS, o.intent)
        Fake.search = { _ -> emptyList() }
        assertFalse("no results is reported, never invented", brain.run(ctx(), "give me links for zzzz qqqq", false).ok)
    }
    @Test fun readTheScreenTextUsesOcrToolOnlyWhenShared() {
        val off = brain.run(ctx(), "read the text on my screen", false)
        assertFalse(off.ok); assertTrue(off.text.contains("Screen sharing is off"))
        Fake.linked = true
        val o = brain.run(ctx(), "read the text on my screen", true)
        assertTrue(o.text, o.ok); assertEquals(BrainIntent.SCREEN_TEXT, o.intent); assertTrue("OCR only: no AI call", calls.isEmpty()); assertTrue(o.text.contains("Wi-Fi"))
    }
    @Test fun shareStatusAndShareControlTools() {
        assertTrue(brain.run(ctx(), "is my screen sharing on?", false).text.contains("off"))
        Fake.linked = true; assertTrue(brain.run(ctx(), "is my screen sharing on?", true).text.contains("on"))
        Fake.linked = false
        val missing = brain.run(ctx(), "start screen share", false); assertFalse(missing.ok); assertTrue(missing.text.contains("Open the Zen Ai app"))
        var asked = 0; var stopped = 0; UiActions.startShare = { asked++ }; UiActions.stopShare = { stopped++ }
        val st = brain.run(ctx(), "start screen share", false)
        assertTrue(st.text, st.ok); assertEquals(1, asked); assertTrue("it never claims sharing is on before the user allows it", st.text.contains("Tap Start now"))
        assertTrue(brain.run(ctx(), "stop screen sharing", false).ok); assertEquals(1, stopped)
    }
    @Test fun floatingAssistantCanBeOpenedFromChat() {
        assertFalse(brain.run(ctx(), "open the floating assistant", false).ok)
        var n = 0; UiActions.openFloating = { n++ }
        val o = brain.run(ctx(), "open the floating assistant", false); assertTrue(o.text, o.ok); assertEquals(1, n); assertEquals(BrainIntent.FLOATING, o.intent)
    }
    @Test fun translateOrSummariseGivenTextUsesTheAiChatToolWithoutSearch() {
        var searched = false; Fake.search = { searched = true; emptyList() }
        val o = brain.run(ctx(), "translate this to Tamil: the meeting is moved to Friday afternoon because of the holiday", false)
        assertTrue(o.text, o.ok); assertEquals(BrainIntent.TRANSFORM, o.intent); assertFalse(searched); assertEquals(1, calls.size)
        Fake.providers = emptyList(); assertFalse("no provider is a clear failure", brain.run(ctx(), "summarize this: the meeting is moved to Friday afternoon because of the holiday", false).ok)
    }
}
