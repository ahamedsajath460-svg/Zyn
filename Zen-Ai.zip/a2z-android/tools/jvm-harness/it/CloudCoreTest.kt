package com.a2z.ai

import com.sun.net.httpserver.HttpServer
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.InetSocketAddress
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import javax.crypto.KeyGenerator

/** Runs against a LOCAL fake GitHub server (127.0.0.1). It proves our client logic, not GitHub itself. */
class CloudCoreTest {
    private lateinit var srv: HttpServer
    private var port = 0
    private val seenAuth = ArrayList<String?>()
    private val apkBytes = ByteArray(5000) { (it % 251).toByte() }

    private fun zip(vararg e: Pair<String, ByteArray>): ByteArray {
        val b = ByteArrayOutputStream(); ZipOutputStream(b).use { z -> for ((n, d) in e) { z.putNextEntry(ZipEntry(n)); z.write(d); z.closeEntry() } }; return b.toByteArray()
    }

    @Before fun up() {
        srv = HttpServer.create(InetSocketAddress("127.0.0.1", 0), 0); port = srv.address.port
        srv.createContext("/repos/o/r/actions/runs/1") { x -> seenAuth.add(x.requestHeaders.getFirst("Authorization")); val b = "{\"id\":1,\"token\":\"ghp_abcdefghijklmnopqrstuvwxyz0123456789\"}".toByteArray(); x.sendResponseHeaders(200, b.size.toLong()); x.responseBody.use { it.write(b) } }
        srv.createContext("/repos/o/r/actions/jobs/9/logs") { x -> seenAuth.add(x.requestHeaders.getFirst("Authorization")); x.responseHeaders.add("Location", "http://127.0.0.1:$port/blob/log.txt"); x.sendResponseHeaders(302, -1); x.close() }
        srv.createContext("/blob/log.txt") { x -> seenAuth.add("blob:" + x.requestHeaders.getFirst("Authorization")); val b = "line1\nstorePassword=hunter22\nFAILURE: Build failed".toByteArray(); x.sendResponseHeaders(200, b.size.toLong()); x.responseBody.use { it.write(b) } }
        srv.createContext("/repos/o/r/actions/runs/2/logs") { x -> x.responseHeaders.add("Location", "http://localhost:$port/evil"); x.sendResponseHeaders(302, -1); x.close() }
        srv.createContext("/repos/o/r/actions/artifacts/5/zip") { x -> x.responseHeaders.add("Location", "http://127.0.0.1:$port/blob/a.zip"); x.sendResponseHeaders(302, -1); x.close() }
        srv.createContext("/blob/a.zip") { x -> val z = zip("../../evil.apk" to apkBytes, "readme.txt" to ByteArray(10), "notes/app-debug.sha256" to "abc".toByteArray()); x.sendResponseHeaders(200, z.size.toLong()); x.responseBody.use { it.write(z) } }
        srv.createContext("/repos/o/r/actions/artifacts/6/zip") { x -> x.sendResponseHeaders(410, -1); x.close() }
        srv.start()
        CloudCore.apiBase = "http://127.0.0.1:$port"; CloudCore.testHosts = setOf("127.0.0.1")
    }
    @After fun down() { srv.stop(0); CloudCore.apiBase = "https://api.github.com"; CloudCore.testHosts = emptySet() }

    @Test fun pathAllowlist() {
        assertTrue(CloudCore.pathAllowed("GET", "/repos/a/b/actions/runs?per_page=5"))
        assertTrue(CloudCore.pathAllowed("POST", "/repos/a/b/actions/workflows/cloud-android-build.yml/dispatches"))
        assertTrue(CloudCore.pathAllowed("PUT", "/repos/a/b/contents/app/keys.json"))        // a FILE called keys.json is fine
        assertTrue(CloudCore.pathAllowed("DELETE", "/repos/a/b/git/refs/heads/x"))
        assertTrue(CloudCore.pathAllowed("DELETE", "/repos/a/b/actions/artifacts/12"))
        assertFalse(CloudCore.pathAllowed("GET", "/repos/a/b/actions/secrets"))
        assertFalse(CloudCore.pathAllowed("PUT", "/repos/a/b/actions/secrets/KEYSTORE_PASSWORD"))
        assertFalse(CloudCore.pathAllowed("GET", "/repos/a/b/actions/variables"))
        assertFalse(CloudCore.pathAllowed("POST", "/repos/a/b/keys"))
        assertFalse(CloudCore.pathAllowed("POST", "/repos/a/b/hooks"))
        assertFalse(CloudCore.pathAllowed("PUT", "/repos/a/b/collaborators/x"))
        assertFalse(CloudCore.pathAllowed("DELETE", "/repos/a/b"))
        assertFalse(CloudCore.pathAllowed("POST", "/repos/a/b/dispatches"))
        assertFalse(CloudCore.pathAllowed("PUT", "/repos/a/b/actions/workflows/x.yml/disable"))
        assertFalse(CloudCore.pathAllowed("GET", "/repos/a/b/../../user/keys"))
        assertFalse(CloudCore.pathAllowed("GET", "/orgs/a/members"))
        assertFalse(CloudCore.pathAllowed("GET", "/user/emails"))
        assertFalse(CloudCore.pathAllowed("GET", "/repos/a/b/contents/x\r\nHost: evil"))
        assertFalse(CloudCore.pathAllowed("TRACE", "/repos/a/b"))
        assertTrue(CloudCore.pathAllowed("GET", "/user"))
        assertFalse(CloudCore.pathAllowed("PATCH", "/user"))
    }

    @Test fun hostAllowlist() {
        CloudCore.testHosts = emptySet()
        assertTrue(CloudCore.hostAllowed("api.github.com"))
        assertTrue(CloudCore.hostAllowed("pipelines.actions.githubusercontent.com"))
        assertTrue(CloudCore.hostAllowed("productionresultssa1.blob.core.windows.net"))
        assertFalse(CloudCore.hostAllowed("evil.com"))
        assertFalse(CloudCore.hostAllowed("github.com.evil.com"))
        assertFalse(CloudCore.hostAllowed("notgithub.com"))
        assertFalse(CloudCore.hostAllowed(null))
    }

    @Test fun tokenShape() {
        assertTrue(CloudCore.tokenShapeOk("ghp_" + "a".repeat(36)))
        assertTrue(CloudCore.tokenShapeOk("github_pat_" + "A1_".repeat(20)))
        assertFalse(CloudCore.tokenShapeOk("hello world"))
        assertFalse(CloudCore.tokenShapeOk("ghp_short"))
        assertFalse(CloudCore.tokenShapeOk("ghp_" + "a".repeat(36) + "\n; rm"))
    }

    @Test fun requestSendsTokenAndRedactsAnswer() {
        val tok = "ghp_" + "Z".repeat(36)
        val r = CloudCore.request("GET", "/repos/o/r/actions/runs/1", null, tok)
        assertEquals(200, r.status); assertEquals("Bearer $tok", seenAuth[0])
        assertFalse(r.body.contains("ghp_abcdefghijklmnopqrstuvwxyz0123456789")); assertTrue(r.body.contains("***"))
    }

    @Test fun redirectDropsTokenAndRedactsLogs() {
        val tok = "ghp_" + "Z".repeat(36)
        val r = CloudCore.request("GET", "/repos/o/r/actions/jobs/9/logs", null, tok)
        assertEquals(200, r.status)
        assertEquals("Bearer $tok", seenAuth[0]); assertEquals("blob:null", seenAuth[1])      // the pre-signed hop got NO Authorization header
        assertTrue(r.body.contains("FAILURE: Build failed")); assertFalse(r.body.contains("hunter22"))
    }

    @Test fun redirectToUnlistedHostIsRefused() {
        val r = CloudCore.request("GET", "/repos/o/r/actions/runs/2/logs", null, "ghp_" + "Z".repeat(36))
        assertEquals(400, r.status); assertTrue(r.body.contains("not allowed"))
    }

    @Test fun missingTokenAndBlockedPath() {
        assertEquals(401, CloudCore.request("GET", "/repos/o/r", null, null).status)
        assertEquals(400, CloudCore.request("GET", "/repos/o/r/actions/secrets", null, "ghp_" + "Z".repeat(36)).status)
    }

    @Test fun artifactZipToApkWithChecksumAndNoZipSlip() {
        val out = File(System.getProperty("java.io.tmpdir"), "cloudtest_" + System.nanoTime())
        val s = CloudCore.downloadArtifact("o", "r", 5L, "ghp_" + "Z".repeat(36), out)!!
        assertEquals("evil.apk", s.name)                                   // "../../" stripped
        assertEquals(apkBytes.size.toLong(), s.size)
        assertEquals(CloudCore.sha256(s.file), s.sha256)
        assertEquals(out.canonicalPath, s.file.canonicalFile.parentFile.canonicalPath)
        assertFalse(File(out, "readme.txt").exists())                      // only apk / sha256 / build-info are kept
        assertTrue(File(out, "app-debug.sha256").exists())
        out.deleteRecursively()
    }

    @Test fun expiredArtifactGivesClearError() {
        val out = File(System.getProperty("java.io.tmpdir"), "cloudtest_" + System.nanoTime())
        try { CloudCore.downloadArtifact("o", "r", 6L, "ghp_" + "Z".repeat(36), out); fail("expected IOException") }
        catch (e: java.io.IOException) { assertTrue(e.message!!.contains("410")) }
    }

    @Test fun redactionPatterns() {
        val t = "token=ghp_" + "a".repeat(36) + "\nAuthorization: Bearer abcdefghijklmnopqrstuvwxyz\nkeyPassword: s3cr3tvalue\nAIza" + "x".repeat(35) + "\nok line"
        val r = CloudCore.redact(t)
        assertFalse(r.contains("s3cr3tvalue")); assertFalse(r.contains("abcdefghijklmnopqrstuvwxyz")); assertFalse(r.contains("AIzax")); assertTrue(r.contains("ok line"))
        assertTrue(CloudCore.redact("-----BEGIN PRIVATE KEY-----\nMIIE\n-----END PRIVATE KEY-----").contains("***"))
        assertEquals("a***b", CloudCore.redact("aSECRETb", "SECRET"))
    }

    @Test fun tailKeepsTheEnd() {
        val big = "x".repeat(100) + "THE_ERROR"
        val t = CloudCore.tail(big, 20); assertTrue(t.endsWith("THE_ERROR")); assertTrue(t.contains("earlier characters cut"))
    }

    @Test fun secretBoxRoundTripAndTamper() {
        val k = KeyGenerator.getInstance("AES").apply { init(256) }.generateKey()
        val box = CloudCore.SecretBox(k)
        val sealed = box.seal("ghp_" + "q".repeat(36))
        assertFalse(sealed.contains("ghp_")); assertEquals("ghp_" + "q".repeat(36), box.open(sealed))
        assertNotEquals(sealed, box.seal("ghp_" + "q".repeat(36)))          // fresh IV every time
        val bad = sealed.dropLast(4) + "AAAA"; assertNull(box.open(bad))
        assertNull(CloudCore.SecretBox(KeyGenerator.getInstance("AES").apply { init(256) }.generateKey()).open(sealed))   // other key
    }
}
