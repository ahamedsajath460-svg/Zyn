package com.a2z.ai

import com.sun.net.httpserver.HttpServer
import org.json.JSONObject
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.InetSocketAddress
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** The background follow-up of a cloud build (what runs when the app is closed), against a LOCAL fake GitHub. */
class CloudWatchLogicTest {
    private lateinit var srv: HttpServer
    private var port = 0
    private var polls = 0
    private var conclusion = "success"
    private var finishAfter = 2
    private val tmp = File(System.getProperty("java.io.tmpdir"), "cwtest_" + System.nanoTime())
    private val apk = ByteArray(3000) { (it % 200).toByte() }
    private val saved = ArrayList<String>()
    private var fg = false
    private val updates = ArrayList<Pair<Long, Boolean>>()
    private var now = 1_000_000L

    private fun zip(): ByteArray { val b = ByteArrayOutputStream(); ZipOutputStream(b).use { z -> z.putNextEntry(ZipEntry("app-debug.apk")); z.write(apk); z.closeEntry() }; return b.toByteArray() }
    private fun send(x: com.sun.net.httpserver.HttpExchange, code: Int, body: String) { val b = body.toByteArray(); x.responseHeaders.add("Content-Type", "application/json"); x.sendResponseHeaders(code, b.size.toLong()); x.responseBody.use { it.write(b) } }

    @Before fun up() {
        srv = HttpServer.create(InetSocketAddress("127.0.0.1", 0), 0); port = srv.address.port
        srv.createContext("/repos/o/r/actions/runs") { x ->
            val p = x.requestURI.path
            when {
                p == "/repos/o/r/actions/runs" -> send(x, 200, "{\"workflow_runs\":[{\"id\":11,\"display_title\":\"other\",\"name\":\"Cloud Android Debug\"},{\"id\":77,\"display_title\":\"Cloud build b123\",\"name\":\"Cloud Android Debug\"}]}")
                p == "/repos/o/r/actions/runs/77" -> { polls++; val done = polls > finishAfter; send(x, 200, "{\"id\":77,\"status\":\"" + (if (done) "completed" else "in_progress") + "\",\"conclusion\":" + (if (done) "\"$conclusion\"" else "null") + "}") }
                p == "/repos/o/r/actions/runs/77/artifacts" -> send(x, 200, "{\"artifacts\":[{\"id\":4,\"name\":\"cloud-log-b123\",\"expired\":false},{\"id\":5,\"name\":\"cloud-apk-b123\",\"expired\":false},{\"id\":6,\"name\":\"cloud-signed-b123\",\"expired\":true}]}")
                else -> send(x, 404, "{\"message\":\"Not Found\"}")
            }
        }
        srv.createContext("/repos/o/r/actions/artifacts/5/zip") { x -> x.responseHeaders.add("Location", "http://127.0.0.1:$port/blob/a.zip"); x.sendResponseHeaders(302, -1); x.close() }
        srv.createContext("/blob/a.zip") { x -> val z = zip(); x.sendResponseHeaders(200, z.size.toLong()); x.responseBody.use { it.write(z) } }
        srv.start(); CloudCore.apiBase = "http://127.0.0.1:$port"; CloudCore.testHosts = setOf("127.0.0.1"); tmp.mkdirs()
    }
    @After fun down() { srv.stop(0); CloudCore.apiBase = "https://api.github.com"; CloudCore.testHosts = emptySet(); tmp.deleteRecursively() }

    private val host = object : CloudWatchLogic.Host {
        override fun token(ns: String): String? = if (ns == "me") "ghp_" + "Z".repeat(36) else null
        override fun appForeground() = fg
        override fun cacheDir() = tmp
        override fun now() = now
        override fun saveApk(f: File, name: String): JSONObject { saved.add(name); return JSONObject().put("name", name).put("size", f.length()).put("where", "Downloads/Zen Ai/Cloud Studio/$name") }
        override fun update(w: CloudWatchLogic.W) { updates.add(w.runId to w.grace) }
    }
    private fun watch(kind: String = "debug", run: Long = 0L) = CloudWatchLogic.W("b123", "me", "o", "r", run, "cloud/my-app", kind, "My App", now)

    @Test fun findsTheRunByBuildId() {
        assertEquals(77L, CloudWatchLogic.findRunId("{\"workflow_runs\":[{\"id\":11,\"display_title\":\"x\"},{\"id\":77,\"display_title\":\"Cloud build b123\"}]}", "b123"))
        assertEquals(0L, CloudWatchLogic.findRunId("{\"workflow_runs\":[]}", "b123")); assertEquals(0L, CloudWatchLogic.findRunId("not json", "b123"))
    }

    @Test fun artifactChoiceMatchesThePage() {
        val j = "{\"artifacts\":[{\"id\":4,\"name\":\"cloud-log-b\"},{\"id\":5,\"name\":\"cloud-apk-b\"},{\"id\":6,\"name\":\"cloud-signed-b\"},{\"id\":7,\"name\":\"cloud-emu-b\"}]}"
        assertEquals(5L, CloudWatchLogic.pickArtifact(j, "debug")); assertEquals(6L, CloudWatchLogic.pickArtifact(j, "release"))
        assertEquals(5L, CloudWatchLogic.pickArtifact(j.replace("\"id\":6,\"name\":\"cloud-signed-b\"", "\"id\":6,\"name\":\"cloud-signed-b\",\"expired\":true"), "release"))
        assertEquals(0L, CloudWatchLogic.pickArtifact("{\"artifacts\":[]}", "debug"))
    }

    @Test fun followsUntilDoneThenSavesTheApk() {
        val w = watch()
        assertNull(CloudWatchLogic.step(w, host)); assertEquals(77L, w.runId)           // found the run, still working
        assertNull(CloudWatchLogic.step(w, host))
        val o = CloudWatchLogic.step(w, host)!!                                           // third look: completed
        assertEquals("success", o.result.optString("status")); assertEquals(5L, o.result.optLong("artifact_id"))
        assertEquals(listOf("app-debug.apk"), saved); assertTrue(o.text.contains("Downloads/Zen Ai/Cloud Studio/app-debug.apk"))
        assertEquals(apk.size.toLong(), o.result.optJSONObject("apk")!!.optLong("size")); assertEquals(CloudCore.sha256(File(tmp, "cloud_apk/app-debug.apk")), o.result.optJSONObject("apk")!!.optString("sha256"))
    }

    @Test fun failedBuildIsReportedWithoutDownload() {
        conclusion = "failure"; finishAfter = 0
        val o = CloudWatchLogic.step(watch(run = 77L), host)!!
        assertEquals("failed", o.result.optString("status")); assertTrue(saved.isEmpty()); assertTrue(o.text.contains("failed"))
    }

    @Test fun cancelledAndTestBuilds() {
        conclusion = "cancelled"; finishAfter = 0
        assertEquals("cancelled", CloudWatchLogic.step(watch(run = 77L), host)!!.result.optString("status"))
        conclusion = "success"; polls = 0
        val o = CloudWatchLogic.step(watch("test", 77L), host)!!
        assertEquals("success", o.result.optString("status")); assertTrue(saved.isEmpty()); assertTrue(o.text.contains("emulator test"))
    }

    @Test fun whenTheAppIsOpenThePageGetsOneMoreRoundFirst() {
        finishAfter = 0; fg = true
        val w = watch(run = 77L)
        assertNull(CloudWatchLogic.step(w, host)); assertTrue(w.grace); assertTrue(updates.contains(77L to true))
        assertNotNull(CloudWatchLogic.step(w, host))                                      // page did not stop the watch: the phone finishes the job
    }

    @Test fun missingTokenWaitsThenGivesUp() {
        val w = CloudWatchLogic.W("b123", "someoneelse", "o", "r", 0L, "", "debug", "My App", now)
        assertNull(CloudWatchLogic.step(w, host))
        now += CloudWatchLogic.GIVE_UP_MS + 1
        val o = CloudWatchLogic.step(w, host)!!; assertEquals("gave_up", o.result.optString("status"))
    }

    @Test fun watchRoundTripsThroughJson() {
        val w = watch(run = 9L); w.grace = true; val r = CloudWatchLogic.W.fromJson(w.toJson())
        assertEquals("b123", r.id); assertEquals(9L, r.runId); assertTrue(r.grace); assertEquals("cloud/my-app", r.branch); assertEquals("My App", r.label)
    }
}
