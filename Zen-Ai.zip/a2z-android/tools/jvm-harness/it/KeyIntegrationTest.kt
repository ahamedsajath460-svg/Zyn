package com.a2z.ai
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

/** AiGateway + KeyPool + ProviderRouter + UsageTracker together, against the stand-in FloatAi (JVM harness only). */
class KeyIntegrationTest {
    private fun ctx() = AgentCtx(1L, System.currentTimeMillis() + 60_000L)
    @Before fun clean() { KeyPool.reset(); KeyPool.auto = true; ProviderRouter.reset(); UsageTracker.reset(); Fake.seenTurns.clear() }

    @Test fun gatewayRotatesToNextKeyOn429AndSameProviderAnswers() {
        Fake.providers = listOf(FProvider("g", "G", "gemini", "https://x", "gemini-2.0-flash", "k1", listOf("k2")))
        KeyPool.set("g", listOf("k1", "k2")); val used = ArrayList<String>()
        Fake.llm = { p, _, _ -> used.add(p.key); if (p.key == "k1") throw RuntimeException("HTTP 429 quota exceeded"); "fine" }
        assertEquals("fine", AiGateway.ask(ProviderRouter.Kind.CHAT, "s", "hi", emptyList(), ctx()))
        assertEquals(listOf("k1", "k2"), used)
        assertEquals("cooling", KeyPool.statusJson("g", System.currentTimeMillis()).getJSONObject(0).getString("state"))
        used.clear(); AiGateway.ask(ProviderRouter.Kind.CHAT, "s", "again", emptyList(), ctx()); assertEquals(listOf("k2"), used)   // k1 is skipped while cooling
    }
    @Test fun allKeysRejectedFallsBackToNextProviderWithoutLooping() {
        Fake.providers = listOf(FProvider("a", "A", "openai", "https://x", "m1", "a1", listOf("a2")), FProvider("b", "B", "openai", "https://x", "m2", "b1"))
        KeyPool.set("a", listOf("a1", "a2")); var calls = 0
        Fake.llm = { p, _, _ -> calls++; if (p.id == "a") throw RuntimeException("401 invalid api key"); "from b" }
        assertEquals("from b", AiGateway.ask(ProviderRouter.Kind.CHAT, "s", "hi", emptyList(), ctx())); assertEquals(3, calls)
        assertEquals(ProviderRouter.State.AUTH_ERROR, ProviderRouter.stateOf("a", System.currentTimeMillis()))
        calls = 0; AiGateway.ask(ProviderRouter.Kind.CHAT, "s", "hi", emptyList(), ctx()); assertEquals(1, calls)   // invalid keys are not retried
    }
    @Test fun noUsageIsRecordedAsUnreportedNotInvented() {
        Fake.providers = listOf(FProvider("g", "G", "gemini", "https://x", "gemini-2.0-flash", "k"))
        Fake.llm = { _, _, _ -> "ok" }; AiGateway.ask(ProviderRouter.Kind.CHAT, "s", "hi", emptyList(), ctx())
        val s = UsageTracker.stat(0, Long.MAX_VALUE); assertEquals(1, s.calls); assertEquals(1, s.unreported); assertEquals(0L, s.inTok)
    }
}

class OcrHealthIntegrationTest {
    private fun ctx() = AgentCtx(1L, System.currentTimeMillis() + 60_000L)
    @Before fun clean() { KeyPool.reset(); ProviderRouter.reset(); UsageTracker.reset(); OcrLang.onlineConsent = false; OcrLang.language = OcrLang.Lang.TAMIL; Fake.seenTurns.clear()
        Fake.providers = listOf(FProvider("g", "G", "gemini", "https://x", "gemini-2.0-flash", "k")) }
    @Test fun noFrameLeavesDeviceWithoutConsent() { Fake.llm = { _, _, _ -> fail("must not be called"); "" }; assertNull(OnlineOcrRunner.read("IMG", ctx())); assertTrue(Fake.seenTurns.isEmpty()) }
    @Test fun consentedTamilReadAndWrongScriptRejected() {
        OcrLang.onlineConsent = true
        Fake.llm = { _, _, t -> assertEquals(1, t.images.size); "வணக்கம் உலகம்" }
        val r = OnlineOcrRunner.read("IMG", ctx())!!; assertEquals("வணக்கம் உலகம்", r.text); assertFalse(r.verified); assertEquals(OcrLang.Engine.ONLINE_VISION, r.engine)
        Fake.llm = { _, _, _ -> "Hello world, this is English" }
        assertEquals("", OnlineOcrRunner.read("IMG", ctx())!!.text)
    }
    @Test fun probeMarksAvailableOnlyAfterRealAnswer() {
        assertEquals(ProviderRouter.State.UNKNOWN, ProviderRouter.stateOf("g", 0L))
        Fake.llm = { _, _, _ -> throw RuntimeException("HTTP 401 invalid api key") }; assertFalse(AiGateway.probe("g")); assertEquals(ProviderRouter.State.AUTH_ERROR, ProviderRouter.stateOf("g", System.currentTimeMillis()))
        ProviderRouter.reset(); Fake.llm = { _, _, _ -> "OK" }; assertTrue(AiGateway.probe("g")); assertEquals(ProviderRouter.State.AVAILABLE, ProviderRouter.stateOf("g", System.currentTimeMillis()))
        assertFalse(AiGateway.probe("missing"))
    }
}
