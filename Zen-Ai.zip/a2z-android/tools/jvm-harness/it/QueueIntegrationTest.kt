package com.a2z.ai
import android.content.Context
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import java.util.concurrent.CopyOnWriteArrayList

class QueueIntegrationTest {
    private val app = Context()
    private fun workerAlive() = Thread.getAllStackTraces().keys.any { it.name == "zyn-task-queue" && it.isAlive }
    @org.junit.After fun drain() {
        TaskManager.pauseQueue(true)                                    // nothing new may start while cleaning up
        for (p in TaskManager.pendingList()) TaskManager.cancelPending(p.id)
        TaskManager.active?.let { if (!it.state.terminal) TaskQueue.cancel(it.id) }
        TaskManager.pauseQueue(false)
        val e = System.currentTimeMillis() + 8000; while (workerAlive() && System.currentTimeMillis() < e) Thread.sleep(25)
    }
    @Before fun clean() {
        drain()
        TaskQueue.pause(false); TaskManager.resetForTest(); ProviderRouter.reset(); Fake.seenTurns.clear(); Orchestrator.releaseDevice()
        Fake.providers = listOf(FProvider("g", "G", "gemini", "https://x", "gemini-2.0-flash", "k"))
        Fake.llm = { _, _, t -> "answer to ${t.text.take(30)}" }; Fake.linked = false
        Fake.search = { _ -> listOf(FloatSearch.Hit("Paris", "https://x/paris", "Paris is the capital of France")) }
        Fake.runner = { t, _ -> true to "done $t" }
    }
    private fun waitFor(ms: Long = 8000, c: () -> Boolean) { val e = System.currentTimeMillis() + ms; while (!c() && System.currentTimeMillis() < e) Thread.sleep(25) }
    private fun settled() = TaskManager.pendingList().isEmpty() && (TaskManager.active?.state?.terminal ?: true)

    @Test fun researchTaskUsesSearchAndReturnsSources() {
        Fake.llm = { _, sys, t -> if (sys.startsWith("Answer the QUESTION")) "Paris [1]" else "x" }
        assertNull(TaskQueue.submit(app, "research the capital of France", 5)); waitFor { settled() && TaskManager.completed().isNotEmpty() }
        val r = TaskManager.completed().single(); assertEquals("Paris [1]", r.result); assertEquals(listOf("https://x/paris"), r.sources.map { it.second })
        val j = TaskManager.resultJson(r.id); assertEquals(1, j.optJSONArray("sources")!!.length())
    }
    @Test fun chatTaskGoesToConversationAgent() {
        assertNull(TaskQueue.submit(app, "hello there", 5)); waitFor { TaskManager.completed().isNotEmpty() }
        assertTrue(TaskManager.completed().single().result.startsWith("answer to hello there"))
    }
    @Test fun priorityDecidesOrderWhenQueueIsPaused() {
        val order = CopyOnWriteArrayList<String>(); Fake.llm = { _, _, t -> order.add(t.text); "ok" }
        TaskQueue.pause(true)
        TaskQueue.submit(app, "hello low", 2); TaskQueue.submit(app, "hello high", 9); TaskQueue.submit(app, "hello mid", 5)
        Thread.sleep(300); assertTrue(order.isEmpty())                       // paused: nothing starts
        TaskQueue.pause(false); waitFor { order.size == 3 && settled() }
        assertEquals(listOf("hello high", "hello mid", "hello low"), order.toList())
    }
    @Test fun phoneTaskRunsThroughTheRunnerAndIsVerified() {
        assertNull(TaskQueue.submit(app, "open settings", 5)); waitFor { TaskManager.completed().isNotEmpty() }
        val r = TaskManager.completed().single(); assertEquals("done open settings", r.result)
        assertTrue(r.checkpoints.any { it.step.startsWith("act:") && it.verified })
    }
    @Test fun failedPhoneTaskIsReportedAndCanBeRetried() {
        var n = 0; Fake.runner = { _, _ -> if (++n == 1) false to "element not found" else true to "ok now" }
        TaskQueue.submit(app, "open settings", 5); waitFor { TaskManager.failed().isNotEmpty() }
        val f = TaskManager.failed().single(); assertEquals(TaskState.FAILED, f.state); assertTrue(f.result.contains("element not found"))
        assertNull(TaskQueue.retry(app, f.id)); waitFor { TaskManager.completed().isNotEmpty() }
        assertEquals("ok now", TaskManager.completed().single().result)
    }
    @Test fun cancelStopsRunningTaskAndQueueContinues() {
        Fake.llm = { _, _, t -> if (t.text.startsWith("hello slow")) { Thread.sleep(10_000); "late" } else "fast" }
        TaskQueue.submit(app, "hello slow task", 9); waitFor { TaskManager.active?.state == TaskState.EXECUTING }
        TaskQueue.submit(app, "hello next", 1)
        val id = TaskManager.active!!.id; val t0 = System.currentTimeMillis()
        assertTrue(TaskQueue.cancel(id)); waitFor { TaskManager.completed().isNotEmpty() }
        assertTrue("took ${System.currentTimeMillis() - t0}", System.currentTimeMillis() - t0 < 5000)
        assertEquals(TaskState.CANCELLED, TaskManager.finishedById(id)!!.state); assertEquals("fast", TaskManager.completed().single().result)
    }
    @Test fun cancelWaitingTask() {
        TaskQueue.pause(true); TaskQueue.submit(app, "hello a", 5); val id = TaskManager.pendingList().single().id
        assertTrue(TaskQueue.cancel(id)); assertTrue(TaskManager.pendingList().isEmpty()); assertFalse(TaskQueue.cancel(id))
    }
    @Test fun duplicateSubmitIsRefused() {
        TaskQueue.pause(true); assertNull(TaskQueue.submit(app, "hello a", 5)); assertNotNull(TaskQueue.submit(app, "Hello  A", 5))
    }
    @Test fun timeoutFailsTheTask() {
        Fake.llm = { _, _, _ -> Thread.sleep(10_000); "late" }
        TaskQueue.pause(true); TaskQueue.submit(app, "hello slow", 5); TaskManager.pendingList().single().timeoutMs = 1200L; TaskQueue.pause(false)
        waitFor { TaskManager.failed().isNotEmpty() }
        val f = TaskManager.failed().single(); assertEquals(TaskState.FAILED, f.state); assertTrue(f.result, f.result.lowercase().contains("timed out"))
    }
    @Test fun providerFallbackAndCooldown() {
        Fake.providers = listOf(FProvider("a", "A", "openai", "https://x", "foo-model", "k"), FProvider("b", "B", "openai", "https://x", "bar-model", "k"))
        Fake.llm = { p, _, _ -> if (p.id == "a") throw IllegalStateException("Rate or quota limit reached for this key/model.") else "from b" }
        TaskQueue.submit(app, "hello x", 5); waitFor { TaskManager.completed().isNotEmpty() }
        assertEquals("from b", TaskManager.completed().single().result)
        assertEquals("b", ProviderRouter.candidates(ProviderRouter.Kind.CHAT, Fake.providers, System.currentTimeMillis()).first().id)   // a is cooling down
    }
    @Test fun screenImageNeverReachesTextOnlyProvider() {
        Fake.linked = true; Fake.providers = listOf(FProvider("d", "DeepSeek", "openai", "https://x", "deepseek-chat", "k"))
        TaskQueue.submit(app, "what is on this screen", 5); waitFor { TaskManager.completed().isNotEmpty() || TaskManager.failed().isNotEmpty() }
        assertTrue(Fake.seenTurns.isNotEmpty()); assertTrue(Fake.seenTurns.all { it.second.images.isEmpty() })
    }
    @Test fun screenImageGoesToVisionProviderWhenOneExists() {
        Fake.linked = true; Fake.providers = listOf(FProvider("d", "DeepSeek", "openai", "https://x", "deepseek-chat", "k"), FProvider("g", "Gemini", "gemini", "https://x", "gemini-2.0-flash", "k"))
        TaskQueue.submit(app, "what is on this screen", 5); waitFor { TaskManager.completed().isNotEmpty() }
        val withImg = Fake.seenTurns.filter { it.second.images.isNotEmpty() }; assertTrue(withImg.isNotEmpty()); assertTrue(withImg.all { it.first == "g" })
    }
    @Test fun visionWithoutScreenShareFailsClearly() {
        Fake.linked = false; TaskQueue.submit(app, "what is on this screen", 5); waitFor { TaskManager.failed().isNotEmpty() || TaskManager.completed().isNotEmpty() }
        // no screen share: the planner falls back to the read-only screen agent (runner), which is fine; assert nothing crashed
        assertTrue(settled())
    }
}
