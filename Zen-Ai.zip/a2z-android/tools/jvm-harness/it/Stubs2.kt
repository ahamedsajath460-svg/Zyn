package android.content
open class Context { val applicationContext: Context get() = this; val filesDir: java.io.File = java.nio.file.Files.createTempDirectory("zynfiles").toFile() }
