package com.a2z.ai
// Functional stand-ins for the Android-bound services, so AgentImpls + TaskQueue + Coordinator + TaskManager run end to end on the JVM here.
import android.content.Context
import java.util.concurrent.CopyOnWriteArrayList
class Turn(val role: String, val text: String, val images: List<String> = emptyList())
object Fake {
    @Volatile var providers: List<FProvider> = listOf(FProvider("g", "G", "gemini", "https://x", "gemini-2.0-flash", "k"))
    @Volatile var llm: (FProvider, String, Turn) -> String = { _, _, t -> "answer to ${t.text.take(30)}" }
    @Volatile var search: (String) -> List<FloatSearch.Hit> = { q -> listOf(FloatSearch.Hit("Paris", "https://x/paris", "Paris is the capital of France")) }
    @Volatile var linked = false
    @Volatile var runner: (String, Boolean) -> Pair<Boolean, String> = { t, _ -> true to "done $t" }
    val seenTurns = CopyOnWriteArrayList<Pair<String, Turn>>()
}
class FloatAi {
    @Volatile private var c = false
    @Volatile var depth: ReasoningPolicy.Depth? = null; @Volatile var usageIn: Long? = null; @Volatile var usageOut: Long? = null
    fun cancel() { c = true }
    fun stream(p: FProvider, sys: String, turns: List<Turn>, onDelta: (String) -> Unit) {
        Fake.seenTurns.add(p.id to turns.last())
        val box = arrayOfNulls<Any>(1)
        val t = Thread { try { box[0] = Fake.llm(p, sys, turns.last()) } catch (e: Throwable) { box[0] = e } }
        t.isDaemon = true; t.start()
        while (t.isAlive) { if (c) throw RuntimeException("cancelled"); Thread.sleep(20) }
        val r = box[0]; if (r is Throwable) throw r; onDelta(r as String)
    }
    companion object { fun friendly(e: Throwable): String = e.message ?: "error" }
}
object FloatStore { fun ordered(): List<FProvider> = Fake.providers }
object FloatSearch { class Hit(val title: String, val url: String, val text: String); fun search(q: String, news: Boolean = false, fresh: String = ""): List<Hit> = Fake.search(q) }
class VObs(val text: String, val jpeg: String)
object AgentVision { fun linked() = Fake.linked; fun observe(): VObs? = VObs("Settings  Wi-Fi  Display", "JPEGDATA") }
object AgentController {
    val listeners = CopyOnWriteArrayList<(String, String) -> Unit>()
    @Volatile var keepHistory = false
    @Volatile var enabled = true
    fun emit(t: String, d: String) { for (l in listeners) l(t, d) }
    fun hardStop(reason: String) { TaskManager.end("stopped", false, reason); emit("result", org.json.JSONObject().put("ok", false).put("text", "Stopped. $reason").toString()) }
    fun pause() {}; fun resume() {}
}
object AgentRunner {
    fun start(ctx: Context, task: String, explainOnly: Boolean = false): String? {
        TaskManager.begin(task)
        val t = Thread { val r = Fake.runner(task, explainOnly); TaskManager.end(if (r.first) "answered" else "failed", r.first, r.second); AgentController.emit("result", org.json.JSONObject().put("ok", r.first).put("text", r.second).toString()) }
        t.isDaemon = true; t.start(); return null
    }
}

object AIAccessibilityService { @Volatile var on = true; fun connected() = on }
