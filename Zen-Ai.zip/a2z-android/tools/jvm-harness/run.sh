#!/bin/bash
# usage: run.sh <test classes...>  (compiles real project sources listed in SRCS + shims, runs JUnit)
set -e
H=$(cd "$(dirname "$0")" && pwd); L=/opt/gradle-8.14.3/lib
SRC=/home/claude/zyn/a2z-android/app/src
CP="$L/kotlin-compiler-embeddable-2.0.21.jar:$L/kotlin-stdlib-2.0.21.jar:$L/kotlin-script-runtime-2.0.21.jar:$L/kotlin-reflect-2.0.21.jar:$L/kotlin-daemon-embeddable-2.0.21.jar:$L/trove4j-1.0.20200330.jar:$L/annotations-24.0.1.jar:$L/kotlinx-coroutines-core-jvm-1.6.4.jar"
rm -rf $H/out && mkdir -p $H/out
java -cp "$CP" org.jetbrains.kotlin.cli.jvm.K2JVMCompiler -no-stdlib -no-reflect -nowarn -jvm-target 17 -cp "$L/kotlin-stdlib-2.0.21.jar:$L/junit-4.13.2.jar:$L/hamcrest-core-1.3.jar" -d $H/out $H/shim/*.kt $(cat $H/srcs.txt) 2>&1 | grep -v "^warning" || true
java -cp "$H/out:$L/kotlin-stdlib-2.0.21.jar:$L/junit-4.13.2.jar:$L/hamcrest-core-1.3.jar" org.junit.runner.JUnitCore "$@"
