package android.util
object Base64 { const val NO_WRAP = 2; fun encodeToString(b: ByteArray, f: Int): String = java.util.Base64.getEncoder().encodeToString(b) }
