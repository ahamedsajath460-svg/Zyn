package org.json
// Minimal org.json stand-in for JVM tests in this environment ONLY (the real project uses Android's org.json / org.json:json for tests).
class JSONException(m: String) : RuntimeException(m)
class JSONArray() {
    val list = ArrayList<Any?>()
    constructor(c: Collection<*>) : this() { list.addAll(c) }
    constructor(s: String) : this() { val v = Parser(s).value(); if (v !is JSONArray) throw JSONException("not array"); list.addAll(v.list) }
    fun put(v: Any?): JSONArray { list.add(v); return this }
    fun length() = list.size
    fun opt(i: Int): Any? = list.getOrNull(i)
    fun optJSONObject(i: Int): JSONObject? = opt(i) as? JSONObject
    fun getJSONObject(i: Int): JSONObject = opt(i) as JSONObject
    fun optJSONArray(i: Int): JSONArray? = opt(i) as? JSONArray
    fun optString(i: Int): String = opt(i)?.let { if (it == JSONObject.NULL) "" else it.toString() } ?: ""
    fun optInt(i: Int): Int = (opt(i) as? Number)?.toInt() ?: 0
    override fun toString(): String = "[" + list.joinToString(",") { ser(it) } + "]"
}
class JSONObject() {
    val map = LinkedHashMap<String, Any?>()
    constructor(s: String) : this() { val v = Parser(s).value(); if (v !is JSONObject) throw JSONException("not object"); map.putAll(v.map) }
    companion object { val NULL = Any() }
    fun put(k: String, v: Any?): JSONObject { map[k] = v; return this }
    fun has(k: String) = map.containsKey(k)
    fun isNull(k: String) = !map.containsKey(k) || map[k] === NULL
    fun opt(k: String): Any? = map[k]
    fun get(k: String): Any = map[k] ?: throw JSONException("missing $k")
    fun getString(k: String): String = get(k).toString()
    fun getJSONObject(k: String): JSONObject = get(k) as JSONObject
    fun getJSONArray(k: String): JSONArray = get(k) as JSONArray
    fun getBoolean(k: String): Boolean = get(k) as Boolean
    fun getInt(k: String): Int = (get(k) as Number).toInt()
    fun optString(k: String): String = optString(k, "")
    fun optString(k: String, d: String): String = map[k].let { if (it == null || it === NULL) d else it.toString() }
    fun optInt(k: String, d: Int = 0): Int = (map[k] as? Number)?.toInt() ?: d
    fun optDouble(k: String, d: Double = Double.NaN): Double = (map[k] as? Number)?.toDouble() ?: d
    fun optLong(k: String, d: Long = 0L): Long = (map[k] as? Number)?.toLong() ?: d
    fun optBoolean(k: String, d: Boolean = false): Boolean = (map[k] as? Boolean) ?: d
    fun optJSONObject(k: String): JSONObject? = map[k] as? JSONObject
    fun optJSONArray(k: String): JSONArray? = map[k] as? JSONArray
    fun keys(): Iterator<String> = map.keys.toList().iterator()
    fun length() = map.size
    override fun toString(): String = "{" + map.entries.joinToString(",") { "\"" + esc(it.key) + "\":" + ser(it.value) } + "}"
}
internal fun esc(s: String): String { val b = StringBuilder(); for (c in s) when (c) { '"' -> b.append("\\\""); '\\' -> b.append("\\\\"); '\n' -> b.append("\\n"); '\r' -> b.append("\\r"); '\t' -> b.append("\\t"); else -> if (c < ' ') b.append(String.format("\\u%04x", c.code)) else b.append(c) }; return b.toString() }
internal fun ser(v: Any?): String = when (v) { null -> "null"; JSONObject.NULL -> "null"; is String -> "\"" + esc(v) + "\""; is Number, is Boolean, is JSONObject, is JSONArray -> v.toString(); else -> "\"" + esc(v.toString()) + "\"" }
internal class Parser(val s: String) {
    var i = 0
    fun ws() { while (i < s.length && s[i].isWhitespace()) i++ }
    fun value(): Any? {
        ws(); if (i >= s.length) throw JSONException("eof")
        val c = s[i]
        return when {
            c == '{' -> { i++; val o = JSONObject(); ws(); if (s[i] == '}') { i++; return o }
                while (true) { ws(); val k = str(); ws(); if (s[i] != ':') throw JSONException("colon"); i++; o.map[k] = value(); ws(); if (s[i] == ',') { i++; continue }; if (s[i] == '}') { i++; break }; throw JSONException("obj") }; o }
            c == '[' -> { i++; val a = JSONArray(); ws(); if (s[i] == ']') { i++; return a }
                while (true) { a.list.add(value()); ws(); if (s[i] == ',') { i++; continue }; if (s[i] == ']') { i++; break }; throw JSONException("arr") }; a }
            c == '"' -> str()
            s.startsWith("true", i) -> { i += 4; true }
            s.startsWith("false", i) -> { i += 5; false }
            s.startsWith("null", i) -> { i += 4; JSONObject.NULL }
            else -> { val st = i; while (i < s.length && (s[i].isDigit() || s[i] in "+-.eE")) i++; if (st == i) throw JSONException("bad"); val t = s.substring(st, i); if (t.contains('.') || t.contains('e') || t.contains('E')) t.toDouble() else t.toLong().let { if (it in Int.MIN_VALUE..Int.MAX_VALUE) it.toInt() else it } }
        }
    }
    fun str(): String { if (s[i] != '"') throw JSONException("str"); i++; val b = StringBuilder()
        while (s[i] != '"') { if (s[i] == '\\') { i++; when (s[i]) { 'n' -> b.append('\n'); 't' -> b.append('\t'); 'r' -> b.append('\r'); 'u' -> { b.append(s.substring(i + 1, i + 5).toInt(16).toChar()); i += 4 }; else -> b.append(s[i]) } } else b.append(s[i]); i++ }
        i++; return b.toString() }
}
