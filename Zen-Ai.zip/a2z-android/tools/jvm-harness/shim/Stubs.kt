package com.a2z.ai
// Stand-ins for Android-bound classes so pure logic can be compiled and tested on the JVM here.
class FProvider(val id: String, val name: String, val type: String, val base: String, val model: String, val key: String, val extraKeys: List<String> = emptyList()) { val label get() = if (name.startsWith("Zen Ai")) name else (if (name.isNotBlank()) name else type) + " · " + model }
object AgentPolicy {
    private val SECRET = Regex("(?i)(password|passcode|pin|otp|cvv|cvc|token|secret)\\s*[:=]?\\s*\\S+")
    private val DIGITS = Regex("\\d{4,}")
    fun redact(s: String, max: Int = 200): String { var t = SECRET.replace(s, "\$1 ••••"); t = DIGITS.replace(t, "••••"); return if (t.length > max) t.take(max) + "…" else t }
}
