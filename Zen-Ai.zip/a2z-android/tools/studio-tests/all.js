const {chromium}=require('playwright');const fs=require('fs');
(async()=>{const b=await chromium.launch(),p=await b.newPage({viewport:{width:412,height:900}});const errs=[];p.on('pageerror',e=>errs.push(e.message));
await p.goto('file:///home/claude/zyn/a2z-android/app/src/main/assets/a2z.html');await p.waitForTimeout(2500);
await p.evaluate(()=>{window.A2ZAuth=null;location.hash='tools';window.__saved=[];const X=Studio.exp,o=X.save;X.save=function(bl,n){const r=new FileReader();r.onload=()=>window.__saved.push({n,d:r.result.split(',')[1]});r.readAsDataURL(bl)};
 Studio.ai.available=()=>true;window.__plan=null;Studio.ai.plan=function(){return Promise.resolve(window.__plan)}});
const open=async id=>{await p.evaluate(id=>{tool=id;drawTools()},id);await p.waitForTimeout(700);await p.evaluate(()=>document.querySelectorAll('.n-gate').forEach(e=>e.classList.remove('n-gate')))};
const tab=async t=>{await p.evaluate(t=>{const b=[...document.querySelectorAll('.zs-tab')].find(x=>x.textContent.trim().replace(/^[^A-Za-z]+/,'')===t);if(!b)throw new Error('no tab '+t);b.click()},t);await p.waitForTimeout(250)};
const btn=async t=>{await p.evaluate(t=>{const b=[...document.querySelectorAll('.zs-tbody button, .zs-tbody .zs-b')].find(x=>x.textContent.trim()===t);if(!b)throw new Error('no button '+t);b.click()},t);await p.waitForTimeout(1600)};
const flush=async n=>{await p.waitForTimeout(n||1800)};
const R=[];const ok=(n,c,x)=>{R.push((c?'PASS ':'FAIL ')+n+(x?' '+x:''));};
const saved=async()=>{const s=await p.evaluate(()=>{const a=window.__saved;window.__saved=[];return a});s.forEach(f=>fs.writeFileSync('out/'+f.n,Buffer.from(f.d,'base64')));return s.map(f=>f.n)};
const run=async(name,fn)=>{try{await fn()}catch(e){ok(name,false,e.message)}};
// logo
await run('logo',async()=>{await open('logo');ok('logo open',await p.evaluate(()=>!!document.querySelector('.zs-logo svg, .zs-logo .zs-host')));await tab('Export');for(const f of ['PNG','SVG','PDF'])await btn(f);const s=await saved();ok('logo export',s.length>=3,s.join())});
for(const [id,exps] of [['poster',['PNG','JPG','PDF','SVG']],['thumb',['PNG','JPG']],['banner',['PNG','JPG','PDF','SVG']],['icon',['SVG','PNG','PDF']],['brandkit',['PNG','PDF','SVG']]]) await run(id,async()=>{await open(id);ok(id+' open',await p.evaluate(()=>!!document.querySelector('.zs-host svg')));await tab('Export');for(const f of exps)await btn(f);const s=await saved();ok(id+' export',s.length===exps.length,s.join())});
// presentation
await run('presentation',async()=>{await open('presentation');await tab('Export');const names=await p.evaluate(()=>[...document.querySelectorAll('.zs-tbody button')].map(x=>x.textContent.trim()));ok('pres buttons',true,names.join('|'));for(const f of ['PPTX','PDF'])await btn(f);const s=await saved();ok('pres export',s.length>=2,s.join())});
await run('infographic',async()=>{await open('infographic');await tab('Export');const names=await p.evaluate(()=>[...document.querySelectorAll('.zs-tbody button')].map(x=>x.textContent.trim()));ok('info buttons',true,names.join('|'));for(const f of ['PNG','PDF','SVG'])await btn(f);const s=await saved();ok('info export',s.length>=3,s.join())});
// mockup
await run('mockup',async()=>{await open('mockup');await tab('Export');for(const f of ['HTML','CSS','SVG','PNG'])await btn(f);const s=await saved();ok('mockup export',s.length===4,s.join());
 await tab('Screens');await btn('Dashboard');ok('mockup 2 screens',await p.evaluate(()=>document.querySelectorAll('.zm-scr .zm-topnav').length===1));
 await p.evaluate(()=>{window.__plan={device:'phone',primary:'#e11d48',screens:[{name:'Food',components:[{type:'appbar',props:{title:'Foodie'}},{type:'card',props:{title:'Biryani',body:'Spicy',tag:'Hot'}},{type:'nav'}]}]}});await tab('AI');await p.evaluate(()=>{document.querySelector('.zs-tbody textarea').value='food app';});await btn('Design screens with AI');ok('mockup ai',await p.evaluate(()=>/Foodie/.test(document.querySelector('.zm-scr').textContent)))});
// palette
await run('palette',async()=>{await open('palette');await tab('Export');await btn('Save file');await btn('PNG swatches');const s=await saved();ok('palette export',s.length===2,s.join());
 await p.evaluate(()=>{window.__plan={name:'Spa',colors:['#2d4a3e','#8fae9b','#e8dcc4','#c9a27e','#f6f1e7']}});await tab('AI');await p.evaluate(()=>{document.querySelector('.zs-tbody textarea').value='spa'});await btn('Suggest palette with AI');ok('palette ai',await p.evaluate(()=>/2D4A3E/i.test(document.querySelector('.zc-strip').textContent)))});
// hub
await run('hub',async()=>{await open('studio');ok('hub 10 cards',await p.evaluate(()=>document.querySelectorAll('.zh-card').length===10));
 await p.evaluate(()=>document.querySelectorAll('.zh-card')[7].click());await p.waitForTimeout(700);await p.evaluate(()=>document.querySelectorAll('.n-gate').forEach(e=>e.classList.remove('n-gate')));ok('hub opens palette',await p.evaluate(()=>tool==='palette'&&!!document.querySelector('.zs-pal')))});
// projects: save & reopen
await run('project',async()=>{await open('icon');await tab('Library');await p.evaluate(()=>{[...document.querySelectorAll('.zi-grid button')][5].click()});await p.waitForTimeout(300);await flush(2200);
 const idx=await p.evaluate(()=>Studio.proj.list('icon').length);ok('project autosaved',idx===1,idx);await open('studio');const rc=await p.evaluate(()=>document.querySelectorAll('.zh-rc').length);ok('hub recent',rc>=1,rc);
 await p.evaluate(()=>document.querySelector('.zh-rc').click());await p.waitForTimeout(1200);await p.evaluate(()=>document.querySelectorAll('.n-gate').forEach(e=>e.classList.remove('n-gate')));ok('hub recent reopens in tool',await p.evaluate(()=>tool==='icon'&&/icon/i.test(document.querySelector('.zs-pname').textContent)))});
// brand consistency
await run('brand',async()=>{const r=await p.evaluate(()=>{const b=Studio.logoDefaults();b.name='Zenith';b.pal=['#0a1128','#22d3ee','#a5f3fc','#0ea5e9'];const c={person:'A B',role:'CEO',phone:'1',email:'e',web:'w',addr:'x'};return Studio.brandAssets.map(a=>{const d=Studio.brandAsset(a[0],b,c);const s=Studio.toSVG(d);return [a[0],s.includes('Zenith')||/g[34]|avatar|logol|letter/.test(a[0]),Studio.validate(d)?1:0]})});ok('brand assets valid',r.every(x=>x[2]),JSON.stringify(r.filter(x=>!x[2])))});
console.log(R.join('\n'));console.log('errors',JSON.stringify(errs));await b.close()})();
