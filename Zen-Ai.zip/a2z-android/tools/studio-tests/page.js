const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch(),p=await b.newPage({viewport:{width:412,height:860}});const errs=[];p.on('pageerror',e=>errs.push(e.message));p.on('console',m=>{if(m.type()==='error')errs.push('console:'+m.text())});
await p.goto('file:///home/claude/zyn/a2z-android/app/src/main/assets/a2z.html');await p.waitForTimeout(2500);await p.evaluate(()=>{location.hash='tools'});await p.evaluate(()=>{window.A2ZAuth=null});await p.waitForTimeout(100);await p.evaluate(()=>{const b=[...document.querySelectorAll('button')].find(x=>/^\s*Skip/.test(x.textContent));if(b)b.click()});await p.waitForTimeout(800);
const ids=await p.evaluate(()=>ALL.filter(x=>x.cat==='create').map(x=>x.id));console.log('create ids',ids.join(','));
const res={};
for(const id of ['studio','logo','poster','thumb','banner','presentation','infographic','mockup','palette','icon','brandkit','imgen','vidgen','l2l']){
 const r=await p.evaluate(async id=>{try{tool=id;drawTools();await new Promise(r=>setTimeout(r,600));document.querySelectorAll('.n-gate').forEach(e=>e.classList.remove('n-gate'));const b=document.querySelector('.tbody');return b?b.innerHTML.length:-1}catch(e){return 'ERR '+e.message}},id);res[id]=r;
 await p.waitForTimeout(150);await p.screenshot({path:'pg-'+id+'.png'});}
console.log(JSON.stringify(res));console.log('errors',JSON.stringify(errs.slice(0,8)));await b.close()})();
