// usage: node shot.js <toolId> <out.png> [width] [tabs comma list]
const {chromium}=require('playwright');
const A='/home/claude/zyn/a2z-android/app/src/main/assets/';
const files=(process.env.FILES||'studio-core.js,studio-io.js,studio-ui.js,studio-logo.js').split(',');
(async()=>{
const [id,out,wd,tabs]=[process.argv[2],process.argv[3],+(process.argv[4]||420),process.argv[5]||''];
const b=await chromium.launch();const pg=await b.newPage({viewport:{width:wd,height:900},deviceScaleFactor:1});
const errs=[];pg.on('pageerror',e=>errs.push(e.message));pg.on('console',m=>{if(m.type()==='error')errs.push(m.text())});
await pg.setContent('<body style="margin:0;background:#222"><div id=w style="padding:8px"></div></body>');
await pg.evaluate(()=>{window.ALL=[];});
for(const f of files)await pg.addScriptTag({path:A+f});
await pg.evaluate(id=>{Studio.tools[id].run(document.getElementById('w'))},id);
await pg.waitForTimeout(500);
const list=tabs?tabs.split(','):[''];
let i=0;
for(const t of list){ if(t){await pg.evaluate(t=>{const b=[...document.querySelectorAll('.zs-tab')].find(x=>x.textContent.toLowerCase().includes(t.toLowerCase()));if(b)b.click();},t);await pg.waitForTimeout(400);}
 await pg.screenshot({path:out.replace('.png',(list.length>1?'-'+(i++):'')+'.png'),fullPage:true});}
console.log('errors',JSON.stringify(errs));await b.close();})();
