const {chromium}=require('playwright');const fs=require('fs');
const A='/home/claude/zyn/a2z-android/app/src/main/assets/';
(async()=>{
const b=await chromium.launch();const pg=await b.newPage({viewport:{width:420,height:800}});
const errs=[];pg.on('pageerror',e=>errs.push(e.message));pg.on('console',m=>{if(m.type()==='error')errs.push(m.text())});
await pg.setContent('<body style="margin:0"><div id=h style="height:500px"></div></body>');
await pg.addScriptTag({path:A+'studio-core.js'});await pg.addScriptTag({path:A+'studio-io.js'});
const r=await pg.evaluate(async()=>{
 const S=Studio,out={};
 const d=S.newDoc(1280,720,{g:['#1a1a2e','#16213e'],a:135});
 d.els.push(S.el('rect',{x:80,y:80,w:300,h:200,fill:{g:['#ff6b6b','#feca57'],a:45},r:24,shadow:{b:20,y:8,c:'#000'}}));
 d.els.push(S.el('ellipse',{x:500,y:100,w:200,h:200,fill:'#48dbfb',stroke:'#fff',sw:6}));
 d.els.push(S.el('text',{text:'Hello Zen Studio\nSecond line',x:80,y:340,w:900,size:80,fill:'#fff',outline:{c:'#000',w:3}}));
 d.els.push(S.el('path',{d:'M50 4L96 92H4Z',vb:[100,100],x:800,y:300,w:200,h:200,fill:'#1dd1a1'}));
 const png=await S.exp.docRaster(d);out.png=png.size;
 const jpg=await S.exp.docRaster(d,{type:'image/jpeg'});out.jpg=jpg.size;
 const pdf=await S.exp.pdf([{doc:d},{doc:d}]);out.pdf=pdf.size;
 const du=await S.ui.dataUrl(png);
 const d2=S.clone(d);d2.els.push(S.el('image',{href:du,x:900,y:20,w:200,h:120}));
 const pp=await S.exp.pptx([{doc:d,notes:'Speaker note one\nline 2'},{doc:d2,notes:''}],{title:'T'});out.pptx=pp.size;
 const toB=async(bl)=>{const u=await S.exp.u8(bl);let s='';for(let i=0;i<u.length;i+=8192)s+=String.fromCharCode.apply(null,u.subarray(i,i+8192));return btoa(s)};
 out.f={png:await toB(png),pdf:await toB(pdf),pptx:await toB(pp),svg:S.toSVG(d)};
 // editor
 const host=document.getElementById('h');const ed=new S.Editor(host,S.clone(d),{sync:true});
 ed.select(ed.doc.els[0].id);ed.drawNow();out.handles=host.querySelectorAll('[data-h]').length;
 ed.duplicate();out.n=ed.doc.els.length;ed.undo();out.n2=ed.doc.els.length;ed.redo();out.n3=ed.doc.els.length;
 const rc=ed.svg.getBoundingClientRect();out.zoom=ed.zoom;
 // simulate drag of first element
 const e0=ed.doc.els[0],x0=e0.x;
 const mk=(t,x,y)=>new PointerEvent(t,{clientX:x,clientY:y,pointerId:1,bubbles:true,button:0});
 const g=ed.svg.querySelector('[data-id="'+e0.id+'"]');const cx=rc.left+(e0.x+50)*ed.zoom,cy=rc.top+(e0.y+50)*ed.zoom;
 g.dispatchEvent(mk('pointerdown',cx,cy));ed.svg.dispatchEvent(mk('pointermove',cx+40,cy+20));ed.svg.dispatchEvent(mk('pointerup',cx+40,cy+20));
 out.moved=ed.doc.els[0].x-x0;
 // project store
 const rec=await S.proj.create('t','Test',{a:1},'');await S.proj.save(rec.id,{a:2},{version:true});const re=await S.proj.open(rec.id);out.proj=[re.data.a,re.versions.length,S.proj.list('t').length];
 const eb=await S.proj.exportBlob(rec.id);const txt=await eb.text();const imp=await S.proj.importText(txt,['t']);out.imp=imp.name;
 await S.proj.restore(rec.id,0);out.rest=(await S.proj.open(rec.id)).data.a;await S.proj.del(rec.id);out.del=S.proj.list('t').length-1;
 return out;});
fs.writeFileSync('o.png',Buffer.from(r.f.png,'base64'));fs.writeFileSync('o.pdf',Buffer.from(r.f.pdf,'base64'));fs.writeFileSync('o.pptx',Buffer.from(r.f.pptx,'base64'));fs.writeFileSync('o.svg',r.f.svg);
delete r.f;console.log(JSON.stringify(r),errs);await b.close();})();
