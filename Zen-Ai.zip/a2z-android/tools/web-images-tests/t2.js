const puppeteer=require('/opt/npm-tools/node_modules/puppeteer'),fs=require('fs');
const URL_='file:///home/claude/a2z-android/app/src/main/assets/a2z.html';
const land=fs.readFileSync('land.png'),port=fs.readFileSync('port.png');
let res=[];const T=(n,ok,x)=>{res.push((ok?'PASS ':'FAIL ')+n+(x?' :: '+x:''));};
(async()=>{
 const b=await puppeteer.launch({executablePath:'/opt/pw-browsers/chromium-1243/chrome-linux64/chrome',headless:'new',args:['--no-sandbox','--allow-file-access-from-files']});
 const p=await b.newPage();const errs=[],reqs=[];p.on('pageerror',e=>errs.push(e.message));
 let mode={openverse:'ok',commons:'ok',pexels:'ok'};
 await p.setRequestInterception(true);
 p.on('request',r=>{const u=r.url();if(u.startsWith('file:'))return r.continue();reqs.push(u);
  const cors={'access-control-allow-origin':'*'};
  const J=o=>r.respond({status:200,contentType:'application/json',headers:cors,body:JSON.stringify(o)});
  if(u.includes('imgs.test/')){if(u.includes('broken'))return r.respond({status:404,body:''});return r.respond({status:200,contentType:'image/png',headers:cors,body:u.includes('port')?port:land})}
  if(u.startsWith('https://api.openverse.org/v1/images/')){if(mode.openverse==='429')return r.respond({status:429,headers:cors,body:'{}'});
   const q=decodeURIComponent(u.split('q=')[1].split('&')[0]);
   return J({results:[1,2,3].map(i=>({title:q+' photo '+i,thumbnail:'https://imgs.test/ov-'+encodeURIComponent(q)+'-'+i+(i==3?'-broken':'')+'.png',url:'https://orig.test/'+encodeURIComponent(q)+i+'.jpg',creator:'Jane <b>Doe</b>',license:'by-sa',license_version:'4.0',license_url:'https://creativecommons.org/licenses/by-sa/4.0/',foreign_landing_url:'https://flickr.test/p/'+i,source:'flickr',width:1200,height:800}))})}
  if(u.startsWith('https://commons.wikimedia.org/')){return J({query:{pages:{1:{title:'File:Test.jpg',imageinfo:[{thumburl:'https://imgs.test/c-1-port.png',url:'https://upload.test/x.jpg',descriptionurl:'https://commons.wikimedia.org/wiki/File:Test.jpg',mime:'image/jpeg',thumbwidth:500,thumbheight:800,extmetadata:{Artist:{value:'<a href="x">Wiki User</a>'},LicenseShortName:{value:'CC BY 4.0'},LicenseUrl:{value:'https://creativecommons.org/licenses/by/4.0'}}}]}}}})}
  r.abort()});
 await p.goto(URL_,{waitUntil:'domcontentloaded'});await new Promise(r=>setTimeout(r,3000));
 // 1 decide
 const D=await p.evaluate(()=>{const z=ZWI,L='A long informative answer. '.repeat(30);return{
  hi:z.decide('Hi',L).go, auto:z.decide('What is Autonomous AI?',L).go, naruto:z.decide('Show me Naruto and Sasuke','ok').go,
  tanglish:z.decide('oru day fulla sappuda 10 to 15 unakku favorite aana food sollu',L).go,
  code:z.decide('write python code for todo app',L).go, gen:z.decide('generate image of a cat',L).go,
  tamil:z.decide('AI பற்றி சொல்லு',L).go, shortchat:z.decide('how are you today',  'I am fine').go, err:z.decide('What is AI?','Error: no key').go}});
 T('Hi -> no search',D.hi===false);T('What is Autonomous AI? -> search',D.auto===true);T('Show me Naruto and Sasuke -> search',D.naruto===true);
 T('Tanglish food list -> search',D.tanglish===true);T('python code -> no search',D.code===false);T('generate image -> no search (left to generator)',D.gen===false);
 T('Tamil "AI pathi sollu" -> search',D.tamil===true);T('small talk -> no search',D.shortchat===false);T('error answer -> no search',D.err===false);
 // 2 inline flow with headings
 const md1='Autonomous AI agents are systems that plan and act on their own.\n\nThey combine models, memory and tools to finish tasks.\n\n## Autonomous AI Agent\n\nAn agent loops: observe, plan, act.\n\n## AI Agent Architecture\n\nTypical parts: planner, memory, tools.\n\n## Summary\n\nDone.'+' filler text for length'.repeat(20);
 const out=await p.evaluate(async md1=>{const c=newChat();cur=c;if(!chats.includes(c))chats.unshift(c);
  c.messages.push({role:'user',content:'What is Autonomous AI Agents?',ts:1});const m={role:'assistant',content:md1,ts:2};c.messages.push(m);render();
  await ZWI._enrich(c,m,'What is Autonomous AI Agents?');await new Promise(r=>setTimeout(r,1200));
  const md=document.querySelector('.msg.bot .md');const kids=[...md.children].map(x=>x.tagName+(x.classList.contains('zwi')?'.zwi':''));
  return{n:(m.wimg||{}).items&&m.wimg.items.length,kids,cap:[...md.querySelectorAll('figcaption')].map(x=>x.textContent),html:md.querySelector('figure')&&md.querySelector('figure').outerHTML.slice(0,300),items:(m.wimg||{items:[]}).items.map(i=>({t:i.title,c:i.creator,l:i.license,site:i.site,w:i.w,at:i.at}))}},md1);
 T('images inserted',out.n>=2,JSON.stringify(out.kids));
 T('inline between paragraphs (not only at bottom)',out.kids.indexOf('FIGURE.zwi')>=0&&out.kids.indexOf('FIGURE.zwi')<out.kids.length-2,JSON.stringify(out.kids));
 T('creator HTML stripped',out.items.every(i=>!/[<>]/.test(i.c||'')),JSON.stringify(out.items[0]));
 T('license kept as given (not "free")',out.items.some(i=>/CC BY/.test(i.l)),out.items.map(i=>i.l).join(','));
 T('broken image filtered out',!out.items.some(i=>/broken/.test(i.t)));
 // 3 reopen
 const re=await p.evaluate(async()=>{render();await new Promise(r=>setTimeout(r,500));return document.querySelectorAll('.msg.bot .md figure.zwi').length});
 T('history reopen re-draws images',re>=2,String(re));
 // like button keeps working + images persist
 const lk=await p.evaluate(async()=>{const b=document.querySelector('.msg.bot .tl .ib:nth-child(2)');b.click();await new Promise(r=>setTimeout(r,300));return document.querySelectorAll('.msg.bot .md figure.zwi').length+'|'+document.querySelectorAll('.msg.bot .tl .ib').length});
 T('message actions intact after decorate',/^\d+\|\d+$/.test(lk)&&+lk.split('|')[0]>=2&&+lk.split('|')[1]>=4,lk);
 // 4 cache: same question no new API calls
 const before=reqs.filter(u=>u.includes('openverse')||u.includes('commons.wiki')).length;
 await p.evaluate(async()=>{const c=cur;const m={role:'assistant',content:c.messages[1].content,ts:3};c.messages.push(m);await ZWI._enrich(c,m,'What is Autonomous AI Agents?')});
 const after=reqs.filter(u=>u.includes('openverse')||u.includes('commons.wiki')).length;
 T('search results cached (no repeat API calls)',after===before,before+'->'+after);
 // 5 list mode with thumbs
 const lm='Here are favourites:\n\n1. **Chicken Biryani** - rice\n2. **Masala Dosa** - crispy\n3. **Chocolate Cake** - sweet\n4. **Mango Juice** - cold\n\nWhich do you like?'+' x'.repeat(200);
 const l=await p.evaluate(async lm=>{const c=newChat();cur=c;chats.unshift(c);c.messages.push({role:'user',content:'unakku favorite food list sollu',ts:1});const m={role:'assistant',content:lm,ts:2};c.messages.push(m);render();await ZWI._enrich(c,m,'unakku favorite food list sollu');await new Promise(r=>setTimeout(r,800));return{li:document.querySelectorAll('.msg.bot li.zli').length,th:document.querySelectorAll('.msg.bot figure.zt').length,items:(m.wimg?m.wimg.items:[]).map(i=>i.q+'@'+i.at.j),cool:['openverse','pexels','unsplash','commons'].map(x=>x+':'+ZWI._inCool(x))}},lm);
 T('list mode: thumbnail beside each item',l.th>=3,JSON.stringify(l));
 // 6 explicit group
 const g=await p.evaluate(async()=>{const c=newChat();cur=c;chats.unshift(c);c.messages.push({role:'user',content:'Show me Naruto and Sasuke',ts:1});const m={role:'assistant',content:'Naruto Uzumaki and Sasuke Uchiha are rivals and friends in the series.',ts:2};c.messages.push(m);render();await ZWI._enrich(c,m,'Show me Naruto and Sasuke');await new Promise(r=>setTimeout(r,800));return{grp:document.querySelectorAll('.msg.bot .zg figure').length}});
 T('explicit multi-subject -> horizontal group',g.grp>=2,JSON.stringify(g));
 // 7 provider 429 -> cooldown + fallback to commons; text still fine
 mode.openverse='429';
 const f=await p.evaluate(async()=>{localStorage.removeItem('zen_wimg_cache');const c=newChat();cur=c;chats.unshift(c);c.messages.push({role:'user',content:'Tell me about the Eiffel Tower',ts:1});const m={role:'assistant',content:'The Eiffel Tower is a wrought iron lattice tower in Paris. '.repeat(10)+'\n\nSecond paragraph.',ts:2};c.messages.push(m);render();await ZWI._enrich(c,m,'Tell me about the Eiffel Tower');await new Promise(r=>setTimeout(r,500));return{cd:ZWI._inCool('openverse'),sites:(m.wimg?m.wimg.items:[]).map(i=>i.site)}});
 T('429 -> cooldown + fallback provider',f.cd===true&&f.sites.includes('Wikimedia Commons'),JSON.stringify(f));
 // 8 all providers fail -> plain text, no images
 mode.openverse='429';await p.evaluate(()=>{localStorage.removeItem('zen_wimg_cache');const c=ZWI.cfg();c.off=['commons'];localStorage.setItem('zen_wimg_cfg',JSON.stringify(c))});
 const nf=await p.evaluate(async()=>{const c=newChat();cur=c;chats.unshift(c);c.messages.push({role:'user',content:'Tell me about the Louvre museum',ts:1});const m={role:'assistant',content:'The Louvre is a famous museum in Paris. '.repeat(15),ts:2};c.messages.push(m);render();await ZWI._enrich(c,m,'Tell me about the Louvre museum');return{w:!!m.wimg,figs:document.querySelectorAll('.msg.bot figure').length}});
 T('no results -> normal text, no images, no fallback generation',nf.w===false&&nf.figs===0,JSON.stringify(nf));
 // 9 security
 const sec=await p.evaluate(()=>[ZWI.safeUrl('http://a.com/x.jpg'),ZWI.safeUrl('javascript:alert(1)'),ZWI.safeUrl('data:image/png;base64,AAA'),ZWI.safeUrl('https://u:p@a.com/x.jpg'),ZWI.safeUrl('https://localhost/x.jpg'),ZWI.safeUrl('https://192.168.1.2/x.jpg'),ZWI.safeUrl('https://a.com/x.exe'),ZWI.safeUrl('https://a.com/x.jpg'),ZWI.txt('<img src=x onerror=alert(1)>Hello')]);
 T('unsafe URLs rejected, https kept, html stripped',sec.slice(0,7).every(x=>x==='')&&sec[7]==='https://a.com/x.jpg'&&!/[<>]/.test(sec[8]),JSON.stringify(sec));
 // 10 no AI image generation requests at all
 T('no Pollinations/AI-generation request made by feature',!reqs.some(u=>/pollinations|image\.generation|dall|imagen/i.test(u)),reqs.filter(u=>/pollinations/.test(u)).join(','));
 T('all image/API requests are https',reqs.every(u=>u.startsWith('https:')||u.startsWith('data:')),reqs.filter(u=>!u.startsWith('https:')&&!u.startsWith('data:')).slice(0,4).join(','));console.log('REQS',[...new Set(reqs.map(u=>u.split('/')[2]))].join(','));
 T('no page errors',errs.length===0,errs.slice(0,3).join(' | '));
 console.log(res.join('\n'));await b.close()})().catch(e=>{console.log('HARNESS FAIL',e.message);process.exit(1)});
