const puppeteer=require('/opt/npm-tools/node_modules/puppeteer'),fs=require('fs');
const land=fs.readFileSync('land.png');let res=[];const T=(n,ok,x)=>res.push((ok?'PASS ':'FAIL ')+n+(x?' :: '+x:''));
(async()=>{const b=await puppeteer.launch({executablePath:'/opt/pw-browsers/chromium-1243/chrome-linux64/chrome',headless:'new',args:['--no-sandbox','--allow-file-access-from-files']});
const p=await b.newPage();const errs=[],reqs=[];p.on('pageerror',e=>errs.push(e.message));await p.setRequestInterception(true);
p.on('request',r=>{const u=r.url();if(u.startsWith('file:'))return r.continue();reqs.push(u);const cors={'access-control-allow-origin':'*'};
 if(u.includes('imgs.test/'))return r.respond({status:200,contentType:'image/png',headers:cors,body:land});
 if(u.startsWith('https://api.openverse.org')){const q=decodeURIComponent(u.split('q=')[1].split('&')[0]);const rs=[1,2].map(i=>({title:q+' '+i,thumbnail:'https://imgs.test/'+encodeURIComponent(q)+i+'.png',url:'https://o.test/'+encodeURIComponent(q)+i,license:'by',license_version:'4.0',foreign_landing_url:'https://f.test/'+i,source:'flickr',width:1200,height:800}));return r.respond({status:200,contentType:'application/json',headers:cors,body:JSON.stringify({results:rs})})}
 r.abort()});
await p.goto('file:///home/claude/a2z-android/app/src/main/assets/a2z.html',{waitUntil:'domcontentloaded'});await new Promise(r=>setTimeout(r,2500));
const out=await p.evaluate(async()=>{
 P.push({id:'mock1',name:'mock',endpoint:'https://mock.test/v1',model:'m',key:'k',on:true});S.primary='mock1';S.suggest=false;
 const L1='Autonomous AI agents plan and perform tasks on their own, using tools and memory. '.repeat(3);
 const ans={t:''};
 window.callAI=async function(pr,sys,turns,on,sig){on(ans.t,'');return{text:ans.t,think:''}};
 const run=async(u,t)=>{ans.t=t;cur=newChat();chats.unshift(cur);cur.messages.push({role:'user',content:u,ts:1});render();await answer();await new Promise(r=>setTimeout(r,2500));const md=document.querySelector('.msg.bot:last-child .md');return{figs:md?md.querySelectorAll('figure.zwi').length:-1,wimg:!!(cur.messages[cur.messages.length-1].wimg),txt:md?md.textContent.slice(0,40):''}};
 const hi=await run('Hi','Hello! How can I help you today?');
 const info=await run('What is Autonomous AI?',L1+'\n\n## Autonomous AI Agent\n\nThe agent loops over observe, plan and act steps.\n\n## AI Agent Architecture\n\nPlanner, memory and tool modules cooperate.\n\n'+L1);
 const reopen=(()=>{const c=cur;render();return document.querySelectorAll('.msg.bot .md figure.zwi').length})();
 return{hi,info,reopen,stored:JSON.parse(localStorage.getItem('a2z.chats')||'{}').chats?JSON.parse(localStorage.getItem('a2z.chats')).chats[0].messages.some(m=>m.wimg&&m.wimg.items&&m.wimg.items.length):'n/a'}});
T('Hi: no images, text normal',out.hi.figs===0&&!out.hi.wimg,JSON.stringify(out.hi));
T('Informational answer via real answer(): images appear',out.info.figs>=2,JSON.stringify(out.info));
T('metadata stored on the assistant message and persisted',out.info.wimg===true&&out.stored===true,String(out.stored));
T('re-open chat redraws images',out.reopen>=2,String(out.reopen));
T('no page errors',errs.length===0,errs.slice(0,3).join('|'));
console.log(res.join('\n'));await b.close()})().catch(e=>{console.log('HARNESS FAIL',e.message);process.exit(1)});
