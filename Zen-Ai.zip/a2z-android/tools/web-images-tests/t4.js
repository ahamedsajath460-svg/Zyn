const puppeteer=require('/opt/npm-tools/node_modules/puppeteer'),fs=require('fs');
const land=fs.readFileSync('land.png'),port=fs.readFileSync('port.png');
(async()=>{const b=await puppeteer.launch({executablePath:'/opt/pw-browsers/chromium-1243/chrome-linux64/chrome',headless:'new',args:['--no-sandbox','--allow-file-access-from-files']});
const p=await b.newPage();await p.setViewport({width:390,height:844,deviceScaleFactor:2});await p.setRequestInterception(true);
p.on('request',r=>{const u=r.url();if(u.startsWith('file:'))return r.continue();const cors={'access-control-allow-origin':'*'};
 if(u.includes('imgs.test/'))return r.respond({status:200,contentType:'image/png',headers:cors,body:/port/.test(u)?port:land});
 if(u.startsWith('https://api.openverse.org')){const q=decodeURIComponent(u.split('q=')[1].split('&')[0]);const rs=[1,2].map(i=>({title:q+' '+i,thumbnail:'https://imgs.test/'+encodeURIComponent(q)+i+(i==2?'port':'')+'.png',url:'https://o.test/'+encodeURIComponent(q)+i,creator:'Jane Doe',license:'by-sa',license_version:'4.0',license_url:'https://creativecommons.org/licenses/by-sa/4.0/',foreign_landing_url:'https://f.test/'+i,source:'flickr',width:i==2?500:1200,height:i==2?800:750}));return r.respond({status:200,contentType:'application/json',headers:cors,body:JSON.stringify({results:rs})})}
 r.abort()});
await p.goto('file:///home/claude/a2z-android/app/src/main/assets/a2z.html',{waitUntil:'domcontentloaded'});await new Promise(r=>setTimeout(r,2500));
await p.evaluate(async()=>{const c=newChat();cur=c;chats.unshift(c);c.messages.push({role:'user',content:'What is Autonomous AI?',ts:1});
const m={role:'assistant',content:'Autonomous AI agents are intelligent systems that can plan and perform tasks on their own.\n\n## Autonomous AI Agent\n\nThe agent loops over observe, plan and act steps until the goal is reached.\n\n## AI Agent Architecture\n\nA planner, a memory and a set of tools work together.'+' More text.'.repeat(40),ts:2};c.messages.push(m);render();await ZWI._enrich(c,m,'What is Autonomous AI?');await new Promise(r=>setTimeout(r,1500))});
await p.evaluate(()=>{const g=document.getElementById('authgate');if(g)g.style.display='none'});await new Promise(r=>setTimeout(r,300));await p.screenshot({path:'inline.png'});
await p.evaluate(()=>document.querySelector('.msg.bot .zwi .zb').click());await new Promise(r=>setTimeout(r,600));await p.screenshot({path:'viewer.png'});
console.log(await p.evaluate(()=>document.getElementById('zwv').innerText.replace(/\n+/g,' | ')));await b.close()})();
