package com.a2z.ai

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.WindowManager.LayoutParams
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONObject

/**
 * The agent's own command bar: a search-bar style pill at the bottom of the screen, used when the floating panel is NOT running.
 * - Tap it, type a task, send: the task goes to [AgentRunner] (typing happens in the small [AgentInputActivity] so the keyboard works).
 * - While a task runs the pill shows the live status and a Stop button.
 * - Permission requests of the agent ([AgentOverlay.confirm]) appear as a card on the phone screen right above the bar (Allow / Deny).
 * It lives in an accessibility overlay window owned by [AIAccessibilityService], so it needs no extra permission, stays over every app and is
 * never part of what the agent reads. When the floating panel is running, the panel does all of this and the bar is hidden.
 */
object AgentBar {
    private val main = Handler(Looper.getMainLooper())
    private var wm: WindowManager? = null
    private var root: LinearLayout? = null
    private var ctxS: AccessibilityService? = null
    private var attached = false

    private var card: LinearLayout? = null
    private var cardTitle: TextView? = null
    private var cardLines: LinearLayout? = null
    private var pill: LinearLayout? = null
    private var hint: TextView? = null
    private var go: TextView? = null
    private var close: TextView? = null

    @Volatile private var confirmCb: ((Boolean) -> Unit)? = null
    private var confirmTitle = ""
    private var confirmLines: List<String> = emptyList()
    private var resultText: String? = null
    private var resultHide: Runnable? = null
    private var listening = false

    /** The user closed the bar with the X. It comes back when the AI Agent or the Command bar switch is turned on again. */
    @Volatile var barHidden = false

    private fun panelOn() = FloatingPanelController.instance != null
    private fun need(): Boolean =
        !panelOn() && ((AgentController.enabled && AgentController.bar && !barHidden) || AgentController.state != "idle" || confirmCb != null || resultText != null)

    /** Shows or hides the bar to match the current state. Safe from any thread. */
    fun sync() { main.post { try { if (need()) show() else hideNow() } catch (_: Throwable) { } } }

    /** Called when the accessibility service goes away. */
    fun destroy() { main.post { hideNow() } }

    // ------------------------------------------------------------------ window
    private fun dp(c: Context, v: Int) = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), c.resources.displayMetrics).toInt()
    private fun bg(color: Int, r: Float) = GradientDrawable().apply { setColor(color); cornerRadius = r }

    private fun navPad(c: Context): Int {
        val id = c.resources.getIdentifier("navigation_bar_height", "dimen", "android")
        val n = if (id > 0) c.resources.getDimensionPixelSize(id) else 0
        return n + dp(c, 8)
    }

    private fun button(c: Context, label: String, color: String, onTap: () -> Unit): TextView = TextView(c).apply {
        text = label; setTextColor(Color.WHITE); setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f); typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER; background = bg(Color.parseColor(color), dp(c, 20).toFloat())
        setPadding(dp(c, 16), dp(c, 9), dp(c, 16), dp(c, 9)); filterTouchesWhenObscured = true
        setOnClickListener { onTap() }
    }

    private fun build(c: Context): LinearLayout {
        val col = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(c, 10), 0, dp(c, 10), navPad(c)) }

        // permission card
        val cd = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL; background = bg(Color.parseColor("#F2161B26"), dp(c, 18).toFloat())
            setPadding(dp(c, 16), dp(c, 14), dp(c, 16), dp(c, 12)); visibility = View.GONE
        }
        val ct = TextView(c).apply { setTextColor(Color.WHITE); setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f); typeface = Typeface.DEFAULT_BOLD }
        val cl = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(c, 6), 0, dp(c, 10)) }
        val row = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.END }
        val deny = button(c, "Deny", "#3A4254") { answer(false) }
        val allow = button(c, "Allow", "#2E9E6B") { answer(true) }
        row.addView(deny); row.addView(allow, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(c, 10) })
        cd.addView(ct); cd.addView(cl); cd.addView(row)
        col.addView(cd, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(c, 8) })

        // search-bar pill
        val p = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; background = bg(Color.parseColor("#EE161B26"), dp(c, 28).toFloat())
            setPadding(dp(c, 16), dp(c, 8), dp(c, 8), dp(c, 8)); minimumHeight = dp(c, 52)
        }
        val star = TextView(c).apply { text = "\u2726"; setTextColor(Color.parseColor("#8FB4FF")); setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f) }
        val h = TextView(c).apply {
            setTextColor(Color.parseColor("#C9D1E0")); setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f); maxLines = 4; ellipsize = TextUtils.TruncateAt.END
            setPadding(dp(c, 10), 0, dp(c, 8), 0)
        }
        val g = button(c, "Go", "#4C8DFF") { onMainTap() }
        val x = TextView(c).apply {
            text = "\u2715"; setTextColor(Color.parseColor("#8A93A6")); setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f); gravity = Gravity.CENTER
            setPadding(dp(c, 12), dp(c, 8), dp(c, 6), dp(c, 8)); setOnClickListener { barHidden = true; sync() }
        }
        p.addView(star); p.addView(h, LinearLayout.LayoutParams(0, -2, 1f)); p.addView(g); p.addView(x)
        p.setOnClickListener { onPillTap() }
        col.addView(p, LinearLayout.LayoutParams(-1, -2))

        card = cd; cardTitle = ct; cardLines = cl; pill = p; hint = h; go = g; close = x
        return col
    }

    private fun show() {
        val svc = AIAccessibilityService.instance ?: return
        listen()
        if (attached && ctxS === svc && root != null) { render(); return }
        hideNow()
        try {
            val w = svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val r = build(svc)
            val l = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT, LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                LayoutParams.FLAG_NOT_FOCUSABLE or LayoutParams.FLAG_NOT_TOUCH_MODAL or LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT)
                .apply { gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; title = "ZynAgentBar" }
            w.addView(r, l)
            wm = w; root = r; ctxS = svc; attached = true
        } catch (_: Throwable) { attached = false; root = null }
        render()
    }

    private fun hideNow() {
        val r = root
        if (r != null) try { wm?.removeViewImmediate(r) } catch (_: Throwable) { }
        root = null; attached = false; card = null; pill = null; hint = null; go = null; close = null; cardTitle = null; cardLines = null
    }

    // ------------------------------------------------------------------ content
    private fun render() {
        val h = hint ?: return; val g = go ?: return; val x = close ?: return
        val c = root?.context ?: return
        val busy = AgentController.state != "idle"
        val cd = card
        if (cd != null) {
            val waiting = confirmCb != null
            cd.visibility = if (waiting) View.VISIBLE else View.GONE
            if (waiting) {
                cardTitle?.text = confirmTitle
                val l = cardLines; l?.removeAllViews()
                for (s in confirmLines.take(8)) l?.addView(TextView(c).apply { text = s; setTextColor(Color.parseColor("#C9D1E0")); setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f); setPadding(0, dp(c, 2), 0, dp(c, 2)) })
            }
        }
        when {
            busy -> {
                h.text = AgentController.status.ifBlank { "Working\u2026" }; h.setTextColor(Color.WHITE)
                g.text = "Stop"; g.background = bg(Color.parseColor("#E5484D"), dp(c, 20).toFloat()); x.visibility = View.GONE
            }
            resultText != null -> {
                h.text = resultText; h.setTextColor(Color.WHITE)
                g.text = "New"; g.background = bg(Color.parseColor("#4C8DFF"), dp(c, 20).toFloat()); x.visibility = View.VISIBLE
            }
            else -> {
                h.text = "Tell the agent what to do\u2026"; h.setTextColor(Color.parseColor("#C9D1E0"))
                g.text = "Go"; g.background = bg(Color.parseColor("#4C8DFF"), dp(c, 20).toFloat()); x.visibility = View.VISIBLE
            }
        }
    }

    private fun onMainTap() { if (AgentController.state != "idle") AgentController.hardStop("Stopped from the command bar.") else openInput() }
    private fun onPillTap() { if (AgentController.state == "idle") openInput() }

    private fun openInput() {
        val c = ctxS ?: return
        resultText = null; render()
        try { c.startActivity(Intent(c, AgentInputActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION or Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)) } catch (_: Throwable) { }
    }

    /** A task typed in [AgentInputActivity]. Stop / pause phrases work here too. */
    fun submit(text: String) {
        main.post {
            val ctx = AIAccessibilityService.instance
            if (ctx == null) { showResult("Accessibility is not connected. Turn on Zyn Ai Agent in Android Accessibility settings."); return@post }
            resultText = null
            if (AgentController.voiceControl(text).isNotEmpty()) { render(); sync(); return@post }
            val err = AgentRunner.start(ctx, text)
            if (err != null) showResult(err) else { render(); sync() }
        }
    }

    private fun showResult(t: String) {
        resultText = t.trim().take(400).ifBlank { null }
        resultHide?.let { main.removeCallbacks(it) }
        val r = Runnable { resultText = null; render(); sync() }
        resultHide = r; main.postDelayed(r, 12_000)
        sync(); render()
    }

    // ------------------------------------------------------------------ permission card
    /** [cb] gets true only from the user's tap on Allow. Shown on the phone screen, whichever app is open. */
    fun confirm(title: String, lines: List<String>, cb: (Boolean) -> Unit) {
        main.post {
            if (AIAccessibilityService.instance == null) { cb(false); return@post }
            confirmCb?.let { try { it(false) } catch (_: Throwable) { } }
            confirmCb = cb; confirmTitle = title; confirmLines = lines
            show(); render()
        }
    }

    private fun answer(ok: Boolean) {
        val cb = confirmCb; confirmCb = null
        render(); sync()
        try { cb?.invoke(ok) } catch (_: Throwable) { }
    }

    fun hideConfirm() { main.post { confirmCb = null; render(); sync() } }

    private fun listen() {
        if (listening) return
        listening = true
        AgentController.listeners.add { t, d ->
            when (t) {
                "result" -> try { val text = JSONObject(d).optString("text"); main.post { showResult(text) } } catch (_: Throwable) { }
                "state" -> main.post { render(); sync() }
            }
        }
    }
}
