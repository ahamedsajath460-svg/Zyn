# Each account keeps its own data

## What happens now
- Sign in as **A**, chat, then log out and sign in as **B**: B sees only B's chats, settings and files. A new account looks like a first install and the greeting says **Welcome** (with the Google first name). 
- Sign in as **A** again: everything A did is back. Nothing is deleted.
- Same account again (even after logout): nothing changes.

## How (assets/a2z.html)
- New early script `#a2z-acct` (right after `#a2z-boot`): on every account switch it saves the current account's data (all `a2z*` localStorage keys, IndexedDB `a2z` and `a2z_memfiles`) into a private archive (IndexedDB `a2z_accts`, key = e-mail), loads the other account's archive (or nothing = fresh), and reloads the page. Writes from the old page are blocked during the switch so nothing leaks across.
- `loadAll()` waits for that step; the Firebase `onAuthStateChanged` callback calls `__zAcctUser(u)`.
- Kept for all accounts (device-level): Firebase login session and `a2z.lastAcct` (login page hint).
- Greeting: while an account has no chat messages and no `a2z_welcomed` flag, the empty chat shows "Welcome to Zyn Ai, <first name>!".

## Notes
- First run after this update: the existing data is kept for the account that was signed in (or last signed in) on the device.
- Data of all accounts stays on this phone. It is not synced to a server.
- Floating-panel chats not yet imported when you switch are saved into the account that was signed in.
- Not tested on a device (no build here). Logic was tested with a fake storage/IndexedDB: A to B to A to B, a new account, and a start-up mismatch (18 checks).
