# Admin panel setup (Firebase console, one time)
The app saves each user (name, email, photo, joined, last open, opens) to Firestore `users/{uid}` after sign-in. Only the owner email can open Settings > Admin panel.

1. Firebase console > project `own-project-bdeee` > Build > **Firestore Database** > Create database (production mode, pick a region).
2. Firestore > **Rules** tab > replace everything with the rules below > Publish.
3. Open the app, sign in once (this creates your own record), then Settings > Admin panel (the row appears only for the owner email).

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{uid} {
      allow create, update: if request.auth != null
        && request.auth.uid == uid
        && request.resource.data.uid == uid;
      allow read: if request.auth != null
        && request.auth.token.email == 'ahamedsajath160@gmail.com'
        && request.auth.token.email_verified == true;
      allow delete: if false;
    }
  }
}
```
Change the owner email in two places: these rules and `ADMIN` in a2z.html (block "v20").
Without the rules step the panel shows "Permission denied" (safe). Never use `allow read: if true`.
The login screen says that name and email are saved.
