# Advanced Vision 2.0 changes
New: ScreenOcr.kt, NativeTts.kt, HighlightOverlay.kt
Modified: FrameStore.kt, ScreenCaptureService.kt, MainActivity.kt, AndroidManifest.xml (TTS_SERVICE query), app/build.gradle.kts (ML Kit text-recognition + devanagari 16.0.1), assets/a2z.html (Advanced Vision dialog; attach() now sends redacted frames)
NOT built or run-tested (no Android SDK in the authoring sandbox). Build with: gradle assembleDebug

# Agent Control 3.0 (added)
New: AIAccessibilityService.kt, AgentController.kt, AgentRunner.kt (planner+executor), AgentOverlay.kt, res/xml/a2z_accessibility.xml, res/values/strings.xml
Modified: MainActivity.kt (agent bridge), AndroidManifest.xml (accessibility service, launcher <queries>), assets/a2z.html (Agent Control dialog)
No new dependencies or permissions (uses existing SYSTEM_ALERT_WINDOW; BIND_ACCESSIBILITY_SERVICE is on the service only).
NOT compiled or device-tested. No gradle wrapper existed in the original ZIP; use Android Studio or a local gradle.

# Final additions
Gradle wrapper (8.7, same as CI) added: ./gradlew assembleDebug. Settings now has "Agent Control" and "Advanced Vision" rows. Floating panel has Voice, Explain, Pause, Stop, Chat, Minimize.
