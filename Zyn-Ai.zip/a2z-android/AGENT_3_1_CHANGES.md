# Zyn Ai Agent 3.1 – incremental upgrade of Agent Control 3.0

**Status: NOT compiled, NOT run on a device.** The authoring environment had no Android SDK, no Kotlin compiler and no network, so `./gradlew assembleDebug` could not be executed. Everything below was checked by reading and by static consistency scripts only. Build and test it before relying on it.

## What changed
| Area | Change |
|---|---|
| Modes | One `mode` setting: `readonly` / `manual` (default) / `trusted`. Old `readOnly` + `approval` settings are migrated automatically. Trusted runs only find, scroll, scroll-to-edge and back without asking; sensitive actions are always confirmed. |
| Understanding | First model call classifies the request: instruction, question, explain, clarify, unsupported. Questions/explanations are answered from the screen and never touch the UI. Prompts understand English, Tamil and Tanglish ("Settings open pannu"). |
| Clarification | A clarifying question is remembered for 10 minutes so the next command continues the same task. |
| Allowlist | `AgentPolicy.validate` rejects any action not on the list, unknown elements, password fields, bad arguments, and protected installer/permission screens before anything is shown or run. |
| Verification | After every action the accessibility tree is re-read. Results are VERIFIED / UNVERIFIED / FAILED (text fields, Settings and app launches are checked specifically). "Done" adds a warning if anything was unverified. |
| Loop safety | Max steps per task (5/10/15, default 10), identical action on identical screen blocked after 2 tries, stop after 2 failures in a row or 3 no-effect actions. |
| Scrolling | Horizontal scroll (left/right) added where the container supports it. |
| Progress | Task, step n of max, plan queue, completed and failed lists in the app, the control bar and the floating panel. |
| History | New persistent `agent_history.json` (app-private): instruction, start time, mode, plan, actions with verification, errors, final status. No screenshots, screen text, typed text or screen-answer text. Digit runs and password/OTP-like fragments are masked. Can be switched off and cleared. |
| Voice | Stop / Pause / Resume phrases in English, Tamil, Tanglish. Spoken progress, previews and results through native TextToSpeech (Voice Control switch). "Ask about screen (voice)" always explains and never acts. |
| Control bar | Two-row bar: Stop always visible; Start, Ask, Explain, Voice, Pause/Resume, Chat in a scrolling row; mode, accessibility and screen-share status line; minimize. |
| Floating chat panel | New agent row: status line, Start Agent (uses the message box text), Pause/Resume Agent, Stop Agent. |
| Settings | Agent Control dialog: mode, voice language (English/Tamil), max steps, keep-history switch, progress, structured history with Clear, Explain screen, Ask about screen. |

## Files
New: `AgentPolicy.kt`, `AgentHistory.kt`, `AGENT_3_1_CHANGES.md`
Modified: `AgentController.kt`, `AgentRunner.kt`, `AgentOverlay.kt`, `AIAccessibilityService.kt`, `MainActivity.kt`, `FloatingAssistantService.kt`, `assets/a2z.html` (Agent Control script block only), `README.md`
Unchanged: package name, manifest, accessibility XML, Gradle files, all providers/keys/chat/history/OCR/Vision/TTS/STT code.
Permissions added: none. Dependencies added: none.

## Known limitations
- Not compiled or tested (see top). The original 3.0 code was also never compiled; it was reviewed and one likely compile error (smart-cast of a nullable JSON object) was fixed while rewriting the runner.
- Android lets accessibility read only what apps expose. Custom-drawn, game, WebView-canvas and FLAG_SECURE screens may be unreadable; the agent says so instead of guessing.
- Voice approval of actions is intentionally NOT supported: only a real tap on Confirm approves.
- Spoken feedback needs the Zyn Ai activity alive (it owns the TTS engine). If Android destroyed it, text status still shows.
- The agent cannot unlock the phone, read passwords/OTPs, make payments, or use hidden touch input.

## Setup
1. Android Studio (Koala+) → open folder → `./gradlew assembleDebug` → install.
2. Settings → Agent Control → switch AI Agent ON, allow "Display over other apps".
3. Tap "Set up Accessibility" → Android Accessibility settings → Zyn Ai Agent → switch on. (On Android 13+ sideloaded apps: App info → ⋮ → Allow restricted settings first.)
4. Try: "Explain what is on my screen" (no actions), then "Open Settings and find Wi-Fi" (confirm each action).

## Test checklist
Existing: chat, providers/keys, chat history, screen share, Vision 2.0/OCR, voice input, TTS, floating bubble. New: each mode, Tamil command, stop/pause/resume by voice, loop block, history clear, permission-off behaviour.
