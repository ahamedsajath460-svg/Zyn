# Zyn Ai Agent 4.0: gesture control upgrade. Build and test report

## Actual build / test status (read first)
- **Release APK: NOT built.** The authoring environment has no Android SDK, no Kotlin compiler, no Gradle distribution and no network. No APK is delivered.
- **Kotlin code: NOT compiled.** All new Kotlin was written and read carefully, but compile errors cannot be ruled out.
- **Unit tests: written, NOT run.** `app/src/test/.../AgentActionsTest.kt`. Run `./gradlew testDebugUnitTest`.
- **Instrumentation / on-device tests: none exist, none run.** No gesture was executed on a real phone.
- The web part (`a2z.html`) was syntax-checked with Node and the Settings pages were run in headless Chromium with a mocked Android bridge. That does not cover the agent.
- To get the APK: push the project to GitHub and run the existing release workflow (it also reports compile errors), or `./gradlew assembleRelease` in Android Studio.

## Implemented (in code, untested on device)
| Request | What was done |
|---|---|
| Real gestures with dispatchGesture() | New `AgentGestures.kt`: tap, double-tap, long-press, swipe, drag (hold then move, continued stroke), full-screen scroll. Blocks until Android confirms completion, 4 s timeout. `canPerformGestures="true"` added to the accessibility XML; description text updated. `gestureCapable()` checks Android really granted it. |
| Node-tree + OCR + coordinates + screenshot | Unchanged tree/OCR/frame pipeline. Gesture actions use an element id (centre of its bounds) or, ONLY when an authorised screenshot is attached to a vision-capable model, 0-1000 coordinates converted to pixels. Click falls back to a touch gesture if the node click is unavailable. Password fields are never touched (checked on elements and on coordinates). |
| Selected provider / model, no new key system | Unchanged: uses the first provider from the existing store. No keys added, logged or hardcoded. |
| Capabilities | Existing `FloatVision` name-based check (no provider offers a reliable capability API). Text-only models get no image, no coordinates, and a prompt saying so. |
| Provider adapters | New `AgentActions.kt`: handles markdown fences, prose around JSON, flat / nested / tool-call shapes, alias names (tap, type, scroll_down...), string ids. Output is validated by `AgentPolicy.validate` (allowlist, ranges, element existence, password, protected screens). |
| Multi-step loop | Existing plan, observe, act, re-read, verify loop kept. New: recoverable errors (network, 429, 5xx, timeout) retried twice, 90 s limit per AI call, "next action" shown. |
| Modes | Manual, **Supervised (new)**, Restricted Automation (the old Trusted, renamed), Read-only. Supervised: plan approved once, then only consequential actions ask. Consequential = payments, sending, deleting, security words in the target, payment/deletion words anywhere on screen, typing, opening apps, and any coordinate-only touch. |
| Safety | Never bypasses lock screen, passwords, CAPTCHA, consent or permission dialogs (installer/permission screens blocked). Only a real tap on Confirm approves. |
| Overlay | Info line now shows mode, Accessibility, Gestures, Overlay, Screen share and "Next:"; new Accessibility settings button. Start / Pause / Resume / Stop / current action / progress / Confirm-Cancel card already existed. |
| Duplicate prevention, lifecycle | Existing loop guard now includes coordinates. Accessibility off = hard stop. |

## Modified files
New: `AgentGestures.kt`, `AgentActions.kt`, `app/src/test/java/com/a2z/ai/AgentActionsTest.kt`, this report.
Modified: `AIAccessibilityService.kt`, `AgentController.kt`, `AgentPolicy.kt`, `AgentRunner.kt`, `AgentOverlay.kt`, `res/xml/a2z_accessibility.xml`, `res/values/strings.xml`, `app/build.gradle.kts` (test deps only), `assets/a2z.html` (mode option, Next line).
Earlier this session: `MainActivity.kt` (real permission bridge), `a2z.html` (Permissions, Theme, Font).

## Permissions
No new manifest permission. Needed: Accessibility service (user enables it; now includes gesture capability, so an already-enabled service must be switched off and on once), Display over other apps, Screen sharing (MediaProjection, asked each time) for screenshots, Notifications (optional).

## Known limitations
- Nothing here was run on a device. Treat every item as unverified.
- Drag/long-press behaviour varies by app; apps that block accessibility gestures (banking, FLAG_SECURE) will fail or show nothing.
- "Detect actual model capabilities" is name-based; custom/unknown models are tried and the API error is shown.
- Media Projection permission cannot be granted from the overlay; it is started from the app (Android requires an Activity dialog).
- Multi-finger gestures (pinch) and keyboard-key input are not implemented.
