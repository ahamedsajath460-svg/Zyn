# Zyn AI now knows ALL app features (full features list added to its prompt)

File: `app/src/main/assets/a2z.html` (script block with `window.A2Z_FULL`, `window.A2Z_HOW`, `const GUIDE`). No Kotlin change.

## What was missing (found by comparing the old list with the code and the *_CHANGES.md files)
Settings home (Profile, Billing, Capabilities, Connectors, Permissions, Theme, Font style, Voice, Agent Control, Advanced Vision, Floating panel, Haptic, Notifications, Time & focus, Privacy, Sharing, Log out), email/Google login and per-account data, premium themes + fonts + app icons, Data saver, Thinking (auto-think, depth),
smart search planner and Photo + AI search, AI Lab / Creative / Developer tools (PDF reader, Instagram search, Image & Video to Link, Website builder ...), Memory page + memory files, Backup / Restore (now under Sharing),
floating panel (4 modes, Panel features switches, drag-to-X, Sources sheet), Ask screen pencil, Voice conversation, AI Agent (modes, Command bar, Fast agent, touch indicator, install wait), Advanced Vision, home widget, Quick Settings tile.

## What changed
- `A2Z_FULL`: 14 new feature lines + updated Floating assistant / Memory / Appearance lines; HOW TO BACK UP now points to Settings > Sharing.
- `A2Z_HOW`: more trigger words (agent, panel, pencil, widget, login, account, permission, privacy, vision, think, font ...) so the full list is sent when the user asks about them.
- `GUIDE`: no longer says "ONLY from this guide" and no longer says Settings has only 6 tabs (it lists the real Settings page).
- The floating panel Chat mode gets the same text automatically (`parts.core` = A2Z_CORE + A2Z_FULL); it reaches the panel after the next app settings save / when the app goes to background, so reopen the panel.
- Ask screen / Explain / Agent prompts are NOT changed (their output format is strict).

## Checked
All 74 script blocks pass `node --check`; A2Z_FULL builds (about 16.7 KB). Not run on a device.
