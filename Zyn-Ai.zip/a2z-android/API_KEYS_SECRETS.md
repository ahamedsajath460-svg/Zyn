# Built-in API keys (GitHub Secrets)

The app works right after the first open without the user adding a key. The keys are added at build time by `.github/workflows/release-apk.yml` (step "Add built-in API keys from secrets") and are never stored in the repository.

GitHub repo → Settings → Secrets and variables → Actions → New repository secret. Add one secret per key (empty ones are skipped):

| Secret name | Count | Used for |
|---|---|---|
| `POLLINATIONS_KEY_1` … `POLLINATIONS_KEY_4` | 4 | Text chat and image generation |
| `GEMINI_KEY_1` … `GEMINI_KEY_4` | 4 | Chat, screen sharing, screen understanding, live screen assistance, AI screen control |
| `TAVILY_KEY_1` … `TAVILY_KEY_2` | 2 | Web search and research |
| `AI_KEYS` (old, optional) | – | Extra keys, one per line, optionally `provider:key` |

How the app uses them:
- Every Pollinations key becomes a text provider **and** an image provider; every Gemini key becomes a Gemini provider. If one key hits a limit, the next one answers automatically (existing fallback order). The user's own providers stay first.
- Tavily keys are tried in turn (rotating start); if one fails or is out of quota, the next is used, then DuckDuckGo/Wikipedia.
- The floating assistant and the AI agent use the same providers.
- Built-in keys are left out of backups and replaced by `[redacted key]` when a chat is shared.

Note: keys inside an APK can be extracted by someone who tears the APK apart. Use keys with usage limits.

## Who can see the built-in keys (v21)
- The built-in keys (from GitHub Secrets) are shown **only** when the signed-in account is the admin e-mail (`ZADMIN` in `a2z.html`, currently ahamedsajath160@gmail.com) and that e-mail is verified (Google sign-in is always verified).
- Every other account: the app still works with the built-in keys, but they are never listed or shown anywhere: not in AI providers, My API Keys, Test all, Billing, provider pickers, "copy key from another provider", the title menu, the line under the app name, or under the messages (the floating panel too). They only see a neutral "Zyn Ai".
- Keys a user adds themselves are always shown to that user (header, under messages, providers).
- Change the admin e-mail in two places: `ZADMIN` in `a2z.html` and the Firestore rules (ADMIN_PANEL_SETUP.md).
