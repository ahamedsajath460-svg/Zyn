# Ask screen pencil (draw on the screen, then ask about the marked area)

## How it works for the user
1. In the floating panel, **long-press "Ask screen"**. (Android asks for screen-capture consent once if it is not running.)
2. A transparent drawing layer covers the phone screen and the button shows a pencil mark. The tool menu opens **above the button**:
   Pen, Marker, Highlighter, Box, Eraser, 6 colours, Undo, Clear, **Close pencil** (= disable).
3. Long-press "Ask screen" again at any time (while the pencil is on) to reopen the menu. A short tap just selects the mode.
4. Draw on the real screen, then type the question in the panel box and send.
   The AI answers about the marked area only.
5. **Close pencil** removes the layer and the strokes.

## What the AI receives (focus on the marked area)
- Image 1: full screenshot with the strokes painted on it (where).
- Image 2: clean close-up of the marked area, without strokes (readable small text). Skipped when the marking covers most of the screen.
- Text: where the marking is (percent of width / height), rules to answer only about the marked area, and on-device OCR of the lines under the marking
  (hidden-sensitive lines stay hidden). With a text-only model no image is sent and the OCR text is used instead.
- The strokes are hidden while the screenshot is taken, so the close-up and the OCR are clean.
- Nothing is marked -> Ask screen works as before (AgentRunner "ask").

## Files
- NEW `ScreenPencil.kt`: overlay window + vector strokes (pen / marker / highlighter / box / vector eraser / undo / clear), bounds, `render()` reused to paint the strokes on the screenshot.
- `FloatingPanelController.kt`: pencil lifecycle (`pencilStart/activatePencil/pencilStop/raiseHost`), marked question (`markedAsk/startMarkedCapture/onMarkShot/sendMarked/markedText/markFail`),
  bridge: `pencilOn/pencilOff/pencilTool/pencilUndo/pencilClear/pencilState/askMarked`, event `pencil`, boot state.
  The panel window is re-added on top of the drawing layer so its buttons stay tappable. Starting the Agent turns the pencil off (the layer would swallow the agent's taps).
- `zyn_float_panel.html`: long-press on the Ask screen button, pencil menu (above the button), button marker, placeholder text, `askMarked` on send.

## Notes
- Rotating the phone clears the strokes (they would no longer line up).
- Stop while the marked screenshot is being prepared cancels it.
- NOT built on-device here (no Android SDK in the authoring sandbox). Build with `./gradlew assembleDebug`.
  The panel page itself was run in a headless browser with a stub bridge (long-press, menu, tools, send path: no JS errors).
