# Zyn AI Autonomous Assistant: Agent Control 4.0 + Advanced Vision 2.0, linked

## Build / test status (read first)
- **Kotlin NOT compiled, tests NOT run, nothing run on a device.** The authoring environment has no Kotlin compiler or Android SDK. Run `./gradlew testDebugUnitTest` then `./gradlew assembleDebug`.
- `a2z.html` was syntax-checked with Node and the Agent Control / Advanced Vision pages were rendered in headless Chromium with a mocked Android bridge.
- While reading AgentRunner.kt a compile error from Agent 4.0 was found and fixed: `describe()` used `item`, which is not in scope there. It now uses the action's own `x` field.

## What the link does (only when Screen Understanding is on and screen share is running; otherwise the agent behaves exactly as before)
| Goal | Implementation |
|---|---|
| Real-time screen understanding | `AgentVision.observe()`: newest redacted frame + on-device OCR as one object (text, lines with boxes). The agent prompt now also gets "OCR LINES" with positions on a 0-1000 grid. |
| Live screen monitoring | `FrameStore.lastAt` + `AgentVision.settle()`: after each action wait until the accessibility tree is unchanged for two reads and a newer frame exists (max 2.8 s), instead of a fixed 0.9 s sleep. While a task runs, `FrameStore.autoOcr` is switched on (and restored after) so changed screens are OCR'd on the device. |
| Vision-to-action | New action `tap_text`: the app finds the exact text on a fresh screenshot OCR (sensitive lines already removed), converts pixels to screen coordinates and touches its centre with the existing gesture code. Allowed only with live OCR, never on password fields, never on the Zyn Ai app, always asks for confirmation (coordinate-only touch). |
| Automatic result verification | Order: accessibility tree change -> screenshot change (`visualVerdict`) -> one optional AI screen check (`aiCheck`, only when still unsure and the step had an "expect"). Messages say which check confirmed it. |
| Error recovery | After a failed or unverified step the history line gets a `RECOVERY:` hint (`AgentVision.recoveryHint`): unexpected app/dialog, cannot scroll, element unusable, nothing changed. Existing limits are unchanged (2 failures, 3 no-effect, step limit, loop guard, AI retries). |
| Seamless Vision <-> Agent | Agent Control shows an "Autonomous Assistant" block (Agent / Accessibility / Overlay / Vision chips, live counters, one button for the next missing setup step). Advanced Vision: Live tab shows the agent link, Ask tab has "Do it with Agent", Highlight regions have "Tap this with the agent". Floating bar info line shows "Vision link". |

## New settings (Agent Control, all default ON, saved with the existing agent config)
`visionVerify`, `aiVerify`, `recovery`, `monitor`.

## Files
New: `AgentVision.kt`, this file. Modified: `AgentRunner.kt`, `AgentPolicy.kt`, `AgentActions.kt`, `AgentController.kt`, `AgentOverlay.kt`, `FrameStore.kt`, `app/src/test/.../AgentActionsTest.kt`, `assets/a2z.html`.
No new permission, dependency or API key. Existing screens and settings are unchanged; the new switches and the block are added to the Agent Control page. One CSS fix: the voice-orb rule `.vb` also styled the status badges in Agent Control and Advanced Vision (blurred blob); they are plain pills again.

## Limits
- Screenshot verification compares with the previous OCR run; returning to a recently seen screen can read as "unchanged" (the accessibility check still covers it).
- OCR on device is Latin + Devanagari only; Tamil/Sinhala text is not found by `tap_text`.
- Frames are only streamed while another app is in front, and not at all in the floating panel's one-screenshot mode.
- An AI screen check is the model's judgement and is labelled as such.
