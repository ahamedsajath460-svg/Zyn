# ChatGPT-style automatic chat titles

File: `app/src/main/assets/a2z.html` (new script `zyn-titles` + hooks in `send()`, `answer()` and the 4 rename handlers).

- New chat: an instant local title (no API, no waiting) from the first meaningful message (greetings are skipped).
  Greeting-only chats are called "Friendly Conversation" (then Friendly Chat, Casual Conversation ...).
- After the first answer: an AI title (3-7 words, Title Case, English / Tamil / Tanglish aware, full conversation context).
  Runs after the reply, never delays it. Generic answers (Greeting, New Chat, Chat 1 ...) are rejected and replaced by the local title.
- Chat started with small talk: re-titled automatically from the first meaningful message.
- Renaming a chat sets `tsrc='user'`; titles of renamed chats are never overwritten.
- Chat fields saved with the history: `tsrc` (local | ai | user | keep), `tlow`, `tv` (migration version).
- Migration: old chats titled Greeting / New chat / Chat N / Floating chat or just their first 40 characters are renamed once.
  Other old titles are kept (`tsrc='keep'`). The old clean-up that trimmed long titles is skipped.
- Setting "AI title" off still gives local titles.
