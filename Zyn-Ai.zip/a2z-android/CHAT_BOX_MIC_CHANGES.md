# Chat box size + mic bar

- **Chat box** is one compact row whenever the keyboard is closed. The app now asks Android whether the keyboard is really open (`MainActivity.watchKeyboard` -> `window.__zynKb(true/false)`), so the big two-row box can no longer stay on after the keyboard is closed. In a browser (Chrome) the visual viewport is used instead (more than 120 px shorter = keyboard open). The old "learned base height" guess was removed.
- **Mic bar** opens from the mic side (right) towards the left (`zrecin` animation).
- **Waves** follow your voice: `NativeSpeech.onRmsChanged` sends the mic level (`rms`, max every 60 ms) to JS; new samples enter on the right (next to the mic) and move left. If the speech service gives no level, a quiet idle wave is shown. In a browser (no native level) only the idle wave is shown.
- Not compiled with the Android SDK here. JS parts tested in headless Chromium.
