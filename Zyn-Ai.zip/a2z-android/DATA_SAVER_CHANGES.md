# Data saver (less mobile data, faster replies)

Setting: Settings > Chat > "Data saver". Default is Auto: Max saver on mobile data, Balanced on Wi-Fi. Off restores the old behaviour.

What it does
- Chat history: instead of re-sending up to 400,000 characters every message, older messages are trimmed (the last 2 messages are always sent in full). Balanced keeps about 90k characters, Max about 24k. Measured on a long test chat: 166,046 characters down to about 47k (Balanced) and about 15k (Max).
- Pictures in older messages are not re-uploaded (Balanced keeps them for 4 messages, Max for 2). Attached pictures use a smaller size and JPEG quality (Max: 512 px).
- "Other chats" memory block added to every request is capped (6,000 / 2,500 characters).
- Searches, page reads, weather, maps and similar lookups are cached for 10 minutes, so repeating them uses no data and answers instantly.
- Web picture search no longer downloads whole pages just to find the preview image; only the page head is read, then the connection is closed.
- Generated pictures are requested smaller (Balanced 75%, Max 60% of the size).
- Connections to your AI providers are opened early (faster first word).
- Screen sharing on mobile data: frames are about 35% smaller (short side 576 px, JPEG quality up to 62).

Files: app/src/main/assets/datasave.js (new), a2z.html (script include, settings row, picture-search change), NetInfo.kt (new), MainActivity.kt (A2ZNative.metered), ScreenCaptureService.kt, AndroidManifest.xml (ACCESS_NETWORK_STATE).
