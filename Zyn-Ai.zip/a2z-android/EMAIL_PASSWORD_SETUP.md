# Email + Password login (replaces the old email one-time-code login)

The app uses plain Firebase Authentication. There is **no custom backend, no Cloud Function and no code step** any more (`firebase-otp/` and `EMAIL_OTP_SETUP.md` were deleted, `otpEnabled` / `otpEndpoint` removed from `firebase-config.js`).

## One-time setup (required, otherwise sign-up shows "Email/password sign-in is not enabled")
1. Firebase console > Authentication > Sign-in method > **Email/Password** > Enable > Save. (Leave "Email link" off.)
2. Authentication > Settings > Authorized domains: keep your domain / `localhost` as before. The Android app needs nothing else.
3. Optional: Authentication > Templates to edit the verification and password-reset emails. Firebase sends them; you deploy nothing.
4. Google login is unchanged.

## What the user sees
- **Sign in** tab: email, password (Show/Hide), Sign in, Forgot password.
- **Create account** tab: optional name, email, password (min 8 characters), confirm password.
- After registering, a verification link is emailed. Using the app is **not** blocked until it is verified (change this in `emailSignUp` if you want to block).
- Forgot password: type the email, tap the link, Firebase mails a reset link. The message is the same whether or not the account exists.
- Errors are shown in plain words: wrong email or password, email already in use, weak password, too many attempts, network error.

## Notes
- Passwords are never stored by the app; Firebase handles hashing, rate limiting and sessions. The session persists like Google login (30-day "last signed in" hint, log-out dialog unchanged).
- Users who registered earlier with the old email-code login have no password: they tap "Forgot password?" once to set one (same email).
- Not tested against the real Firebase project (no network here). The UI and glue code were tested with a faked Firebase SDK.
