# Firebase Google sign-in setup (package com.a2z.ai)
1. Edit `app/src/main/assets/firebase-config.js` with your Firebase Web App config + `webClientId`.
2. Firebase console > Authentication > Sign-in method > enable **Google**.
3. Get the signing fingerprints: `./gradlew :app:signingReport` (debug) or `keytool -list -v -keystore <your.jks>` (release).
4. Firebase console > Project settings > Your apps > **Add app > Android**, package `com.a2z.ai`, add the **SHA-1 and SHA-256** (debug and release). Add every signing key you use.
5. Authentication > Settings > Authorized domains: add the domain you open the web preview from (localhost is allowed by default).
6. If your API key has HTTP-referrer restrictions, allow `https://appassets.androidplatform.net/*` (the APK page origin) and your web-preview origin.
No google-services.json or Gradle Google-services plugin is needed: the APK gets a Google ID token natively and signs in to Firebase with it.
