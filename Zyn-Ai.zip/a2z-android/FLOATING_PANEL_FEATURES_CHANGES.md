# Floating panel: full chat features + on/off switches

**Settings > Floating panel > Panel features** (new separate page, same style as the other settings pages). Every switch applies to all panel modes.

| Group | Switches |
|---|---|
| Modes | Chat, Ask screen, Agent, Explain screen |
| Chat features | Web search, Search automatically, Search on every message, Deep thinking, Personality, My instructions, Memory, Other chats, App skills, Live typing, Backup providers |
| Input / output | Attachments, Voice input, Read aloud, Read answers automatically |
| Screen and chats | Screen share, Chat history, Find in chat, Retry and copy, Save panel chats in the app |

## How it works
- `a2z.html`: `FPXG` / `FPX()` / `floatFeaturesPage()`; switches live in `S.fpx` (saved by `saveCore`). `snap()` now also syncs `parts` (owner, persona, instructions, memory, profile, chat index, app skills), `fpx` and `ws` (search engine, max results, snippet length, recency, Tavily keys; memory only).
- `FloatStore`: keeps `fpx`, `parts`, `ws`; `composeSystem()` builds the chat prompt from the switches; `agentContext()` adds persona / instructions / memory to Ask, Explain and Agent prompts without changing their output format.
- `FloatSearch.kt` (new): the panel's web search (Tavily keys, then Wikipedia), same auto rule as the app chat. Runs before the request when the question needs it.
- `FloatingPanelController`: streaming and backup-provider switches; every bridge call is gated by its switch (turned-off feature shows a clear message). New bridge `feat()` and `openFeatures()`.
- `zyn_float_panel.html`: hides mode buttons, mic, attach, history, find, read-aloud and retry/copy per switch; auto read-aloud; "Panel features" row in the panel menu opens the page in the app (`MainActivity` extra `a2z_panel_features`).
- Switches reach the panel when the app syncs (every settings save, and when the app goes to the background). Reopen the panel to refresh.

## Not verified
Kotlin was not compiled here (no Android SDK); the HTML/JS parse cleanly and brackets balance. Build with `./gradlew assembleDebug` or the GitHub Actions workflow and test on a device.

## Drag to X to close (bubble)
- While you drag the bubble, a dark circle with an X appears at the bottom centre (a separate non-touchable overlay window, drawn under the bubble). It grows when the bubble is over it; dropping the bubble there closes the floating assistant.
- Switch: Panel features > Bubble > "Drag to X to close" (key `dragclose`, on by default).
- Code: `FloatingPanelController` (`addTarget`, `xShow`, `xUpdate`, `endBubbleDrag`). Not compiled or tested on a device.

## Ask screen reads the screen UNDER the panel (not the panel itself)
- Problem: while you type in the panel it takes keyboard focus and becomes Android's "active window", so `rootInActiveWindow` returned the panel (com.a2z.ai) and Ask screen described itself.
- Fix: `AIAccessibilityService.pickRoot()` uses the window list and takes the top-most application window that is not the panel. The panel window is titled `ZynFloatPanel` and its close target `ZynFloatX` (set in `FloatingPanelController`). The lock screen still wins and is never read past. Falls back to `rootInActiveWindow` if the window list is not available.
- `a2z_accessibility.xml`: added `flagRetrieveInteractiveWindows`. After installing the update, turn the Zyn Ai accessibility service off and on once so Android applies the new flag.
- Limit: live screen share frames (screenshots/OCR) still show whatever is on screen, including the panel if it overlaps. The one-tap "Capture" hides the panel first.
- Not compiled or tested on a device.

## Agent: wait for install / download to finish
- Problem: for "install this app" the agent saw Play Store show "Pending..." and finished with "I can't confirm yet".
- Fix (`AgentRunner`): when the model says `done`, the task is install/download/update-like and the screen still shows Pending / Downloading / Installing / Waiting / Queued / Updating, the agent now waits (checks every 4 s, up to 90 s), then reads the new screen and continues. If it is still in progress after 90 s, the result says so.
- Not compiled or tested on a device.

## Bubble: no more square patch behind the circle
- Cause: the bubble window is exactly the circle (56dp), but the circle had an outer `box-shadow`, a `backdrop-filter` blur and a 1.06x zoom while dragging. Anything outside the window is cut off, so the shadow showed as a darker square around the circle.
- Fix (`zyn_float_panel.html`, native integration CSS): no outer shadow, no blur, no drag zoom; depth now comes from an inset shadow inside the circle. Same size, similar colour.
- Checked by rendering the old and new CSS in a clipped 56px window in a headless browser (old reproduced the square, new is a clean circle). Not tested on the phone.

## Close / open panel: no stray logo flying to the bubble
- What the video showed: closing the panel resized the window to bubble size at once while the page still drew the panel layout, so only the top-left corner (the Zyn logo square) was visible and it slid across the screen to the edge before the bubble appeared. Opening had the same half-switched frame.
- Fix: `FloatingPanelController.cloak()` hides the overlay (alpha 0) when opening or closing, and `uncloak()` fades it back in once the page reports `shown()` (called after two animation frames in `setMode`). A 350 ms timer shows it anyway if the page never answers.
- Not tested on the phone (the frame timing was read from your recording).

## Fast agent (screen control speed)
Switch: Panel features > Agent speed > "Fast agent" (key `fastagent`, on by default).
- **No AI call for one-action commands** ("open whatsapp", "whatsapp open pannu", "home", "back", "notifications", "open settings"): the action is built locally and still goes through the normal approval, validation and verification, then the task finishes at once. Anything longer ("open chrome and search cats") goes to the AI as before.
- **No separate planning call** in Auto / Trusted mode (the step loop plans as it goes). Manual / Supervised still show the plan preview, so that call stays there.
- **Faster wait after each action**: polls every 120 ms instead of 350 ms, at most 1.6 s instead of 2.8 s, and does not wait for a new screen-share frame. A screen that is still unchanged gets 0.9 s to start changing, so slow app launches are not reported as "no change".
- **Lighter prompts**: when the accessibility tree already lists the screen (4+ items), the screenshot and OCR are not attached for that step.
- **No extra AI "did it work?" call** after an unverified action; the next step sees "UNVERIFIED" and decides.
- Still slow by nature: each AI step takes as long as the chosen provider answers (free providers can take several seconds), and Manual mode waits for your taps. Not tested on a device.

## Agent without the floating panel: Command bar + permission card on the phone screen
- **Running the agent no longer starts the floating panel.** (`AgentOverlay.showBar` used to start the panel service; it now only reports to the panel if it is already running.)
- **Command bar** (new `AgentBar.kt`): when the AI Agent is on and the floating panel is NOT running, a search-bar style pill sits at the bottom of the screen over every app. Tap it, type a task, press Go: the agent does it. While a task runs the pill shows the live status and a Stop button; the result shows for about 12 seconds. The X hides it; it returns when the AI Agent or Command bar switch is turned on again.
- **Typing** happens in the small see-through `AgentInputActivity` (an overlay window cannot reliably take the keyboard). Send closes it first, so the agent reads the app that was open before.
- **Permission questions on the phone screen:** when the panel is not running, `AgentOverlay.confirm` shows an Allow / Deny card right above the bar (no panel, no app needed). Only a tap on Allow approves; the buttons ignore touches when another window covers them.
- The bar lives in an accessibility overlay window owned by the accessibility service: no extra permission, and it is never part of what the agent reads. When the floating panel starts it takes over (the bar hides); when the panel stops the bar comes back.
- Switch: Settings > Agent Control > "Command bar" (key `bar`, on by default).
- Not compiled or tested on a device. The "Display over other apps" permission is still required to start a task (unchanged).

## Voice conversation (orange waveform button)
- New orange waveform button in the panel's input row, right after the mic (like ChatGPT's voice button). Tap it: it listens, you talk, your words are sent automatically, the answer is read aloud, then it listens again, until you tap the button again.
- Works in Chat, Ask screen and Agent modes (it uses the normal send, so the agent's result is spoken too).
- Say "stop", "exit", "bye", "nillu" or "mudinjidhu" to end it. It also ends after 4 silent tries in a row, on any error, or when the panel is minimized or closed.
- Tap the button while it is speaking to interrupt and talk at once.
- Reading aloud works even when the "Read aloud" switch is off; the voice conversation has its own switch: Panel features > Input and output > "Voice conversation" (key `live`, on by default; it needs "Voice input" on too).
- The language for listening and speaking is the one set in Agent Control (default en-US).
- Checked: JS syntax and a simulated run of the state machine (start, send, speak, listen again, stop phrase, silence limit, failed reply). Not tested on a phone with the real speech services.

## Voice conversation v2: closer to real time (no extra API)
- **Speaks while the answer is still being written.** Every finished sentence is queued to the voice at once (`NativeTts.append`, no flush), so you hear the first sentence about as soon as the AI has written it, not after the whole answer. The listening starts again only after the answer is complete and the voice has finished.
- **Sends the moment you pause.** The panel watches the live words; after about 1 second without new words it stops the recognizer and sends. The recognizer is also asked for shorter end-of-speech times (`NativeSpeech.start(lang, fast)`; some speech services ignore this).
- **Spoken-style answers.** In a voice conversation the prompt asks for 1 to 3 short natural sentences, no markdown or lists, and skips the long app-skills text and "thinking" mode, so the first words arrive sooner. Streaming is forced on in this mode even if "Live typing" is off.
- **Interrupt:** tap the orange button while it thinks or talks: generation and speech stop and it listens to you at once.
- Checked with a simulated run (pause detection, sentence splitting, no early listening, interrupt, errors). Not tested with the real speech services on a phone.
- Still not true speech-to-speech like ChatGPT's voice: you cannot interrupt by just talking (the phone would hear the AI's own voice), and the voice is the phone's Text-to-speech. That needs a realtime audio API (for example Gemini Live or OpenAI Realtime) and its API key.
