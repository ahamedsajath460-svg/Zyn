# Unified Floating Panel
- ONE overlay window (bubble <-> panel) = FloatingPanelController, hosting assets/zyn_float_panel.html (your uploaded design) in a WebView with a native bridge (JS object "ZP").
- FloatingAssistantService is now only a foreground-service shell. Old native bubble/chat UI (FloatUi.kt) deleted.
- AgentOverlay is a facade: no window of its own; status + confirmation card live in the panel.
- Chat: FloatAi/FloatStore (providers, keys, history). Agent: AgentRunner/AgentController/AgentHistory. Vision: FrameStore/ScreenCaptureService/ScreenOcr/AgentVision/HighlightOverlay.
- New: FloatPickActivity (camera/photo/file attach), FileProvider, CaptureRequestActivity live-share mode, AgentController.listeners, FloatStore chat management, NativeSpeech takes Context.
- NOT built/tested on-device: no Android SDK in the authoring sandbox. Build with: ./gradlew assembleDebug
- Chat web search now uses the same adult/porn block as the AI web search tool (wrapper after __adultText in a2z.html).
- Performance: a2z.html end-of-body CSS removes backdrop blur and ambient animation (lag on weak phones).
