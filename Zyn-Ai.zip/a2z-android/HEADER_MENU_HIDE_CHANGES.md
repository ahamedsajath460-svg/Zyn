# Header 3-dot menu only when the chat has messages

New `zyn-os2-hide` style + script at the end of `app/src/main/assets/a2z.html`.
The 3-dot button (`#os2`) is hidden on a new/empty chat and appears as soon as the chat has a message
(also hides again if you switch to an empty chat or delete all messages).
