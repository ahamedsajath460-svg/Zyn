# Agent: "circle it" action + stale screenshot fix

## Bug (from the screen recording)
Task: `screen la WhatsApp enga irukku circle pottu kaattu`. The agent answered that it cannot circle the WhatsApp icon and that it only sees an
"Update WhatsApp" page with a DOWNLOAD button. The real screen was the Zyn Ai app / the Android home screen.

## Causes
1. **No circle action.** The agent's allowlist and prompt had no way to point at anything, so the model (correctly, for its tool list) said it could not.
   `HighlightOverlay` exists but is only the numbered OCR boxes of the Advanced Vision tab; the agent never used it.
2. **Stale screenshot.** `AgentVision.observe()` used `FrameStore.latest(1)` with no age check. Continuous sharing stops storing frames while the Zyn Ai app
   is in front, so the newest frame was the earlier "Update WhatsApp" screen, and the model described that.
3. When the Zyn Ai app itself is in front, nothing told the model that the user means another screen.

## Changes
- New `ScreenMarker.kt`: pulsing ring in a non-touchable accessibility overlay, removed after 6 s (also on accessibility off).
- New agent action `highlight` (`id`, or visible `text`, or `x`,`y` with a screenshot). Aliases: circle, mark, outline, point_at, ...
  Looks for the target in the accessibility tree first, then in screenshot OCR. Never touches anything, never asks for approval, never marks password fields.
- `AgentPolicy`: allowlist, validation, LOW_RISK. `AgentRunner`: prompt (HIGHLIGHT rule + planner example), execute, describe, verify, no confirm card.
- `AgentVision.observe()` ignores frames older than 8 s (continuous) / 30 s (manual): `AgentVision.isStale`.
- `AgentRunner.observe()` adds a NOTE when the foreground app is Zyn Ai itself: go home / open the app first.
- Tests: `AgentHighlightTest` in `AgentActionsTest.kt`.

## Not verified
Not compiled, not run on a device (no Kotlin compiler or Android SDK here). Build with the existing GitHub workflow or `./gradlew testDebugUnitTest assembleRelease`.

# Floating bubble: grey square instead of the round bubble

## What the recording shows
After the panel closes, the bubble (at its snapped edge position, 4dp from the side) is drawn as a flat grey-blue SQUARE with sharp corners, no ring and
no sparkle, for several seconds; it moves to other edge positions, and on the home screen it is a dark-blue square. The colour equals the bubble's fill
(rgba(38,58,100,.58)), so the window is right but the WebView paints one wrong frame inside it.
Rendering the page in headless Chromium at 56x56 gives a correct round bubble, so the CSS is fine; the wrong frame comes from the Android WebView while the
overlay window is resized / re-shown (panel <-> bubble, hide for capture). The earlier CSS and `cloak()` fixes reduced it but did not remove it.

## Fix
- `FloatingPanelController.bubbleChrome()`: in bubble mode the Host window itself paints the disc (same fill + thin white ring) and clips everything to a circle
  (`GradientDrawable.OVAL` + `clipToOutline`). Removed again in panel mode. Called in `show()`, `openPanel()`, `closePanel()`.
- `zyn_float_panel.html`: in bubble mode the page's `.fab` is transparent; the page only draws the sparkle and status dot.
- Worst case is now a plain round bubble for a moment, never a square.

## Not verified
Not compiled or run on a device. If a square still shows after this, the wrong frame is outside the clip (a different window); then the window re-add in `setHidden()` is the next suspect.

# Panel input row: one slot for Voice conversation / Send (like Claude)
- Before: the orange voice-conversation button and the Send button were both always shown next to the mic.
- Now (`zyn_float_panel.html`, `syncSendLive()`): the right-hand slot shows
  - the **voice conversation** button when the box is empty and nothing is attached (keyboard open or closed),
  - the **Send** button when there is text or an attachment,
  - **Stop** (Send button in stop state) while a reply is streaming.
  While a voice conversation is running its button stays so it can be stopped. If the Live/Mic feature is switched off, Send is always shown.
- The mic (dictation) button is unchanged. Voice button now has the same size and shape as Send.
- Checked in headless Chromium with a stubbed bridge: empty -> voice, typed -> send, cleared -> voice, attachment -> send, busy -> stop; no page errors. Not tested on the phone.

# Panel menu > "Panel features" now opens INSIDE the floating panel
- Before: the row called `openFeatures`, which started the Zyn Ai app. Now it opens a new `features` page in the panel's own settings area (back arrow returns to the menu). It lists the same 27 switches / groups as the app (copied from `FPXG` in `a2z.html`).
- A switch applies at once (`setFeat` bridge -> `FloatStore.fpx`, then `applyFeat()`), so modes, voice, attachments etc. change immediately.
- The app owns the settings, so the change is also handed over: `FloatStore.pendingFpx` (tiny file `a2z_float_fpx.json`) keeps panel-made changes; every sync from the app is overlaid with them; the app reads them (`floatPeekFpx`), merges into `S.fpx`, saves, and acks (`floatAckFpx`). The app polls every 2 s and on resume, so it also works while the app is closed.
- Files: `zyn_float_panel.html`, `FloatStore.kt`, `FloatingPanelController.kt`, `MainActivity.kt`, `a2z.html`.
- Checked in headless Chromium with a stubbed bridge: menu row opens the page, 27 switches, toggling calls `setFeat`, `openFeatures` is never called, no page errors. Native Kotlin is not compiled or run on a device.
- The old `openFeatures` bridge method is left in place (unused).
