# New tool: Image & Video to Link (Tools > Creative)

Upgraded from `video___image_to_link_convert.html` and added to the Zyn Ai Tools list. All code is in `assets/a2z.html` (last `<script>` block). No Kotlin change, no new permission.

## What is better than the old file
| Old file | Zyn Ai tool |
|---|---|
| imgbb API key written inside the file | Same key is built in for ImgBB; Catbox (default) needs no key. A key pasted in the tool overrides it |
| One file at a time | Up to 20 photos/videos in a queue, uploaded one by one (light on low-end phones) |
| No progress, page froze | Real progress bar, Stop button, Retry on failed files |
| Photo always re-saved as JPEG 80% (PNG lost) | Original is kept by default. Optional Compress: high / medium / small |
| Crashed on any error | Clear messages: no internet, host unreachable, too big (limits per host), wrong file type |
| Short link only from is.gd | is.gd, then v.gd. If both fail the full link is still shown |
| Nothing saved | "Recent links" list (last 40) with Copy, Open, Remove |
| alert() popups | App toasts and buttons: Copy, Copy real link, Open, Share, Copy all links |
| Catbox only for video | Choose host: Catbox (permanent), Litterbox (1 h / 12 h / 24 h / 3 days), ImgBB (photos) |

Also: thumbnails are tiny (96 px) so many large photos do not use much memory; a confirm appears before a big upload on mobile data; duplicates are skipped; no AI provider warning is shown for this tool.

## Things to know
- **Not run on a device and not tested against the real hosts** (the build environment has no network). The code passed a syntax check and 26 logic tests with a mocked DOM and mocked uploads.
- If the phone's WebView blocks a host (CORS), the tool shows "Could not reach the host. Try the other host." Switch host in the tool.
- Links are public: anyone who has the link can open the file. A note is shown in the tool.
- Removing a link from "Recent links" does not delete the file from the host.
- The ImgBB key from the old HTML file is now built into the tool (`DEF_KEY` in the last script block of `a2z.html`), so ImgBB works with no setup. Anyone who unpacks the APK can read it. If it is abused, make a new key on api.imgbb.com and replace `DEF_KEY`. A key pasted in the tool's ImgBB box overrides it.

## App key button (admin only)
- The **App key** button is drawn only when the signed-in account is the admin (same rule as `zIsAdmin`: e-mail in `ZADMIN` and verified), like the Admin panel row in Settings. For everyone else the button does not exist and the key is never drawn on the page.
- The button is checked each time the tool page is drawn, so open the tool again after signing in or out.
- Admin: key is masked first (last 4 characters visible); Show / Hide, Copy, Close. If the admin signs out, the panel closes on the next redraw. Leaving and re-opening the tool also closes it.
- Same limit as the other built-in keys (see KEYS_ADMIN_ONLY_CHANGES.md): this hides the key in the app screen, not from someone who unzips the APK.
