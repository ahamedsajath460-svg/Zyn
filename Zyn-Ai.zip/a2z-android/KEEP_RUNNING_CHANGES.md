# Tools keep running when you leave them

**Problem:** a tool that was working lost its page when you went to Chat, Studio or another tool (the page was rebuilt), and the app could be stopped by Android when you switched apps.

**What changed**
- `a2z.html` (one script block appended, id `zyn-keep-running`): a working tool keeps its page (input, progress, result). Reopen it from Tools and you see the same page, finished or still running. "Start over" and "Use again" from History still give a fresh form. Up to 8 pages are kept.
- While any tool works, JS calls `A2ZNative.keepAlive(true)`; 12 s after all tools are idle it calls `keepAlive(false)`.
- New `KeepAliveService.kt` (foreground service type dataSync + partial wake lock, auto-stops after 30 min). New bridge method `keepAlive` in `MainActivity.kt`, service stopped in `onDestroy`.
- `AndroidManifest.xml`: `FOREGROUND_SERVICE_DATA_SYNC`, `WAKE_LOCK`, `KeepAliveService`.
- When a tool finishes while you are away: notification if the app is in the background, otherwise a message inside the app.
- Video tool note text updated (you no longer have to keep the page open).

**Limits**
- Not compiled with Android SDK here; the JavaScript part was tested in headless Chromium.
- Closing the app from Recents or force-stop still ends the job.
- "Working" is detected from the tool's status text (Working…, Starting…, Generating…) or a visible Cancel/Stop button. A new tool that uses other wording may not be detected.
