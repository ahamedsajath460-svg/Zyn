# Built-in keys visible only to admin (v21)

Problem: keys added as GitHub Secrets showed up for every user (provider list, key field, under the app name, under messages).

Fix (app/src/main/assets/a2z.html, block "v21" before `saveCore`, and script `a2z-keyguard` at the end):
- `zIsAdmin()` = signed in with the verified admin e-mail. Everyone else = `zHide()`.
- Built-in providers get a neutral name ("Zyn Ai 1..") for non-admins; the real label is kept in `rn` and restored for the admin on sign-in / sign-out.
- Provider screens use `PV()` (the list without built-in providers for non-admins): Settings > AI providers, Providers page, My API Keys, Test all, Billing, "copy key from another provider".
- `openProvider()` refuses to open a built-in provider for non-admins.
- Header line, "via ..." under messages, progress text, tools pill, dashboard, error list: no provider/model text for built-in keys (empty or "Zyn Ai"). Old saved messages that carry a built-in name are hidden too.
- Title menu shows one "Zyn Ai" entry + the user's own providers.
- Technical details are passed through `redact()` so no key text can appear.
- Native floating panel (FloatStore.kt, FloatingAssistantService.kt): "Zyn Ai N" providers show only that name, no model, no "via" line.

Note: the keys are still inside the APK (assets/default-keys.json), so this hides them from the app UI, not from someone who unzips the APK. For real protection put the keys behind a server (e.g. a Firebase Cloud Function) instead of in the APK.

## API key fields (v21b)
- Removed the Paste / Copy / Clear buttons under every API key field and the custom long-press "API key" menu (Copy, Paste, Cut, Select all, Clear).
- The key field keeps only the eye icon. Show the key with the eye, then long-press it like any other text (Android's normal copy / paste / cut menu).

## Get API key button (v21c)
- Setup guide button now says "Get free API key" (provider has a free tier) or "Get API key", and "Open website" for no-key providers.
- It opens the page where the key is created (a2z.html script `a2z-keyurls` fixes catalog links such as NVIDIA, OpenRouter, Serper, Brave, Moonshot, YouTube Data, Giphy, Unsplash).
- It opens through the native bridge `A2ZNative.openUrl` (MainActivity.kt), falling back to window.open.
