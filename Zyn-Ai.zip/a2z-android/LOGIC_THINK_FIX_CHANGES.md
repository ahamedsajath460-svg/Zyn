# Chat logic fix: Tamil / Tamil-English questions now trigger "think deeper"

## Cause
`ZT.need()` in `a2z.html` decides when the model should reason before answering. Its keyword list was English only (why, how, explain, solve...). A Tamil or Tamil-English question almost never matched, so the app sent it with thinking switched off (Gemini 2.5 Flash `thinkingBudget:0`, Gemini 3 `thinkingLevel:low`). Result: fast, shallow answers that ignore instructions or get the logic wrong.

## Change (one line, `a2z.html`)
- `need()` now also returns true for: Tamil/Sinhala script messages longer than 25 characters or containing `?`; common Tamil-in-English-letters question words (eppadi, enna, yen, sollu, vilakkam, kanakku, mudiyuma, ...); any message over 120 characters (was 180).
- Short greetings ("hi", "வணக்கம்", "thanks") still answer fast, without thinking.

## Not changed (other possible causes)
- "Remember my other chats" is ON by default and puts up to 12,000 characters of older chats into every request. This can distract the model. Turn it off in Settings to test.
- Build/tests were not run on a device. The patched script block passes `node --check`; the `need()` rule was tested on sample messages.
