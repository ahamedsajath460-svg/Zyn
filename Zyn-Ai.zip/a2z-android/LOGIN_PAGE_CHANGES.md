# New login page

- Old Google-centric login gate (`#authgate`) removed: its HTML, CSS (`zyn-login`, `zyn-login-anim`, gate rules) and form JS (`zyn-login-js`).
- New design added in `app/src/main/assets/a2z.html`: animated gradient background, glass card, floating labels, show/hide password eye, sign in / create account / forgot password views (all in one card), success check animation.
- Still uses your existing Firebase code: `A2ZAuth.emailSignIn`, `emailSignUp`, `resetPassword`, and the `#ag-btn` Continue with Google button (same ids, so the Google/native flow is untouched).
- Kept ids used by the main script: `ag-btn`, `ag-msg`, `ag-last`. Logout dialog (`#lodlg`) is unchanged.
- Gate CSS lives in <head> so the login page never flashes unstyled while the app loads.
- Password rule: at least 8 characters on sign up. Name is optional.
