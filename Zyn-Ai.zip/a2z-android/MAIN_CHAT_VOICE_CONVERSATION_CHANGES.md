# Voice conversation in the main chat

The orange waveform voice conversation from the floating panel is now also in the Zyn Ai main chat.

## What you see
- Input box, right side, ONE slot (same idea as the panel):
  - nothing typed, nothing attached -> orange **waveform** button
  - text or an attachment -> **Send**
  - normal reply streaming -> **Stop**
  - while a voice conversation runs, the waveform button stays (red = listening, amber = thinking, orange glow = speaking) so it can be stopped.
- Tap it: it listens, you talk, your words are sent the moment you pause (about 1 second), the answer is spoken sentence by sentence while it is still being written, then it listens again.
- Tap the button while it thinks or talks = interrupt (generation and speech stop, it listens to you at once). Tap when idle = end the conversation.
- Say `stop`, `exit`, `bye`, `goodbye`, `that's all`, `nillu`, `nillunga`, `mudinjidhu`, `நிறுத்து` to end it by voice.
- The small mic button, leaving the app, 3 "nothing heard" in a row, a failed answer or a speech error all end the conversation.
- Hidden outside the Android app (needs the native bridge).

## How it works
- It uses the normal `send()` / `answer()`: same chat, memory, web search, providers and automatic fallback as typing. The message and the answer are saved in the chat like any other.
- While it is on: the system prompt gets a "spoken-style" rule (1 to 3 short sentences, no markdown/lists/code) and the slow "thinking" mode is skipped.
- Listening language = the voice language of the app (`S.vlang`, the language box of the voice input bar; default ta-IN). Speaking language is detected from the text (Tamil, Sinhala, Hindi, else English / your English variant), with your chosen voice, speed and pitch.
- The old "Voice chat (hands-free)" switch is turned off when the new conversation starts, so the two never fight.
- Watchdog: if the answer path never reports back (special tools, another chat opened) it listens again after a few seconds instead of hanging.

## Files
- `app/src/main/assets/a2z.html`
  - `#live` button next to `#send`, CSS `a2z-live-css`
  - script `a2z-live` (the whole loop; wraps `window.__nsr`, `window.__ntts`, `sysPrompt`, `ZT.want`, `setBusy`, `drawAtt`)
  - 3 small hooks in `answer()`: `__liveStream` (each streamed chunk), `__liveReply` (answer done, and failure)
- `app/src/main/java/com/a2z/ai/MainActivity.kt`
  - `sttStartFast(lang)`: like `sttStart` with shorter end-of-speech times (`NativeSpeech.start(lang, fast=true)`); the permission launcher keeps the fast flag
  - `ttsAppend(text, lang, rate, pitch, voice)`: `NativeTts.append`, queues a sentence without flushing
  - new private `sttGo(lang, fast)` shared by `sttStart` / `sttStartFast`

## Checked / not checked
- All inline scripts of `a2z.html` pass `node --check`.
- Simulated run with a fake phone bridge: pause detection, sentence-by-sentence speaking, no early listening, interrupt (thinking and speaking), voice command stop, 3 retries then stop, failed answer, speech error, watchdog.
- Not compiled and not tested on a real phone (no Android build here).
- Still not true speech-to-speech: you cannot interrupt by just talking (the phone would hear its own voice), and the voice is the phone's Text-to-speech.
