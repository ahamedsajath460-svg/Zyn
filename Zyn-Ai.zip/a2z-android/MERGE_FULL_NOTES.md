# Zyn Ai full merge (Zyn-Ai.zip + Zyn-Ai-settings-integrated.zip)

Base = Zyn-Ai.zip. Everything from the settings project was added on top; nothing from the base was removed.

## How each differing file was merged
| File | Result |
|---|---|
| `assets/a2z.html` | Base file + the settings hooks and the `v30` (ZX) script block, web-search engine/limit options, auto-continue switch, memory-file backup/restore, chat-share key redaction, new Sharing page, extra voice languages, "+" menu restyle. Base-only parts kept: Keep-running block, mic waveform / cancel, keyboard-aware chat box, "Key added" labels, "Test all keys" button, video-job note. |
| `MainActivity.kt` | Base + `ttsSpeakEx`, `ttsVoices`, `setSecureScreen`, `secureScreen`, `applySecure` (FLAG_SECURE). Base-only kept: `keepAlive`, `watchKeyboard`, KeepAliveService stop in `onDestroy`. |
| `NativeTts.kt` | Settings version (adds `voices()` and the optional voice name; `speak` stays backward compatible). |
| `NativeSpeech.kt` | Base version (keeps the live RMS level used by the mic waveform). |
| `AndroidManifest.xml` | Base version (KeepAliveService, FOREGROUND_SERVICE_DATA_SYNC, WAKE_LOCK). |
| `KeepAliveService.kt`, `.github/workflows/release-apk.yml`, Gradle files, resources | Unchanged from base. |

## Checks that were actually run
- All 53 inline `<script>` blocks of the merged `a2z.html` pass `node --check`.
- Every `A2ZNative.*` method called from JS has a matching `@JavascriptInterface` method in `MainActivity.kt`.

## NOT run
- `./gradlew assembleDebug` was not run: the authoring environment has no Android SDK and no network. Kotlin was not compiled here. Build with the GitHub Actions workflow (or Android Studio) and check for errors.
- Nothing was tested on a real device.

## Built-in keys update
Per-provider secrets (`POLLINATIONS_KEY_1..4`, `GEMINI_KEY_1..4`, `TAVILY_KEY_1..2`) added to the workflow; Pollinations keys also create image providers; Tavily keys rotate on failure. See `API_KEYS_SECRETS.md`. Tested with fake keys in headless Chromium (providers created, Tavily failover, redaction); not tested with real keys.
