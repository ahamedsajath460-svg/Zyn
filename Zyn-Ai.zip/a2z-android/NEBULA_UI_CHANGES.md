# Zyn Ai Nebula chat UI (visual-only change)

Changed file: app/src/main/assets/a2z.html (one CSS block + one small JS block appended before </body>,
ids `a2z-nebula-css` / `a2z-nebula-js`). No Kotlin, API, provider, storage or other-screen code touched.
To roll back: delete those two blocks (and the Plus Jakarta Sans <link> just above them).

## What it adds
- Header: glass capsule, animated AI orb, gradient brand, model/provider line (existing #sub), New chat button
  (calls the existing #nc handler), chat history (#mb), personality (#pb), settings/more (#os2).
- Live status capsule driven by the app's real activity row (TR): Processing, Analyzing, Thinking,
  Searching, Creating (image/video), Writing, Complete, Error, Stopped. Nothing is faked; it follows the
  actual `.trw` label and streamed text, and clears itself when the reply ends.
- Waiting indicator: glowing AI core with rotating rings. Streaming: animated gradient border, light sweep,
  glowing caret. Finish: green completion pulse that fades out.
- User bubbles (gradient border, glass), AI cards (glass, gradient border), markdown headings/lists/quotes/tables,
  code block frame (existing syntax highlighter kept), action buttons + new Share button (A2ZNative.shareText).
- Aurora background (3 orbs, wave, 12 particles), transform/opacity only; paused when app is hidden;
  particles/backdrop blur/border animation switched off on low-end phones (<=4 cores or <=2 GB) and with reduced-motion.
- Floating composer: animated outline on focus, ambient glow, animated send button, attachment menu animation.
- Empty chat: AI core, aurora greeting, quick actions (Web search, Think deeper, Photo, Voice) and 4 suggestion
  cards. They only click existing buttons / fill the existing input.
- Light (pearl) and dark (midnight) palettes; amoled/ocean/forest/rose keep working and are tinted.
- Typography: Plus Jakarta Sans (falls back to system-ui; Tamil/Sinhala keep Noto). Change `--nfont` to go back to Comic Neue.

## Verified / not verified
- Headless Chromium 390x780: no JS errors; empty, waiting, streaming and complete states in light and dark.
- NOT done: Gradle build / APK, device test, TTS, voice, attachments, screen share, agent (no Android SDK or network here).
  Run the GitHub Actions workflow or Android Studio to build and test on a phone.

## Startup flash fix (old UI visible / flicker on launch) - event-driven, no timers
Cause: Nebula CSS/JS sat at the very end of a ~4,600-line body and 26 legacy <style> blocks lived in the body; the first
render also waits on IndexedDB, and two startup tasks (applyDesign/route, paintAv/bind/nightTick) ran ~40 ms later.
a2z.html:
- ALL body <style> blocks (incl. Nebula, kept last so the cascade is unchanged) now live in <head>. No duplicates.
- <head> script `a2z-boot`: applies the saved theme (+ night-mode rule) from localStorage before first paint and hides <body>
  (`html.n-boot`) behind a Nebula gradient pinned to the startup theme (`--zb0/--zb1`).
- Reveal happens once: after init (storage load + first render) has settled AND the startup tasks that were registered with
  `__zynHold/__zynRelease` finished; `__nebulaSync()` decorates the first render right before the class is removed.
  If init throws, it reveals immediately; if init never starts, it reveals on window `load`. No setTimeout anywhere.
- Fonts: Google Fonts links are non-blocking; Plus Jakarta Sans link moved to <head>.
- Nebula JS tells the app the current Nebula background (`A2ZNative.bootColor`) when the theme changes.
Kotlin/resources: MainActivity.kt (new bridge method `bootColor`, window + WebView background set from the saved colour,
defaulting to the system light/dark Nebula colour), res/values/themes.xml + colors.xml + values-night/colors.xml, and the
manifest theme -> Theme.Zyn.Start (same AppCompat DayNight parent + Nebula windowBackground). Package name, storage keys and all
existing bridge methods are unchanged.

## Bottom nav removed
`document.body.append(pg,nav)` -> `document.body.append(pg)` in a2z.html. Tools / Studio remain in the side menu.

## Login gate + log-out confirmation
- First launch (no saved Firebase session in localStorage) shows a full-screen sign-in page (`#authgate`) from the first frame; it hides
  when Firebase reports a signed-in user. Offline launches with a saved session go straight to the app.
- If firebase-config.js has no valid config, the gate is skipped so the app stays usable.
- Sidebar "Log out" now opens a confirmation dialog (`#lodlg`) with "Remove from this device". Unchecked: name/email/photo are kept
  in localStorage `a2z.lastAcct` for 30 days (shown as "Last signed in as ..." on the sign-in page); checked: removed. Chats/settings are never deleted.

## Settings > Log out
Settings page "Log out" row now opens the same Claude-style dialog (when Firebase sign-in is configured) instead of the old
"This app has no account" sheet (kept as fallback when there is no Firebase config). Log out signs out of Google -> sign-in page.
"Remove from this device" also clears saved API keys (old Settings log-out behaviour) and the remembered account; unchecked keeps keys.
Chats, memory and settings are never deleted. Settings page closes after logout.
