# Permissions (real state) + Theme + Font style

Changed files: `app/src/main/java/com/a2z/ai/MainActivity.kt`, `app/src/main/assets/a2z.html`. Nothing else.

## 1. Permissions page now tells the truth
- Every status is read live from Android (`A2ZNative.permStatus()`): **Allowed / Not allowed / Blocked**. It refreshes after any pop-up and when you come back from phone Settings.
- Tapping a row asks Android (`permRequest`). If Android will no longer show its pop-up (Blocked), the row opens the right Settings page.
- Location and Calendar rows show your setting AND Android's state, e.g. `Always · Not allowed`, with a line saying the feature stays off.
- Removed the rows that were only fixed text (Screen sharing, Files and photos, Internet, Background service, Audio settings). They were not switches. A note explains why.
- The old web-based check (`navigator.permissions`) is only used in a normal browser, never inside the Android app.

## 2. Features really need the permission
- **Camera / Microphone inside the page (getUserMedia):** before, `onPermissionRequest` granted the page everything even if Android said no. Now it asks Android and passes on only what was allowed.
- **Notifications:** the old Web Notification API does not work in Android WebView, so reply alerts never showed. Now they use a real Android notification (`notifShow`), and only when allowed.
- **Calendar:** no longer pops up a permission request when you type words like "today". It reads only if Android allows READ, and adds events only if READ + WRITE are allowed and the mode is Read & Write.
- **Location:** blocked in Android = no location read and a clear message (before it also asked "Allow location this time?").
- Voice typing, floating assistant, highlights and the AI Agent already checked their permission natively; unchanged.

## 3. Theme + Font style (Settings only, inside the app)
- Settings > **Theme**: Royal Gold, Aurora, Crimson Velvet (dark); Ivory Luxe, Arctic Frost (light). The old themes stay under "Standard".
- Settings > **Font style**: Outfit, Sora, Playfair, Space Grotesk, JetBrains Mono (+ Default). Each is previewed in its own font, with Tamil text falling back to Noto Sans Tamil.
- Fonts load from Google Fonts on first use (one stylesheet each); offline they fall back to a normal font.
- Font now also applies to chat, input box and menus (before it only changed the page base font).
- Light themes still switch to dark in Night mode.

Not compiled or run on a device here (no Android SDK). The page was tested in a headless browser with a mocked Android bridge.
