# Zyn Ai – Android wrapper with system-wide screen sharing
1. Open this folder in Android Studio (Koala+), let Gradle sync, run on a device (Android 8.0+).
2. Your existing app is app/src/main/assets/a2z.html (all original code untouched; one script block appended).
3. In the app: "+" menu > Share screen > Start > allow the system prompt. Switch to any app/website, return, tap "Ask about screen".
Model/keys: unchanged. Frames are attached through the app's existing attachment flow, so your selected primary model and key manager handle the request.


## Gemini 3.6 Flash (default model)
- Default primary model: `gemini-3.6-flash` via `https://generativelanguage.googleapis.com/v1beta` (verified against Google's Gemini API docs; stable/GA, text+image+video+audio+PDF in, text out). Google lists it as previous-generation; Gemini 3.8 Flash is newer. Change the model in Settings > AI providers > Gemini any time.
- On first launch after this update, Gemini providers with an empty model or the old default `gemini-2.5-flash` switch to `gemini-3.6-flash`; the first Gemini provider with a key becomes primary only if you never picked one. Custom models, keys, provider order, and manual choices are kept. Other providers remain the automatic fallback.
- Requests send the key in the `x-goog-api-key` header (not in the URL). For Gemini 3.5+ models `temperature/top_p/top_k` are not sent and a trailing model turn is dropped (Google API rules).
- Images (including screen-share frames) go as `inlineData`. Settings > AI providers > Test all sends a real request to each model; a 404 adds a check that tells you whether the key is valid but the model is unavailable.
- API keys are entered by you and stay on the device; no backend secret is in the APK or the HTML.


## Floating Assistant Panel (over other apps)
- Start: in the app "+" menu > **Floating assistant** > Start. Android asks for "Display over other apps" (Huawei: Settings > Apps > Apps > gear > Special access > Draw over other apps).
- Bubble: drag to move, tap to open/close the panel. Panel header: drag to move, minimize (-), maximize/restore, close (x = stops the assistant and frees everything).
- Uses the same providers, models and API keys as the app (primary first, then the app's fallback order; the answering model is shown under each reply). Keys are held in memory only by native code.
- Floating chats are added to the app's chat history automatically. "Clear chat" starts a new chat; the old one stays in history.
- New files: FloatingAssistantService.kt, FloatStore.kt, FloatAi.kt, FloatUi.kt. Changed: MainActivity.kt, AndroidManifest.xml, a2z.html (one script block appended).
- Not verified on a real device or compiled in the authoring environment (no Android SDK).


## Ask AI While Using Other Apps (screen questions from the floating panel)
Start the floating assistant, open any app, tap the bubble. The panel now has a screen bar:
- **Ask AI About My Screen**: captures the screen, shows a preview, opens the keyboard. Type a question (or just tap send for a default "explain my screen" request).
- **Capture Screen**: captures and shows the preview only. The screenshot is sent with your next message.
- **Pause / Resume / Stop sharing**: Pause blocks captures; Stop releases the projection, the notification and the screenshot in memory.
- **Indicator**: red dot + text in the panel, red dot on the bubble, and the ongoing "screen capture is on" notification. Nothing is captured until you tap a button (manual mode = the virtual display is paused between screenshots).
- First use shows Android's official screen-capture dialog (the panel hides itself so it does not cover it). The panel also hides for the instant of the screenshot so it is not in the picture.
- Screenshot: max 720x1280-class, JPEG q70, held in RAM only, sent only to the ONE provider selected in the panel header (no silent fallback), never saved or added to chat history (history keeps only "[Screenshot attached] your question").
- Models: the header list tags each model [image] / [text only] / [image: unknown]. Text-only models are blocked with a message and the picker opens. Unknown models are tried; if the API rejects the image you get a "choose model" prompt. The check is name-based (no official capability endpoint exists), so a new model may show "unknown".
- Changed: ScreenCaptureService.kt (one-shot CAPTURE + manual mode), FrameStore.kt, FloatingAssistantService.kt, FloatAi.kt, FloatUi.kt, AndroidManifest.xml. New: CaptureRequestActivity.kt, FloatVision.kt. a2z.html and MainActivity.kt untouched.
- Limits: protected (FLAG_SECURE/DRM) windows come out black (never bypassed, a warning is shown). Android 14+ lets the user share a single app only. Follow-up questions are text-only (re-capture to attach a new screenshot). Not compiled or tested on a device in the authoring environment (no Android SDK).


# Agent 3.1 (added)
See AGENT_3_1_CHANGES.md. Three modes (Read-only / Manual confirmation default / Trusted), intent classification, allowlist, verified actions, persistent history, voice control, agent row in the floating panel. Not compiled or device-tested.


# Permissions, Theme, Font style (added)
See PERMISSIONS_THEME_CHANGES.md. Real Android permission status, no fake rows, features blocked without permission, 5 premium themes, 5 font styles. Not compiled or device-tested.
