# Semantic understanding, context awareness, intelligent query generation

All changes are in `app/src/main/assets/a2z.html` (script `zyn-smart` + 5 small hooks in `answer()`).
No API, key rotation, provider, settings, auth or chat-history code was removed.

1. Semantic understanding - the router (one small AI call) now returns meaning, intent, language, entities and queries.
   Long / Tamil / Tanglish messages that the keyword check calls "no search" are judged by meaning (semantic override).
2. Context awareness - the planner sees the last 6 messages, the options the assistant listed ("the second one",
   "which is better") and the previous web search. Previous results are also handed to the answer when a message points back.
   Each searched reply stores a tiny `zq` field (queries, entities, meaning).
3. Query generation - 1 to 4 optimized Tavily queries (filler removed, entities kept, references resolved), run through the
   normal webSearch chain (cache + key rotation + cooldowns), merged round-robin without duplicates.
   Offline fallback planner works without the router.
