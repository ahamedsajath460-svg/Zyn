# Settings integration (all inside the EXISTING Settings pages; no new buttons, categories or pages)

| Category | Where | What was added |
|---|---|---|
| Agent Control | top of the Agent Control dialog | Chat preferences (response style, length, streaming, auto-continue, custom instructions), Personalities (default, create/edit/delete), AI behavior (creativity, emoji, formatting, clarifying questions, step-by-step) |
| Voice | Voice settings page | Android TextToSpeech routing, voice choice, exact speed and pitch, voice input on/off, more languages (Hindi, English UK/India) |
| Capabilities | Capabilities page | Web search on/off + auto, engine choice, language, recency, max results, snippet length, Tavily key with test, link to search APIs |
| Theme | Theme sheet | Accent colour, chat background (colour / gradient / picture + dim), bubble style, bubble width, spacing, chat width, avatars, reduce animations, reset |
| Font style | Font style sheet | Size slider, weight, line/paragraph spacing, alignment, your-message style, code size, letter spacing, high contrast, live preview |
| Sharing | Sharing sheet | Chat / settings / provider config / memory backups, selective backup, import & restore (merge or replace), undo last restore |
| Privacy | Privacy sheet | Backup encryption (AES-256-GCM, PBKDF2), API-key backup policy, key redaction when sharing chats, screenshot block (FLAG_SECURE), backup file check |

Existing "Full backup" and "Import backup file" buttons now use the new secure flow. Old backup files still import.

## Files changed
- `app/src/main/assets/a2z.html`: new script block `v30` (module `ZX`) at the end, small hooks in the existing pages, web-search engine/limit options, auto-continue switch, memory-file export/import, chat-share key redaction.
- `NativeTts.kt`: optional voice name + `voices()` list. `MainActivity.kt`: bridge `ttsSpeakEx`, `ttsVoices`, `setSecureScreen`, `secureScreen` and the FLAG_SECURE preference.

## Not verified
Kotlin was not compiled here (no Android SDK in the authoring environment); the GitHub Actions workflow builds it. The JS was run in headless Chromium with a mocked Android bridge. Not tested on a real device.
