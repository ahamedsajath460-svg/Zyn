# Side panel - small text like the Claude app (v18)

Only CSS changed (new `<style id="zyn-side-v18">` in `app/src/main/assets/a2z.html`, right after `zyn-side-smooth`).
- Zyn Ai title 1.7rem -> 1.5rem; search button 46px -> 38px
- Chat / Tools / Studio rows: text .95rem -> .84rem, icons 28px -> 20px, tighter padding
- Chat list: text .95rem -> .84rem, chat icon 24px -> 16px, row padding 13px -> 9px
- Pinned / Recents labels .85rem -> .8rem
- Bottom: profile circle 56px -> 40px, New chat button 56px -> 40px high
Panel width, smooth open/close and swipe are unchanged.

# Header 3-dot menu only when the chat has messages
`#os2` (the 3-dot button) gets class `nomsg` (display:none) while the open chat has no messages; see `<style id="zyn-os2-hide">` + `<script id="zyn-os2-hide-js">` at the end of `a2z.html`. It re-checks whenever the chat list area changes (new chat, switch chat, send, delete).

# Long-press menu on a chat (side panel) - Claude style
`<style id="zyn-chat-menu">` + `<script id="zyn-chat-menu-js">` at the end of `a2z.html`. Long press on a chat now opens a small popup next to it:
Pin/Unpin, Rename, Select chats (starts the existing multi-select mode), Add to project, Delete. Rename/Delete use in-page dialogs (JS prompt/confirm do not work in the Android WebView).

# "+" sheet like Claude's "Add to session" sheet (second pass)
`<style id="zyn-plus-v2">` + `<script id="zyn-plus-v2-js">` at the end of `a2z.html`. Rows are joined into rounded cards with thin dividers (two groups: Video / Create image / Create video, then the tool rows), each with a grey sub-line, 44px icon circles, chevrons. Camera / Photos / Files tiles unchanged.

# Chat titles = topic of the chat
"AI chat titles" was OFF by default, so chats stayed named after the first message ("hi"). Now ON by default (`S.aititle!==false`; the Settings toggle still turns it off). After the first reply the AI names the chat by topic (2-5 words, e.g. "Greeting"), saves it and refreshes the side panel. A plain hello falls back to "Greeting" if the AI call fails. Costs 1 extra request per new chat.

(Popup made smaller: 184px wide, .82rem text, 17px icons.)

# Code Writer API error + chat Preview parity (`<script id="zyn-cw-chat-js">` at the end of a2z.html)
- Code Writer (cwAsk) tries the provider that last worked first (so chat's working provider is used), skips providers that returned 401/403 this session, retries a provider without "thinking" before giving up on it, and when all fail lists every provider and its reason (it used to show only the last one).
- Chat: Preview of an HTML code block now inlines the CSS/JS code blocks of the same message (matched by file name, else by type), runs with the same sandbox shim as Code Writer (localStorage works) and shows "Console: no errors / Error: ..." with a "Fix with AI" button. Copy, Download, "Download all (.zip)" already existed in chat.
