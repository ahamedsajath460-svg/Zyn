# Real thinking (Claude, Gemini, Groq, ChatGPT / OpenAI, OpenRouter)

Chat replies can now really think, not only "think step by step" in the prompt.

## How it is switched on
- **Think deeper** (the existing switch in the + menu): always think.
- **Auto-think on hard questions** (new switch, ON by default): when Think deeper is off, the app still thinks for questions that look hard (code, maths, "why / how / explain / compare / debug", long messages, attachments) and answers simple chat quickly.
- **Thinking depth** Low / Medium / High (new row, default Medium) sets how much it thinks.

## What is sent to each provider
| Provider | Request |
|---|---|
| Claude Fable / Mythos / Opus 4.6+ / Sonnet 4.6+ and 5.x | `thinking: {type: "adaptive", display: "summarized"}` + `output_config.effort` (temperature removed) |
| Older Claude (4.x, 3.7) | `thinking: {type: "enabled", budget_tokens}` (3000 / 8000 / 16000), `max_tokens` raised to fit |
| Gemini 3.x | `thinkingConfig {thinkingLevel, includeThoughts: true}` |
| Gemini 2.5 | `thinkingConfig {thinkingBudget, includeThoughts: true}` |
| Groq (gpt-oss, Qwen3, DeepSeek R1 and similar) | `reasoning_format: "parsed"` + `reasoning_effort` where the model supports it |
| OpenAI (o-series, gpt-5.x) | `reasoning_effort` (temperature removed). OpenAI does not return the thinking text, so only the answer is shown |
| OpenRouter | `reasoning: {effort}` + `include_reasoning` |
| Models without thinking (for example Llama, GPT-4o) | nothing extra is sent |

If a provider rejects a thinking option (HTTP 400 that mentions thinking, reasoning, effort, budget or temperature), the app retries once with the simpler option, then without thinking, and remembers this for that model until the app is closed. Other errors (wrong key and so on) are not retried.

## What you see
- The Reasoning block opens while the model is thinking ("Thinking\u2026"), closes when the answer starts, and stays as "Thought for N s".
- Only chat uses it. Tools, the floating assistant and the agent are unchanged.

## Files
`assets/a2z.html` only: base `callAI` (3 one-line hooks), the chat call in `answer()`, and two new script blocks (`zyn-think`, `zyn-think-ui`) plus `zyn-think-css`.

## Not checked
No device run. The request bodies were checked against a mocked fetch for Claude (adaptive, budget, retry), Gemini 3 / 2.5 (including a rejected level), Groq, OpenAI, OpenRouter; all 47 inline scripts parse.
