# Touch indicator for AI Touch Control

Adds a visible real-time touch indicator to the agent's touch gestures. Nothing existing was removed or restyled.

## What you see
| AI action | Indicator |
|---|---|
| Tap / click | finger flies to the element, presses, purple ripple, element outlined |
| Double-tap | two teal ripples 150 ms apart (same timing as the two strokes) |
| Long-press | amber progress ring fills over the real hold time, burst ripple when it ends |
| Swipe | blue trail; finger moves along the path over the real stroke duration |
| Drag | orange hold ring (500 ms), then finger and trail move to the drop point; target element highlighted on arrival |
| Failed / cancelled gesture | red ripple, then fade |

The finger tip is drawn on the exact pixel passed to `dispatchGesture()`.

## Synchronisation with real gestures (`AgentGestures.run`)
1. `TouchIndicator.prepare` - finger flies in (220 ms) and the element is highlighted; the worker waits, then dispatches.
2. `TouchIndicator.fire` - called immediately before `dispatchGesture()`; press/path animation uses the same durations as the strokes.
3. `TouchIndicator.finish` - called from `onCompleted` / `onCancelled` (or on refusal / timeout), so the picture ends when Android reports the result.
Drag is two real dispatches (hold, then move); the finger stays down between them.
Node actions (`click`, `focus`) have no gesture, so the indicator fires with the action and finishes with its real result.

## Safety
- Separate `TYPE_ACCESSIBILITY_OVERLAY` window owned by the accessibility service: no extra permission, `FLAG_NOT_TOUCHABLE`, not important for accessibility. It never receives or blocks touches and never appears in what the agent reads.
- Removed shortly after each gesture, on Stop, and when Accessibility is turned off.
- Never points at password fields.

## Setting
Agent Control -> "Touch indicator" switch (default ON). Stored on the page (`a2za_touchIndicator`) and sent with `agentConfig`; native flag is `TouchIndicator.enabled`; reported in `agentStatus`. Switching off removes the overlay at once and also skips the 220 ms fly-in wait.

## Files
New: `TouchIndicator.kt`. Changed: `AgentGestures.kt`, `AgentRunner.kt`, `AgentController.kt`, `AIAccessibilityService.kt`, `assets/a2z.html`.

## Not checked
Kotlin compile, APK build and on-device behaviour were not run (no Android toolchain here). Brace balance and the page script syntax were checked. Please run `./gradlew assembleDebug` and try tap, double-tap, long-press, swipe and drag on a device.
Scrolling through node actions (`scroll`, `scroll_edge`, `find`) are not touches and show no indicator; scroll by swipe does.

## Share screen dialog restyle (CSS only)
Added one `<style id="zyn-share-dialog">` block at the end of the styles in `assets/a2z.html`. It restyles `#ssd` (Share screen) with the chat screen's glass look: `--nglass2` blurred panel, `--nline` border, 28px radius, glass pill dropdowns, glass pill buttons, accent Start / Ask about screen buttons, theme-aware (light, dark, Nebula-lite). No markup, JavaScript, screen-sharing logic or other screens were changed.

## Floating AI assistant restyle (visual only)
`FloatUi.kt` and `FloatingAssistantService.kt`: the floating panel now uses the same glass look as the chat screen. Every colour is derived from the active theme palette (`Pal.glass()`, `glassSoft()`, `nline()`), so Light, Dark, AMOLED, Ocean, Forest, Rose and synced themes keep working.
- Panel: ~92% opaque theme background, 28dp corners, accent-tinted hairline border.
- Header: floating glass pill (like the chat header) instead of a solid band; still the drag handle.
- Chips (Ask AI About My Screen, Capture, Pause, Stop, Start Agent, Copy, Clear chat): glass pills, accent for primary.
- Message box: glass pill; Send stays the accent circle. Provider picker: rounded glass card.
- Messages: chat-style bubbles (user = accent-tinted gradient, assistant = glass, small corner like the chat).
- Floating bubble: glossy sphere like the orb in the chat header; red capture dot and badge unchanged.
No behaviour, AI, provider, capture, agent, permission or window-flag code changed. Real background blur is not used (it blurs the whole window rectangle, not the rounded shape), so the panel is made mostly opaque for readability.
Not compiled or run on a device here.
