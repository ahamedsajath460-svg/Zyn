# AI web search: tap a photo -> AI + web + photos (stays in the app)
- Before: tapping a photo under a website opened the raw image in another site/browser.
- Now: the photo opens an in-app "Photo + AI search" window. The AI looks at the photo (vision), writes what it shows, makes a web query from it, then shows related websites, related photos under each site, and a short AI answer with [1], [2] sources.
- Tapping a photo inside that window repeats the same steps from the new photo. Photos in the website-photo and "More" windows behave the same.
- Code: script block "v18" in app/src/main/assets/a2z.html; one line `window.__wsKit` added in the AI web search patch.
- Needs a vision-capable model. If the photo cannot be read, the caption/file name is used for the search.
- Not run on a device (no Android SDK here); all script blocks pass a JS syntax check.

# Instagram search tool (v19)
- New tool "Instagram search" (Tools > AI Lab): searches ONLY instagram.com (site: filter) and shows photos under each result.
- Tapping a photo opens the in-app AI photo window, which also searches Instagram only.
- Instagram blocks some pages (private / login-only), those results show no photos; the title still opens the page.

# v20: bigger photos (280px tall, one per row in website photo windows), larger cards and text in web search, Instagram search and the photo window.

# Big photos
- Photos in AI web search, Instagram search, website-photo, More and photo-AI windows are now full width (one per row, up to 78% of screen height). Text size is unchanged. CSS block just before </body>.

# Instagram search fix
- Instagram has no open search API like YouTube (Basic Display API is closed; Graph API only does hashtag search / business-account lookup for your own Business or Creator login). So the tool searches in this order: Tavily (instagram.com filter) -> your search engines (Serper, Brave...) -> free DuckDuckGo page through proxies. Not tested with live network here.

# Chat long-press menu size
- The popup used id #cm, which the camera dialog also uses (full-screen CSS), so the menu stretched to full height. Renamed the popup to #cmenu; it is now small and fits its 5 items.

# Side panel
- Width min(72vw,290px) (was 84vw/360px); text slightly bigger (rows .98rem, menu 1rem, section titles .9rem). CSS at end of a2z.html.
