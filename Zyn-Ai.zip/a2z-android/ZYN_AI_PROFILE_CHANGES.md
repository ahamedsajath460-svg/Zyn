# Launcher icon and login animation

- Launcher icon: black logo, adaptive (transparent background, foreground + monochrome), plus legacy PNGs in `res/mipmap-*dpi`. Files: `AndroidManifest.xml`, `res/mipmap-anydpi-v26`, `res/mipmap-*dpi`, `res/drawable-nodpi/ic_launcher_foreground.png`.
- Login page: new animation in `assets/a2z.html` (`<style id="zyn-login-anim">` and the SVG inside `.ag-mid`).
- The earlier Zyn AI profile picture (image asset, `--zyn-ai`, `ZynLogo`) has been removed; floating bubble, panel header and login mark are back to the original look.
