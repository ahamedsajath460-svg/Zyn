
## Ask screen reading the panel again (regression fix)
- Cause: `AccessibilityWindowInfo.getTitle()` returns the window's `accessibilityTitle`, NOT `LayoutParams.title`, so the old "ZynFloatPanel" title check never matched and the panel could be picked as "the screen".
- Fix: both overlay windows now also set `accessibilityTitle` (API 28+). `AIAccessibilityService.isOwnPanel()` also treats any com.a2z.ai window as the panel unless the Zyn Ai app screen is really showing (`FrameStore.ownActivityVisible`, set by MainActivity onStart/onStop) or the window type is not TYPE_APPLICATION. Never falls back to the panel as the active window; extra pass for launchers that report an odd window type.
- If nothing else is readable, Ask screen now says so plainly (check Accessibility / turn on screen share) instead of describing the panel.
- Not compiled or tested on a device.
