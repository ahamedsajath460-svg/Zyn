plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.a2z.ai"
    compileSdk = 34
    defaultConfig { applicationId = "com.a2z.ai"; minSdk = 26; targetSdk = 34; versionCode = (System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 1); versionName = "1.0" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    lint { checkReleaseBuilds = false; abortOnError = false }
    // Fixed release signing key (keeps the SHA-1/SHA-256 stable for Firebase Google sign-in). Only used when KEYSTORE_FILE is set (CI).
    signingConfigs {
        create("release") {
            val f = System.getenv("KEYSTORE_FILE")
            if (f != null) { storeFile = file(f); storePassword = System.getenv("KEYSTORE_PASSWORD"); keyAlias = System.getenv("KEY_ALIAS"); keyPassword = System.getenv("KEY_PASSWORD") }
        }
    }
    buildTypes { release { isMinifyEnabled = false; if (System.getenv("KEYSTORE_FILE") != null) signingConfig = signingConfigs.getByName("release") } }
}
dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.webkit:webkit:1.11.0")
    implementation("com.google.android.gms:play-services-tasks:18.2.0")
    implementation("com.google.mlkit:text-recognition:16.0.1")            // on-device OCR (Latin)
    implementation("com.google.mlkit:text-recognition-devanagari:16.0.1") // on-device OCR (Hindi)
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.json:json:20231013")   // real org.json for JVM unit tests (Android stubs return defaults)
    implementation("com.google.android.gms:play-services-auth:21.2.0") // native Google Sign-In (ID token -> Firebase JS Auth)
}
