/* Zyn Ai Data Saver: less mobile data, faster replies.
   Loaded before the main script (fetch layer) and patches app functions once the page has loaded.
   Setting: Settings > Data saver (S.dsave): auto | bal | max | off. Default auto (Max on mobile data, Balanced on Wi-Fi). */
(function(){
'use strict';
if(window.__zynDataSave)return;window.__zynDataSave=1;

/* ---------- level ---------- */
function setting(){try{return(typeof S!=='undefined'&&S&&S.dsave)||'auto'}catch(e){return'auto'}}
function metered(){
  try{const N=window.A2ZNative;if(N&&typeof N.metered==='function')return!!N.metered()}catch(e){}
  try{const c=navigator.connection;if(c){if(c.saveData)return true;if(c.type)return!/^(wifi|ethernet)$/.test(c.type);if(c.effectiveType)return true}}catch(e){}
  return true;                                   /* unknown network: be careful with data */
}
function level(){const s=setting();if(s==='off'||s==='bal'||s==='max')return s;return metered()?'max':'bal'}
const LV={
  bal:{cap:90000,keep:2,maxUser:6000,maxAsst:5000,maxFile:30000,imgDist:4,mem:6000,img:640,jpg:.72,gen:.75},
  max:{cap:24000,keep:2,maxUser:2000,maxAsst:1800,maxFile:5000,imgDist:2,mem:2500,img:512,jpg:.65,gen:.6}
};
window.__zynDS={level,metered,setting};

/* ---------- 1. fetch layer: short-lived cache for lookups, so repeating a search/page read costs no data ---------- */
const rawFetch=window.fetch.bind(window);
const CACHE_RX=[
  /^https:\/\/[a-z-]+\.wikipedia\.org\/w\/api\.php/,/^https:\/\/nominatim\.openstreetmap\.org\//,/^https:\/\/api\.open-meteo\.com\//,
  /^https:\/\/api\.coingecko\.com\//,/^https:\/\/restcountries\.com\//,/^https:\/\/api\.openverse\.org\//,/^https:\/\/r\.jina\.ai\//,
  /^https:\/\/api\.allorigins\.win\/raw/,/^https:\/\/corsproxy\.io\//,/^https:\/\/api\.codetabs\.com\//,/^https:\/\/api\.tavily\.com\/search$/
];
const TTL=10*60*1000,MAXB=8*1024*1024,MAXONE=1.5*1024*1024;
const store=new Map();let bytes=0;
function put(k,v){const o=store.get(k);if(o){bytes-=o.n;store.delete(k)}store.set(k,v);bytes+=v.n;
  for(const [kk,vv] of store){if(bytes<=MAXB)break;bytes-=vv.n;store.delete(kk)}}
function keyOf(url,init){
  const m=((init&&init.method)||'GET').toUpperCase();
  if(m==='GET')return'G '+url;
  if(m==='POST'&&/api\.tavily\.com\/search$/.test(url)&&init&&typeof init.body==='string'){try{const b=JSON.parse(init.body);return'P '+url+' '+JSON.stringify([b.query,b.max_results,b.search_depth,b.include_answer,b.include_images,b.topic])}catch(e){}}
  return null;
}
window.fetch=function(input,init){
  try{
    const url=typeof input==='string'?input:(input&&input.url)||'';
    if(level()!=='off'&&typeof input==='string'&&CACHE_RX.some(r=>r.test(url))&&!(init&&(init.cache==='no-store'||init.cache==='reload'))){
      const k=keyOf(url,init);
      if(k){
        const hit=store.get(k);
        if(hit&&Date.now()-hit.t<TTL){put(k,hit);return Promise.resolve(new Response(hit.buf.slice(0),{status:hit.status,statusText:hit.st,headers:hit.h}))}
        return rawFetch(input,init).then(r=>{
          if(r.ok&&r.status===200){const c=r.clone();c.arrayBuffer().then(buf=>{if(buf.byteLength<=MAXONE)put(k,{t:Date.now(),buf,status:200,st:r.statusText,h:[...r.headers.entries()],n:buf.byteLength})}).catch(()=>{})}
          return r;
        });
      }
    }
  }catch(e){}
  return rawFetch(input,init);
};

/* Read only the first part of a page (enough for <head> meta tags), then close the connection. */
window.__zHead=async function(url,maxBytes,signal){
  maxBytes=maxBytes||65536;
  const r=await rawFetch(url,{signal});
  if(!r.ok||!r.body||!r.body.getReader)return await r.text();
  const rd=r.body.getReader(),dec=new TextDecoder();let out='',n=0;
  try{while(n<maxBytes){const {done,value}=await rd.read();if(done)break;n+=value.length;out+=dec.decode(value,{stream:true});if(/<\/head>/i.test(out))break}}
  finally{try{await rd.cancel()}catch(e){}}
  const e=out.search(/<\/head>/i);
  return e>=0?out.slice(0,e+7):out.slice(0,maxBytes);
};

/* ---------- 2. patches that need the app's own functions (run after page load) ---------- */
function cut(s,n){s=String(s||'');if(s.length<=n)return s;const h=Math.floor(n*.62);return s.slice(0,h)+'\n...[trimmed to save data]...\n'+s.slice(s.length-(n-h))}
function trimMsg(txt,role,L){
  return String(txt||'').split(/\n\n(?=\[File: )/).map((p,i)=>/^\[File: /.test(p)?cut(p,L.maxFile):cut(p,role==='user'?L.maxUser:L.maxAsst)).join('\n\n');
}
function squeeze(t,L){
  const out=[];let used=0;
  for(let i=t.length-1;i>=0;i--){
    const m=t[i],age=t.length-1-i,recent=age<L.keep;
    const txt=recent?m.text:trimMsg(m.text,m.role,L);
    if(!recent&&out.length>=L.keep&&used+txt.length>L.cap)break;      /* older messages are dropped once the budget is used */
    used+=txt.length;
    out.push({role:m.role,text:txt,img:(m.img&&m.img.length&&age<=L.imgDist)?m.img:[]});
  }
  out.reverse();
  while(out.length&&out[0].role!=='user')out.shift();
  return out;
}
function patch(){
  /* chat history: send a trimmed copy instead of up to 400,000 characters every message */
  try{
    if(typeof window.build==='function'&&!window.build.__ds){
      const orig=window.build;
      const nb=function(c){
        const lv=level();if(lv==='off')return orig(c);
        let t,old;
        try{old=S.depth;S.depth=1e9;t=orig(c)}finally{S.depth=old}      /* take everything, then squeeze it ourselves */
        if(!Array.isArray(t)||!t.length)return t;
        return squeeze(t,LV[lv]);
      };
      nb.__ds=1;window.build=nb;
    }
  }catch(e){}
  /* other-chat memory block that is added to every request */
  try{
    if(typeof window.crossMem==='function'&&!window.crossMem.__ds){
      const orig=window.crossMem;
      const nm=function(){const v=orig.apply(this,arguments),lv=level();if(lv==='off'||typeof v!=='string')return v;const cap=LV[lv].mem;return v.length>cap?v.slice(0,cap):v};
      nm.__ds=1;window.crossMem=nm;
    }
  }catch(e){}
  /* pictures you attach: smaller size and JPEG quality */
  try{
    if(typeof window.shrink==='function'&&typeof loadImg==='function'&&typeof el==='function'&&!window.shrink.__ds){
      const orig=window.shrink;
      const ns=async function(f){
        const lv=level();if(lv==='off')return orig(f);
        const L=LV[lv],u=URL.createObjectURL(f);
        try{
          const i=await loadImg(u),mx=Math.min(+S.imgsz||640,L.img),s=Math.min(1,mx/Math.max(i.naturalWidth,i.naturalHeight)),c=el('canvas');
          c.width=Math.max(1,i.naturalWidth*s|0);c.height=Math.max(1,i.naturalHeight*s|0);
          c.getContext('2d').drawImage(i,0,0,c.width,c.height);
          return c.toDataURL('image/jpeg',L.jpg);
        }finally{URL.revokeObjectURL(u)}
      };
      ns.__ds=1;window.shrink=ns;
    }
  }catch(e){}
  /* generated pictures: smaller download (Pollinations) */
  try{
    if(typeof SIZES==='object'&&SIZES&&!SIZES.__ds){
      const B={};Object.keys(SIZES).forEach(k=>{B[k]=SIZES[k].slice()});
      Object.keys(B).forEach(k=>{
        Object.defineProperty(SIZES,k,{configurable:true,enumerable:true,get(){
          const lv=level(),b=B[k];if(lv==='off')return b;const f=LV[lv].gen;
          return b.map(v=>Math.max(256,Math.round(v*f/64)*64));
        }});
      });
      Object.defineProperty(SIZES,'__ds',{value:1,enumerable:false});
    }
  }catch(e){}
  /* faster first byte: open the connections to the AI providers early */
  try{
    const seen=new Set(),add=u=>{try{const o=new URL(u).origin;if(seen.has(o)||/appassets\.androidplatform\.net/.test(o))return;seen.add(o);const l=document.createElement('link');l.rel='preconnect';l.href=o;l.crossOrigin='anonymous';document.head.appendChild(l)}catch(e){}};
    if(typeof P!=='undefined'&&Array.isArray(P))P.forEach(p=>{if(p&&p.on!==false&&p.endpoint&&(p.cat==null||p.cat==='chat'||p.cat==='image'))add(p.endpoint)});
    if(typeof __tavKeys==='function'&&(__tavKeys()||[]).length)add('https://api.tavily.com');
  }catch(e){}
}
function start(){patch();setTimeout(patch,1500);setTimeout(patch,5000)}   /* re-run: providers/keys are loaded asynchronously */
if(document.readyState==='complete')start();else window.addEventListener('load',start);
})();
