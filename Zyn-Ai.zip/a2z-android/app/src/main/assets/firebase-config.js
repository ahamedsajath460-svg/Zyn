/* PASTE YOUR EXISTING FIREBASE WEB APP CONFIG HERE (Firebase console > Project settings > Your apps > Web app > SDK setup).
   webClientId = the "Web client (auto created by Google Service)" OAuth client ID
   (Firebase console > Authentication > Sign-in method > Google > Web SDK configuration, or Google Cloud > APIs & Services > Credentials).
   It is needed by the Android APK to get a Google ID token. These values are public identifiers, not secrets. */
window.A2Z_FIREBASE = {
  apiKey: "AIzaSyAIHZsgZTH7Gu0tTUuGniHp-mYJbijNpfs",
  authDomain: "own-project-bdeee.firebaseapp.com",
  projectId: "own-project-bdeee",
  storageBucket: "own-project-bdeee.firebasestorage.app",
  messagingSenderId: "164047180415",
  appId: "1:164047180415:web:0a1883e9d35d4258e3e54a",
  webClientId: "164047180415-u3hls19od2dn6l4lknjeccntpasu9i5g.apps.googleusercontent.com"
};
