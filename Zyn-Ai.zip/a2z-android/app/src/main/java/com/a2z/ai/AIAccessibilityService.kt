package com.a2z.ai

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.Rect
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import org.json.JSONArray
import org.json.JSONObject

/** One readable / actionable element of the current window. [id] is only valid for the snapshot that produced it. */
class UiItem(val id: Int, val role: String, val text: String, val viewId: String, val clickable: Boolean, val scrollable: Boolean,
             val editable: Boolean, val password: Boolean, val bounds: Rect, val node: AccessibilityNodeInfo)

class Snap(val pkg: String, val items: List<UiItem>, val note: String?) {
    val hasPassword get() = items.any { it.password }
    fun hash(): Int = pkg.hashCode() * 31 + items.joinToString("|") { it.role + it.text + it.bounds.flattenToString() }.hashCode()
    fun toText(): String = buildString {
        append("App package: ").append(pkg).append('\n')
        items.forEach { i ->
            append('[').append(i.id).append("] ").append(i.role)
            if (i.text.isNotEmpty()) append(" \"").append(i.text).append('"')
            val f = ArrayList<String>(); if (i.clickable) f.add("clickable"); if (i.scrollable) f.add("scrollable"); if (i.editable) f.add("editable"); if (i.password) f.add("password-field")
            if (f.isNotEmpty()) append(" (").append(f.joinToString(",")).append(')')
            append('\n')
        }
    }
}

/**
 * Accessibility connection of the AI agent. The user must switch it on in Android Settings; the app never enables it.
 * It does NOT monitor anything: the single declared event type is ignored. It only reads the active window when the agent
 * (or "Ask about current screen") asks for it, and only performs supported node actions and global actions.
 * Never reads password fields, never reads the lock screen, never touches the Zyn Ai app itself.
 */
class AIAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile var instance: AIAccessibilityService? = null
        fun connected() = instance != null
        private const val MAX_NODES = 260
    }
    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) { /* intentionally unused: no monitoring */ }
    override fun onInterrupt() {}
    override fun onUnbind(i: Intent?): Boolean { instance = null; TouchIndicator.hide(); AgentController.hardStop("Accessibility access was turned off."); return super.onUnbind(i) }
    override fun onDestroy() { instance = null; TouchIndicator.hide(); super.onDestroy() }

    private fun shortRole(c: CharSequence?): String { val s = c?.toString() ?: return "View"; val n = s.substringAfterLast('.'); return if (n.isEmpty()) "View" else n }

    private fun isKeyguard(r: AccessibilityNodeInfo): Boolean {
        val p = r.packageName?.toString() ?: return false
        return p.contains("keyguard", true) || (p == "com.android.systemui" && r.className?.toString()?.contains("Keyguard", true) == true)
    }

    /**
     * The window the user is really looking at under Zyn Ai's floating panel: the top-most application window that is not the panel
     * (or its close target). While the user types in the panel it becomes the "active" window, so rootInActiveWindow would read the
     * panel itself; the window list does not have that problem. The lock screen always wins (never read anything behind it).
     * Falls back to the active window when the window list is not available.
     */
    private fun pickRoot(): AccessibilityNodeInfo? {
        try {
            val ws = windows
            if (ws != null && ws.isNotEmpty()) {
                for (w in ws) {                                    // top-most first
                    if (w.type != AccessibilityWindowInfo.TYPE_SYSTEM) continue
                    val r = try { w.root } catch (_: Throwable) { null } ?: continue
                    if (isKeyguard(r)) return r
                }
                for (w in ws) {
                    val t = w.title?.toString() ?: ""
                    if (t == "ZynFloatPanel" || t == "ZynFloatX") continue
                    if (w.type != AccessibilityWindowInfo.TYPE_APPLICATION) continue
                    val r = try { w.root } catch (_: Throwable) { null } ?: continue
                    if (r.packageName == null) continue
                    return r
                }
            }
        } catch (_: Throwable) { }
        return try { rootInActiveWindow } catch (_: Throwable) { null }
    }

    /** Reads the screen under the floating panel. Returns null if nothing readable (no window, secure window, lock screen). */
    fun snapshot(): Snap? {
        val root = pickRoot() ?: return null
        val pkg = root.packageName?.toString() ?: return null
        if (pkg.contains("keyguard", true) || (pkg == "com.android.systemui" && root.className?.toString()?.contains("Keyguard", true) == true))
            return Snap(pkg, emptyList(), "The lock screen is showing. The agent never reads or bypasses the lock screen.")
        val out = ArrayList<UiItem>(); val r = Rect()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || out.size >= MAX_NODES) return
            if (n.isVisibleToUser) {
                val pw = n.isPassword
                var t = (n.text?.toString() ?: n.contentDescription?.toString() ?: "").trim().replace('\n', ' ')
                if (pw) t = ""
                if (t.length > 90) t = t.take(90) + "…"
                if (t.isNotEmpty() || n.isClickable || n.isScrollable || n.isEditable) {
                    n.getBoundsInScreen(r)
                    out.add(UiItem(out.size + 1, shortRole(n.className), t, n.viewIdResourceName ?: "", n.isClickable, n.isScrollable, n.isEditable, pw, Rect(r), n))
                }
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return Snap(pkg, out, if (out.isEmpty()) "No readable elements. The window may be protected (FLAG_SECURE), custom-drawn, or not accessible." else null)
    }

    fun click(i: UiItem): Boolean {
        if (!i.node.refresh()) return false
        var n: AccessibilityNodeInfo? = i.node
        while (n != null && !n.isClickable) n = n.parent
        return n?.performAction(AccessibilityNodeInfo.ACTION_CLICK) ?: false
    }
    fun focus(i: UiItem): Boolean {
        if (!i.node.refresh()) return false
        return i.node.performAction(AccessibilityNodeInfo.ACTION_FOCUS) || i.node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }
    fun setText(i: UiItem, text: String): Boolean {
        if (i.password || !i.editable || !i.node.refresh()) return false
        val b = Bundle(); b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        return i.node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    }
    fun scroll(i: UiItem, forward: Boolean): Boolean = scroll(i, if (forward) "down" else "up")
    /** dir: up | down (vertical) or left | right (horizontal, only where the container supports it). */
    fun scroll(i: UiItem, dir: String): Boolean {
        if (!i.node.refresh()) return false
        val action = when (dir) {
            "up" -> AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
            "left" -> AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_LEFT.id
            "right" -> AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_RIGHT.id
            else -> AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
        }
        return i.node.performAction(action)
    }
    /** True only if Android really granted this service the gesture capability (user enabled it with canPerformGestures). */
    fun gestureCapable(): Boolean = try { (serviceInfo.capabilities and android.accessibilityservice.AccessibilityServiceInfo.CAPABILITY_CAN_PERFORM_GESTURES) != 0 } catch (_: Throwable) { false }
    fun centerOf(i: UiItem): Pair<Int, Int> = i.bounds.centerX() to i.bounds.centerY()
    fun global(kind: String): Boolean = when (kind) {
        "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
        "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
        "notifications" -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
        "recents" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
        else -> false
    }
    /** JSON of the current UI for the chat ("Ask about current screen" without screen sharing). Password values are never included. */
    fun snapshotJson(): String {
        val s = snapshot() ?: return JSONObject().put("ok", false).put("error", "Nothing readable on the active window.").toString()
        val a = JSONArray(); s.items.forEach { a.put(JSONObject().put("id", it.id).put("role", it.role).put("text", it.text).put("clickable", it.clickable).put("scrollable", it.scrollable).put("editable", it.editable)) }
        return JSONObject().put("ok", true).put("pkg", s.pkg).put("note", s.note ?: "").put("text", s.toText()).put("items", a).toString()
    }
}
