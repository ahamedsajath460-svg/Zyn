package com.a2z.ai

import org.json.JSONArray
import org.json.JSONObject

/**
 * Provider adapter layer. Different providers (Gemini, OpenAI, Claude, DeepSeek, Groq, OpenRouter, Mistral, Together, custom) wrap the
 * same instruction differently: markdown fences, prose around the JSON, "type" at the top level, tool-call style
 * {"name":..,"arguments":..}, string ids, alias names ("tap", "type"). [parse] turns all of that into ONE normalised object:
 * {"explain","expect","next","action":{"type","id","id2","x","y","x2","y2","dir","edge","text","app","result"}}.
 * It only normalises. Whether the action is allowed is decided afterwards by [AgentPolicy.validate].
 */
object AgentActions {
    private val ALIAS = mapOf(
        "click" to "click", "press" to "click", "select" to "click", "touch" to "click", "click_element" to "click",
        "tap" to "tap", "tap_xy" to "tap", "tap_at" to "tap",
        "double_tap" to "double_tap", "doubletap" to "double_tap", "double_click" to "double_tap", "double-tap" to "double_tap",
        "long_press" to "long_press", "longpress" to "long_press", "long_click" to "long_press", "long-press" to "long_press", "hold" to "long_press",
        "swipe" to "swipe", "fling" to "swipe", "drag" to "drag", "drag_and_drop" to "drag",
        "set_text" to "set_text", "type" to "set_text", "input" to "set_text", "enter_text" to "set_text", "write" to "set_text", "fill" to "set_text", "input_text" to "set_text",
        "focus" to "focus", "scroll" to "scroll", "scroll_edge" to "scroll_edge", "find" to "find", "search" to "find",
        "back" to "back", "go_back" to "back", "home" to "home", "go_home" to "home", "notifications" to "notifications",
        "open_app" to "open_app", "launch_app" to "open_app", "open" to "open_app", "launch" to "open_app", "open_settings" to "open_settings",
        "done" to "done", "finish" to "done", "complete" to "done", "finished" to "done", "end" to "done")

    /** All balanced {...} candidates in [t], outermost first, ignoring braces inside strings. */
    fun candidates(t: String): List<String> {
        val out = ArrayList<String>(); var i = 0
        while (i < t.length) {
            if (t[i] != '{') { i++; continue }
            var d = 0; var inStr = false; var esc = false; var j = i; var end = -1
            while (j < t.length) {
                val c = t[j]
                if (inStr) { if (esc) esc = false else if (c == '\\') esc = true else if (c == '"') inStr = false }
                else if (c == '"') inStr = true else if (c == '{') d++ else if (c == '}') { d--; if (d == 0) { end = j; break } }
                j++
            }
            if (end < 0) break
            out.add(t.substring(i, end + 1)); i = end + 1
        }
        return out
    }

    private fun obj(v: Any?): JSONObject? = when (v) {
        is JSONObject -> v
        is String -> try { JSONObject(v) } catch (_: Throwable) { null }
        else -> null
    }

    /** Finds the object that actually holds the action in any of the known provider shapes. */
    private fun locate(o: JSONObject): Pair<JSONObject, JSONObject>? {   // (outer with explain/expect, action holder)
        obj(o.opt("action"))?.let { return o to it }
        (o.optJSONArray("actions"))?.optJSONObject(0)?.let { return o to (obj(it.opt("action")) ?: it) }
        val tc = o.optJSONArray("tool_calls")?.optJSONObject(0) ?: o.optJSONObject("function_call") ?: o.optJSONObject("tool_call")
        if (tc != null) {
            val f = tc.optJSONObject("function") ?: tc
            val name = f.optString("name"); val args = obj(f.opt("arguments")) ?: obj(f.opt("input")) ?: JSONObject()
            if (name.isNotEmpty()) return o to JSONObject(args.toString()).put("type", name)
        }
        if (o.has("name") && (o.has("arguments") || o.has("input") || o.has("parameters"))) {
            val args = obj(o.opt("arguments")) ?: obj(o.opt("input")) ?: obj(o.opt("parameters")) ?: JSONObject()
            return o to JSONObject(args.toString()).put("type", o.optString("name"))
        }
        if (o.opt("action") is String) return o to JSONObject(o.toString()).put("type", o.optString("action"))
        if (o.has("type") || o.has("tool")) return o to JSONObject(o.toString()).apply { if (!has("type")) put("type", optString("tool")) }
        return null
    }

    private fun num(v: Any?): Int? = when (v) {
        is Number -> v.toDouble().toInt()
        is String -> v.trim().removePrefix("#").toDoubleOrNull()?.toInt()
        else -> null
    }

    fun normalizeAction(raw: JSONObject): JSONObject? {
        var t = raw.optString("type").trim().lowercase().replace(' ', '_')
        var dir = raw.optString("dir", raw.optString("direction", "")).trim().lowercase()
        if (t.startsWith("scroll_") && t != "scroll_edge") { dir = t.removePrefix("scroll_"); t = "scroll" }
        val type = ALIAS[t] ?: return null
        val a = JSONObject().put("type", type)
        listOf("id" to listOf("id", "element_id", "element", "index"), "id2" to listOf("id2", "to_id", "target_id"),
            "x" to listOf("x", "x1", "from_x"), "y" to listOf("y", "y1", "from_y"), "x2" to listOf("x2", "to_x", "end_x"), "y2" to listOf("y2", "to_y", "end_y"))
            .forEach { (k, names) -> names.firstNotNullOfOrNull { n -> if (raw.has(n)) num(raw.opt(n)) else null }?.let { a.put(k, it) } }
        if (dir in setOf("forward", "next")) dir = "down"; if (dir in setOf("backward", "previous", "prev")) dir = "up"
        if (dir.isNotEmpty()) a.put("dir", dir)
        raw.optString("edge").takeIf { it.isNotEmpty() }?.let { a.put("edge", it.lowercase()) }
        (raw.optString("text").ifEmpty { raw.optString("value").ifEmpty { raw.optString("query") } }).takeIf { it.isNotEmpty() }?.let { a.put("text", it) }
        (raw.optString("app").ifEmpty { raw.optString("app_name").ifEmpty { raw.optString("name").takeIf { type == "open_app" } ?: "" } }).takeIf { it.isNotEmpty() }?.let { a.put("app", it) }
        raw.optString("result").takeIf { it.isNotEmpty() }?.let { a.put("result", it) }
        return a
    }

    /** Returns the normalised command, or null if [text] contains no recognisable action. */
    fun parse(text: String): JSONObject? {
        val clean = text.replace("```json", "").replace("```", "")
        for (c in candidates(clean)) {
            val o = try { JSONObject(c) } catch (_: Throwable) { continue }
            val (outer, holder) = locate(o) ?: continue
            val a = normalizeAction(holder) ?: continue
            return JSONObject().put("explain", outer.optString("explain", holder.optString("explain", "")))
                .put("expect", outer.optString("expect", holder.optString("expect", "")))
                .put("next", outer.optString("next", holder.optString("next", ""))).put("action", a)
        }
        return null
    }
}
