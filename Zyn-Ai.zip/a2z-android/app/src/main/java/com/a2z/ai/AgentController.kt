package com.a2z.ai

import android.content.Context
import android.content.Intent
import android.provider.Settings
import org.json.JSONArray
import org.json.JSONObject

/**
 * Policy, state and permission checks of the AI agent (single source of truth, native side).
 * The AI model can only PROPOSE actions as JSON. Whether an action runs is decided here, in [AgentPolicy], and by the user's
 * taps on the native confirmation card; nothing the AI or any screen text says can approve an action.
 *
 * Operating modes: "readonly" (explain only), "manual" (default: every action is previewed and confirmed),
 * "trusted" (only the predefined low-risk actions in [AgentPolicy.LOW_RISK] run without asking; sensitive ones never do).
 */
object AgentController {
    @Volatile var enabled = false           // "AI Agent" switch. Off = no task can start.
    @Volatile var useScreen = true          // add screen-share OCR/frames when sharing is on
    @Volatile var mode = "manual"           // readonly | manual | supervised | trusted (= Restricted Automation)
    val readOnly get() = mode == "readonly"
    val trusted get() = mode == "trusted"
    val supervised get() = mode == "supervised"
    @Volatile var voice = false             // spoken progress and results (native TextToSpeech)
    @Volatile var lang = "en-US"
    @Volatile var maxSteps = 10             // per task, clamped to 3..15 by the runner
    @Volatile var keepHistory = true
    @Volatile var state = "idle"            // idle | planning | waiting | running | paused
    @Volatile var status = "Agent is idle"
    @Volatile var paused = false
    @Volatile var stopRequested = false
    @Volatile var panel = false             // optional control bar kept on screen while idle
    @Volatile var onEvent: ((String, String) -> Unit)? = null
    @Volatile var onSpeak: ((String) -> Unit)? = null
    @Volatile var onSpeakStop: (() -> Unit)? = null
    val approvedLow = HashSet<String>()     // Trusted mode: non-sensitive actions the user already approved during THIS task

    // ---------- task progress (shown in the app and the control bar) ----------
    private var pTask = ""; private var pStep = 0; private var pMax = 0; private var pCur = ""; @Volatile var pNext = ""
    private val pQueue = ArrayList<String>(); private val pDone = ArrayList<String>(); private val pFail = ArrayList<String>()
    @Synchronized fun progressStart(task: String, max: Int) { pTask = task; pStep = 0; pMax = max; pCur = ""; pNext = ""; pQueue.clear(); pDone.clear(); pFail.clear() }
    @Synchronized fun progressQueue(q: List<String>) { pQueue.clear(); pQueue.addAll(q) }
    @Synchronized fun progressStep(n: Int, cur: String) { pStep = n; pCur = cur }
    @Synchronized fun progressDone(s: String) { pDone.add(s.take(120)); while (pDone.size > 20) pDone.removeAt(0) }
    @Synchronized fun progressFail(s: String) { pFail.add(s.take(160)); while (pFail.size > 20) pFail.removeAt(0) }
    @Synchronized fun progressJson(): JSONObject = JSONObject().put("task", pTask).put("step", pStep).put("max", pMax).put("current", pCur).put("next", pNext)
        .put("queue", JSONArray(pQueue)).put("completed", JSONArray(pDone)).put("failed", JSONArray(pFail))

    fun emit(t: String, d: String) { try { onEvent?.invoke(t, d) } catch (_: Throwable) { } }
    fun set(s: String, text: String) {
        state = s; status = text
        emit("state", JSONObject().put("state", s).put("status", text).toString())
        AgentOverlay.setStatus(text, s == "paused")
    }
    /** Spoken feedback through native Android TextToSpeech (only when Voice Control is on). */
    fun say(text: String) { if (voice && text.isNotBlank()) try { onSpeak?.invoke(text) } catch (_: Throwable) { } }

    fun config(json: String) {
        val o = JSONObject(json)
        enabled = o.optBoolean("enabled", enabled); useScreen = o.optBoolean("screen", useScreen)
        mode = when {
            o.has("mode") -> o.optString("mode").let { if (it == "readonly" || it == "trusted" || it == "supervised") it else "manual" }
            o.has("readOnly") || o.has("approval") -> if (o.optBoolean("readOnly", false)) "readonly" else if (o.optString("approval", "manual") == "trusted") "trusted" else "manual"
            else -> mode
        }
        TouchIndicator.enabled = o.optBoolean("touchIndicator", TouchIndicator.enabled); if (!TouchIndicator.enabled) TouchIndicator.hide()
        voice = o.optBoolean("voice", voice); lang = o.optString("lang", lang).ifBlank { "en-US" }
        maxSteps = o.optInt("maxSteps", maxSteps).coerceIn(3, 15); keepHistory = o.optBoolean("keepHistory", keepHistory)
        if (mode != "trusted") approvedLow.clear()
        if (!enabled) hardStop("AI Agent was switched off.")
    }
    fun status(ctx: Context): String = JSONObject().put("enabled", enabled).put("screen", useScreen).put("mode", mode).put("voice", voice).put("lang", lang)
        .put("maxSteps", maxSteps).put("keepHistory", keepHistory).put("state", state).put("status", status).put("accessibility", AIAccessibilityService.connected()).put("gestures", AIAccessibilityService.instance?.gestureCapable() == true).put("touchIndicator", TouchIndicator.enabled)
        .put("overlay", FloatPerm.has(ctx)).put("panel", panel).put("share", FrameStore.state).put("progress", progressJson()).toString()

    fun pause() { if (state == "running" || state == "planning") { paused = true; set("paused", "Agent paused"); say("Agent paused") } }
    fun resume() { if (paused) { paused = false; set("running", "Agent resumed"); say("Agent resumed") } }

    /** Emergency stop: ends the task at once, closes every agent overlay, silences speech and forgets the UI snapshot. Safe from any thread. */
    fun hardStop(reason: String) {
        val was = state != "idle"
        stopRequested = true; paused = false
        AgentRunner.interrupt()
        AgentOverlay.hideAll(panel); TouchIndicator.hide()
        state = "idle"; status = "Agent stopped"
        if (was) {
            AgentHistory.end("stopped", reason)
            emit("result", JSONObject().put("ok", false).put("text", "Stopped. $reason").toString())
            try { onSpeakStop?.invoke() } catch (_: Throwable) { }
            say("Agent stopped")
        }
        emit("state", JSONObject().put("state", "idle").put("status", status).toString())
    }

    /** Voice control phrases (English / Tamil / Tanglish). Returns stopped | paused | resumed | idle (nothing running) | "" (not a control phrase). */
    fun voiceControl(text: String): String = when (AgentPolicy.voiceCommand(text)) {
        "stop" -> { hardStop("Voice stop command."); "stopped" }
        "pause" -> if (state == "running" || state == "planning") { pause(); "paused" } else "idle"
        "resume" -> if (paused) { resume(); "resumed" } else "idle"
        else -> ""
    }

    fun openAccessibilitySettings(ctx: Context) { try { ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) { } }

    fun isStopPhrase(t: String) = AgentPolicy.voiceCommand(t) == "stop"

    private val sensitive = Regex("(?i)\\b(send|post|publish|tweet|share|delete|remove|erase|clear data|wipe|reset|pay|buy|purchase|order|checkout|subscribe|donate|transfer|withdraw|deposit|bank|wallet|upi|card|credit|debit|cvv|recharge|paypal|gpay|phonepe|paytm|install|uninstall|allow|grant|permit|permission|accessibility|device admin|sign out|log out|logout|password|passcode|pin|otp|security|account|unlock|factory)\\b|அனுப்பு|நீக்கு|வாங்கு|செலுத்து|அழி")
    fun isHigh(type: String, target: String, screenText: String = "", hasElement: Boolean = true): Boolean =
        type == "set_text" || type == "open_app" || type == "open_settings" ||
        (type in setOf("click", "focus", "tap", "double_tap", "long_press", "drag") && (!hasElement || sensitive.containsMatchIn(target) || sensitiveScreen.containsMatchIn(screenText)))
    /** Screens where ANY tap can be consequential (payment, order, deletion, security). */
    private val sensitiveScreen = Regex("(?i)(place order|pay now|confirm payment|total amount|delete account|delete all|factory reset|erase all|send money|transfer funds|unknown apps|device admin|uninstall)")
}
