package com.a2z.ai

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.util.DisplayMetrics
import android.view.ViewConfiguration
import android.view.WindowManager
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Real touch gestures through AccessibilityService.dispatchGesture(). Every call blocks (worker thread only, never the main thread)
 * until Android reports the gesture completed or cancelled, or [TIMEOUT_MS] passes. Returns (ok, message). Nothing is simulated.
 * Coordinates are real screen pixels; use [toPx] to convert the model's 0..1000 normalised coordinates.
 */
object AgentGestures {
    const val TIMEOUT_MS = 4000L

    @Suppress("DEPRECATION")
    fun screen(s: AccessibilityService): Pair<Int, Int> {
        val dm = DisplayMetrics()
        val wm = s.getSystemService(android.content.Context.WINDOW_SERVICE) as WindowManager
        wm.defaultDisplay.getRealMetrics(dm)
        return dm.widthPixels to dm.heightPixels
    }
    /** 0..1000 normalised -> screen pixels (clamped inside the screen). */
    fun toPx(s: AccessibilityService, nx: Int, ny: Int): Pair<Int, Int> {
        val (w, h) = screen(s)
        return (nx.coerceIn(0, 1000) * (w - 1) / 1000) to (ny.coerceIn(0, 1000) * (h - 1) / 1000)
    }

    private fun stroke(x: Float, y: Float, start: Long, dur: Long) =
        GestureDescription.StrokeDescription(Path().apply { moveTo(x, y) }, start, dur.coerceAtLeast(1))

    /** Waits [ms] on the worker thread (the finger flies in), but gives up at once if Stop was pressed. */
    private fun pause(ms: Long) {
        var l = ms
        while (l > 0 && !AgentController.stopRequested) {
            try { Thread.sleep(minOf(l, 20L)) } catch (_: InterruptedException) { Thread.currentThread().interrupt(); return }
            l -= 20L
        }
    }

    /**
     * Dispatches the gesture and waits for Android's result. When [t] is given and the touch indicator is on, the indicator is
     * prepared before, fired right before dispatchGesture(), and finished from the real onCompleted / onCancelled callback.
     */
    private fun run(s: AccessibilityService, g: GestureDescription, okMsg: String, t: TouchSpec? = null): Pair<Boolean, String> {
        val tt = if (TouchIndicator.enabled) t else null
        if (tt != null && tt.first) { pause(TouchIndicator.prepare(s, tt)); if (AgentController.stopRequested) return false to "stopped before the gesture" }
        val latch = CountDownLatch(1); var done = false
        val fin = AtomicBoolean(false)
        fun end(ok: Boolean) { if (tt != null && fin.compareAndSet(false, true)) TouchIndicator.finish(tt, ok) }
        tt?.let { TouchIndicator.fire(it) }
        val accepted = try {
            s.dispatchGesture(g, object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(d: GestureDescription?) { done = true; end(true); latch.countDown() }
                override fun onCancelled(d: GestureDescription?) { end(false); latch.countDown() }
            }, null)
        } catch (e: Throwable) { end(false); return false to "Android refused the gesture: ${e.message}" }
        if (!accepted) { end(false); return false to "Android did not accept the gesture (gestures not enabled for this service?)" }
        if (!latch.await(TIMEOUT_MS, TimeUnit.MILLISECONDS)) { end(false); return false to "the gesture timed out" }
        return if (done) true to okMsg else false to "Android cancelled the gesture (another touch or a protected screen)"
    }

    /**
     * Touch indicator for a node action (ACTION_CLICK / FOCUS) that has no gesture of its own: flies the finger to the element and
     * fires the ripple now; the caller performs the action right after and then calls TouchIndicator.finish(spec, realResult).
     * Returns null when the indicator is off, the element is empty, or it is a password field (never pointed at).
     */
    fun showClick(s: AccessibilityService, item: UiItem): TouchSpec? {
        if (!TouchIndicator.enabled || item.password || item.bounds.width() <= 0 || item.bounds.height() <= 0) return null
        val t = TouchSpec("tap", item.bounds.centerX(), item.bounds.centerY(), durationMs = 60, bounds = item.bounds)
        pause(TouchIndicator.prepare(s, t)); TouchIndicator.fire(t)
        return t
    }

    fun tap(s: AccessibilityService, x: Int, y: Int, hl: Rect? = null, ind: Boolean = true) = run(s, GestureDescription.Builder().addStroke(stroke(x.toFloat(), y.toFloat(), 0, 60)).build(), "tapped at $x,$y",
        if (ind) TouchSpec("tap", x, y, durationMs = 60, bounds = hl) else null)
    fun doubleTap(s: AccessibilityService, x: Int, y: Int, hl: Rect? = null) = run(s, GestureDescription.Builder()
        .addStroke(stroke(x.toFloat(), y.toFloat(), 0, 50)).addStroke(stroke(x.toFloat(), y.toFloat(), 150, 50)).build(), "double-tapped at $x,$y",
        TouchSpec("double_tap", x, y, durationMs = 200, bounds = hl))
    fun longPress(s: AccessibilityService, x: Int, y: Int, hl: Rect? = null): Pair<Boolean, String> {
        val ms = ViewConfiguration.getLongPressTimeout() + 300L
        return run(s, GestureDescription.Builder().addStroke(stroke(x.toFloat(), y.toFloat(), 0, ms)).build(), "long-pressed at $x,$y",
            TouchSpec("long_press", x, y, durationMs = ms, bounds = hl))
    }
    fun swipe(s: AccessibilityService, x1: Int, y1: Int, x2: Int, y2: Int, ms: Long = 350, hl: Rect? = null): Pair<Boolean, String> {
        val p = Path().apply { moveTo(x1.toFloat(), y1.toFloat()); lineTo(x2.toFloat(), y2.toFloat()) }
        val dur = ms.coerceIn(100, 1500)
        return run(s, GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, dur)).build(), "swiped $x1,$y1 to $x2,$y2",
            TouchSpec("swipe", x1, y1, x2, y2, dur, bounds = hl, moving = true))
    }
    /** Press and hold at the start for ~500 ms, then move to the end (drag and drop, reorder, slider handles). Uses a continued stroke (API 26+). */
    fun drag(s: AccessibilityService, x1: Int, y1: Int, x2: Int, y2: Int, hl: Rect? = null, hl2: Rect? = null): Pair<Boolean, String> {
        val hold = GestureDescription.StrokeDescription(Path().apply { moveTo(x1.toFloat(), y1.toFloat()) }, 0, 500, true)
        val move = hold.continueStroke(Path().apply { moveTo(x1.toFloat(), y1.toFloat()); lineTo(x2.toFloat(), y2.toFloat()) }, 0, 600, false)
        val a = run(s, GestureDescription.Builder().addStroke(hold).build(), "held", TouchSpec("drag", x1, y1, durationMs = 500, bounds = hl, last = false))
        if (!a.first) return a
        return run(s, GestureDescription.Builder().addStroke(move).build(), "dragged $x1,$y1 to $x2,$y2",
            TouchSpec("drag", x1, y1, x2, y2, 600, bounds2 = hl2, first = false, moving = true))
    }
    /** Swipe a full-screen scroll in [dir] (the content moves the opposite way, like a finger). */
    fun scrollScreen(s: AccessibilityService, dir: String): Pair<Boolean, String> {
        val (w, h) = screen(s); val cx = w / 2; val cy = h / 2
        return when (dir) {
            "down" -> swipe(s, cx, h * 7 / 10, cx, h * 3 / 10)
            "up" -> swipe(s, cx, h * 3 / 10, cx, h * 7 / 10)
            "left" -> swipe(s, w * 3 / 10, cy, w * 7 / 10, cy)
            "right" -> swipe(s, w * 7 / 10, cy, w * 3 / 10, cy)
            else -> false to "invalid direction"
        }
    }
}
