package com.a2z.ai

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Persistent, privacy-conscious activity log of the AI agent (app-private file agent_history.json, never uploaded).
 * Stores: instruction, start time, mode, planned steps, executed actions with their verification result, errors, final status.
 * Never stores: screenshots, screen text, typed text, or answers to screen questions. Digit runs of 4+ and password/OTP-like
 * fragments are masked. Can be switched off (keepHistory) and cleared at any time.
 */
object AgentHistory {
    private const val MAX_TASKS = 40
    private const val MAX_ACTIONS = 30
    private var file: File? = null
    private val items = ArrayList<JSONObject>()
    private var cur: JSONObject? = null

    @Synchronized fun init(c: Context) {
        if (file != null) return
        val f = File(c.applicationContext.filesDir, "agent_history.json"); file = f
        try {
            if (f.exists()) { val a = JSONArray(f.readText()); for (i in 0 until a.length()) items.add(a.getJSONObject(i)) }
        } catch (_: Throwable) { items.clear() }
        for (o in items) if (o.optString("status") == "running") o.put("status", "interrupted")   // process died mid-task
    }

    private fun save() {
        val f = file ?: return
        try {
            val a = JSONArray(); for (o in items) a.put(o)
            val tmp = File(f.parentFile, f.name + ".tmp"); tmp.writeText(a.toString())
            if (!tmp.renameTo(f)) { f.writeText(a.toString()); tmp.delete() }
        } catch (_: Throwable) { }
    }

    @Synchronized fun begin(task: String, mode: String) {
        if (!AgentController.keepHistory) { cur = null; return }
        val o = JSONObject().put("id", System.currentTimeMillis()).put("task", AgentPolicy.redact(task, 300)).put("start", System.currentTimeMillis())
            .put("mode", mode).put("status", "running").put("plan", JSONArray()).put("actions", JSONArray()).put("errors", JSONArray()).put("result", "")
        cur = o; items.add(o)
        while (items.size > MAX_TASKS) items.removeAt(0)
        save()
    }
    @Synchronized fun plan(steps: List<String>) {
        val o = cur ?: return
        val a = JSONArray(); for (s in steps) a.put(AgentPolicy.redact(s)); o.put("plan", a); save()
    }
    @Synchronized fun action(desc: String, ok: Boolean, result: String) {
        val o = cur ?: return
        val a = o.getJSONArray("actions"); if (a.length() >= MAX_ACTIONS) return
        a.put(JSONObject().put("at", System.currentTimeMillis()).put("action", AgentPolicy.redact(desc)).put("ok", ok).put("result", AgentPolicy.redact(result))); save()
    }
    @Synchronized fun error(msg: String) {
        val o = cur ?: return
        o.getJSONArray("errors").put(AgentPolicy.redact(msg)); save()
    }
    /** Idempotent: a second call for the same task does nothing. */
    @Synchronized fun end(status: String, text: String) {
        val o = cur ?: return
        o.put("status", status).put("end", System.currentTimeMillis()).put("result", AgentPolicy.redact(text, 400)); cur = null; save()
    }
    @Synchronized fun toJson(): String { val a = JSONArray(); for (i in items.indices.reversed()) a.put(items[i]); return a.toString() }
    @Synchronized fun clear() { items.clear(); cur = null; save() }
}
