package com.a2z.ai

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/**
 * The typing half of [AgentBar]: a see-through screen with one input bar that rises above the keyboard (an overlay window cannot
 * reliably take the keyboard, an activity can). Send hands the text to [AgentBar.submit] and closes itself, so the agent then reads
 * the app that was open before, not this screen.
 */
class AgentInputActivity : Activity() {
    private fun dp(v: Int) = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE or WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE)
        window.setBackgroundDrawable(ColorDrawable(Color.parseColor("#66000000")))
        val root = FrameLayout(this).apply { setOnClickListener { close() } }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; isClickable = true
            background = GradientDrawable().apply { setColor(Color.parseColor("#FF161B26")); cornerRadius = dp(28).toFloat() }
            setPadding(dp(18), dp(6), dp(8), dp(6))
        }
        val et = EditText(this).apply {
            hint = "Tell the agent what to do\u2026"; setHintTextColor(Color.parseColor("#8A93A6")); setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f); background = null; maxLines = 3
            setRawInputType(InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES)
            imeOptions = EditorInfo.IME_ACTION_SEND; setHorizontallyScrolling(false)
        }
        fun send() {
            val t = et.text.toString().trim()
            if (t.isEmpty()) return
            close()
            Handler(Looper.getMainLooper()).postDelayed({ AgentBar.submit(t) }, 300)     // let this screen leave first
        }
        et.setOnEditorActionListener { _, a, _ -> if (a == EditorInfo.IME_ACTION_SEND || a == EditorInfo.IME_ACTION_DONE) { send(); true } else false }
        val go = TextView(this).apply {
            text = "Go"; setTextColor(Color.WHITE); setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            background = GradientDrawable().apply { setColor(Color.parseColor("#4C8DFF")); cornerRadius = dp(20).toFloat() }
            setPadding(dp(16), dp(9), dp(16), dp(9)); setOnClickListener { send() }
        }
        bar.addView(et, LinearLayout.LayoutParams(0, -2, 1f)); bar.addView(go)
        root.addView(bar, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply { setMargins(dp(10), 0, dp(10), dp(10)) })
        setContentView(root)
        et.requestFocus()
    }

    private fun close() { finish(); overridePendingTransition(0, 0) }
}
