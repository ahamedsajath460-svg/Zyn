package com.a2z.ai

import android.content.Context
import android.content.Intent
import android.os.Build
import org.json.JSONObject

/**
 * Compatibility facade. The agent no longer has a window of its own: its status, controls and the action-confirmation card
 * are part of the ONE unified floating panel ([FloatingPanelController]). Existing callers (AgentController, AgentRunner, the app's
 * bridge) keep working unchanged. Nothing here creates a window.
 */
object AgentOverlay {
    // ---- Settings > Floating panel (kept for the app's settings page). Only [opacity] still has a visible effect (panel transparency default). ----
    private val ALL_BTNS = listOf("start", "ask", "explain", "voice", "pause", "access", "chat")
    @Volatile var btns: Set<String> = ALL_BTNS.toSet()
    @Volatile var atTop = true
    @Volatile var startMin = false
    @Volatile var opacity = 95

    fun configure(json: String) {
        val o = JSONObject(json)
        o.optJSONArray("buttons")?.let { a -> btns = (0 until a.length()).map { a.optString(it) }.filter { it in ALL_BTNS }.toSet() }
        if (o.has("pos")) atTop = o.optString("pos") != "bottom"
        startMin = o.optBoolean("startMin", startMin)
        opacity = o.optInt("opacity", opacity).coerceIn(40, 100)
    }

    fun reload(ctx: Context) { FloatingPanelController.instance?.pushStatus(true) }

    /** Makes sure the single floating panel service is running (needs the overlay permission). */
    private fun ensureService(ctx: Context): Boolean {
        if (FloatingPanelController.instance != null) return true
        if (!FloatPerm.has(ctx)) return false
        return try {
            val i = Intent(ctx.applicationContext, FloatingAssistantService::class.java).setAction(FloatingAssistantService.ACT_START)
            if (Build.VERSION.SDK_INT >= 26) ctx.applicationContext.startForegroundService(i) else ctx.applicationContext.startService(i)
            true
        } catch (_: Throwable) { false }
    }

    fun showBar(ctx: Context) { ensureService(ctx); FloatingPanelController.instance?.pushStatus(true) }

    fun setStatus(text: String, paused: Boolean) { FloatingPanelController.instance?.pushStatus(true) }

    /** [cb] gets true only from the user's tap on Confirm inside the panel. */
    fun confirm(ctx: Context, title: String, lines: List<String>, cb: (Boolean) -> Unit) {
        val c = FloatingPanelController.instance
        if (c != null) { c.showConfirm(title, lines, cb); return }
        if (!ensureService(ctx)) { cb(false); return }
        FloatingPanelController.queued = FloatingPanelController.Confirm(title, lines, cb)
    }

    fun hideAll(keepBar: Boolean = false) { FloatingPanelController.instance?.hideConfirm(); FloatingPanelController.queued = null }
}
