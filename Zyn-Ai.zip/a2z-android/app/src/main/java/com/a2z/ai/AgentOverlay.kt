package com.a2z.ai

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView

/**
 * The always-visible agent control bar and the native confirmation card.
 * Header (always visible, also when minimized): minimize, status text, Stop. Below (collapsible): permission / mode line and a
 * horizontally scrolling row of Start, Ask, Explain, Voice, Pause/Resume, Chat. The bar cannot be hidden by the AI during a task.
 * Only real finger taps on these buttons confirm anything. Target text in the confirmation card comes from the screen and is shown as data.
 */
object AgentOverlay {
    private val main = Handler(Looper.getMainLooper())
    private var wm: WindowManager? = null
    private var bar: LinearLayout? = null
    private var barText: TextView? = null
    private var infoText: TextView? = null
    private var pauseBtn: Button? = null
    private var detail: View? = null
    private var card: View? = null
    private var min = false
    private var lastStatus = "ready"
    private const val BG = "#F21D1B20"; private const val FG = "#E6E0E9"; private const val AC = "#D0BCFF"

    private fun lp(grav: Int, y: Int, w: Int = WindowManager.LayoutParams.MATCH_PARENT) = WindowManager.LayoutParams(w, WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT).apply { gravity = grav; this.y = y }

    private fun btn(c: Context, t: String, accent: Boolean, on: () -> Unit) = Button(c).apply {
        text = t; isAllCaps = false; contentDescription = t; setTextColor(if (accent) Color.parseColor("#381E72") else Color.parseColor(FG))
        setBackgroundColor(if (accent) Color.parseColor(AC) else Color.parseColor("#49454F")); setPadding(24, 8, 24, 8); setOnClickListener { on() }
    }

    private fun openMain(c: Context, extra: String?) {
        try { c.startActivity(Intent(c, MainActivity::class.java).apply { if (extra != null) putExtra(extra, true) }.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)) } catch (_: Exception) { }
    }

    private fun modeLabel() = when (AgentController.mode) { "readonly" -> "Read-only"; "trusted" -> "Restricted automation"; "supervised" -> "Supervised"; else -> "Manual" }
    private fun infoLine(): String {
        val svc = AIAccessibilityService.instance
        return "Mode: ${modeLabel()} · Accessibility: ${if (svc != null) "on" else "OFF"} · Gestures: ${if (svc?.gestureCapable() == true) "on" else "OFF"} · Overlay: on · Screen share: ${FrameStore.state}" +
            (if (AgentController.pNext.isNotBlank()) "\nNext: ${AgentController.pNext}" else "")
    }

    fun showBar(ctx: Context) = main.post {
        if (bar != null) return@post
        val c = ctx.applicationContext; wm = c.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val root = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.parseColor(BG)); setPadding(16, 10, 16, 10) }
        val head = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val t = TextView(c).apply { setTextColor(Color.parseColor(FG)); textSize = 13f; text = "Zyn Ai Agent: $lastStatus"; maxLines = 2; setPadding(12, 0, 12, 0); layoutParams = LinearLayout.LayoutParams(0, WindowManager.LayoutParams.WRAP_CONTENT, 1f) }
        val info = TextView(c).apply { setTextColor(Color.parseColor("#CAC4D0")); textSize = 11f; text = infoLine(); setPadding(0, 6, 0, 6) }
        val p = btn(c, "Pause", false) { if (AgentController.paused) AgentController.resume() else AgentController.pause() }
        val st = btn(c, "Start", false) { openMain(c, "a2z_agent_open") }
        val ask = btn(c, "Ask", false) { openMain(c, "a2z_agent_ask") }
        val x = btn(c, "Explain", false) { val e = AgentRunner.start(c, "Explain what is on this screen", true); if (e != null) setStatus(e, false) }
        val v = btn(c, "Voice", false) { openMain(c, "a2z_agent_voice") }
        val o = btn(c, "Chat", false) { openMain(c, null) }
        val ax = btn(c, "Accessibility", false) { AgentController.openAccessibilitySettings(c) }
        val s = btn(c, "Stop", true) { AgentController.hardStop("You pressed Stop.") }
        val row = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(st, ask, x, v, p, ax, o).forEachIndexed { i, b -> row.addView(b, LinearLayout.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT).apply { if (i > 0) leftMargin = 8 }) }
        val scroller = HorizontalScrollView(c).apply { isHorizontalScrollBarEnabled = false; addView(row) }
        val det = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; addView(info); addView(scroller) }
        val m = btn(c, "–", false) { min = !min; det.visibility = if (min) View.GONE else View.VISIBLE }
        m.contentDescription = "Minimize or expand the agent panel"
        head.addView(m); head.addView(t); head.addView(s)
        root.addView(head); root.addView(det)
        bar = root; barText = t; infoText = info; pauseBtn = p; detail = det
        try { wm?.addView(root, lp(Gravity.TOP, 60)) } catch (_: Throwable) { bar = null }
    }

    fun setStatus(text: String, paused: Boolean) = main.post {
        lastStatus = text
        barText?.text = "Zyn Ai Agent: $text"; pauseBtn?.text = if (paused) "Resume" else "Pause"; infoText?.text = infoLine()
    }

    /** [cb] gets true only from the user's tap on Confirm. */
    fun confirm(ctx: Context, title: String, lines: List<String>, cb: (Boolean) -> Unit) = main.post {
        hideCard()
        val c = ctx.applicationContext; wm = wm ?: c.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val box = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.parseColor("#FA211F26")); setPadding(32, 28, 32, 24) }
        box.addView(TextView(c).apply { text = title; setTextColor(Color.parseColor(AC)); textSize = 17f; setTypeface(typeface, Typeface.BOLD) })
        lines.forEach { l -> box.addView(TextView(c).apply { text = l; setTextColor(Color.parseColor(FG)); textSize = 14f; setPadding(0, 8, 0, 0) }) }
        val row = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 20, 0, 0) }
        row.addView(btn(c, "Cancel", false) { hideCard(); cb(false) }, LinearLayout.LayoutParams(0, WindowManager.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = 12 })
        row.addView(btn(c, "Confirm", true) { hideCard(); cb(true) }, LinearLayout.LayoutParams(0, WindowManager.LayoutParams.WRAP_CONTENT, 1f))
        box.addView(row)
        card = box
        try { wm?.addView(box, lp(Gravity.BOTTOM, 80)) } catch (_: Throwable) { card = null; cb(false) }
    }
    private fun hideCard() { try { card?.let { wm?.removeView(it) } } catch (_: Throwable) { }; card = null }
    fun hideAll(keepBar: Boolean = false) = main.post {
        hideCard()
        if (keepBar && bar != null) { barText?.text = "Zyn Ai Agent: idle"; pauseBtn?.text = "Pause"; infoText?.text = infoLine(); return@post }
        try { bar?.let { wm?.removeView(it) } } catch (_: Throwable) { }; bar = null; barText = null; infoText = null; pauseBtn = null; detail = null; min = false
    }
}
