package com.a2z.ai

import org.json.JSONObject

/**
 * Pure policy logic of the AI agent: the allowlist every model-proposed action must pass, voice control phrases
 * (English, Tamil, Tanglish) and redaction of anything that looks like a secret before it is stored.
 * Nothing here can approve an action; it can only reject.
 */
object AgentPolicy {
    /** The ONLY action types the agent can ever execute. Anything else the model proposes is rejected. */
    val ALLOWED = setOf("click", "focus", "set_text", "scroll", "scroll_edge", "find", "back", "home", "notifications", "open_app", "open_settings", "done", "tap", "double_tap", "long_press", "swipe", "drag", "tap_text")
    private val GESTURES = setOf("tap", "double_tap", "long_press", "swipe", "drag")
    /** Run without asking only in Trusted Automation mode. Everything else needs a confirmation tap. */
    val LOW_RISK = setOf("find", "scroll", "scroll_edge", "back")
    private val NEEDS_ELEMENT = setOf("click", "focus", "set_text")
    private val ON_SCREEN = setOf("click", "focus", "set_text", "scroll", "scroll_edge", "tap", "double_tap", "long_press", "swipe", "drag", "tap_text")
    private val DIRS = setOf("up", "down", "left", "right")
    private val BLOCKED_PKGS = listOf("com.android.packageinstaller", "com.google.android.packageinstaller", "com.android.permissioncontroller", "com.google.android.permissioncontroller")

    fun blockedPackage(pkg: String?): Boolean = pkg != null && BLOCKED_PKGS.any { pkg.startsWith(it) }

    /** Returns null when the proposed action is allowed, otherwise a short reason. [snap] is the screen the model saw. */
    fun validate(a: JSONObject, snap: Snap?, hasImage: Boolean = false, hasOcr: Boolean = false): String? {
        val type = a.optString("type")
        if (type !in ALLOWED) return "action type '$type' is not on the allowed list"
        if (type in NEEDS_ELEMENT) {
            val id = a.optInt("id", -1)
            val el = snap?.items?.firstOrNull { x -> x.id == id } ?: return "there is no element #$id on the current screen"
            if (type == "set_text") {
                if (el.password) return "password fields are never filled"
                if (!el.editable) return "element #$id is not an editable text field"
                val t = a.optString("text")
                if (t.isEmpty() || t.length > 500) return "the text to enter is empty or too long"
            }
        }
        if (type in GESTURES) {
            fun pt(x: String, y: String): Boolean? = if (a.has(x) != a.has(y)) null else a.has(x)
            fun inRange(k: String) = !a.has(k) || a.optInt(k, -1) in 0..1000
            if (!inRange("x") || !inRange("y") || !inRange("x2") || !inRange("y2")) return "coordinates must be between 0 and 1000"
            val p1 = pt("x", "y") ?: return "x and y must be given together"
            val p2 = pt("x2", "y2") ?: return "x2 and y2 must be given together"
            if (p1 && !hasImage) return "coordinates can only be used when a screenshot is attached; use an element id"
            val id = a.optInt("id", -1); val id2 = a.optInt("id2", -1)
            fun el(i: Int) = snap?.items?.firstOrNull { x -> x.id == i }
            if (a.has("id") && el(id) == null) return "there is no element #$id on the current screen"
            if (a.has("id2") && el(id2) == null) return "there is no element #$id2 on the current screen"
            if (el(id)?.password == true || el(id2)?.password == true) return "password fields are never touched"
            val hasFrom = p1 || a.has("id")
            when (type) {
                "tap", "double_tap", "long_press" -> if (!hasFrom) return "give an element id, or x and y with a screenshot"
                "swipe" -> if (!(p1 && p2) && a.optString("dir") !in DIRS) return "swipe needs dir (up/down/left/right) or x,y,x2,y2"
                "drag" -> if (!hasFrom || !(p2 || a.has("id2"))) return "drag needs a start (id or x,y) and an end (id2 or x2,y2)"
            }
        }
        when (type) {
            "scroll" -> if (a.optString("dir", "down") !in DIRS) return "invalid scroll direction"
            "scroll_edge" -> if (a.optString("edge", "bottom") !in setOf("top", "bottom")) return "invalid scroll edge"
            "find" -> { val t = a.optString("text").trim(); if (t.isEmpty() || t.length > 80) return "the search text is missing or too long" }
            "tap_text" -> {
                val t = a.optString("text").trim()
                if (t.isEmpty() || t.length > 80) return "the text to tap is missing or too long"
                if (!hasOcr) return "tap_text needs live screen sharing with OCR text; use an element id"
            }
            "open_app" -> { val t = a.optString("app").trim(); if (t.isEmpty() || t.length > 60) return "the app name is missing or too long" }
        }
        if (type in ON_SCREEN && blockedPackage(snap?.pkg)) return "this is a protected system screen (installer or permission dialog); the agent does not interact with it"
        return null
    }

    // ---------- voice control phrases ----------
    private const val SUFFIX = "(\\s+(it|now|agent|task|please|pannu|panunga|pannunga|பண்ணு|பண்ணுங்க))?[\\s.!]*$"
    private val STOP = Regex("(?i)^\\s*(stop|cancel|halt|abort|enough|quit|niruthu|nirutthu|niruthunga|niruththu|நிறுத்து|நிறுத்துங்க|நிறுத்தவும்|ரத்து|நில்)$SUFFIX")
    private val PAUSE = Regex("(?i)^\\s*(pause|wait|hold on|hold|freeze|kaathiru|kathiru|niruthi\\s*vai|nirutthi\\s*vai|காத்திரு|இடைநிறுத்து|நிறுத்தி\\s*வை|நிறுத்தி\\s*வையுங்க)$SUFFIX")
    private val RESUME = Regex("(?i)^\\s*(resume|continue|go on|carry on|proceed|thodarbu|thodaru|thodar|தொடர்|தொடரு|தொடருங்க)$SUFFIX")

    /** "stop", "pause", "resume" or "" (not a control phrase, so it is a normal command). */
    fun voiceCommand(t: String): String = when {
        STOP.matches(t) -> "stop"
        PAUSE.matches(t) -> "pause"
        RESUME.matches(t) -> "resume"
        else -> ""
    }

    // ---------- redaction for stored history ----------
    private val SECRET = Regex("(?i)(password|passcode|pin|otp|cvv|cvc|token|secret)\\s*[:=]?\\s*\\S+")
    private val DIGITS = Regex("\\d{4,}")
    fun redact(s: String, max: Int = 200): String {
        var t = SECRET.replace(s, "\$1 ••••")
        t = DIGITS.replace(t, "••••")
        return if (t.length > max) t.take(max) + "…" else t
    }
}
