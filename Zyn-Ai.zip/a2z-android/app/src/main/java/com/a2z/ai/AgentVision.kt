package com.a2z.ai

import org.json.JSONObject

/** One recognised line of screen text. The box is in screenshot pixels. */
class VLine(val text: String, val l: Int, val t: Int, val r: Int, val b: Int)

/**
 * What the agent "sees" in one observation: redacted OCR text and lines (sensitive lines are already removed by [ScreenOcr]) plus the
 * redacted screenshot. [w] and [h] are the screenshot size in pixels. [changed] / [textChanged] compare with the previous OCR run.
 */
class VObs(val text: String, val lines: List<VLine>, val w: Int, val h: Int, val jpeg: String, val changed: Boolean, val textChanged: Boolean, val at: Long)

/**
 * The bridge between Advanced Vision (screen frames + on-device OCR) and Agent Control (planner + executor).
 * One place that turns the live screen share into agent input, watches the screen settle after an action, checks results visually
 * and writes recovery hints. Everything stays in memory; nothing here can approve or run an action.
 * The functions without Android types are pure so they can be unit tested on the JVM.
 */
object AgentVision {
    // ---- live counters shown in Agent Control and the Advanced Vision Live tab ----
    @Volatile var last: VObs? = null; private set
    @Volatile var observations = 0; private set
    @Volatile var changes = 0; private set
    @Volatile var visualVerified = 0; private set
    @Volatile var aiVerified = 0; private set
    @Volatile var recoveries = 0; private set

    fun countVisual() { visualVerified++ }
    fun countAi() { aiVerified++ }
    fun countRecovery() { recoveries++ }
    fun resetCounters() { observations = 0; changes = 0; visualVerified = 0; aiVerified = 0; recoveries = 0 }

    /** True when the agent may use the live screen share: Screen Understanding on, sharing running, Privacy Mode off. */
    fun linked(): Boolean = AgentController.useScreen && FrameStore.state == "running" && !FrameStore.privacy
    fun badge(): String = if (linked()) "on" else "off"

    /** Newest redacted screenshot + OCR as one observation, or null when sharing is off or nothing was captured yet. */
    fun observe(): VObs? {
        if (!linked()) return null
        val f = FrameStore.latest(1).lastOrNull() ?: return null
        return try {
            val r = JSONObject(ScreenOcr.analyze(f, "auto", true))
            if (!r.optBoolean("ok")) return null
            val lines = ArrayList<VLine>()
            val bl = r.optJSONArray("blocks")
            if (bl != null) for (i in 0 until bl.length()) {
                val ls = bl.getJSONObject(i).optJSONArray("lines") ?: continue
                for (j in 0 until ls.length()) {
                    val o = ls.getJSONObject(j)
                    if (o.optBoolean("red")) continue
                    val t = o.optString("t"); if (t.isBlank() || t == "[hidden]") continue
                    val b = o.optJSONArray("box") ?: continue
                    lines.add(VLine(t, b.optInt(0), b.optInt(1), b.optInt(2), b.optInt(3)))
                }
            }
            val o = VObs(r.optString("text"), lines, r.optInt("w"), r.optInt("h"), if (r.has("jpeg")) r.getString("jpeg") else f, r.optBoolean("changed"), r.optBoolean("textChanged"), System.currentTimeMillis())
            observations++; if (o.changed) changes++; last = o; o
        } catch (_: Throwable) { null }
    }

    /** True once a frame newer than [since] exists (or when frames are not streaming, in which case there is nothing to wait for). */
    fun frameFresh(since: Long): Boolean = FrameStore.mode != "continuous" || FrameStore.state != "running" || FrameStore.lastAt > since

    /**
     * Live monitor: after an action, wait until the accessibility tree has stopped changing for two reads in a row (and a newer frame exists),
     * up to [maxMs]. Returns the settled snapshot. [sleep] must be cancel-aware (it throws when the user presses Stop).
     */
    fun settle(read: () -> Snap?, sleep: (Long) -> Unit, since: Long, maxMs: Long = 2800L, pollMs: Long = 350L, needFresh: Boolean = true,
               before: Int? = null, minChangeMs: Long = 0L): Snap? {
        var prev = read(); var stable = 0; var waited = 0L
        while (waited < maxMs) {
            sleep(pollMs); waited += pollMs
            val cur = read()
            if (cur?.hash() == prev?.hash()) {
                stable++
                // fast mode: a screen that is still the same as before the action gets [minChangeMs] to start changing before it counts as "unchanged"
                val tooSoon = before != null && cur?.hash() == before && waited < minChangeMs
                if (stable >= 2 && !tooSoon && (!needFresh || frameFresh(since))) return cur
            } else stable = 0
            prev = cur
        }
        return prev
    }

    /** "VERIFIED ..." text when the screenshot itself shows a change after the action, otherwise null. */
    fun visualVerdict(after: VObs?, since: Long, expect: String): String? {
        if (after == null || after.at < since) return null
        if (!after.changed && !after.textChanged) return null
        val hit = expectMet(expect, after.text)
        return "VERIFIED by the screenshot: the screen changed" + (if (hit) " and shows the expected text" else "")
    }

    fun statusJson(): JSONObject {
        val p = FloatStore.ordered().firstOrNull()
        val l = last
        return JSONObject().put("linked", linked()).put("share", FrameStore.state).put("privacy", FrameStore.privacy).put("frames", FrameStore.count())
            .put("lines", l?.lines?.size ?: 0).put("ageMs", if (l == null) -1 else System.currentTimeMillis() - l.at)
            .put("observations", observations).put("changes", changes).put("visual", visualVerified).put("ai", aiVerified).put("recoveries", recoveries)
            .put("model", if (p == null) "none" else FloatVision.tag(p))
    }

    // ================= pure helpers (JVM-testable) =================

    private val STOP = setOf("screen", "visible", "should", "shown", "show", "shows", "displayed", "page", "with", "that", "this", "will", "appear", "appears", "open", "opened", "list", "item", "items", "from", "into", "after", "tapped", "tapping")

    /** Best line for [query]: exact match first, then the shortest line that contains it. Case-insensitive. */
    fun findText(lines: List<VLine>, query: String): VLine? {
        val q = query.trim().lowercase(); if (q.isEmpty()) return null
        return lines.firstOrNull { it.text.trim().lowercase() == q }
            ?: lines.filter { it.text.lowercase().contains(q) }.minByOrNull { it.text.length }
    }

    /** Centre of [l] converted from screenshot pixels to real screen pixels. */
    fun toScreen(l: VLine, fw: Int, fh: Int, sw: Int, sh: Int): Pair<Int, Int> {
        val cx = (l.l + l.r) / 2; val cy = (l.t + l.b) / 2
        return (cx.toLong() * sw / fw.coerceAtLeast(1)).toInt().coerceIn(0, (sw - 1).coerceAtLeast(0)) to
            (cy.toLong() * sh / fh.coerceAtLeast(1)).toInt().coerceIn(0, (sh - 1).coerceAtLeast(0))
    }

    /** "[x1,y1,x2,y2] text" per line on a 0..1000 grid, so the model can point at text without element ids. */
    fun positioned(lines: List<VLine>, w: Int, h: Int, max: Int = 40): String {
        if (lines.isEmpty() || w <= 0 || h <= 0) return ""
        return lines.take(max).joinToString("\n") { "[${it.l * 1000 / w},${it.t * 1000 / h},${it.r * 1000 / w},${it.b * 1000 / h}] ${it.text.replace('\n', ' ').take(60)}" }
    }

    /** Meaningful words (4+ letters) of the model's "expect" sentence. */
    fun words(expect: String): Set<String> = expect.lowercase().split(Regex("[^\\p{L}\\p{N}]+")).filter { it.length >= 4 && it !in STOP }.toSet()

    /** At least half of the expected words appear in the OCR text. */
    fun expectMet(expect: String, screenText: String): Boolean {
        val w = words(expect); if (w.isEmpty()) return false
        val t = screenText.lowercase()
        return w.count { t.contains(it) } * 2 >= w.size
    }

    /**
     * One-line advice for the planner after a failed or unverified step, so the next attempt changes approach instead of repeating.
     * [otherPkg] is the package that came to the front when it is not the one the action was started in.
     */
    fun recoveryHint(type: String, ok: Boolean, msg: String, otherPkg: String?, hasOcr: Boolean, noEffect: Int): String {
        val tapText = if (hasOcr) " or use tap_text with the exact visible label" else ""
        return "RECOVERY: " + when {
            otherPkg != null && type != "open_app" -> "a different screen ($otherPkg) came to the front. If it is a dialog or an ad, close it with back; otherwise return with back or open the app again."
            !ok && (msg.contains("scroll", true)) -> "this screen cannot be scrolled with accessibility; try swipe$tapText."
            !ok && type in setOf("click", "focus", "set_text") -> "that element could not be used. Re-read the SCREEN and choose another id$tapText."
            !ok -> "the action failed. Choose a different action or finish with done."
            noEffect >= 2 -> "two actions in a row changed nothing. The screen may be loading, covered by a dialog, or the target is not tappable. Try scroll, find, back$tapText, or finish with done."
            hasOcr -> "the screen did not change. It may still be loading or the touch missed. Try tap_text with the exact visible label, scroll, or back."
            else -> "the screen did not change. It may still be loading or the touch missed. Try scroll, find or back."
        }
    }
}
