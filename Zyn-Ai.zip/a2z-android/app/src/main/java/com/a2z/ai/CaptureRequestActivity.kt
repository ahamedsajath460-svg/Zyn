package com.a2z.ai
import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import androidx.core.content.ContextCompat

/**
 * Invisible helper activity: shows Android's official "Start recording or casting?" consent dialog for the floating panel
 * (a service cannot show it by itself), then starts the existing [ScreenCaptureService] in manual mode. Never bypasses the dialog.
 */
class CaptureRequestActivity : Activity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        if (s != null) return   // re-created by the system: the original request is still pending
        try {
            val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            @Suppress("DEPRECATION") startActivityForResult(mpm.createScreenCaptureIntent(), 77)
        } catch (_: Throwable) { FrameStore.onPermission?.invoke(false); finish() }
    }

    @Deprecated("") @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 77) { finish(); return }
        if (resultCode == RESULT_OK && data != null) {
            try {
                ContextCompat.startForegroundService(this, Intent(this, ScreenCaptureService::class.java).apply {
                    action = ScreenCaptureService.START
                    putExtra(ScreenCaptureService.CODE, resultCode); putExtra(ScreenCaptureService.DATA, data)
                    putExtra(ScreenCaptureService.MODE, ScreenCaptureService.MODE_MANUAL)
                })
                FrameStore.onPermission?.invoke(true)
            } catch (_: Throwable) { FrameStore.onPermission?.invoke(false) }
        } else FrameStore.onPermission?.invoke(false)
        finish()
    }
}
