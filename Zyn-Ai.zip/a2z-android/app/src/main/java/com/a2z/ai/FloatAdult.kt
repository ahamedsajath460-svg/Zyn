package com.a2z.ai

import java.net.URI

/** Same adult (18+) block as the app's web search tool: blocks adult search words and adult websites in results and photos. */
object FloatAdult {
    private val DOMAINS = ("pornhub.com xvideos.com xnxx.com xhamster.com redtube.com youporn.com tube8.com spankbang.com eporner.com thumbzilla.com porn.com beeg.com txxx.com hclips.com tnaflix.com drtuber.com sunporno.com youjizz.com xtube.com motherless.com porntrex.com pornone.com hqporner.com fapality.com porndig.com nuvid.com vporn.com 4tube.com fux.com extremetube.com keezmovies.com pornmd.com pornpics.com xxxbunker.com youporngay.com gaytube.com cumlouder.com camwhores.tv missav.com javhd.com " +
        "brazzers.com realitykings.com bangbros.com naughtyamerica.com mofos.com blacked.com tushy.com vixen.com digitalplayground.com evilangel.com kink.com teamskeet.com fakehub.com nubiles.com babes.com twistys.com " +
        "chaturbate.com stripchat.com bongacams.com livejasmin.com cam4.com myfreecams.com camsoda.com flirt4free.com " +
        "nhentai.net hanime.tv e-hentai.org exhentai.org fakku.net hentai2read.com 8muses.com").split(" ")
    private val TLD = Regex("\\.(xxx|porn|adult|sex)$")
    private val KEY = Regex("^(xxx|porn\\w*|hentai\\w*|xvideos?\\w*|xnxx\\w*|xhamster\\w*|nsfw)$")
    private val TEXT = Regex("\\b(porn\\w*|xxx|hentai|nsfw|blow ?jobs?|hand ?jobs?|cum ?shots?|bukkake|milfs?|gang ?bangs?|creampies?|dildos?|(nude|naked) (pics?|photos?|videos?)|sex (videos?|tapes?|chat|cams?|stories|pics?|photos?)|sex ?stor\\w*|adult (videos?|movies?|content)|kama ?kath\\w*)\\b", RegexOption.IGNORE_CASE)

    fun text(s: String?): Boolean = s != null && TEXT.containsMatchIn(s)

    fun url(u: String?): Boolean {
        val h = try { (URI(u ?: return false).host ?: return false).removePrefix("www.").lowercase() } catch (_: Throwable) { return false }
        return TLD.containsMatchIn(h) || DOMAINS.any { h == it || h.endsWith(".$it") } || h.split(Regex("[.\\-]")).any { KEY.matches(it) }
    }
}
