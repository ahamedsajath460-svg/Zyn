package com.a2z.ai

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.*
import java.util.concurrent.CancellationException
import javax.net.ssl.SSLException

/** [images]: base64 JPEG screenshots attached to this turn (empty for normal text turns). */
class Turn(val role: String, val text: String, val images: List<String> = emptyList())

/** Streaming client for the same three provider formats the app supports (OpenAI-style, Claude, Gemini). One instance per request. */
class FloatAi {
    class ApiError(val status: Int, val raw: String) : IOException("HTTP $status: $raw")

    @Volatile private var conn: HttpURLConnection? = null
    @Volatile var cancelled = false; private set
    fun cancel() { cancelled = true; try { conn?.disconnect() } catch (_: Throwable) { } }

    private class Spec(val url: String, val headers: Map<String, String>, val body: String, val parse: (JSONObject, (String) -> Unit) -> Unit)

    private fun JSONObject.str(k: String): String? = if (isNull(k)) null else optString(k)

    private fun fail(j: JSONObject) {
        val e = j.opt("error")
        if (e != null && e != JSONObject.NULL) throw ApiError(0, if (e is JSONObject) (e.str("message") ?: e.toString()) else e.toString())
    }

    private fun spec(p: FProvider, sys: String, turns: List<Turn>, think: Boolean): Spec {
        val base = p.base.trimEnd('/')
        val h = LinkedHashMap<String, String>(); h["Content-Type"] = "application/json"; h["Accept"] = "text/event-stream"; h["Accept-Encoding"] = "identity" // gzip would buffer SSE chunks
        when (p.type) {
            "anthropic" -> {
                h["x-api-key"] = p.key; h["anthropic-version"] = "2023-06-01"
                val msgs = JSONArray(); turns.forEach { t ->
                    val content: Any = if (t.images.isEmpty()) t.text else JSONArray().apply {
                        t.images.forEach { b -> put(JSONObject().put("type", "image").put("source", JSONObject().put("type", "base64").put("media_type", "image/jpeg").put("data", b))) }
                        put(JSONObject().put("type", "text").put("text", t.text))
                    }
                    msgs.put(JSONObject().put("role", t.role).put("content", content))
                }
                val body = JSONObject().put("model", p.model).put("max_tokens", 4096).put("stream", true).put("system", sys).put("messages", msgs)
                return Spec(base + "/v1/messages", h, body.toString()) { j, emit ->
                    if (j.optString("type") == "error") fail(j)
                    if (j.optString("type") == "content_block_delta") j.optJSONObject("delta")?.str("text")?.let { if (it.isNotEmpty()) emit(it) }
                }
            }
            "gemini" -> {
                h["x-goog-api-key"] = p.key
                val contents = JSONArray()
                turns.forEach { t ->
                    val parts = JSONArray()
                    t.images.forEach { b -> parts.put(JSONObject().put("inlineData", JSONObject().put("mimeType", "image/jpeg").put("data", b))) }
                    parts.put(JSONObject().put("text", t.text))
                    contents.put(JSONObject().put("role", if (t.role == "user") "user" else "model").put("parts", parts))
                }
                val body = JSONObject().put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys)))).put("contents", contents)
                val m = p.model.removePrefix("models/")
                if (think) thinkCfg(m)?.let { body.put("generationConfig", JSONObject().put("thinkingConfig", it)) }
                return Spec("$base/models/$m:streamGenerateContent?alt=sse", h, body.toString()) { j, emit ->
                    fail(j)
                    j.optJSONObject("promptFeedback")?.str("blockReason")?.let { throw ApiError(0, "blocked by Google: $it") }
                    val parts = j.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
                    if (parts != null) for (i in 0 until parts.length()) {
                        val pt = parts.optJSONObject(i) ?: continue
                        if (!pt.optBoolean("thought")) pt.str("text")?.let { if (it.isNotEmpty()) emit(it) }
                    }
                }
            }
            else -> {
                if (p.key.isNotEmpty()) h["Authorization"] = "Bearer " + p.key
                val msgs = JSONArray().put(JSONObject().put("role", "system").put("content", sys))
                turns.forEach { t ->
                    val content: Any = if (t.images.isEmpty()) t.text else JSONArray().apply {
                        put(JSONObject().put("type", "text").put("text", t.text))
                        t.images.forEach { b -> put(JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", "data:image/jpeg;base64,$b"))) }
                    }
                    msgs.put(JSONObject().put("role", t.role).put("content", content))
                }
                val body = JSONObject().put("model", p.model).put("stream", true).put("messages", msgs)
                val b = base.removeSuffix("/chat/completions")
                return Spec("$b/chat/completions", h, body.toString()) { j, emit ->
                    fail(j)
                    val ch = j.optJSONArray("choices")?.optJSONObject(0)
                    (ch?.optJSONObject("delta")?.str("content") ?: ch?.optJSONObject("message")?.str("content"))?.let { if (it.isNotEmpty()) emit(it) }
                }
            }
        }
    }

    /** Blocking. Call from a worker thread. Throws on any failure (check [cancelled] first). */
    fun stream(p: FProvider, sys: String, turns: List<Turn>, onDelta: (String) -> Unit) {
        val key = p.model.removePrefix("models/")
        val lowThink = p.type == "gemini" && thinkCfg(key) != null && synchronized(noThink) { key !in noThink }
        try { run(p, sys, turns, lowThink, onDelta) }
        catch (e: ApiError) {
            // model rejected the thinking setting: remember it and retry once without
            if (lowThink && e.status == 400 && Regex("think", RegexOption.IGNORE_CASE).containsMatchIn(e.raw) && !cancelled) {
                synchronized(noThink) { noThink.add(key) }
                run(p, sys, turns, false, onDelta)
            } else throw e
        }
    }

    private fun run(p: FProvider, sys: String, turns: List<Turn>, think: Boolean, onDelta: (String) -> Unit) {
        val s = spec(p, sys, turns, think)
        val c = URL(s.url).openConnection() as HttpURLConnection
        conn = c
        try {
            if (cancelled) throw CancellationException()
            c.connectTimeout = 20_000; c.readTimeout = 90_000; c.requestMethod = "POST"; c.doOutput = true; c.useCaches = false
            s.headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
            val bytes = s.body.toByteArray(Charsets.UTF_8)
            c.setFixedLengthStreamingMode(bytes.size)
            c.outputStream.use { it.write(bytes) }
            val code = c.responseCode
            if (code !in 200..299) throw ApiError(code, errText(c))
            var got = false
            val extra = StringBuilder()
            c.inputStream.bufferedReader(Charsets.UTF_8).use { r ->
                while (true) {
                    val line = r.readLine() ?: break
                    if (cancelled) throw CancellationException()
                    if (!line.startsWith("data:")) { if (extra.length < 65536) extra.append(line).append('\n'); continue }
                    val d = line.substring(5).trim()
                    if (d.isEmpty()) continue
                    if (d == "[DONE]") break
                    val j = try { JSONObject(d) } catch (_: Exception) { continue }
                    s.parse(j) { got = true; onDelta(it) }
                }
            }
            if (!got && extra.isNotBlank()) { // server ignored stream=true and sent plain JSON
                try { s.parse(JSONObject(extra.toString())) { got = true; onDelta(it) } } catch (e: ApiError) { throw e } catch (_: Exception) { }
            }
            if (!got) throw IOException("empty reply")
        } finally {
            try { c.disconnect() } catch (_: Throwable) { }
            if (conn === c) conn = null
        }
    }

    private fun errText(c: HttpURLConnection): String {
        val raw = try { c.errorStream?.bufferedReader(Charsets.UTF_8)?.use { it.readText().take(8000) } ?: "" } catch (_: Throwable) { "" }
        return try {
            val o = if (raw.trimStart().startsWith("[")) JSONArray(raw).optJSONObject(0) ?: JSONObject() else JSONObject(raw)
            val e = o.opt("error")
            when { e is JSONObject -> e.optString("message", raw); e is String -> e; o.has("message") -> o.optString("message"); else -> raw }
        } catch (_: Throwable) { raw }
    }

    companion object {
        private val noThink = HashSet<String>()
        /** Fast replies: minimal thinking for Gemini (its default thinking delays the first word by seconds). */
        private fun thinkCfg(model: String): JSONObject? {
            val m = model.lowercase()
            return when {
                m.startsWith("gemini-3") -> JSONObject().put("thinkingLevel", "low")
                m.startsWith("gemini-2.5-flash") -> JSONObject().put("thinkingBudget", 0)
                else -> null
            }
        }

        /** Plain-language error text (same spirit as the app's own friendly()). */
        fun friendly(e: Throwable): String {
            val m = e.message ?: ""
            if (e is ApiError) {
                val s = e.status; val r = e.raw
                return when {
                    s == 429 || Regex("quota|rate.?limit", RegexOption.IGNORE_CASE).containsMatchIn(r) -> "Rate or quota limit reached for this key/model. Try again shortly."
                    s == 401 || s == 403 || Regex("api[ _-]?key (not valid|invalid|expired)|API_KEY_INVALID", RegexOption.IGNORE_CASE).containsMatchIn(r) -> "The API key was rejected (invalid, expired or not allowed)."
                    s == 404 -> "Model or endpoint not found."
                    s == 400 -> "Bad request. " + r.take(140)
                    s >= 500 -> "The server is busy. Try again shortly."
                    else -> r.take(160).ifEmpty { "Request failed." }
                }
            }
            return when {
                e is UnknownHostException -> "No internet connection, or the server address can't be found."
                e is SocketTimeoutException -> "The request timed out. Check your connection and try again."
                e is SSLException -> "Secure connection failed. Check the device date/time and network."
                e is ConnectException || e is NoRouteToHostException -> "Could not reach the server. Check the network or the endpoint address."
                m.contains("Cleartext", true) -> "Only https endpoints are allowed in this app."
                m == "empty reply" -> "The model returned an empty reply."
                else -> m.take(160).ifEmpty { "Something went wrong." }
            }
        }
    }
}
