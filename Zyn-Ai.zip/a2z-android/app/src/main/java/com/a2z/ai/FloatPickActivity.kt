package com.a2z.ai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.OpenableColumns
import androidx.core.content.FileProvider
import java.io.File

/**
 * Invisible helper activity for the floating panel's attach menu (a service cannot start Android's pickers itself).
 * kind: "photo" (images), "file" (any file), "camera" (system camera app). The picked bytes go to [FloatingPanelController.onPicked].
 */
class FloatPickActivity : Activity() {
    private var camFile: File? = null

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        if (s != null) return
        try {
            when (intent?.getStringExtra("kind")) {
                "camera" -> {
                    if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf(Manifest.permission.CAMERA), 5)
                    else launchCamera()
                }
                "photo" -> launchPicker("image/*")
                else -> launchPicker("*/*")
            }
        } catch (_: Throwable) { finish() }
    }

    private fun launchPicker(type: String) {
        val i = Intent(Intent.ACTION_GET_CONTENT).setType(type).addCategory(Intent.CATEGORY_OPENABLE).putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        @Suppress("DEPRECATION") startActivityForResult(Intent.createChooser(i, "Attach"), 41)
    }

    private fun launchCamera() {
        val f = File(cacheDir, "float_cam.jpg"); camFile = f
        val uri = FileProvider.getUriForFile(this, "$packageName.fp", f)
        val i = Intent(MediaStore.ACTION_IMAGE_CAPTURE).putExtra(MediaStore.EXTRA_OUTPUT, uri).addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
        @Suppress("DEPRECATION") startActivityForResult(i, 42)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (code == 5 && res.isNotEmpty() && res[0] == PackageManager.PERMISSION_GRANTED) { try { launchCamera() } catch (_: Throwable) { finish() } } else finish()
    }

    @Deprecated("") @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) { finish(); return }
        val uris = ArrayList<Uri>()
        if (requestCode == 42) camFile?.let { uris.add(Uri.fromFile(it)) }
        else if (requestCode == 41 && data != null) {
            data.clipData?.let { c -> for (i in 0 until minOf(c.itemCount, 10)) uris.add(c.getItemAt(i).uri) }
            if (uris.isEmpty()) data.data?.let { uris.add(it) }
        }
        val app = applicationContext
        Thread {
            for (u in uris) {
                try {
                    val name = if (u.scheme == "file") (u.lastPathSegment ?: "photo.jpg") else app.contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c -> if (c.moveToFirst()) c.getString(0) else null } ?: "file"
                    val mime = if (u.scheme == "file") "image/jpeg" else (app.contentResolver.getType(u) ?: "application/octet-stream")
                    val bytes = if (u.scheme == "file") File(u.path ?: "").readBytes() else app.contentResolver.openInputStream(u)?.use { it.readBytes() } ?: continue
                    FloatingPanelController.instance?.onPicked(name, mime, bytes)
                } catch (_: Throwable) { }
            }
            camFile?.delete()
        }.start()
        finish()
    }
}
