package com.a2z.ai

import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import org.json.JSONObject

/**
 * Web search for the floating panel chat. Mirrors the app's chat search: live weather, the chosen engine (DuckDuckGo / Wikipedia),
 * Tavily keys (auto/tavily), your own search APIs, Gemini + Google Search, then DuckDuckGo and Wikipedia as fallbacks. No content filter is applied (by request). Limits (engine, max results, snippet length, recency) come from the app's settings via FloatStore.ws.
 * Always call from a worker thread.
 */
object FloatSearch {
    class Hit(val title: String, val url: String, val text: String)

    private val WANT = Regex("\\b(internet|online|web|google|search|latest|today|todays|current(ly)?|news|weather|whether|forecast|price|score|live|trending|tonight|tomorrow)\\b|net\\s*la\\b|இணைய|இன்று|வானிலை|செய்தி|நாளை", RegexOption.IGNORE_CASE)
    private val GREET = Regex("^(hi+|hello+|hey+|hai|ok(ay)?|thanks?|thank you|bye|yes|no|good (morning|night|evening)|vanakkam|nandri|sari)\\W*$", RegexOption.IGNORE_CASE)

    /** Same rule as the app: search when it is on for every message, or (auto) when the question asks for fresh facts. Small talk never searches. */
    fun wanted(text: String): Boolean {
        val t = text.trim()
        if (!FloatStore.feat("web")) return false
        if (t.length < 6 || GREET.containsMatchIn(t)) return false
        if (FloatStore.feat("webalways", false)) return true
        return FloatStore.feat("webauto") && WANT.containsMatchIn(t)
    }

    fun search(q0: String): List<Hit> {
        val q = q0.trim().take(200)
        val cfg = FloatStore.ws
        val eng = cfg.optString("eng", "auto").ifEmpty { "auto" }
        val mx = cfg.optInt("max", 6).coerceIn(1, 10)
        val len = cfg.optInt("len", 0)
        val lang = cfg.optString("lang", "")
        fun fin(a: List<Hit>) = a.take(mx).map { if (len > 0) Hit(it.title, it.url, it.text.take(len)) else it }
        // live weather answers come straight from Open-Meteo, exactly like the app
        try { val w = weather(q); if (w != null) return fin(listOf(w)) } catch (_: Throwable) { }
        if (eng == "wiki") return try { fin(wiki(q, mx, lang)) } catch (_: Throwable) { emptyList() }
        if (eng == "ddg") return try { fin(ddg(q)) } catch (_: Throwable) { emptyList() }
        val keys = cfg.optJSONArray("keys")
        if ((eng == "auto" || eng == "tavily") && keys != null) {
            for (i in 0 until keys.length()) {
                val key = keys.optString(i)
                if (key.isBlank()) continue
                try { val r = tavily(q, mx, key, cfg.optString("rec")); if (r.isNotEmpty()) return fin(r) } catch (_: Throwable) { }
            }
        }
        // the search APIs added in the app (Serper, Brave, Exa, Jina, Perplexity, Google Programmable Search, SearXNG, ...)
        val apis = cfg.optJSONArray("apis")
        if (apis != null) for (i in 0 until apis.length()) {
            val a = apis.optJSONObject(i) ?: continue
            if (eng != "auto" && eng != a.optString("id")) continue
            try { val r = runApi(a, q, mx, lang); if (r.isNotEmpty()) return fin(r) } catch (_: Throwable) { }
        }
        // Gemini + Google Search digest (automatic mode only, like the app)
        if (eng == "auto") { try { val g = geminiDigest(q, cfg); if (g.isNotEmpty()) return fin(g) } catch (_: Throwable) { } }
        try { val d = ddg(q); if (d.isNotEmpty()) return fin(d) } catch (_: Throwable) { }
        return try { fin(wiki(q, mx, lang)) } catch (_: Throwable) { emptyList() }
    }

    fun block(h: List<Hit>): String =
        "Web search results (use them and cite as [1], [2]; say so if they do not answer the question):\n" +
            h.mapIndexed { i, x -> "[${i + 1}] ${x.title} - ${x.url}\n${x.text}" }.joinToString("\n\n")

    private fun tavily(q: String, mx: Int, key: String, rec: String): List<Hit> {
        val body = JSONObject().put("query", q).put("max_results", mx)
        if (rec.isNotBlank()) body.put("time_range", rec)
        val j = JSONObject(http("https://api.tavily.com/search", body.toString(), key))
        val a = j.optJSONArray("results") ?: return emptyList()
        val l = ArrayList<Hit>()
        for (i in 0 until a.length()) { val x = a.optJSONObject(i) ?: continue; l.add(Hit(x.optString("title"), x.optString("url"), x.optString("content"))) }
        return l
    }

    private fun wiki(q: String, mx: Int, lang: String = ""): List<Hit> {
        val lg = if (Regex("^[a-z]{2}$").matches(lang)) lang else if (Regex("[\\u0B80-\\u0BFF]").containsMatchIn(q)) "ta" else if (Regex("[\\u0D80-\\u0DFF]").containsMatchIn(q)) "si" else "en"
        val url = "https://$lg.wikipedia.org/w/api.php?action=query&generator=search&gsrsearch=" + URLEncoder.encode(q, "UTF-8") +
            "&gsrlimit=" + minOf(mx, 4) + "&prop=extracts%7Cinfo&exintro=1&explaintext=1&exchars=700&exlimit=" + minOf(mx, 4) + "&inprop=url&format=json"
        val pages = JSONObject(http(url, null, null)).optJSONObject("query")?.optJSONObject("pages") ?: return emptyList()
        val l = ArrayList<Hit>()
        val it = pages.keys()
        while (it.hasNext()) { val x = pages.optJSONObject(it.next()) ?: continue; l.add(Hit(x.optString("title"), x.optString("fullurl"), x.optString("extract"))) }
        return l
    }

    /** DuckDuckGo instant-answer API (same call the app uses). */
    private fun ddg(q: String): List<Hit> {
        val j = JSONObject(http("https://api.duckduckgo.com/?q=" + URLEncoder.encode(q, "UTF-8") + "&format=json&no_html=1&skip_disambig=1", null, null))
        val o = ArrayList<Hit>()
        if (j.optString("AbstractURL").isNotEmpty() && j.optString("AbstractText").isNotEmpty())
            o.add(Hit(j.optString("Heading").ifEmpty { q }, j.optString("AbstractURL"), j.optString("AbstractText")))
        fun rel(a: org.json.JSONArray?) {
            if (a == null) return
            for (i in 0 until a.length()) {
                val x = a.optJSONObject(i) ?: continue
                if (x.has("Topics")) rel(x.optJSONArray("Topics"))
                else if (x.optString("FirstURL").isNotEmpty() && x.optString("Text").isNotEmpty()) o.add(Hit(x.optString("Text").take(90), x.optString("FirstURL"), x.optString("Text")))
            }
        }
        rel(j.optJSONArray("RelatedTopics"))
        val r = j.optJSONArray("Results")
        if (r != null) for (i in 0 until r.length()) { val x = r.optJSONObject(i) ?: continue; if (x.optString("FirstURL").isNotEmpty()) o.add(Hit(x.optString("Text"), x.optString("FirstURL"), x.optString("Text"))) }
        return o.take(6)
    }

    private val WX_WORDS = Regex("weather|whether|temperature|forecast|rain|mazhai|veyil|\u0BB5\u0BBE\u0BA9\u0BBF\u0BB2\u0BC8|\u0BAE\u0BB4\u0BC8|\u0BB5\u0BC6\u0BAF\u0BBF\u0BB2\u0BCD", RegexOption.IGNORE_CASE)
    private val WX_STOP = ("today todays whether weather check pannu sri lanka srilanka extract enna epdi eppadi internet paru search live temperature forecast tomorrow irukku iruku time what will give tell please near about from with this that need want show current right now tonight").split(" ").toSet()
    private val WXC = mapOf(0 to "Clear sky", 1 to "Mainly clear", 2 to "Partly cloudy", 3 to "Overcast", 45 to "Fog", 48 to "Fog", 51 to "Light drizzle", 53 to "Drizzle", 55 to "Heavy drizzle",
        56 to "Freezing drizzle", 57 to "Freezing drizzle", 61 to "Light rain", 63 to "Rain", 65 to "Heavy rain", 66 to "Freezing rain", 67 to "Freezing rain", 71 to "Light snow", 73 to "Snow",
        75 to "Heavy snow", 80 to "Rain showers", 81 to "Rain showers", 82 to "Violent rain showers", 95 to "Thunderstorm", 96 to "Thunderstorm with hail", 99 to "Thunderstorm with hail")

    /** Live weather from Open-Meteo, same wording as the app (Colombo when the place is not recognised). */
    private fun weather(q: String): Hit? {
        if (!WX_WORDS.containsMatchIn(q)) return null
        val toks = Regex("[a-z]{4,}").findAll(q.lowercase()).map { it.value }.filter { it !in WX_STOP }.distinct().toList()
        var name = ""; var country = ""; var lat = 0.0; var lon = 0.0; var found = false
        for (t in toks) {
            try {
                val j = JSONObject(http("https://geocoding-api.open-meteo.com/v1/search?count=1&language=en&name=" + URLEncoder.encode(t, "UTF-8"), null, null))
                val r = j.optJSONArray("results")?.optJSONObject(0)
                if (r != null) { name = r.optString("name"); country = r.optString("country"); lat = r.optDouble("latitude"); lon = r.optDouble("longitude"); found = true; break }
            } catch (_: Throwable) { }
        }
        if (!found) { name = "Colombo"; country = "Sri Lanka"; lat = 6.9271; lon = 79.8612 }
        val j = JSONObject(http("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,apparent_temperature,relative_humidity_2m,precipitation,weather_code,wind_speed_10m&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max&timezone=auto&forecast_days=3", null, null))
        val c = j.optJSONObject("current") ?: return null
        val d = j.optJSONObject("daily") ?: return null
        val times = d.optJSONArray("time") ?: return null
        val days = (0 until times.length()).joinToString("\n") { i ->
            times.optString(i) + ": " + (d.optJSONArray("weather_code")?.optInt(i)?.let { WXC[it] } ?: "n/a") + ", " + d.optJSONArray("temperature_2m_min")?.opt(i) + " to " + d.optJSONArray("temperature_2m_max")?.opt(i) +
                " C, rain chance " + d.optJSONArray("precipitation_probability_max")?.opt(i) + "%"
        }
        val where = name + if (country.isNotEmpty()) ", $country" else ""
        val text = (if (!found) "The place was not recognised, so Colombo is shown. Tell the user this.\n" else "") +
            "Live weather for $where at " + c.optString("time").replace("T", " ") + " (local time): " + (WXC[c.optInt("weather_code")] ?: "n/a") + ", " + c.opt("temperature_2m") + " C (feels like " + c.opt("apparent_temperature") + " C), humidity " +
            c.opt("relative_humidity_2m") + "%, wind " + c.opt("wind_speed_10m") + " km/h, rain now " + c.opt("precipitation") + " mm.\nForecast:\n" + days
        return Hit("Open-Meteo live weather: $where", "https://open-meteo.com/", text)
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
    private fun httpOk(u: String) = u.startsWith("http://") || u.startsWith("https://")

    /** One search API the user added in the app. Same requests and field mapping as the app's data layer. */
    private fun runApi(a: JSONObject, q: String, mx: Int, lang: String): List<Hit> {
        val kind = a.optString("kind"); val ep = a.optString("endpoint").trim(); val key = a.optString("key").trim(); val cx = a.optString("cx").trim()
        val join = if (ep.contains("?")) "&" else "?"
        val out = ArrayList<Hit>()
        fun arr(j: JSONObject, name: String) = j.optJSONArray(name) ?: org.json.JSONArray()
        when (kind) {
            "s-free" -> { try { out.addAll(ddg(q)) } catch (_: Throwable) { }; if (out.isEmpty()) try { out.addAll(wiki(q, mx, lang)) } catch (_: Throwable) { } }
            "s-tavily", "d-tavily" -> {
                val rich = kind == "s-tavily"
                val body = JSONObject().put("query", q).put("max_results", 6)
                if (rich) body.put("search_depth", "basic").put("include_answer", true)
                val j = JSONObject(httpx(ep, "POST", mapOf("Authorization" to "Bearer $key"), body.toString()))
                val r = arr(j, "results"); for (i in 0 until r.length()) { val x = r.optJSONObject(i) ?: continue; out.add(Hit(x.optString("title"), x.optString("url"), x.optString("content"))) }
                val ans = j.optString("answer"); if (rich && ans.isNotEmpty() && out.isNotEmpty()) out[0] = Hit(out[0].title, out[0].url, "Summary: $ans\n\n" + out[0].text)
            }
            "s-serper", "d-serper" -> {
                val j = JSONObject(httpx(ep, "POST", mapOf("X-API-KEY" to key), JSONObject().put("q", q).put("num", 6).toString()))
                val r = arr(j, "organic"); for (i in 0 until r.length()) { val x = r.optJSONObject(i) ?: continue; out.add(Hit(x.optString("title"), x.optString("link"), x.optString("snippet"))) }
                val ab = j.optJSONObject("answerBox"); val at = ab?.optString("answer").orEmpty().ifEmpty { ab?.optString("snippet").orEmpty() }
                if (kind == "s-serper" && at.isNotEmpty() && out.isNotEmpty()) out[0] = Hit(out[0].title, out[0].url, "Answer: $at\n\n" + out[0].text)
            }
            "s-gcse", "d-gcse" -> {
                val j = JSONObject(httpx(ep + join + "key=" + enc(key) + "&cx=" + enc(cx) + "&num=6&q=" + enc(q), "GET", emptyMap(), null))
                val r = arr(j, "items"); for (i in 0 until r.length()) { val x = r.optJSONObject(i) ?: continue; out.add(Hit(x.optString("title"), x.optString("link"), x.optString("snippet"))) }
            }
            "s-brave" -> {
                val j = JSONObject(httpx(ep + join + "count=6&q=" + enc(q), "GET", mapOf("X-Subscription-Token" to key), null))
                val r = j.optJSONObject("web")?.optJSONArray("results") ?: org.json.JSONArray()
                for (i in 0 until r.length()) { val x = r.optJSONObject(i) ?: continue; out.add(Hit(x.optString("title"), x.optString("url"), x.optString("description").replace(Regex("<[^>]+>"), ""))) }
            }
            "s-exa" -> {
                val body = JSONObject().put("query", q).put("numResults", 6).put("contents", JSONObject().put("text", JSONObject().put("maxCharacters", 700)))
                val j = JSONObject(httpx(ep, "POST", mapOf("x-api-key" to key), body.toString()))
                val r = arr(j, "results"); for (i in 0 until r.length()) { val x = r.optJSONObject(i) ?: continue; out.add(Hit(x.optString("title").ifEmpty { x.optString("url") }, x.optString("url"), x.optString("text"))) }
            }
            "s-jina" -> {
                val j = JSONObject(httpx(ep.trimEnd('/') + "/?q=" + enc(q), "GET", mapOf("Authorization" to "Bearer $key"), null))
                val r = arr(j, "data"); for (i in 0 until minOf(r.length(), 6)) { val x = r.optJSONObject(i) ?: continue; out.add(Hit(x.optString("title"), x.optString("url"), x.optString("description").ifEmpty { x.optString("content") }.take(700))) }
            }
            "s-pplx" -> {
                val j = JSONObject(httpx(ep, "POST", mapOf("Authorization" to "Bearer $key"), JSONObject().put("query", q).put("max_results", 6).toString()))
                val r = arr(j, "results"); for (i in 0 until r.length()) { val x = r.optJSONObject(i) ?: continue; out.add(Hit(x.optString("title"), x.optString("url"), x.optString("snippet"))) }
            }
            "s-searxng" -> {
                val base = ep.trimEnd('/').removeSuffix("/search")
                val h = HashMap<String, String>(); if (key.isNotEmpty()) h["Authorization"] = "Bearer $key"
                val j = JSONObject(httpx("$base/search?format=json&q=" + enc(q), "GET", h, null))
                val r = arr(j, "results"); for (i in 0 until minOf(r.length(), 6)) { val x = r.optJSONObject(i) ?: continue; out.add(Hit(x.optString("title"), x.optString("url"), x.optString("content"))) }
            }
        }
        return out.filter { httpOk(it.url) }.take(mx)
    }

    /** Gemini with Google Search grounding: a short factual digest plus the source links (same prompt as the app). */
    private fun geminiDigest(q: String, cfg: JSONObject): List<Hit> {
        val no = HashSet<String>(); cfg.optJSONArray("nogs")?.let { a -> for (i in 0 until a.length()) no.add(a.optString(i)) }
        val list = FloatStore.providers.filter { it.type == "gemini" && it.key.isNotBlank() && it.id !in no }.take(4)
        for (p in list) {
            try {
                val m = p.model.removePrefix("models/")
                val body = JSONObject()
                    .put("systemInstruction", JSONObject().put("parts", org.json.JSONArray().put(JSONObject().put("text", "You are a web research assistant. Use Google Search. Reply with a factual digest of what the web says (maximum 250 words). Include dates, numbers and names."))))
                    .put("contents", org.json.JSONArray().put(JSONObject().put("role", "user").put("parts", org.json.JSONArray().put(JSONObject().put("text", q)))))
                    .put("tools", org.json.JSONArray().put(JSONObject().put("google_search", JSONObject())))
                val j = JSONObject(httpx(p.base.trimEnd('/') + "/models/$m:generateContent", "POST", mapOf("x-goog-api-key" to p.key), body.toString(), 25_000))
                val c = j.optJSONArray("candidates")?.optJSONObject(0) ?: continue
                val parts = c.optJSONObject("content")?.optJSONArray("parts")
                val sb = StringBuilder()
                if (parts != null) for (i in 0 until parts.length()) { val pt = parts.optJSONObject(i) ?: continue; if (!pt.optBoolean("thought", false)) sb.append(pt.optString("text")) }
                val text = sb.toString().trim()
                val ch = c.optJSONObject("groundingMetadata")?.optJSONArray("groundingChunks")
                val src = ArrayList<Hit>()
                if (ch != null) for (i in 0 until ch.length()) {
                    val w = ch.optJSONObject(i)?.optJSONObject("web") ?: continue
                    val u = w.optString("uri"); if (httpOk(u)) src.add(Hit(w.optString("title").ifEmpty { u }, u, ""))
                }
                if (src.isNotEmpty()) return src.mapIndexed { i, s -> Hit(s.title, s.url, if (i == 0) "Google Search digest: $text" else "Source for the digest above.") }
                if (text.isNotEmpty()) return listOf(Hit("Google Search", "https://www.google.com/search?q=" + enc(q), text))
            } catch (_: Throwable) { }
        }
        return emptyList()
    }

    private fun httpx(url: String, method: String, headers: Map<String, String>, body: String?, readMs: Int = 15_000): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 10_000; c.readTimeout = readMs; c.requestMethod = method
            c.setRequestProperty("Accept", "application/json")
            headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
            if (body != null) { c.doOutput = true; c.setRequestProperty("Content-Type", "application/json"); c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) } }
            if (c.responseCode !in 200..299) throw IllegalStateException("HTTP " + c.responseCode)
            return c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally { try { c.disconnect() } catch (_: Throwable) { } }
    }

    private fun http(url: String, body: String?, auth: String?): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 10_000; c.readTimeout = 15_000
            c.setRequestProperty("Accept", "application/json")
            if (body != null) {
                c.requestMethod = "POST"; c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                if (auth != null) c.setRequestProperty("Authorization", "Bearer $auth")
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            if (c.responseCode !in 200..299) throw IllegalStateException("HTTP " + c.responseCode)
            return c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally { try { c.disconnect() } catch (_: Throwable) { } }
    }
}
