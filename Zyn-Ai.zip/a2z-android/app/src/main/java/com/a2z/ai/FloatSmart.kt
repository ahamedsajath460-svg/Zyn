package com.a2z.ai

import java.util.concurrent.ConcurrentHashMap
import org.json.JSONObject

/**
 * Intent-aware web search for the floating panel (same idea as the app chat): decides BEFORE every answer whether a live search is needed,
 * understands English / Tamil / Tanglish and follow-up questions, and rewrites the question into a standalone search query.
 * Sure cases are decided by fast rules (no API call); unsure ones ask the AI router once (cached). Call from a worker thread.
 */
object FloatSmart {
    class Decision(val go: Boolean, val q: String, val news: Boolean = false, val fresh: String = "", val why: String = "")

    private val I = RegexOption.IGNORE_CASE
    private val NEG = Regex("""\b(don'?t|do not|dont|no need|without|stop)\b.{0,25}\b(search|google|internet|web|net|browse)\b|\b(search|internet|web|net)\b.{0,18}\b(venaam|vendam|vendaam|venam|illama|illaama|pannaadha|pannadha|pannathe)\b|தேட வேண்டாம்|இணையம் வேண்டாம்""", I)
    private val EXPL = Regex("""\b(search( for| about| pannu| panni)?|google( it| pannu| la| il)?|look ?up|web ?search|(on|in|from) the (web|internet)|check (online|the web|the net|net)|browse|net ?(la|il)|internet ?(la|il)|thedi ?(paar|paaru|thaa|kudu|sollu)|thedu|find (me )?(online|links?|sources?|websites?))\b|தேடு|தேடி|இணையத்தில|இணையத்துல|கூகிள்|கூகுள்""", I)
    private val LINK = Regex("""\b(links?|url|urls|website|websites|official (site|page|website)|download (link|page|from)|docs|documentation|api reference|changelog|release notes|github|sources?|where (can|do) i (download|buy|watch|find|get))\b|இணைப்பு|இணையதளம்|வலைத்தளம்""", I)
    private val STRONG = Regex("""\b(news|headlines?|breaking|latest|newest|trending|score|scores|standings|fixtures?|schedule|price|prices|rate|rates|stock|stocks|share price|bitcoin|btc|ethereum|crypto|gold|silver|petrol|diesel|fuel|dollar|usd|exchange rate|weather|forecast|temperature|release date|released|launched|new version|patch|election|winner|ipl|world cup|box office|vilai|vila|nilavaram|seithi|seithigal|puthusa|puthu|puthiya|ippo|ippodhu|innaiku|inniku|indru|inru|innikku|ennaiku)\b|விலை|செய்தி|செய்திகள|சமீபத்திய|புதிய|இன்று|இன்றைய|இப்போது|இப்பொழுது|நிலவரம்|வானிலை|ரேட்|தேர்தல் முடிவு|அறிவிப்பு""", I)
    private val WEAK = Regex("""\b(today|tonight|yesterday|tomorrow|now|currently|current|recent(ly)?|this (week|month|year)|right now|as of|2024|2025|2026|new|ceo|president|prime minister|minister|champion|best|top|compare|comparison|review|reviews|alternatives?|available|near me|nearby|opening hours)\b|இப்போ|தற்போது|நேற்று|நாளை""", I)
    private val MATH = Regex("""^[\s\d+\-*/^().,%=x×÷√π]+$|\b(calculate|solve|simplify|integrate|differentiate|derivative|equation|factori[sz]e|sum of|product of|square root|percentage of|percent of|lcm|hcf|gcd|compound interest|average of|\d+\s*[+\-*/x×÷^]\s*\d+)\b|கணக்கிடு|கூட்டு|கழி""", I)
    private val TRANS = Regex("""\b(translate|translation|translated|meaning of|meaning in|means? in (tamil|english|sinhala|hindi)|(tamil|english|sinhala)(il|la|le)? (sollu|enna|eppadi|ezhuthu)|how (do|to) (you )?say)\b|மொழிபெயர்|தமிழில்|ஆங்கிலத்தில்|அர்த்தம்|என்றால் என்ன""", I)
    private val CRAFT = Regex("""\b(write|rewrite|compose|draft|poem|kavithai|story|essay|speech|email|letter|caption|slogan|lyrics|joke|summari[sz]e|paraphrase|proofread|grammar|improve|fix|debug|refactor|optimi[sz]e|code|coding|function|script|regex|sql|html|css|python|java(script)?|kotlin|convert)\b|கவிதை|கதை|எழுது""", I)
    private val KNOW = Regex("""^(what is|what are|what does|what was|who was|who invented|who discovered|why|how does|how do|how to|how can|explain|define|difference between|tell me about|describe|enna|eppadi|epdi|yen|yaaru)\b|^(என்ன|ஏன்|எப்படி|யார்|எது)\b|\b(explain|define|difference between|eppidi|eppadi|epdi)\b""", I)
    private val SELF = Regex("""\b(who are you|what are you|your name|who (made|created|built) you|what can you do|how are you|nee yaaru|unga peyar|un peyar|nee enna|how old are you)\b|நீ யார்|உன் பெயர்|உங்கள் பெயர்""", I)
    private val FOLLOW = Regex("""^(and|also|then|so|what about|how about|aprom|apram|appo|appuram|appadi ?na|mattrum|athu|adhu|ithu|idhu|athan|adhan|aana|ana|but|more|next|another|again|continue|tell me more|more details?|source|link|links)\b|\b(it|its|that|this|those|these|they|them|their|he|she|him|her|his|there|athu|adhu|ithu|idhu|avan|aval|avar|avanga|avangaloda|anga|angu|athoda|adhoda|ithoda)\b|^(அது|இது|அவர்|அவங்க|அங்கே|அப்புறம்|மேலும்|அதன்|இதன்|அப்போ)""", I)
    private val YEAR = Regex("""\b20(2[4-9]|3\d)\b""")
    private val QW = Regex("""\?|\b(what|who|when|where|which|how|why|is|are|does|do|did|can|will|enna|eppo|enga|evlo|evvalavo|yaar|yaaru|eppadi|epdi|irukka|irukkum|irukkaa)\b|என்ன|எவ்வளவு|எப்போது|எங்கே|யார்|இருக்கா|இருக்கு""", I)
    private val CURNOW = Regex("""\b(current(ly)?|today|tonight|right now|this (week|month|year)|as of now|as of today)\b""", I)
    private val NEWS = Regex("""\b(news|headlines?|breaking)\b|செய்தி""", I)

    private fun wc(s: String) = s.trim().split(Regex("\\s+")).count { it.isNotEmpty() }

    private class V(val v: Char, val why: String, val expl: Boolean = false, val follow: Boolean = false)

    private fun sync(text: String, prevSearched: Boolean): V {
        val t = text.trim().replace(Regex("\\s+"), " ")
        if (t.isEmpty()) return V('n', "empty")
        if (NEG.containsMatchIn(t)) return V('n', "you said not to search")
        val n = wc(t)
        val chit = n <= 4 && Regex("""^(hi+|hello+|hey+|hai|ok(ay)?|thanks?|thank you|bye|yes|no|good (morning|night|evening)|vanakkam|nandri|sari|nalla irukken|nalla irukken|eppadi irukka|epdi irukka|suhama|sugama|enna panra|how are you|super|nice|cool|haha+|lol)\W*$""", I).containsMatchIn(t)
        if (chit) return V('n', "casual chat")
        if (EXPL.containsMatchIn(t)) return V('y', "you asked to search", expl = true)
        val fresh = STRONG.containsMatchIn(t); val weak = WEAK.containsMatchIn(t) || YEAR.containsMatchIn(t)
        val link = LINK.containsMatchIn(t); val q = QW.containsMatchIn(t)
        val fup = n <= 9 && FOLLOW.containsMatchIn(t)
        if (fup && prevSearched && !MATH.containsMatchIn(t) && !TRANS.containsMatchIn(t)) return V('y', "follow-up to a searched answer", follow = true)
        if (SELF.containsMatchIn(t)) return V('n', "about me")
        if (MATH.containsMatchIn(t) && !fresh) return V('n', "maths")
        if (TRANS.containsMatchIn(t) && !fresh) return V('n', "translation")
        if (CRAFT.containsMatchIn(t) && !fresh && !link && !Regex("""\b(latest|current|new|2025|2026)\b""", I).containsMatchIn(t)) return V('n', "writing / coding")
        if (link && n <= 14) return V('y', "you want links or sources")
        if (fresh && !CRAFT.containsMatchIn(t) && (q || n >= 2)) return V('y', "needs current information")
        if (fresh) return V('m', "maybe current")
        if (q && CURNOW.containsMatchIn(t) && n >= 3) return V('y', "needs current information")
        if (fup) return V('m', "follow-up")
        if (weak && q && n >= 3) return V('m', "maybe current")
        if (KNOW.containsMatchIn(t) && !weak) return V('n', "general knowledge")
        if (n <= 3) return V('n', "short chat")
        if (!q && !weak) return V('n', "no question")
        return V('m', "unclear")
    }

    private const val ROUTER = "You decide whether answering the user's LATEST message needs a live web search. Reply with ONLY one JSON object: {\"search\":true|false,\"query\":\"...\",\"news\":true|false,\"fresh\":\"day|week|month|year|\"}.\n" +
        "search=true ONLY when the answer depends on current, recent or changing facts (news, prices, rates, scores, weather, releases, versions, current office-holders, recent events, availability, up-to-date documentation), or the user wants links, websites or sources, or asks to search.\n" +
        "search=false for greetings, small talk in any language (English, Tamil, Tanglish), maths, translation, writing, coding help, opinions, advice, timeless general knowledge, and questions about this chat or about you.\n" +
        "Use the earlier messages to resolve follow-ups (it, that, athu, avar, \"and in Chennai?\"). \"query\" must be a standalone, specific web search query (max 12 words, no pronouns, keep names and the user's language for local topics). If search=false use \"\". news=true only for news/headlines. fresh = how recent results must be, else \"\"."

    private class R(val search: Boolean, val query: String, val news: Boolean, val fresh: String)
    private val rc = ConcurrentHashMap<String, R>()
    @Volatile private var failures = 0

    private fun route(text: String, hist: List<FMsg>): R? {
        val ctx = hist.takeLast(5).dropLast(1).filter { it.text.isNotBlank() }.takeLast(4)
        val key = text.lowercase().trim() + "|" + ctx.joinToString("|") { it.text.lowercase().take(60) }
        rc[key]?.let { return it }
        if (failures >= 3) return null
        val p = FloatStore.ordered().let { l -> l.firstOrNull { it.name.contains("pollinations", true) || it.type.contains("pollinations", true) } ?: l.firstOrNull() } ?: return null
        val body = (if (ctx.isNotEmpty()) "Earlier messages:\n" + ctx.joinToString("\n") { (if (it.role == "user") "User: " else "Assistant: ") + it.text.replace(Regex("\\s+"), " ").take(220) } + "\n\n" else "") +
            "Latest user message: " + text.trim().take(400) + "\nToday: " + java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.ENGLISH).format(java.util.Date())
        return try {
            val sb = StringBuilder(); val ai = FloatAi()
            val killer = Thread { try { Thread.sleep(9000); ai.cancel() } catch (_: Throwable) { } }.also { it.isDaemon = true; it.start() }
            try { ai.stream(p, ROUTER, listOf(Turn("user", body))) { sb.append(it) } } finally { killer.interrupt() }
            val m = Regex("\\{[\\s\\S]*\\}").find(sb.toString().replace("```json", "").replace("```", "")) ?: run { failures++; return null }
            val j = JSONObject(m.value)
            val f = j.optString("fresh", "").let { if (Regex("^(day|week|month|year)$").matches(it)) it else "" }
            val r = R(j.optBoolean("search", false), j.optString("query", "").trim().take(160), j.optBoolean("news", false), f)
            if (rc.size > 150) rc.clear(); rc[key] = r; failures = 0; r
        } catch (_: Throwable) { failures++; null }
    }

    private fun plain(text: String, hist: List<FMsg>, follow: Boolean): String {
        var q = text.trim().replace(Regex("\\b(please|pls|plz|search|google|pannu|panni|paaru|thedu|sollu|kudu|thaa|venum|vendum)\\b", I), " ").replace(Regex("\\s+"), " ").trim().trimEnd('?', '!', '.')
        if (follow || wc(q) <= 3) {
            val pu = hist.dropLast(1).lastOrNull { it.role == "user" && it.text.isNotBlank() }?.text
            if (pu != null && !pu.equals(text, true)) q = pu.trim().trimEnd('?', '!', '.').take(110) + " " + q
        }
        return q.take(200).ifEmpty { text.trim().take(200) }
    }

    /** [hist] = the conversation so far INCLUDING the latest user message (last item). */
    fun decide(text: String, hist: List<FMsg>): Decision {
        if (!FloatStore.feat("web")) return Decision(false, "", why = "web search is off")
        val always = FloatStore.feat("webalways", false); val auto = FloatStore.feat("webauto")
        val prevSearched = hist.dropLast(1).lastOrNull { it.role != "user" }?.srcs?.isNotBlank() == true
        val s = sync(text, prevSearched)
        if (s.v == 'y') {
            if (!always && !auto && !s.expl) return Decision(false, "", why = "auto search is off")
            val r = if (s.follow || wc(text) <= 6 || s.expl) route(text, hist) else null
            if (r != null && !r.search && !s.expl && !s.follow) return Decision(false, "", why = "answering directly")
            return Decision(true, r?.query?.ifBlank { null } ?: plain(text, hist, s.follow), (r?.news == true) || NEWS.containsMatchIn(text), r?.fresh ?: "", s.why)
        }
        if (s.v == 'm') {
            if (!always && (!auto || wc(text) < 4)) return Decision(false, "", why = s.why)
            val r = route(text, hist)
            if (r != null) return if (r.search) Decision(true, r.query.ifBlank { plain(text, hist, s.why == "follow-up") }, r.news, r.fresh, "needs current information") else Decision(false, "", why = "answering directly")
            if (always && wc(text) >= 5) return Decision(true, plain(text, hist, s.why == "follow-up"), why = "search is on")
        }
        return Decision(false, "", why = s.why)
    }
}
