package com.a2z.ai

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URI
import java.net.URL
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import org.json.JSONArray
import org.json.JSONObject

/**
 * Sources sheet of the floating panel (same idea as the app chat's "Sources" > "More"): site icons, and reading ONE website:
 * short summary, the best "More links", and "Photos" from that site. The panel page cannot load anything from the network
 * (blockNetworkLoads), so everything is fetched here and sent to the page as text / small data: images.
 * Always call from a background thread.
 */
object FloatSources {
    private val favCache = ConcurrentHashMap<String, String>()
    private const val UA = "Mozilla/5.0 (Linux; Android 10; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36"
    private val BADL = Regex("(login|signin|sign-in|signup|sign-up|register|privacy|terms|cookie|javascript:|mailto:|tel:|^#)", RegexOption.IGNORE_CASE)
    private val BADI = Regex("(logo|sprite|icon|avatar|pixel|tracking|blank|spacer|1x1|\\.svg|\\.gif|data:)", RegexOption.IGNORE_CASE)
    private val SYS = "You help a user explore one website. You get an excerpt of one page and a numbered list of candidate links from the same website. Pick up to 8 links that are the most useful next pages related to this page. Reply with ONLY JSON, no markdown: {\"summary\":\"two short sentences about what this page is about\",\"links\":[{\"i\":1,\"why\":\"max 12 words on why it is useful\"}]}. Write summary and why in simple English unless the page title is in another language, then use that language."

    fun host(u: String): String = try { (URI(u).host ?: u).removePrefix("www.") } catch (_: Throwable) { u }

    private fun get(url: String, ms: Int, accept: String? = null, max: Int = 1_500_000): ByteArray? {
        val c = URL(url).openConnection() as HttpURLConnection
        return try {
            c.connectTimeout = ms; c.readTimeout = ms; c.instanceFollowRedirects = true
            c.setRequestProperty("User-Agent", UA); if (accept != null) c.setRequestProperty("Accept", accept)
            if (c.responseCode !in 200..299) null else c.inputStream.use { ins ->
                val out = ByteArrayOutputStream(); val buf = ByteArray(8192); var n = 0
                while (true) { val r = ins.read(buf); if (r < 0) break; out.write(buf, 0, r); n += r; if (n >= max) break }
                out.toByteArray()
            }
        } finally { try { c.disconnect() } catch (_: Throwable) { } }
    }

    /** Site icon as a data: URI (cached), or null. */
    fun favicon(host: String): String? {
        if (host.isBlank()) return null
        favCache[host]?.let { return it }
        return try {
            val b = get("https://www.google.com/s2/favicons?domain=" + java.net.URLEncoder.encode(host, "UTF-8") + "&sz=64", 6000, null, 60_000) ?: return null
            val d = "data:image/png;base64," + Base64.encodeToString(b, Base64.NO_WRAP); favCache[host] = d; d
        } catch (_: Throwable) { null }
    }

    private fun abs(u: String, base: String): String = try { URI(base).resolve(u.trim().removePrefix("<").removeSuffix(">")).toString() } catch (_: Throwable) { u }

    private class Page(val md: String, val links: List<Pair<String, String>>, val imgs: List<Triple<String, String, Int>>)   // imgs: url, alt, score

    private fun readPage(url: String): Page {
        val links = ArrayList<Pair<String, String>>(); val imgs = ArrayList<Triple<String, String, Int>>(); var md = ""
        try {   // reader service first (clean text + links + images), exactly like the app
            val b = get("https://r.jina.ai/$url", 18000, "application/json", 800_000)
            if (b != null) {
                val d = JSONObject(String(b, Charsets.UTF_8)).optJSONObject("data")
                if (d != null) {
                    md = d.optString("content", "")
                    d.optString("image", "").takeIf { it.isNotBlank() }?.let { imgs.add(Triple(abs(it, url), "", 3)) }
                    val nb = Regex("!\\[([^\\]]*)\\]\\(\\s*(<[^>]+>|[^)\\s]+)[^)]*\\)").replace(md) { m -> imgs.add(Triple(abs(m.groupValues[2], url), m.groupValues[1], 0)); " " }
                    Regex("\\[([^\\]\\n]{2,140})\\]\\(\\s*(<[^>]+>|[^)\\s]+)[^)]*\\)").findAll(nb).forEach { m -> links.add(m.groupValues[1].trim() to abs(m.groupValues[2], url)) }
                }
            }
        } catch (_: Throwable) { }
        if (links.size < 5 || imgs.size < 3) {   // fall back to the raw page
            try {
                val h = get(url, 15000)?.let { String(it, Charsets.UTF_8) } ?: ""
                if (h.length > 200) {
                    Regex("<meta[^>]+(?:property=[\"']og:image[\"']|name=[\"']twitter:image[\"'])[^>]*content=[\"']([^\"']+)[\"']", RegexOption.IGNORE_CASE).findAll(h).forEach { imgs.add(Triple(abs(it.groupValues[1], url), "", 3)) }
                    Regex("<img\\b[^>]*>", RegexOption.IGNORE_CASE).findAll(h).forEach { t ->
                        val tag = t.value
                        fun at(n: String) = Regex("\\b$n=[\"']([^\"']+)[\"']", RegexOption.IGNORE_CASE).find(tag)?.groupValues?.get(1)
                        val s = at("data-src") ?: at("data-lazy-src") ?: at("src"); if (s != null) imgs.add(Triple(abs(s, url), at("alt") ?: "", 0))
                    }
                    Regex("<a\\b[^>]*href=[\"']([^\"']+)[\"'][^>]*>(.*?)</a>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)).findAll(h).forEach { m ->
                        val t = m.groupValues[2].replace(Regex("<[^>]+>"), " ").replace(Regex("\\s+"), " ").trim(); if (t.length >= 4) links.add(t to abs(m.groupValues[1], url))
                    }
                    if (md.isBlank()) md = h.replace(Regex("(?is)<(script|style)[^>]*>.*?</\\1>"), " ").replace(Regex("<[^>]+>"), " ").replace(Regex("\\s+"), " ").take(6000)
                }
            } catch (_: Throwable) { }
        }
        return Page(md, links, imgs)
    }

    private fun clean(u: String) = u.substringBefore('#').trimEnd('/').lowercase()

    private fun thumb(url: String): String? = try {
        val b = get(url, 7000, null, 1_200_000) ?: return null
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }; BitmapFactory.decodeByteArray(b, 0, b.size, o)
        if (o.outWidth < 120 || o.outHeight < 80) return null
        var s = 1; while (o.outWidth / (s * 2) >= 360) s *= 2
        val bm = BitmapFactory.decodeByteArray(b, 0, b.size, BitmapFactory.Options().apply { inSampleSize = s }) ?: return null
        val sc = if (bm.width > 360) Bitmap.createScaledBitmap(bm, 360, maxOf(1, bm.height * 360 / bm.width), true) else bm
        val out = ByteArrayOutputStream(); sc.compress(Bitmap.CompressFormat.JPEG, 70, out)
        if (out.size() > 120_000) null else "data:image/jpeg;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    } catch (_: Throwable) { null }

    /** Reads [url] and reports through [emit] (each call = one JSON event for the page): st (status), sum + links, img (one photo), fin (final line). */
    fun read(id: String, url: String, title: String, alive: () -> Boolean, emit: (JSONObject) -> Unit) {
        val host = host(url)
        fun e(vararg kv: Pair<String, Any?>) { if (alive()) emit(JSONObject().put("id", id).also { o -> kv.forEach { (k, v) -> o.put(k, v) } }) }
        try {
            val pg = readPage(url)
            if (!alive()) return
            val key = clean(url); val cand = LinkedHashMap<String, Array<Any>>()   // key -> [title, url, snippet, same, score]
            fun add(t0: String, u0: String, sn: String, sc: Int) {
                val u = abs(u0, url); if (!(u.startsWith("http://") || u.startsWith("https://"))) return
                val k = clean(u); if (k.isEmpty() || k == key || BADL.containsMatchIn(u)) return
                val hh = host(u); val same = hh == host || hh.endsWith(".$host") || host.endsWith(".$hh"); val t = t0.replace(Regex("\\s+"), " ").trim()
                val depth = try { if (URI(u).path.split('/').count { it.isNotEmpty() } >= 2) 1 else 0 } catch (_: Throwable) { 0 }
                val s = (if (same) 5 else 0) + sc + minOf(t.length, 60) / 20 + depth
                val o = cand[k]; if (o == null || (o[4] as Int) < s) cand[k] = arrayOf<Any>(t.ifEmpty { (o?.get(0) as? String) ?: "" }, u, sn.ifEmpty { (o?.get(2) as? String) ?: "" }, same, s)
            }
            pg.links.forEach { if (it.first.length >= 4) add(it.first, it.second, "", 0) }
            try { FloatSearch.search("site:$host " + title.ifBlank { host }).forEach { h -> add(h.title, h.url, if (h.text.startsWith("Web digest") || h.text.startsWith("Source for")) "" else h.text.replace(Regex("\\s+"), " ").take(160), 3) } } catch (_: Throwable) { }
            var list = cand.values.sortedByDescending { it[4] as Int }
            val same = list.filter { it[3] as Boolean }; if (same.size >= 3) list = same
            list = list.take(40)
            var sum = ""; var picks: List<Pair<Int, String>>? = null
            if (list.isNotEmpty()) {
                e("st" to "AI is choosing the best links…")
                try {
                    val p = FloatStore.ordered().firstOrNull()
                    if (p != null) {
                        val txt = "Page: ${title.ifBlank { host }} ($url)\n\nPage text:\n" + pg.md.replace(Regex("\\s+"), " ").take(3500) + "\n\nCandidate links:\n" +
                            list.mapIndexed { i, x -> "${i + 1}. " + (x[0] as String).ifEmpty { "(no title)" }.take(100) + " - " + x[1] + (if ((x[2] as String).isNotEmpty()) " | " + (x[2] as String).take(100) else "") }.joinToString("\n")
                        val sb = StringBuilder(); FloatAi().stream(p, SYS, listOf(Turn("user", txt))) { sb.append(it) }
                        val m = Regex("\\{[\\s\\S]*\\}").find(sb.toString())
                        if (m != null) {
                            val j = JSONObject(m.value); sum = j.optString("summary", "")
                            val seen = HashSet<Int>(); val l = ArrayList<Pair<Int, String>>(); val a = j.optJSONArray("links") ?: JSONArray()
                            for (k in 0 until a.length()) { val q = a.optJSONObject(k) ?: continue; val i = q.optInt("i") - 1; if (i in list.indices && seen.add(i)) l.add(i to q.optString("why", "")) }
                            picks = l
                        }
                    }
                } catch (_: Throwable) { }
            }
            if (!alive()) return
            val pk = (if (picks.isNullOrEmpty()) list.take(8).mapIndexed { i, x -> i to (x[2] as String) } else picks!!).take(8)
            val la = JSONArray(); pk.forEach { (i, why) -> val x = list[i]; la.put(JSONObject().put("t", (x[0] as String).ifEmpty { host(x[1] as String) }).put("u", x[1]).put("why", why).put("p", host(x[1] as String) + try { URI(x[1] as String).path.trimEnd('/') } catch (_: Throwable) { "" })) }
            e("sum" to sum, "links" to la)
            val seenI = HashSet<String>()
            val imgs = pg.imgs.filter { it.first.startsWith("http") && !BADI.containsMatchIn(it.first) && seenI.add(it.first) }.sortedByDescending { it.third }.take(14)
            var shown = 0
            if (imgs.isNotEmpty()) {
                val pool = Executors.newFixedThreadPool(4)
                imgs.forEach { im -> pool.execute { if (alive() && shown < 12) { val d = thumb(im.first); if (d != null && alive()) { synchronized(this) { if (shown < 12) { shown++; e("img" to JSONObject().put("u", im.first).put("d", d)) } } } } } }
                pool.shutdown(); try { pool.awaitTermination(40, TimeUnit.SECONDS) } catch (_: Throwable) { }
            }
            e("fin" to if (pk.isNotEmpty() || shown > 0) "Tap a link or photo to open it. Photos belong to their owners." else "Nothing found. The website may block the app. Tap Open website.")
        } catch (_: Throwable) { e("fin" to "Could not read this website. Tap Open website.") }
    }
}
