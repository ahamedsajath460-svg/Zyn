package com.a2z.ai

import android.app.AppOpsManager
import android.content.Context
import android.graphics.Color
import android.os.Build
import android.os.Process
import android.provider.Settings
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** One text-capable provider exactly as the app's own provider manager resolved it (ready, in the app's priority order). */
class FProvider(val id: String, val name: String, val type: String, val base: String, val model: String, val key: String) {
    // Built-in (secret) providers arrive from the page with a neutral "Zyn Ai N" name: show only that, never the model.
    val label get() = if (name.startsWith("Zyn Ai")) name else (if (name.isNotBlank()) name else type) + " · " + model
}

class FMsg(val role: String, var text: String, val ts: Long, var via: String = "")

class FConv(val id: String, var title: String, var updated: Long, val msgs: MutableList<FMsg>) {
    var pinned = false; var name = ""
    var imported = 0          // how many messages the app's chat history already has
    val dirty get() = msgs.any { it.text.isNotBlank() } && msgs.size > imported
}

/**
 * Bridge state between the app's JavaScript (provider manager, keys, theme) and the native floating panel.
 *
 * - Providers/API keys: kept IN MEMORY ONLY (pushed by the page via A2ZNative.floatSync). Never written to disk by native code.
 * - Floating conversations: stored in the app's private files dir (text only) until the app's chat history has imported them.
 */
object FloatStore {
    private val lock = Any()
    @Volatile var providers: List<FProvider> = emptyList()
    @Volatile var synced = false
    @Volatile var systemBase = ""
    @Volatile var theme = "auto"
    @Volatile var colors: Map<String, Int> = emptyMap()
    /** Provider picked inside the floating panel (does NOT change the app's primary provider). */
    @Volatile var selectedId: String? = null

    private var file: File? = null
    private val convs = ArrayList<FConv>()
    private var currentId: String? = null
    private var loaded = false

    fun init(ctx: Context) = synchronized(lock) {
        if (loaded) return@synchronized
        file = File(ctx.applicationContext.filesDir, "a2z_float_chats.json")
        loaded = true
        try {
            val f = file!!
            if (!f.exists()) return@synchronized
            val root = JSONObject(f.readText())
            currentId = root.optString("cur").ifEmpty { null }
            val arr = root.optJSONArray("convs") ?: return@synchronized
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val ms = ArrayList<FMsg>()
                val ma = o.optJSONArray("m") ?: JSONArray()
                for (k in 0 until ma.length()) {
                    val m = ma.optJSONObject(k) ?: continue
                    ms.add(FMsg(m.optString("r", "user"), m.optString("t", ""), m.optLong("ts"), m.optString("v", "")))
                }
                convs.add(FConv(o.optString("id"), o.optString("title", "Floating chat"), o.optLong("u"), ms).also { it.imported = o.optInt("n"); it.pinned = o.optBoolean("pin"); it.name = o.optString("nm") })
            }
        } catch (_: Throwable) { /* corrupt file: start clean */ convs.clear() }
    }

    // ---------- provider/theme sync (called from the WebView JS bridge thread) ----------
    fun applySync(json: String): Boolean {
        return try {
            val o = JSONObject(json)
            val list = ArrayList<FProvider>()
            val arr = o.optJSONArray("providers") ?: JSONArray()
            for (i in 0 until arr.length()) {
                val p = arr.optJSONObject(i) ?: continue
                val type = p.optString("type", "openai").let { if (it == "anthropic" || it == "gemini") it else "openai" }
                val base = p.optString("base").trim().trimEnd('/')
                val model = p.optString("model").trim()
                if (base.isEmpty() || model.isEmpty()) continue
                list.add(FProvider(p.optString("id"), p.optString("name"), type, base, model, p.optString("key").trim()))
            }
            val cm = HashMap<String, Int>()
            o.optJSONObject("colors")?.let { c -> c.keys().forEach { k -> parseColor(c.optString(k))?.let { v -> cm[k] = v } } }
            systemBase = o.optString("sys")
            theme = o.optString("theme", "auto").ifEmpty { "auto" }
            colors = cm
            providers = list
            if (selectedId != null && list.none { it.id == selectedId }) selectedId = null
            synced = true
            true
        } catch (_: Throwable) { false }
    }

    private fun parseColor(s: String): Int? {
        var v = s.trim()
        if (!v.startsWith("#")) return null
        if (v.length == 4) v = "#" + v[1] + v[1] + v[2] + v[2] + v[3] + v[3]
        return try { Color.parseColor(v) } catch (_: Throwable) { null }
    }

    fun ordered(): List<FProvider> {
        val l = providers
        val sel = l.firstOrNull { it.id == selectedId } ?: return l
        return listOf(sel) + l.filter { it !== sel }
    }

    // ---------- conversations ----------
    fun current(): FConv = synchronized(lock) {
        convs.firstOrNull { it.id == currentId } ?: newConvLocked()
    }

    private fun newConvLocked(): FConv {
        val c = FConv("f" + java.lang.Long.toString(System.currentTimeMillis(), 36) + (Math.random() * 1000).toInt(), "Floating chat", System.currentTimeMillis(), ArrayList())
        convs.add(c); currentId = c.id
        return c
    }

    /** Clear Chat: start a fresh conversation. The previous one (if it had messages) stays queued for the app's chat history. */
    fun newConv(): FConv = synchronized(lock) {
        val cur = convs.firstOrNull { it.id == currentId }
        if (cur != null && cur.msgs.isEmpty()) return@synchronized cur
        newConvLocked()
    }

    fun addMsg(c: FConv, m: FMsg) = synchronized(lock) {
        c.msgs.add(m); c.updated = System.currentTimeMillis()
        if (c.msgs.size == 1 && m.role == "user") c.title = m.text.replace(Regex("\\s+"), " ").trim().take(40).ifEmpty { "Floating chat" }
        while (c.msgs.size > 200) { c.msgs.removeAt(0); if (c.imported > 0) c.imported-- }
    }

    fun setText(m: FMsg, t: String, via: String? = null) = synchronized(lock) { m.text = t; if (via != null) m.via = via }

    fun removeMsg(c: FConv, m: FMsg) = synchronized(lock) { c.msgs.remove(m); Unit }

    fun snapshot(c: FConv): List<FMsg> = synchronized(lock) { c.msgs.filter { it.text.isNotBlank() } }

    // ---------- hand-over to the app's chat history (JS bridge) ----------
    fun peekJson(): String = synchronized(lock) {
        val out = JSONArray()
        for (c in convs) {
            val ms = c.msgs.filter { it.text.isNotBlank() }
            if (ms.isEmpty() || c.msgs.size <= c.imported) continue
            val mj = JSONArray()
            ms.forEach { m -> mj.put(JSONObject().put("r", m.role).put("t", m.text).put("ts", m.ts).put("v", m.via)) }
            out.put(JSONObject().put("id", c.id).put("title", c.title).put("updated", c.updated).put("msgs", mj))
        }
        out.toString()
    }

    fun ackJson(json: String) = synchronized(lock) {
        try {
            val a = JSONArray(json)
            for (i in 0 until a.length()) {
                val o = a.optJSONObject(i) ?: continue
                convs.firstOrNull { it.id == o.optString("id") }?.let { it.imported = o.optInt("n").coerceIn(0, it.msgs.size) }
            }
            // Fully imported, non-current conversations are now in the app's history: drop the native copy.
            convs.removeAll { it.id != currentId && it.imported >= it.msgs.size }
            writeLocked()
        } catch (_: Throwable) { }
    }

    // ---------- chat history management for the unified panel ----------
    fun list(): List<FConv> = synchronized(lock) { convs.filter { c -> c.msgs.any { it.text.isNotBlank() } }.sortedByDescending { it.updated } }
    fun open(id: String): Boolean = synchronized(lock) { if (convs.any { it.id == id }) { currentId = id; true } else false }
    fun pin(id: String) = synchronized(lock) { convs.firstOrNull { it.id == id }?.let { it.pinned = !it.pinned }; writeLocked() }
    fun rename(id: String, n: String) = synchronized(lock) { convs.firstOrNull { it.id == id }?.name = n.trim().take(60); writeLocked() }
    fun delete(ids: Set<String>) = synchronized(lock) { convs.removeAll { it.id in ids }; if (currentId in ids) currentId = null; writeLocked() }
    fun titleOf(c: FConv) = c.name.ifBlank { c.title }

    fun save() = synchronized(lock) { writeLocked() }

    private fun writeLocked() {
        val f = file ?: return
        try {
            val arr = JSONArray()
            for (c in convs.takeLast(30)) {
                val ma = JSONArray()
                c.msgs.filter { it.text.isNotBlank() }.forEach { m -> ma.put(JSONObject().put("r", m.role).put("t", m.text).put("ts", m.ts).put("v", m.via)) }
                arr.put(JSONObject().put("id", c.id).put("title", c.title).put("u", c.updated).put("n", c.imported).put("pin", c.pinned).put("nm", c.name).put("m", ma))
            }
            val tmp = File(f.parentFile, f.name + ".tmp")
            tmp.writeText(JSONObject().put("cur", currentId ?: "").put("convs", arr).toString())
            if (!tmp.renameTo(f)) { f.delete(); tmp.renameTo(f) }
        } catch (_: Throwable) { }
    }
}

object FloatPerm {
    /** True when Android lets this app draw over other apps. Includes a fallback for a known Android 8.0 canDrawOverlays() bug. */
    fun has(ctx: Context): Boolean {
        try { if (Settings.canDrawOverlays(ctx)) return true } catch (_: Throwable) { }
        if (Build.VERSION.SDK_INT == Build.VERSION_CODES.O) {
            try {
                val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
                @Suppress("DEPRECATION")
                return ops.checkOpNoThrow("android:system_alert_window", Process.myUid(), ctx.packageName) == AppOpsManager.MODE_ALLOWED
            } catch (_: Throwable) { }
        }
        return false
    }
}
