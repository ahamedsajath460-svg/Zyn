package com.a2z.ai

import android.app.PendingIntent
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import androidx.core.content.ContextCompat

/**
 * Quick Settings tile ("Zyn Float") for the notification panel: one tap starts or stops the floating assistant.
 * Without the "Display over other apps" permission the tile opens the app, which then shows the permission dialog.
 */
class FloatTileService : TileService() {
    companion object {
        /** Asks Android to call onStartListening again so the tile shows the current state. */
        fun refresh(ctx: Context) {
            try { TileService.requestListeningState(ctx, ComponentName(ctx, FloatTileService::class.java)) } catch (_: Throwable) { }
        }
    }

    override fun onStartListening() { render(FloatingAssistantService.running) }

    override fun onClick() {
        if (FloatingAssistantService.running) {
            try { stopService(Intent(this, FloatingAssistantService::class.java)) } catch (_: Throwable) { }
            render(false); return
        }
        if (!FloatPerm.has(this)) { openApp(); return }
        try {
            ContextCompat.startForegroundService(this, Intent(this, FloatingAssistantService::class.java).setAction(FloatingAssistantService.ACT_START))
            render(true)
        } catch (_: Throwable) { openApp() }
    }

    private fun render(on: Boolean) {
        val t = qsTile ?: return
        t.state = if (on) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        t.label = "Zyn Float"
        if (Build.VERSION.SDK_INT >= 29) t.subtitle = if (on) "On" else "Off"
        t.icon = Icon.createWithResource(this, R.drawable.ic_zw_bubble)
        t.updateTile()
    }

    private fun openApp() {
        val i = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP).putExtra("a2z_float_start", true)
        if (Build.VERSION.SDK_INT >= 34) {
            startActivityAndCollapse(PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
        } else {
            @Suppress("DEPRECATION") startActivityAndCollapse(i)
        }
    }
}
