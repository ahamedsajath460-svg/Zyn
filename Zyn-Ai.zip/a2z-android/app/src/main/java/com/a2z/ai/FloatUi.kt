package com.a2z.ai

import android.content.Context
import android.content.res.Configuration
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.text.Spannable
import android.text.SpannableStringBuilder
import android.text.style.*
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.widget.EditText
import android.widget.FrameLayout

/** Material 3 colour roles, identical to the CSS variables in a2z.html so the panel matches the app theme. */
class Pal(val bg: Int, val side: Int, val ink: Int, val mut: Int, val line: Int, val usr: Int, val acc: Int, val onAcc: Int, val bad: Int, val code: Int) {
    companion object {
        private fun c(v: Int) = v or (0xFF shl 24)
        val LIGHT = Pal(c(0xFEF7FF), c(0xF3EDF7), c(0x1D1B20), c(0x49454F), c(0xCAC4D0), c(0xE8DEF8), c(0x6750A4), c(0xFFFFFF), c(0xB3261E), c(0xECE6F0))
        val DARK = Pal(c(0x141218), c(0x211F26), c(0xE6E0E9), c(0xCAC4D0), c(0x49454F), c(0x4A4458), c(0xD0BCFF), c(0x381E72), c(0xF2B8B5), c(0x2B2930))
        private val NAMED = mapOf(
            "amoled" to Pal(c(0x000000), c(0x121212), c(0xE6E0E9), c(0xCAC4D0), c(0x2B2930), c(0x2B2930), c(0xD0BCFF), c(0x381E72), c(0xF2B8B5), c(0x141218)),
            "ocean" to Pal(c(0x0B1A2A), c(0x12273D), c(0xE3EEFB), c(0xA6BAD3), c(0x27425F), c(0x1B3856), c(0x8ECBFF), c(0x00325A), c(0xFFB4AB), c(0x0A1626)),
            "forest" to Pal(c(0xF6FBF3), c(0xE8F0E4), c(0x181D17), c(0x424940), c(0xC1C9BE), c(0xD6E8D1), c(0x3A6A3C), c(0xFFFFFF), c(0xB3261E), c(0xE1EADD)),
            "rose" to Pal(c(0xFFF8F7), c(0xFCEAE8), c(0x201A19), c(0x534341), c(0xD8C2BF), c(0xFFDAD6), c(0x904A45), c(0xFFFFFF), c(0xB3261E), c(0xF5E1DE)))

        fun resolve(ctx: Context): Pal {
            val night = (ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
            val auto = if (night) DARK else LIGHT
            return when (val t = FloatStore.theme) {
                "", "auto" -> auto
                "light" -> LIGHT
                "dark" -> DARK
                else -> synced(FloatStore.colors) ?: NAMED[t] ?: auto
            }
        }

        private fun synced(m: Map<String, Int>): Pal? {
            val k = listOf("bg", "side", "ink", "mut", "line", "usr", "acc", "onacc", "bad", "code").map { m[it] ?: return null }
            return Pal(k[0], k[1], k[2], k[3], k[4], k[5], k[6], k[7], k[8], k[9])
        }
    }
    val dark get() = Color.luminance(bg) < 0.5f
}

fun roundRect(color: Int, radiusPx: Float, stroke: Int = 0, strokePx: Int = 0) = GradientDrawable().apply {
    setColor(color); cornerRadius = radiusPx; if (strokePx > 0) setStroke(strokePx, stroke)
}

/** Chat-screen "Nebula" glass look, derived from the active theme palette so every theme keeps working. */
fun Pal.glass(): Int = (bg and 0x00FFFFFF) or (0xEB shl 24)        // panel: ~92% opaque theme background
fun Pal.glassSoft(): Int = (side and 0x00FFFFFF) or (0xB8 shl 24)  // controls on the panel: ~72% opaque
fun Pal.nline(): Int = (acc and 0x00FFFFFF) or (0x44 shl 24)       // hairline border tinted with the accent

/** Message bubble shaped like the chat screen: user = rounded with a small bottom-right corner, assistant = small top-left corner. */
fun bubbleRect(pal: Pal, user: Boolean, dp: Float) = GradientDrawable().apply {
    val big = 20f * dp; val small = 6f * dp
    cornerRadii = if (user) floatArrayOf(big, big, big, big, small, small, big, big) else floatArrayOf(small, small, big, big, big, big, big, big)
    if (user) { orientation = GradientDrawable.Orientation.TL_BR; colors = intArrayOf((pal.acc and 0x00FFFFFF) or (0x3A shl 24), (pal.acc and 0x00FFFFFF) or (0x22 shl 24)); setStroke(maxOf(1, dp.toInt()), pal.nline()) }
    else { setColor(pal.glassSoft()); setStroke(maxOf(1, dp.toInt()), pal.nline()) }
}

/** Minimal SVG path parser (M L H V C S Z, absolute+relative) so the panel can reuse the app's 24dp Material icons with no resources. */
object SvgPath {
    private val tok = Regex("([MmLlHhVvCcSsZz])|(-?(?:\\d+\\.?\\d*|\\.\\d+)(?:[eE][-+]?\\d+)?)")
    fun parse(d: String): Path {
        val p = Path(); val t = tok.findAll(d).map { it.value }.toList()
        var i = 0; var cmd = 'M'; var x = 0f; var y = 0f; var sx = 0f; var sy = 0f; var lcx = 0f; var lcy = 0f
        fun n() = t[i++].toFloat()
        while (i < t.size) {
            if (t[i][0].isLetter()) cmd = t[i++][0]
            val rel = cmd.isLowerCase()
            when (cmd.uppercaseChar()) {
                'M' -> { val a = n(); val b = n(); x = if (rel) x + a else a; y = if (rel) y + b else b; p.moveTo(x, y); sx = x; sy = y; cmd = if (rel) 'l' else 'L' }
                'L' -> { val a = n(); val b = n(); x = if (rel) x + a else a; y = if (rel) y + b else b; p.lineTo(x, y) }
                'H' -> { val a = n(); x = if (rel) x + a else a; p.lineTo(x, y) }
                'V' -> { val a = n(); y = if (rel) y + a else a; p.lineTo(x, y) }
                'C' -> { val a = n(); val b = n(); val c = n(); val dd = n(); val e = n(); val f = n()
                    val o = if (rel) x else 0f; val q = if (rel) y else 0f
                    p.cubicTo(o + a, q + b, o + c, q + dd, o + e, q + f); lcx = o + c; lcy = q + dd; x = o + e; y = q + f }
                'S' -> { val c = n(); val dd = n(); val e = n(); val f = n()
                    val o = if (rel) x else 0f; val q = if (rel) y else 0f
                    p.cubicTo(2 * x - lcx, 2 * y - lcy, o + c, q + dd, o + e, q + f); lcx = o + c; lcy = q + dd; x = o + e; y = q + f }
                'Z' -> { p.close(); x = sx; y = sy }
                else -> return p
            }
        }
        return p
    }
}

object Ic {
    const val SPARKLE = "M19 9l1.25-2.75L23 5l-2.75-1.25L19 1l-1.25 2.75L15 5l2.75 1.25L19 9zm-7.5.5L9 4 6.5 9.5 1 12l5.5 2.5L9 20l2.5-5.5L17 12l-5.5-2.5zM19 15l-1.25 2.75L15 19l2.75 1.25L19 23l1.25-2.75L23 19l-2.75-1.25L19 15z"
    const val MIN = "M19 13H5v-2h14v2z"
    const val MAX = "M7 14H5v5h5v-2H7v-3zm-2-4h2V7h3V5H5v5zm12 7h-3v2h5v-5h-2v3zM14 5v2h3v3h2V5h-5z"
    const val RESTORE = "M5 16h3v3h2v-5H5v2zm3-8H5v2h5V5H8v3zm6 11h2v-3h3v-2h-5v5zm2-11V5h-2v5h5V8h-3z"
    const val CLOSE = "M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"
    const val SEND = "M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"
    const val STOP = "M6 6h12v12H6z"
    const val COPY = "M16 1H4c-1.1 0-2 .9-2 2v14h2V3h12V1zm3 4H8c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h11c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zm0 16H8V7h11v14z"
    const val DELETE = "M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"
    const val MORE = "M7.41 8.59L12 13.17l4.59-4.58L18 10l-6 6-6-6 1.41-1.41z"
    const val CAMERA = "M9 2L7.17 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2h-3.17L15 2H9zm3 15c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5z"
    const val PAUSE = "M6 19h4V5H6v14zm8-14v14h4V5h-4z"
    const val PLAY = "M8 5v14l11-7z"
    const val CHECK = "M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"
}

class IconView(ctx: Context, d: String, var tint: Int) : View(ctx) {
    private var path = SvgPath.parse(d)
    private val scaled = Path()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    fun setIcon(d: String) { path = SvgPath.parse(d); onSizeChanged(width, height, width, height); invalidate() }
    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val s = minOf(w, h) / 24f
        val m = Matrix().apply { setScale(s, s); postTranslate((w - 24 * s) / 2f, (h - 24 * s) / 2f) }
        path.transform(m, scaled)
    }
    override fun onDraw(c: Canvas) { paint.color = tint; c.drawPath(scaled, paint) }
}

/** The draggable bubble. Tap = toggle panel, drag = move (service snaps it to an edge on release). */
class BubbleView(ctx: Context, pal: Pal) : View(ctx) {
    var onTap: (() -> Unit)? = null
    var onDrag: ((Float, Float) -> Unit)? = null
    var onRelease: ((Boolean) -> Unit)? = null
    var badge = false; set(v) { field = v; invalidate() }
    /** Red dot at the bottom-right of the bubble while screen capture is on. */
    var capturing = false; set(v) { field = v; invalidate() }
    private var fill = pal.acc; private var ink = pal.onAcc; private var dot = pal.bad
    private var orb: RadialGradient? = null
    private fun mix(a: Int, b: Int, t: Float): Int {
        fun ch(x: Int, y: Int) = (x + (y - x) * t).toInt().coerceIn(0, 255)
        return Color.rgb(ch(Color.red(a), Color.red(b)), ch(Color.green(a), Color.green(b)), ch(Color.blue(a), Color.blue(b)))
    }
    /** Glossy sphere like the orb in the chat header: highlight at the top-left, accent in the middle, darker rim. */
    private fun buildOrb() {
        val w = width.toFloat(); if (w <= 0f) return
        orb = RadialGradient(w * 0.36f, w * 0.30f, w * 0.64f, intArrayOf(mix(fill, Color.WHITE, 0.55f), fill, mix(fill, Color.BLACK, 0.28f)), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
    }
    private val icon = SvgPath.parse(Ic.SPARKLE); private val scaled = Path()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    private var dx = 0f; private var dy = 0f; private var lx = 0f; private var ly = 0f; private var moved = false
    fun setPal(p: Pal) { fill = p.acc; ink = p.onAcc; dot = p.bad; buildOrb(); invalidate() }
    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        buildOrb()
        val s = (w * 0.5f) / 24f
        scaled.reset(); icon.transform(Matrix().apply { setScale(s, s); postTranslate((w - 24 * s) / 2f, (h - 24 * s) / 2f) }, scaled)
    }
    override fun onDraw(c: Canvas) {
        val r = width / 2f
        paint.style = Paint.Style.FILL; paint.color = 0x33000000; c.drawCircle(r, r + 2, r - 2, paint)
        if (orb != null) { paint.shader = orb; c.drawCircle(r, r, r - 3, paint); paint.shader = null } else { paint.color = fill; c.drawCircle(r, r, r - 3, paint) }
        paint.style = Paint.Style.STROKE; paint.strokeWidth = maxOf(1.5f, width * 0.02f); paint.color = 0x66FFFFFF; c.drawCircle(r, r, r - 3, paint); paint.style = Paint.Style.FILL
        paint.color = ink; c.drawPath(scaled, paint)
        if (badge) { paint.color = dot; c.drawCircle(width * 0.8f, height * 0.2f, width * 0.12f, paint) }
        if (capturing) { paint.color = 0xFFFFFFFF.toInt(); c.drawCircle(width * 0.8f, height * 0.8f, width * 0.15f, paint); paint.color = 0xFFE53935.toInt(); c.drawCircle(width * 0.8f, height * 0.8f, width * 0.11f, paint) }
    }
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; lx = dx; ly = dy; moved = false }
            MotionEvent.ACTION_MOVE -> {
                if (!moved && Math.hypot((e.rawX - dx).toDouble(), (e.rawY - dy).toDouble()) > slop) moved = true
                if (moved) { onDrag?.invoke(e.rawX - lx, e.rawY - ly) }
                lx = e.rawX; ly = e.rawY
            }
            MotionEvent.ACTION_UP -> { if (!moved) onTap?.invoke(); onRelease?.invoke(moved) }
            MotionEvent.ACTION_CANCEL -> onRelease?.invoke(moved)
        }
        return true
    }
}

class PanelRoot(ctx: Context) : FrameLayout(ctx) {
    var onBack: (() -> Boolean)? = null
    var onFocus: ((Boolean) -> Unit)? = null
    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (e.keyCode == KeyEvent.KEYCODE_BACK && e.action == KeyEvent.ACTION_UP && onBack?.invoke() == true) return true
        return super.dispatchKeyEvent(e)
    }
    override fun onWindowFocusChanged(has: Boolean) { super.onWindowFocusChanged(has); onFocus?.invoke(has) }
}

class PanelEdit(ctx: Context) : EditText(ctx) {
    var onImeBack: (() -> Unit)? = null
    override fun onKeyPreIme(k: Int, e: KeyEvent): Boolean {
        if (k == KeyEvent.KEYCODE_BACK && e.action == KeyEvent.ACTION_UP) { onImeBack?.invoke(); return true }
        return super.onKeyPreIme(k, e)
    }
}

/** Tiny markdown renderer: code fences, `inline code`, **bold**, headings, bullets. Cheap enough to run while streaming. */
object MiniMd {
    private val inl = Regex("\\*\\*(.+?)\\*\\*|`([^`\\n]+)`")
    private val head = Regex("^\\s{0,3}#{1,6}\\s+")
    private val bullet = Regex("^(\\s*)[-*]\\s+")
    fun render(src: String, pal: Pal): CharSequence {
        val sb = SpannableStringBuilder(); var code = false; var first = true
        for (raw in src.split("\n")) {
            if (raw.trimStart().startsWith("```")) { code = !code; continue }
            if (!first) sb.append('\n'); first = false
            val st = sb.length
            if (code) {
                sb.append(raw)
                sb.setSpan(TypefaceSpan("monospace"), st, sb.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                sb.setSpan(BackgroundColorSpan(pal.code), st, sb.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                continue
            }
            var line = raw; var h = false
            head.find(line)?.let { line = line.substring(it.value.length); h = true }
            bullet.find(line)?.let { line = it.groupValues[1] + "• " + line.substring(it.value.length) }
            var last = 0
            for (m in inl.findAll(line)) {
                sb.append(line, last, m.range.first)
                val s = sb.length
                if (m.groupValues[1].isNotEmpty()) { sb.append(m.groupValues[1]); sb.setSpan(StyleSpan(Typeface.BOLD), s, sb.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE) }
                else { sb.append(m.groupValues[2]); sb.setSpan(TypefaceSpan("monospace"), s, sb.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE); sb.setSpan(BackgroundColorSpan(pal.code), s, sb.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE) }
                last = m.range.last + 1
            }
            sb.append(line, last, line.length)
            if (h) { sb.setSpan(StyleSpan(Typeface.BOLD), st, sb.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE); sb.setSpan(RelativeSizeSpan(1.12f), st, sb.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE) }
        }
        return sb
    }
}
