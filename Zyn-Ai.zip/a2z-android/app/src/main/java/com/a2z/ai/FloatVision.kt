package com.a2z.ai

/**
 * Decides whether a provider's model can take image input. Image input is part of the official API of all three request formats
 * (Anthropic "image" blocks, Gemini "inlineData", OpenAI-style "image_url"), but NOT every model behind them accepts images.
 * There is no universal capability endpoint, so this is a conservative name-based check:
 *  YES = known image-capable family, NO = known text-only model (blocked, user must pick another), UNKNOWN = tried, and the API's answer is shown.
 */
object FloatVision {
    enum class S { YES, NO, UNKNOWN }

    private val textOnly = listOf("embedding", "embed-", "whisper", "tts", "imagen", "rerank", "moderation", "gpt-3.5", "gpt-oss", "deepseek-chat",
        "deepseek-reasoner", "deepseek-r1", "o1-mini", "o1-preview", "o3-mini", "codestral", "mixtral", "text-davinci", "claude-2", "claude-1",
        "claude-instant", "gemini-1.0", "llama-3.2-1b", "llama-3.2-3b", "llama-3.1", "llama-3.3", "llama3-", "gemma-3-1b", "gemma-2", "aqa")
    private val visionMark = listOf("vision", "-vl", "vl-", "llava", "pixtral", "minicpm-v", "internvl", "glm-4v", "moondream", "smolvlm", "omni")
    private val openAiVision = listOf("gpt-4o", "gpt-4.1", "gpt-4.5", "gpt-4-turbo", "gpt-5", "chatgpt-4o", "llama-3.2-11b", "llama-3.2-90b", "llama-4",
        "mistral-small-3", "mistral-medium", "grok-4", "gemini", "claude", "phi-4-multimodal")

    fun support(p: FProvider): S {
        val m = p.model.lowercase().removePrefix("models/")
        fun has(l: List<String>) = l.any { m.contains(it) }
        val vm = has(visionMark)
        if (m == "gemini-pro" || (m == "gpt-4" || (m.startsWith("gpt-4-") && !has(openAiVision) && !vm))) return S.NO
        if (!vm && has(textOnly)) return S.NO
        if (vm) return S.YES
        return when (p.type) {
            "anthropic" -> if (m.contains("claude")) S.YES else S.UNKNOWN
            "gemini" -> if (m.startsWith("gemini")) S.YES else S.UNKNOWN
            else -> if (has(openAiVision) || Regex("^o[134](-|$)").containsMatchIn(m)) S.YES else S.UNKNOWN
        }
    }

    fun tag(p: FProvider) = when (support(p)) { S.YES -> "image"; S.NO -> "text only"; S.UNKNOWN -> "image: unknown" }
}
