package com.a2z.ai

import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Point
import android.graphics.Typeface
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.text.InputType
import android.util.Base64
import android.util.DisplayMetrics
import android.util.TypedValue
import android.view.*
import android.view.WindowManager.LayoutParams
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Floating assistant: draggable bubble + chat panel drawn over other apps (TYPE_APPLICATION_OVERLAY, needs "Display over other apps").
 * Uses the providers / keys / theme / persona pushed by the app's existing provider manager (see FloatStore) - nothing is re-entered or replaced.
 * The panel window only exists while it is open; closing the service removes every window, stops the worker thread and cancels the request.
 */
class FloatingAssistantService : Service() {
    companion object {
        const val ACT_START = "a2z.float.start"; const val ACT_STOP = "a2z.float.stop"; const val ACT_TOGGLE = "a2z.float.toggle"
        private const val CH = "a2z_float"; private const val NID = 8
        @Volatile var running = false; private set
    }

    private class Req { @Volatile var cancelled = false; var ai = FloatAi(); var image = false }
    private class Chip(val row: LinearLayout, val label: TextView, val icon: IconView)
    private class CapUi(val dot: View, val text: TextView, val statusRow: View, val bar: View, val ask: Chip, val capture: Chip, val pause: Chip, val stop: Chip,
                        val previewBox: View, val thumb: ImageView, val note: TextView)
    private class Ui(val root: PanelRoot, val scroll: ScrollView, val list: LinearLayout, val input: PanelEdit, val sendBox: FrameLayout,
                     val sendIcon: IconView, val model: TextView, val maxIcon: IconView, val clear: TextView, val status: TextView,
                     val picker: ScrollView, val pickerList: LinearLayout, val cap: CapUi)

    private lateinit var wm: WindowManager
    private lateinit var tctx: Context
    private var pal = Pal.LIGHT
    private val main = Handler(Looper.getMainLooper())
    private var worker: ExecutorService? = null
    private var bubble: BubbleView? = null
    private lateinit var bubbleLp: LayoutParams
    private var bubbleX = 0; private var bubbleY = 0          // saved (user) position
    private class AgUi(val text: TextView, val start: Chip, val pause: Chip, val stop: Chip)
    private var agUi: AgUi? = null
    private var ui: Ui? = null
    private var panelLp: LayoutParams? = null
    private var maximized = false; private var typing = false; private var stick = true
    private var panelX = Int.MIN_VALUE; private var panelY = 0
    private var draft = ""
    private var req: Req? = null
    private var streamMsg: FMsg? = null
    private var streamTv: TextView? = null
    private var errView: View? = null
    private var lastError: String? = null
    private var clearArmed = false
    // ---- screen capture state (the screenshot lives in RAM only; never written to disk) ----
    private var pendingShot: ByteArray? = null; private var pendingBlank = false; private var pendingThumb: Bitmap? = null
    private var retryShot: ByteArray? = null
    private var overlayHidden = false; private var capturingNow = false; private var bigThumb = false
    private var action: String? = null            // "ask" | "capture": what to do once screen capture is running
    private var capMsg: String? = null
    private var lastPick = false; private var lastRetry = true
    private val unhideRun = Runnable { if (overlayHidden) setOverlayHidden(false) }
    private val clearMsgRun = Runnable { capMsg = null; refreshCapture() }
    private val prefs by lazy { getSharedPreferences("a2z_float_ui", MODE_PRIVATE) }
    private val busy get() = req != null

    // ---------------------------------------------------------------- lifecycle
    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        FloatStore.init(applicationContext)
        refreshTheme()
        worker = Executors.newSingleThreadExecutor()
        FrameStore.onState = { main.post { onCaptureState() } }
        FrameStore.onShot = { sh -> main.post { onShot(sh) } }
        FrameStore.onPermission = { ok -> main.post { onPermission(ok) } }
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == ACT_STOP) { stopSelf(); return START_NOT_STICKY }
        if (!goForeground()) { stopSelf(); return START_NOT_STICKY }
        if (bubble == null && !showBubble()) { stopSelf(); return START_NOT_STICKY }
        if (i?.action == ACT_TOGGLE) togglePanel()
        return START_NOT_STICKY
    }

    override fun onConfigurationChanged(c: Configuration) {
        super.onConfigurationChanged(c)
        val reopen = ui != null
        refreshTheme()
        bubble?.setPal(pal)
        if (reopen && !overlayHidden) { closePanelWindow(); openPanel() } else if (!reopen) clampBubble()
        applyBubble()
    }

    override fun onDestroy() {
        running = false
        main.removeCallbacksAndMessages(null)
        FrameStore.onState = null; FrameStore.onShot = null; FrameStore.onPermission = null
        // Release screen capture if THIS panel started it (manual mode); a sharing session started from the app's own dialog is left alone.
        if (FrameStore.mode == ScreenCaptureService.MODE_MANUAL && FrameStore.state != "stopped") try { stopService(Intent(this, ScreenCaptureService::class.java)) } catch (_: Throwable) { }
        overlayHidden = false; pendingShot = null; retryShot = null
        pendingThumb?.let { try { it.recycle() } catch (_: Throwable) { } }; pendingThumb = null
        req?.let { it.cancelled = true; it.ai.cancel() }; req = null
        worker?.shutdownNow(); worker = null
        closePanelWindow()
        bubble?.let { try { wm.removeViewImmediate(it) } catch (_: Throwable) { } }; bubble = null
        FloatStore.save()
        try { stopForeground(true) } catch (_: Throwable) { }
        super.onDestroy()
    }

    // ---------------------------------------------------------------- foreground notification
    private fun goForeground(): Boolean {
        try {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel(CH, "Floating assistant", NotificationManager.IMPORTANCE_LOW))
            fun act(a: String, label: String): Notification.Action {
                val pi = PendingIntent.getService(this, a.hashCode(), Intent(this, FloatingAssistantService::class.java).setAction(a), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
                @Suppress("DEPRECATION") return Notification.Action.Builder(0, label, pi).build()
            }
            val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), PendingIntent.FLAG_IMMUTABLE)
            val n = Notification.Builder(this, CH).setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("Zyn Ai floating assistant is on").setContentText("Tap the bubble to chat over any app.")
                .setOngoing(true).setContentIntent(open).addAction(act(ACT_TOGGLE, "Show / hide")).addAction(act(ACT_STOP, "Stop")).build()
            if (Build.VERSION.SDK_INT >= 34) startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(NID, n)
            return true
        } catch (e: Exception) { toast("Could not start the floating assistant service"); return false }
    }

    // ---------------------------------------------------------------- helpers
    private fun refreshTheme() {
        pal = Pal.resolve(this)
        tctx = ContextThemeWrapper(applicationContext, if (pal.dark) android.R.style.Theme_Material else android.R.style.Theme_Material_Light)
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density + 0.5f).toInt()
    private fun screen(): Point { val dm = DisplayMetrics(); @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(dm); return Point(dm.widthPixels, dm.heightPixels) }
    private fun statusBar(): Int { val id = resources.getIdentifier("status_bar_height", "dimen", "android"); return if (id > 0) resources.getDimensionPixelSize(id) else dp(24) }
    private fun toast(m: String) { try { Toast.makeText(applicationContext, m, Toast.LENGTH_SHORT).show() } catch (_: Throwable) { } }
    private fun lp(w: Int, h: Int, focusable: Boolean) = LayoutParams(w, h, LayoutParams.TYPE_APPLICATION_OVERLAY,
        LayoutParams.FLAG_NOT_TOUCH_MODAL or LayoutParams.FLAG_LAYOUT_IN_SCREEN or (if (focusable) 0 else LayoutParams.FLAG_NOT_FOCUSABLE), PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START }
    private fun copy(t: String) {
        try { (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("Zyn Ai", t)); toast("Copied") } catch (_: Throwable) { toast("Could not copy") }
    }
    private fun openApp() { try { startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)) } catch (_: Throwable) { toast("Open Zyn Ai from your launcher") } }

    // ---------------------------------------------------------------- bubble
    private fun showBubble(): Boolean {
        if (!FloatPerm.has(this)) { toast("Allow \"Display over other apps\" for Zyn Ai first"); return false }
        val s = screen(); val size = dp(56)
        bubbleX = prefs.getInt("bx", s.x - size - dp(8)); bubbleY = prefs.getInt("by", s.y / 3)
        val v = BubbleView(tctx, pal)
        bubbleLp = lp(size, size, false)
        v.onTap = { togglePanel() }
        v.onDrag = { ddx, ddy -> bubbleX += ddx.toInt(); bubbleY += ddy.toInt(); clampBubble(); applyBubble() }
        v.onRelease = { moved -> if (moved) snapBubble() }
        clampBubble(); bubbleLp.x = bubbleX; bubbleLp.y = bubbleY
        return try { wm.addView(v, bubbleLp); bubble = v; true } catch (e: Exception) { toast("Android refused the overlay window (permission?)"); false }
    }
    private fun clampBubble() {
        val s = screen(); val size = dp(56)
        bubbleX = bubbleX.coerceIn(0, (s.x - size).coerceAtLeast(0)); bubbleY = bubbleY.coerceIn(0, (s.y - size).coerceAtLeast(0))
    }
    private fun applyBubble() {
        val b = bubble ?: return
        bubbleLp.x = bubbleX; bubbleLp.y = bubbleY
        try { wm.updateViewLayout(b, bubbleLp) } catch (_: Throwable) { }
    }
    private fun snapBubble() {
        val s = screen(); val size = dp(56)
        bubbleX = if (bubbleX + size / 2 < s.x / 2) dp(4) else s.x - size - dp(4)
        clampBubble(); applyBubble()
        prefs.edit().putInt("bx", bubbleX).putInt("by", bubbleY).apply()
        parkBubble()
    }
    /** While the panel is open the bubble stays visible and moves out of its way (or hides if the panel fills the screen). */
    private fun parkBubble() {
        val b = bubble ?: return; val p = panelLp
        var x = bubbleX; var y = bubbleY; var show = !overlayHidden
        b.capturing = FrameStore.state != "stopped"
        if (p != null) {
            val s = screen(); val size = dp(56); val g = dp(6)
            val hit = x < p.x + p.width && x + size > p.x && y < p.y + p.height && y + size > p.y
            if (hit) {
                when {
                    p.y + p.height + g + size <= s.y -> y = p.y + p.height + g
                    p.x + p.width + g + size <= s.x -> x = p.x + p.width + g
                    p.x - g - size >= 0 -> x = p.x - g - size
                    p.y - g - size >= 0 -> y = p.y - g - size
                    else -> show = false
                }
            }
        }
        b.visibility = if (show) View.VISIBLE else View.GONE
        bubbleLp.flags = if (show) bubbleLp.flags and LayoutParams.FLAG_NOT_TOUCHABLE.inv() else bubbleLp.flags or LayoutParams.FLAG_NOT_TOUCHABLE
        bubbleLp.x = x; bubbleLp.y = y
        try { wm.updateViewLayout(b, bubbleLp) } catch (_: Throwable) { }
    }

    // ---------------------------------------------------------------- panel window
    private fun togglePanel() { if (ui == null) openPanel() else minimize() }

    private fun minimize() {
        draft = ui?.input?.text?.toString() ?: draft
        closePanelWindow(); parkBubble()
    }

    private fun closePanelWindow() {
        val u = ui ?: return
        try { (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(u.input.windowToken, 0) } catch (_: Throwable) { }
        try { wm.removeViewImmediate(u.root) } catch (_: Throwable) { }
        ui = null; agUi = null; panelLp = null; streamTv = null; errView = null; typing = false; clearArmed = false
    }

    private fun openPanel() {
        val u = buildPanel()
        val p = lp(0, 0, false).apply { softInputMode = LayoutParams.SOFT_INPUT_ADJUST_PAN; flags = flags or LayoutParams.FLAG_HARDWARE_ACCELERATED }
        panelLp = p; ui = u
        layoutPanel(p)
        try { wm.addView(u.root, p) } catch (e: Exception) { ui = null; panelLp = null; toast("Android refused the overlay window (permission?)"); return }
        bubble?.badge = false
        renderConversation(); refreshHeader(); refreshSend(); refreshCapture()
        parkBubble()
    }

    private fun layoutPanel(p: LayoutParams) {
        val s = screen(); val land = s.x > s.y; val m = dp(8)
        val w: Int; var h: Int
        if (maximized) { w = s.x - 2 * m; h = s.y - 2 * m - statusBar() }
        else { w = minOf(s.x - dp(24), dp(420)); h = minOf((s.y * (if (land) 0.82f else 0.62f)).toInt(), dp(560)) }
        if (typing) h = minOf(h, (s.y * (if (land) 0.5f else 0.46f)).toInt())
        p.width = w; p.height = h
        if (maximized) { p.x = m; p.y = m + statusBar() / 2 }
        else {
            if (panelX == Int.MIN_VALUE) { panelX = (s.x - w) / 2; panelY = statusBar() + dp(12) }
            panelX = panelX.coerceIn(0, (s.x - w).coerceAtLeast(0)); panelY = panelY.coerceIn(0, (s.y - dp(48)).coerceAtLeast(0))
            p.x = panelX; p.y = if (typing) minOf(panelY, statusBar() + dp(4)) else panelY
        }
        p.y = p.y.coerceIn(0, (s.y - minOf(h, dp(48))).coerceAtLeast(0))
    }
    private fun relayout() { val u = ui ?: return; val p = panelLp ?: return; layoutPanel(p); try { wm.updateViewLayout(u.root, p) } catch (_: Throwable) { }; parkBubble() }

    private fun enterTyping() {
        val u = ui ?: return; val p = panelLp ?: return
        if (typing) return
        typing = true
        u.cap.statusRow.visibility = View.GONE; u.cap.bar.visibility = View.GONE
        p.flags = p.flags and LayoutParams.FLAG_NOT_FOCUSABLE.inv()
        layoutPanel(p); try { wm.updateViewLayout(u.root, p) } catch (_: Throwable) { }
        u.input.postDelayed({
            val cur = ui ?: return@postDelayed
            cur.input.requestFocus()
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(cur.input, InputMethodManager.SHOW_IMPLICIT)
        }, 120)
    }
    private fun exitTyping() {
        val u = ui ?: return; val p = panelLp ?: return
        if (!typing) return
        typing = false
        u.cap.statusRow.visibility = View.VISIBLE; u.cap.bar.visibility = View.VISIBLE
        try { (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(u.input.windowToken, 0) } catch (_: Throwable) { }
        u.input.clearFocus()
        p.flags = p.flags or LayoutParams.FLAG_NOT_FOCUSABLE
        layoutPanel(p); try { wm.updateViewLayout(u.root, p) } catch (_: Throwable) { }
        parkBubble()
    }

    // ---------------------------------------------------------------- panel UI
    private fun tv(text: String, sp: Float, color: Int, bold: Boolean = false) = TextView(tctx).apply {
        this.text = text; setTextSize(TypedValue.COMPLEX_UNIT_SP, sp); setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD
    }
    private fun iconBtn(path: String, tint: Int, size: Int = 40, onClick: () -> Unit): Pair<FrameLayout, IconView> {
        val ic = IconView(tctx, path, tint)
        val f = FrameLayout(tctx).apply {
            addView(ic, FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER)); isClickable = true; setOnClickListener { onClick() }
            val d = roundRect(Color.TRANSPARENT, dp(20).toFloat()); background = d
        }
        f.layoutParams = LinearLayout.LayoutParams(dp(size), dp(size))
        return f to ic
    }
    private fun chip(path: String, label: String, onClick: () -> Unit): Pair<LinearLayout, TextView> {
        val t = tv(label, 12f, pal.ink)
        val row = LinearLayout(tctx).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(6), dp(12), dp(6)); background = roundRect(pal.glassSoft(), dp(20).toFloat(), pal.nline(), dp(1))
            addView(IconView(tctx, path, pal.mut), LinearLayout.LayoutParams(dp(16), dp(16)).apply { rightMargin = dp(6) }); addView(t)
            isClickable = true; setOnClickListener { onClick() }
        }
        return row to t
    }

    private fun actChip(path: String, label: String, primary: Boolean, onClick: () -> Unit): Chip {
        val t = tv(label, 12f, if (primary) pal.onAcc else pal.ink).apply { maxLines = 1 }
        val ic = IconView(tctx, path, if (primary) pal.onAcc else pal.mut)
        val row = LinearLayout(tctx).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(10), dp(7), dp(12), dp(7))
            background = if (primary) roundRect(pal.acc, dp(20).toFloat()) else roundRect(pal.glassSoft(), dp(20).toFloat(), pal.nline(), dp(1))
            addView(ic, LinearLayout.LayoutParams(dp(16), dp(16)).apply { rightMargin = dp(6) }); addView(t)
            isClickable = true; setOnClickListener { onClick() }; contentDescription = label
        }
        return Chip(row, t, ic)
    }

    private fun buildPanel(): Ui {
        val root = PanelRoot(tctx).apply { background = roundRect(pal.glass(), dp(28).toFloat(), pal.nline(), dp(1)); clipToOutline = true }
        val col = LinearLayout(tctx).apply { orientation = LinearLayout.VERTICAL }
        root.addView(col, FrameLayout.LayoutParams(-1, -1))

        // header (drag handle)
        val header = LinearLayout(tctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), dp(6), dp(6), dp(6)); background = roundRect(pal.glassSoft(), dp(24).toFloat(), pal.nline(), dp(1)) }
        header.addView(IconView(tctx, Ic.SPARKLE, pal.acc), LinearLayout.LayoutParams(dp(22), dp(22)).apply { rightMargin = dp(10) })
        val titles = LinearLayout(tctx).apply { orientation = LinearLayout.VERTICAL }
        titles.addView(tv("Zyn Ai - Assistant", 15f, pal.ink, true))
        val model = tv("", 11.5f, pal.mut).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END; setPadding(0, dp(2), 0, dp(2)); isClickable = true }
        titles.addView(model)
        header.addView(titles, LinearLayout.LayoutParams(0, -2, 1f))
        val (minB, _) = iconBtn(Ic.MIN, pal.ink) { minimize() }
        val (maxB, maxIc) = iconBtn(if (maximized) Ic.RESTORE else Ic.MAX, pal.ink) { maximized = !maximized; ui?.maxIcon?.setIcon(if (maximized) Ic.RESTORE else Ic.MAX); relayout() }
        val (closeB, _) = iconBtn(Ic.CLOSE, pal.ink) { toast("Floating assistant closed. Start it again from Zyn Ai."); stopSelf() }
        minB.contentDescription = "Minimize"; maxB.contentDescription = "Maximize / restore"; closeB.contentDescription = "Close"
        header.addView(minB); header.addView(maxB); header.addView(closeB)
        col.addView(header, LinearLayout.LayoutParams(-1, dp(54)).apply { setMargins(dp(8), dp(8), dp(8), dp(2)) })
        attachDrag(header)

        // messages
        val list = LinearLayout(tctx).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(10), dp(12), dp(10)) }
        val scroll = ScrollView(tctx).apply {
            isVerticalScrollBarEnabled = false; overScrollMode = View.OVER_SCROLL_NEVER; addView(list, FrameLayout.LayoutParams(-1, -2))
            setOnScrollChangeListener { v, _, y, _, _ -> val sv = v as ScrollView; stick = y + sv.height >= list.height - dp(60) }
        }
        col.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        // screen capture bar: indicator + controls + screenshot preview
        val capDot = View(tctx)
        val capText = tv("", 11.5f, pal.mut).apply { maxLines = 2 }
        val capStatus = LinearLayout(tctx).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), dp(4), dp(12), dp(2))
            addView(capDot, LinearLayout.LayoutParams(dp(10), dp(10)).apply { rightMargin = dp(8) }); addView(capText, LinearLayout.LayoutParams(0, -2, 1f))
        }
        val chAsk = actChip(Ic.SPARKLE, "Ask AI About My Screen", true) { onCapture(true) }
        val chCap = actChip(Ic.CAMERA, "Capture Screen", false) { onCapture(false) }
        val chPause = actChip(Ic.PAUSE, "Pause", false) { onPauseResume() }
        val chStop = actChip(Ic.STOP, "Stop sharing", false) { onStopCapture() }
        val chipRow = LinearLayout(tctx).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(12), dp(2), dp(12), dp(4)) }
        listOf(chAsk, chCap, chPause, chStop).forEachIndexed { i, c -> chipRow.addView(c.row, LinearLayout.LayoutParams(-2, -2).apply { if (i > 0) leftMargin = dp(6) }) }
        val chipScroll = HorizontalScrollView(tctx).apply { isHorizontalScrollBarEnabled = false; overScrollMode = View.OVER_SCROLL_NEVER; addView(chipRow) }
        val thumb = ImageView(tctx).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER; adjustViewBounds = true; setPadding(dp(2), dp(2), dp(2), dp(2))
            background = roundRect(pal.side, dp(10).toFloat(), pal.line, dp(1)); contentDescription = "Screenshot preview. Tap to enlarge or shrink."
            setOnClickListener { bigThumb = !bigThumb; applyThumbSize() }
        }
        val prevNote = tv("", 11.5f, pal.mut)
        val (rmB, _) = chip(Ic.CLOSE, "Remove screenshot") { clearPending(); refreshCapture() }
        val prevCol = LinearLayout(tctx).apply { orientation = LinearLayout.VERTICAL; addView(prevNote); addView(rmB, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(6) }) }
        val prevBox = LinearLayout(tctx).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(2), dp(12), dp(4)); visibility = View.GONE
            addView(thumb, LinearLayout.LayoutParams(-2, dp(88))); addView(prevCol, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(10) })
        }
        col.addView(capStatus, LinearLayout.LayoutParams(-1, -2)); col.addView(chipScroll, LinearLayout.LayoutParams(-1, -2)); col.addView(prevBox, LinearLayout.LayoutParams(-1, -2))
        val cap = CapUi(capDot, capText, capStatus, chipScroll, chAsk, chCap, chPause, chStop, prevBox, thumb, prevNote)

        // AI Agent controls: type a task in the message box below, then Start Agent. Pause / Resume / Stop work during a task.
        val agText = tv("", 11.5f, pal.mut).apply { maxLines = 2; setPadding(dp(14), dp(4), dp(12), dp(2)) }
        val chAgStart = actChip(Ic.SPARKLE, "Start Agent", true) { onAgentStart() }
        val chAgPause = actChip(Ic.PAUSE, "Pause Agent", false) { onAgentPause() }
        val chAgStop = actChip(Ic.STOP, "Stop Agent", false) { AgentController.hardStop("You pressed Stop."); refreshAgent() }
        val agRow = LinearLayout(tctx).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(12), dp(2), dp(12), dp(4)) }
        listOf(chAgStart, chAgPause, chAgStop).forEachIndexed { i, c -> agRow.addView(c.row, LinearLayout.LayoutParams(-2, -2).apply { if (i > 0) leftMargin = dp(6) }) }
        val agScroll = HorizontalScrollView(tctx).apply { isHorizontalScrollBarEnabled = false; overScrollMode = View.OVER_SCROLL_NEVER; addView(agRow) }
        col.addView(agText, LinearLayout.LayoutParams(-1, -2)); col.addView(agScroll, LinearLayout.LayoutParams(-1, -2))
        agUi = AgUi(agText, chAgStart, chAgPause, chAgStop)

        // actions row
        val status = tv("", 11.5f, pal.mut).apply { gravity = Gravity.END; maxLines = 1 }
        val (copyB, _) = chip(Ic.COPY, "Copy") { copyLast() }
        val (clearB, clearT) = chip(Ic.DELETE, "Clear chat") { onClear() }
        val actions = LinearLayout(tctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(4), dp(12), dp(4)) }
        actions.addView(copyB); actions.addView(clearB, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(8) })
        actions.addView(status, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(8) })
        col.addView(actions, LinearLayout.LayoutParams(-1, -2))

        // input row
        val input = PanelEdit(tctx).apply {
            hint = "Message Zyn Ai"; setHintTextColor(pal.mut); setTextColor(pal.ink); setTextSize(TypedValue.COMPLEX_UNIT_SP, 14.5f)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            imeOptions = EditorInfo.IME_FLAG_NO_EXTRACT_UI or EditorInfo.IME_FLAG_NO_FULLSCREEN
            maxLines = 4; minHeight = dp(44); setPadding(dp(16), dp(10), dp(16), dp(10)); background = roundRect(pal.glassSoft(), dp(24).toFloat(), pal.nline(), dp(1))
            setText(draft)
            setOnTouchListener { _, e -> if (e.actionMasked == MotionEvent.ACTION_DOWN) enterTyping(); false }
            onImeBack = { exitTyping() }
        }
        val sendIcon = IconView(tctx, Ic.SEND, pal.onAcc)
        val sendBox = FrameLayout(tctx).apply {
            background = roundRect(pal.acc, dp(22).toFloat()); addView(sendIcon, FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER))
            isClickable = true; setOnClickListener { if (busy) stopRequest() else send() }; contentDescription = "Send"
        }
        val inRow = LinearLayout(tctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.BOTTOM; setPadding(dp(10), dp(4), dp(10), dp(10)) }
        inRow.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
        inRow.addView(sendBox, LinearLayout.LayoutParams(dp(44), dp(44)).apply { leftMargin = dp(8) })
        col.addView(inRow, LinearLayout.LayoutParams(-1, -2))

        // provider picker (inside the panel)
        val pickerList = LinearLayout(tctx).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(6), dp(6), dp(6), dp(6)) }
        val picker = ScrollView(tctx).apply { visibility = View.GONE; background = roundRect(pal.bg, dp(20).toFloat(), pal.nline(), dp(1)); addView(pickerList) }
        root.addView(picker, FrameLayout.LayoutParams(-1, -2).apply { topMargin = dp(52); leftMargin = dp(10); rightMargin = dp(10) })

        root.onBack = { if (typing) { exitTyping(); true } else { minimize(); true } }
        root.onFocus = { has -> if (!has && typing) exitTyping() }
        val u = Ui(root, scroll, list, input, sendBox, sendIcon, model, maxIc, clearT, status, picker, pickerList, cap)
        model.setOnClickListener { togglePicker() }
        return u
    }

    private fun attachDrag(h: View) {
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
        h.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = panelX; oy = panelY; true }
                MotionEvent.ACTION_MOVE -> {
                    if (!maximized && !typing) { panelX = ox + (e.rawX - sx).toInt(); panelY = oy + (e.rawY - sy).toInt(); relayout() }
                    true
                }
                else -> true
            }
        }
    }

    private fun refreshHeader() {
        val u = ui ?: return
        val p = FloatStore.ordered().firstOrNull()
        u.model.text = (if (p != null) p.label else "No provider ready") + "  ▾"
    }

    private fun openPicker() { val u = ui ?: return; if (u.picker.visibility != View.VISIBLE) togglePicker() }

    private fun togglePicker() {
        val u = ui ?: return
        if (u.picker.visibility == View.VISIBLE) { u.picker.visibility = View.GONE; return }
        u.pickerList.removeAllViews()
        val cur = FloatStore.ordered().firstOrNull()
        u.pickerList.addView(tv("Uses your Zyn Ai providers and keys. [image] = can read screenshots", 11.5f, pal.mut).apply { setPadding(dp(10), dp(4), dp(10), dp(6)) })
        FloatStore.providers.forEach { p ->
            val row = tv((if (p === cur) "✓  " else "     ") + p.label + "  [" + FloatVision.tag(p) + "]", 13.5f, pal.ink).apply {
                setPadding(dp(10), dp(10), dp(10), dp(10)); isClickable = true
                setOnClickListener {
                    FloatStore.selectedId = p.id; u.picker.visibility = View.GONE; refreshHeader()
                    if (lastPick) { lastPick = false; lastError = null; errView?.let { v -> u.list.removeView(v) }; errView = null }
                    refreshCapture()
                }
            }
            u.pickerList.addView(row)
        }
        if (FloatStore.providers.isEmpty()) u.pickerList.addView(tv(if (FloatStore.synced) "No provider is ready. Add an API key in Zyn Ai → Settings." else "Open Zyn Ai once so your providers can sync.", 13f, pal.ink).apply { setPadding(dp(10), dp(8), dp(10), dp(8)) })
        u.pickerList.addView(tv("Open Zyn Ai settings…", 13f, pal.acc, true).apply { setPadding(dp(10), dp(10), dp(10), dp(10)); isClickable = true; setOnClickListener { u.picker.visibility = View.GONE; openApp() } })
        u.picker.visibility = View.VISIBLE
    }

    private fun refreshSend() {
        val u = ui ?: return
        u.sendIcon.setIcon(if (busy) Ic.STOP else Ic.SEND)
        u.sendBox.contentDescription = if (busy) "Stop" else "Send"
        u.status.text = if (busy) (if (streamMsg == null) (if (req?.image == true) "Analyzing screenshot…" else "Thinking…") else "Writing…") else ""
    }

    // ---------------------------------------------------------------- messages
    private fun maxW(frac: Float) = ((panelLp?.width ?: screen().x) * frac).toInt()

    private fun msgView(m: FMsg): View {
        val user = m.role == "user"
        val box = LinearLayout(tctx).apply { orientation = LinearLayout.VERTICAL; gravity = if (user) Gravity.END else Gravity.START }
        val t = tv("", 14.5f, pal.ink).apply {
            maxWidth = maxW(if (user) 0.86f else 0.94f); setPadding(dp(12), dp(8), dp(12), dp(8))
            background = bubbleRect(pal, user, tctx.resources.displayMetrics.density)
            text = if (user) m.text else MiniMd.render(m.text, pal)
            setOnLongClickListener { copy(m.text); true }
        }
        box.addView(t)
        if (!user && m.via.isNotEmpty()) box.addView(tv(m.via, 10.5f, pal.mut).apply { setPadding(dp(6), dp(2), dp(6), 0); maxWidth = maxW(0.94f); maxLines = 2 })
        box.layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6); bottomMargin = dp(6) }
        box.tag = t
        return box
    }

    private fun addView(v: View) {
        val u = ui ?: return
        u.list.addView(v)
        while (u.list.childCount > 40) u.list.removeViewAt(0)   // keep RAM low: only the latest messages are drawn
        scrollDown()
    }
    private fun scrollDown() { val u = ui ?: return; if (stick) u.scroll.post { u.scroll.scrollTo(0, u.list.height) } }

    private fun renderConversation() {
        val u = ui ?: return
        u.list.removeAllViews(); streamTv = null; errView = null
        val msgs = FloatStore.snapshot(FloatStore.current()).takeLast(30)
        if (msgs.isEmpty() && !busy) u.list.addView(tv(emptyHint(), 13.5f, pal.mut).apply { gravity = Gravity.CENTER; setPadding(dp(16), dp(36), dp(16), dp(16)) })
        for (m in msgs) { val v = msgView(m); u.list.addView(v); if (m === streamMsg) streamTv = v.tag as TextView }
        if (busy && streamMsg == null) { val ph = msgView(FMsg("assistant", "…", 0)); streamTv = ph.tag as TextView; u.list.addView(ph) }
        lastError?.let { showError(it, lastPick, lastRetry) }
        stick = true; scrollDown()
    }
    private fun emptyHint(): String {
        val p = FloatStore.ordered().firstOrNull()
        return when {
            !FloatStore.synced -> "Open the Zyn Ai app once so your AI providers and keys can sync, then come back."
            p == null -> "No AI provider is ready. Open Zyn Ai → Settings → AI providers and add an API key."
            else -> "Ask anything. Answers come from your Zyn Ai provider:\n${p.label}"
        }
    }

    private fun showError(text: String, pick: Boolean = false, canRetry: Boolean = true) {
        val u = ui ?: return
        errView?.let { u.list.removeView(it) }
        val retry = tv("Retry", 13f, pal.acc, true).apply { setPadding(0, dp(8), dp(12), 0); isClickable = true; setOnClickListener { retryLast() } }
        val choose = tv("Choose model", 13f, pal.acc, true).apply { setPadding(0, dp(8), dp(12), 0); isClickable = true; setOnClickListener { openPicker() } }
        val open = tv("Open settings", 13f, pal.acc, true).apply { setPadding(0, dp(8), 0, 0); isClickable = true; setOnClickListener { openApp() } }
        val box = LinearLayout(tctx).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(10), dp(12), dp(10)); background = roundRect(Color.TRANSPARENT, dp(14).toFloat(), pal.bad, dp(1))
            addView(tv(text, 13f, pal.bad))
            addView(LinearLayout(tctx).apply { orientation = LinearLayout.HORIZONTAL; if (pick) addView(choose); if (canRetry) addView(retry); addView(open) })
        }
        box.layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) }
        errView = box; u.list.addView(box); scrollDown()
    }

    // ---------------------------------------------------------------- actions
    private fun copyLast() {
        val m = FloatStore.snapshot(FloatStore.current()).lastOrNull { it.role == "assistant" }
        if (m == null) toast("Nothing to copy yet") else copy(m.text)
    }

    private fun onClear() {
        val u = ui ?: return
        if (!clearArmed) {
            clearArmed = true; u.clear.text = "Tap again to clear"; u.clear.setTextColor(pal.bad)
            main.postDelayed({ clearArmed = false; ui?.clear?.let { it.text = "Clear chat"; it.setTextColor(pal.ink) } }, 3000)
            return
        }
        clearArmed = false; u.clear.text = "Clear chat"; u.clear.setTextColor(pal.ink)
        stopRequest(); retryShot = null; lastPick = false; lastRetry = true
        val had = FloatStore.snapshot(FloatStore.current()).isNotEmpty()
        FloatStore.newConv(); lastError = null; streamMsg = null
        worker?.execute { FloatStore.save() }
        renderConversation()
        if (had) toast("Chat cleared. The old chat stays in your Zyn Ai history.")
    }

    private fun retryLast() {
        if (busy) return
        val c = FloatStore.current()
        if (FloatStore.snapshot(c).lastOrNull()?.role != "user") return
        lastError = null; lastPick = false; errView?.let { ui?.list?.removeView(it) }; errView = null
        startRequest(c, retryShot)
    }

    private fun send() {
        val u = ui ?: return
        val shot = pendingShot
        var t = u.input.text.toString().trim()
        if ((t.isEmpty() && shot == null) || busy || capturingNow) return
        if (FloatStore.ordered().isEmpty()) { lastError = emptyHint(); lastPick = false; lastRetry = false; showError(lastError!!, false, false); return }
        if (shot != null) {
            val p = FloatStore.ordered().first()
            if (FloatVision.support(p) == FloatVision.S.NO) {   // nothing is sent; text and screenshot stay in place
                lastError = "\"${p.model}\" is a text-only model, so it can't read a screenshot. Choose a model marked [image] in the list. Your screenshot and text are kept."
                lastPick = true; lastRetry = false
                showError(lastError!!, true, false); openPicker(); return
            }
            if (t.isEmpty()) t = "Explain what is on my screen: the app or website, the visible text and buttons, any errors or warnings, and what I should do next."
        }
        u.input.setText(""); draft = ""
        exitTyping()
        val c = FloatStore.current()
        if (FloatStore.snapshot(c).isEmpty()) u.list.removeAllViews()
        val m = FMsg("user", if (shot != null) "[Screenshot attached] $t" else t, System.currentTimeMillis())
        FloatStore.addMsg(c, m); addView(msgView(m))
        lastError = null; lastPick = false; lastRetry = true; errView?.let { u.list.removeView(it) }; errView = null
        clearPending()
        startRequest(c, shot)
    }

    private fun systemPrompt(withShot: Boolean): String {
        val date = SimpleDateFormat("EEEE, d MMMM yyyy, HH:mm", Locale.ENGLISH).format(Date())
        return listOf(FloatStore.systemBase, "Current date and time: $date.",
            "Language rule: reply in the language and script of the user's latest message (for example English, Tamil, Sinhala, or Tamil typed in English letters).",
            "You are answering inside a small floating chat panel on a phone, so keep replies focused and concise unless the user asks for detail.",
            if (withShot) "The user attached a screenshot of their own Android screen to their latest message. Describe and answer only from what is actually visible in it; if something is cut off, blank or unreadable, say so instead of guessing. Do not repeat sensitive details such as passwords, card numbers or one-time codes." else "")
            .filter { it.isNotBlank() }.joinToString("\n\n")
    }

    private fun buildTurns(c: FConv): List<Turn> {
        val out = ArrayList<Turn>(); var budget = 24000
        for (m in FloatStore.snapshot(c).asReversed()) {
            if (budget <= 0 || out.size >= 24) break
            budget -= m.text.length
            val role = if (m.role == "user") "user" else "assistant"
            if (out.isNotEmpty() && out.last().role == role) { val last = out.removeAt(out.size - 1); out.add(Turn(role, m.text + "\n\n" + last.text)) }
            else out.add(Turn(role, m.text))
        }
        out.reverse()
        while (out.isNotEmpty() && out.first().role != "user") out.removeAt(0)
        return out
    }

    private fun withImage(t: List<Turn>, b64: String): List<Turn> {
        if (t.isEmpty() || t.last().role != "user") return t
        return t.dropLast(1) + Turn("user", t.last().text, listOf(b64))
    }

    private fun startRequest(c: FConv, shot: ByteArray? = null) {
        val rq = Req(); rq.image = shot != null; req = rq; streamMsg = null; retryShot = shot
        // A screenshot goes ONLY to the one provider the user selected: no silent fallback to other providers.
        val providers = if (shot != null) FloatStore.ordered().take(1) else FloatStore.ordered()
        val sys = systemPrompt(shot != null); val baseTurns = buildTurns(c)
        if (ui != null) {
            val ph = msgView(FMsg("assistant", "…", 0)); streamTv = ph.tag as TextView; addView(ph)
        }
        refreshSend()
        val ex = worker ?: return
        ex.execute {
            val turns = if (shot != null) withImage(baseTurns, Base64.encodeToString(shot, Base64.NO_WRAP)) else baseTurns
            val errors = ArrayList<String>(); var used: FProvider? = null; var fellBack = false
            val sb = StringBuilder(); var lastPost = 0L; var lastErr: Throwable? = null
            for ((idx, p) in providers.withIndex()) {
                if (rq.cancelled) break
                rq.ai = FloatAi().also { if (rq.cancelled) it.cancel() }
                val via = p.label + if (idx > 0) " (fallback)" else ""
                try {
                    rq.ai.stream(p, sys, turns) { d ->
                        sb.append(d)
                        val now = System.currentTimeMillis()
                        if (now - lastPost >= 100) { lastPost = now; val s = sb.toString(); main.post { onText(rq, s, via) } }
                    }
                    used = p; fellBack = idx > 0; lastErr = null; break
                } catch (e: Throwable) {
                    if (rq.cancelled) break
                    lastErr = e; errors.add(p.name.ifBlank { p.type } + ": " + FloatAi.friendly(e))
                    if (sb.isNotEmpty()) break          // never switch provider in the middle of an answer
                }
            }
            val text = sb.toString(); val via = used?.let { it.label + if (fellBack) " (fallback)" else "" } ?: providers.firstOrNull()?.label ?: ""
            main.post { onDone(rq, text, via, used != null, errors, lastErr) }
        }
    }

    private fun onText(rq: Req, text: String, via: String) {
        if (rq !== req) return
        var m = streamMsg
        if (m == null) { m = FMsg("assistant", text, System.currentTimeMillis(), via); streamMsg = m; FloatStore.addMsg(FloatStore.current(), m); refreshSend() }
        else FloatStore.setText(m, text, via)
        streamTv?.text = MiniMd.render(text, pal)
        scrollDown()
    }

    private fun onDone(rq: Req, text: String, via: String, ok: Boolean, errors: List<String>, err: Throwable?) {
        if (rq !== req) return
        req = null
        val c = FloatStore.current(); var m = streamMsg; streamMsg = null
        if (text.isNotEmpty()) {
            if (m == null) { m = FMsg("assistant", text, System.currentTimeMillis(), via); FloatStore.addMsg(c, m) }
            FloatStore.setText(m, text, if (ok) via else "$via · interrupted")
        }
        if (ok) retryShot = null
        if (!ok && !rq.cancelled && err != null) {
            lastPick = false; lastRetry = true
            lastError = if (errors.size > 1) errors.joinToString("\n") { "• $it" } else FloatAi.friendly(err)
            if (rq.image && err is FloatAi.ApiError && err.status in intArrayOf(400, 404, 415, 422)) {
                lastError = "This model did not accept the screenshot, so it may not support image input. Tap Choose model, pick one marked [image], then tap Retry.\n" + FloatAi.friendly(err)
                lastPick = true
            }
            if (text.isEmpty()) { ui?.let { u -> streamTv?.let { t -> u.list.removeView(t.parent as View) } } }
        } else if (text.isEmpty() && rq.cancelled) ui?.let { u -> streamTv?.let { t -> u.list.removeView(t.parent as View) } }
        streamTv = null
        worker?.execute { FloatStore.save() }
        if (ui != null) { renderConversation(); refreshSend() } else if (text.isNotEmpty()) { bubble?.badge = true }
    }

    private fun stopRequest() {
        val rq = req ?: return
        rq.cancelled = true; rq.ai.cancel()
        onDone(rq, streamMsg?.text ?: "", streamMsg?.via ?: "", false, emptyList(), null)
    }

    // ---------------------------------------------------------------- screen capture (reuses ScreenCaptureService)
    private fun capActive() = FrameStore.state != "stopped"

    private fun setCapMsg(m: String?) {
        capMsg = m; main.removeCallbacks(clearMsgRun)
        if (m != null) main.postDelayed(clearMsgRun, 9000)
        refreshCapture()
    }

    /** "Ask AI About My Screen" (ask = true: also opens the keyboard) and "Capture Screen" (ask = false). */
    private fun onCapture(ask: Boolean) {
        if (capturingNow) return
        setCapMsg(null)
        action = if (ask) "ask" else "capture"
        if (!capActive()) requestPermission() else if (FrameStore.state == "paused") { action = null; setCapMsg("Screen capture is paused. Tap Resume first.") } else takeShot()
    }

    private fun requestPermission() {
        setOverlayHidden(true)      // keep our overlay off Android's consent dialog
        try { startActivity(Intent(this, CaptureRequestActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (_: Throwable) { action = null; setOverlayHidden(false); setCapMsg("Could not open Android's screen capture permission dialog.") }
    }

    private fun onPermission(ok: Boolean) {
        if (ok) return              // ScreenCaptureService is starting; onCaptureState() continues when it is running
        action = null; setOverlayHidden(false)
        setCapMsg("Screen capture permission was declined. Nothing was captured.")
    }

    private fun onCaptureState() {
        bubble?.capturing = capActive()
        if (FrameStore.state == "stopped") {
            val hadWork = action != null || capturingNow
            action = null; capturingNow = false
            clearPending(); retryShot = null
            if (overlayHidden) setOverlayHidden(false)
            if (hadWork) setCapMsg("Screen capture stopped.") else refreshCapture()
            return
        }
        if (FrameStore.state == "running" && action != null && !capturingNow) takeShot()
        refreshCapture()
    }

    /** Hide our own overlay first (so the panel is not in the screenshot), then ask the capture service for ONE frame. */
    private fun takeShot() {
        if (action == null) return
        capturingNow = true
        setOverlayHidden(true); refreshCapture()
        main.postDelayed({
            if (!capturingNow) return@postDelayed
            try { startService(Intent(this, ScreenCaptureService::class.java).setAction(ScreenCaptureService.CAPTURE).putExtra(ScreenCaptureService.QUALITY, 70)) }
            catch (_: Throwable) { onShot(Shot(null, 0, 0, false, "Could not reach the screen capture service.")) }
        }, 320)
    }

    private fun onShot(sh: Shot) {
        if (!capturingNow) return
        val wasAsk = action == "ask"; action = null; capturingNow = false
        setOverlayHidden(false)
        val jpeg = sh.jpeg
        if (jpeg == null) { setCapMsg(sh.error ?: "Screenshot failed."); return }
        clearPending()
        pendingShot = jpeg; pendingBlank = sh.blank
        pendingThumb = decodeThumb(jpeg)
        if (ui == null) bubble?.badge = true
        setCapMsg(null)
        if (wasAsk) enterTyping()
    }

    private fun decodeThumb(b: ByteArray): Bitmap? = try {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(b, 0, b.size, o)
        var ss = 1; while (o.outHeight / (ss * 2) >= dp(260)) ss *= 2
        BitmapFactory.decodeByteArray(b, 0, b.size, BitmapFactory.Options().apply { inSampleSize = ss; inPreferredConfig = Bitmap.Config.RGB_565 })
    } catch (_: Throwable) { null }

    private fun clearPending() {
        pendingShot = null; pendingBlank = false
        ui?.cap?.thumb?.setImageDrawable(null)
        pendingThumb?.let { try { it.recycle() } catch (_: Throwable) { } }; pendingThumb = null
    }

    private fun onPauseResume() {
        if (!capActive()) return
        val a = if (FrameStore.state == "paused") ScreenCaptureService.RESUME else ScreenCaptureService.PAUSE
        try { startService(Intent(this, ScreenCaptureService::class.java).setAction(a)) } catch (_: Throwable) { setCapMsg("Could not reach the screen capture service.") }
    }

    private fun onStopCapture() {
        action = null; capturingNow = false
        if (capActive()) try { stopService(Intent(this, ScreenCaptureService::class.java)) } catch (_: Throwable) { }
        clearPending(); retryShot = null
        refreshCapture()
    }

    private fun setOverlayHidden(h: Boolean) {
        if (h == overlayHidden) return
        main.removeCallbacks(unhideRun)
        if (h) {
            exitTyping()
            overlayHidden = true
            ui?.let { try { wm.removeViewImmediate(it.root) } catch (_: Throwable) { } }
            main.postDelayed(unhideRun, 45000)       // safety net: never leave the user without the bubble
        } else {
            overlayHidden = false
            val u = ui; val p = panelLp
            if (u != null && p != null) try { layoutPanel(p); wm.addView(u.root, p) } catch (_: Throwable) { ui = null; panelLp = null }
        }
        parkBubble()
        refreshCapture()
    }

    private fun applyThumbSize() {
        val t = ui?.cap?.thumb ?: return
        t.layoutParams = (t.layoutParams as LinearLayout.LayoutParams).apply { height = dp(if (bigThumb) 260 else 88) }
        t.requestLayout()
    }

    private fun onAgentStart() {
        val task = ui?.input?.text?.toString()?.trim().orEmpty()
        if (task.isEmpty()) { toast("Type the task in the message box first, then tap Start Agent."); return }
        val err = AgentRunner.start(applicationContext, task)
        if (err != null) { toast(err); refreshAgent(); return }
        draft = ""; ui?.input?.setText(""); minimize()      // get out of the way: the agent bar takes over
    }
    private fun onAgentPause() { if (AgentController.paused) AgentController.resume() else AgentController.pause(); refreshAgent() }
    private fun refreshAgent() {
        val a = agUi ?: return
        val run = AgentController.state != "idle"; val paused = AgentController.paused
        val mode = when (AgentController.mode) { "readonly" -> "Read-only"; "trusted" -> "Trusted"; else -> "Manual confirmation" }
        a.text.text = "Agent: " + (if (!AgentController.enabled) "OFF (enable it in Settings > Agent Control)" else AgentController.status) + " · " + mode + " · Accessibility " + (if (AIAccessibilityService.connected()) "on" else "OFF")
        a.text.setTextColor(if (run) pal.ink else pal.mut)
        a.start.row.alpha = if (run) 0.5f else 1f
        a.pause.row.visibility = if (run) View.VISIBLE else View.GONE
        a.stop.row.visibility = if (run) View.VISIBLE else View.GONE
        a.pause.label.text = if (paused) "Resume Agent" else "Pause Agent"
        a.pause.icon.setIcon(if (paused) Ic.PLAY else Ic.PAUSE)
    }

    private fun refreshCapture() {
        refreshAgent()
        val u = ui ?: return; val c = u.cap
        val active = capActive(); val paused = FrameStore.state == "paused"; val manual = FrameStore.mode == ScreenCaptureService.MODE_MANUAL
        val dotColor = when { capMsg != null -> pal.bad; paused -> 0xFFF9A825.toInt(); active -> 0xFFE53935.toInt(); else -> pal.line }
        c.dot.background = roundRect(dotColor, dp(5).toFloat())
        c.text.text = capMsg ?: when {
            capturingNow -> "Taking screenshot…"
            paused -> "Screen capture PAUSED. No screenshots can be taken."
            active && manual -> "Screen capture ON. A screenshot is taken only when you tap a button."
            active -> "Screen sharing ON (continuous, started in the app)."
            else -> "Screen capture is off."
        }
        c.text.setTextColor(if (capMsg != null) pal.bad else if (active && !paused) pal.ink else pal.mut)
        c.pause.row.visibility = if (active) View.VISIBLE else View.GONE
        c.stop.row.visibility = if (active) View.VISIBLE else View.GONE
        c.pause.label.text = if (paused) "Resume" else "Pause"
        c.pause.icon.setIcon(if (paused) Ic.PLAY else Ic.PAUSE)
        c.pause.row.contentDescription = if (paused) "Resume screen capture" else "Pause screen capture"
        c.ask.row.alpha = if (capturingNow) 0.5f else 1f; c.capture.row.alpha = if (capturingNow) 0.5f else 1f
        val shot = pendingShot
        c.previewBox.visibility = if (shot != null) View.VISIBLE else View.GONE
        if (shot != null) {
            c.thumb.setImageBitmap(pendingThumb); applyThumbSize()
            val p = FloatStore.ordered().firstOrNull()
            c.note.text = (if (pendingBlank) "This capture looks completely black. The app may block screenshots (protected or DRM window), or the screen is just dark. " else "") +
                "It is sent with your next message to " + (p?.label ?: "your selected model") + " only, and is not saved."
            c.note.setTextColor(if (pendingBlank) pal.bad else pal.mut)
        }
        u.input.hint = if (shot != null) "Ask about this screen (or just tap send)" else "Message Zyn Ai"
    }
}
