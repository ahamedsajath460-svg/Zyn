package com.a2z.ai

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.os.Build
import android.os.IBinder
import android.widget.Toast

/**
 * Foreground-service shell of the unified floating panel. All UI (bubble, panel, chat, agent control, vision) lives in
 * [FloatingPanelController]; this class only owns its lifetime and the notification controls. The old native bubble / chat UI
 * and the separate agent control bar are gone: there is exactly ONE bubble and ONE panel.
 */
class FloatingAssistantService : Service() {
    companion object {
        const val ACT_START = "a2z.float.start"; const val ACT_STOP = "a2z.float.stop"; const val ACT_TOGGLE = "a2z.float.toggle"; const val ACT_AGENT_STOP = "a2z.float.agentstop"
        private const val CH = "a2z_float"; private const val NID = 8
        @Volatile var running = false; private set
    }

    private var controller: FloatingPanelController? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        FloatStore.init(applicationContext)
        AgentHistory.init(applicationContext)
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == ACT_STOP) { stopSelf(); return START_NOT_STICKY }
        if (!goForeground()) { stopSelf(); return START_NOT_STICKY }
        if (i?.action == ACT_AGENT_STOP) AgentController.hardStop("You pressed Stop in the notification.")
        var c = controller
        if (c == null) { c = FloatingPanelController(this); controller = c }
        if (!c.show()) { stopSelf(); return START_NOT_STICKY }     // show() is a no-op when the single window already exists
        if (i?.action == ACT_TOGGLE) c.toggleFromNotification()
        return START_NOT_STICKY
    }

    override fun onConfigurationChanged(c: Configuration) {
        super.onConfigurationChanged(c)
        controller?.onConfigChanged(c)
    }

    override fun onDestroy() {
        running = false
        controller?.destroy(); controller = null
        try { stopForeground(true) } catch (_: Throwable) { }
        super.onDestroy()
    }

    private fun goForeground(): Boolean {
        try {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel(CH, "Floating assistant", NotificationManager.IMPORTANCE_LOW))
            fun act(a: String, label: String): Notification.Action {
                val pi = PendingIntent.getService(this, a.hashCode(), Intent(this, FloatingAssistantService::class.java).setAction(a), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
                @Suppress("DEPRECATION") return Notification.Action.Builder(0, label, pi).build()
            }
            val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), PendingIntent.FLAG_IMMUTABLE)
            val n = Notification.Builder(this, CH).setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("Zyn Ai floating assistant is on").setContentText("Tap the bubble to chat, run the agent or share your screen.")
                .setOngoing(true).setContentIntent(open).addAction(act(ACT_TOGGLE, "Show / hide")).addAction(act(ACT_AGENT_STOP, "Stop agent")).addAction(act(ACT_STOP, "Close")).build()
            if (Build.VERSION.SDK_INT >= 34) startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(NID, n)
            return true
        } catch (e: Exception) { try { Toast.makeText(applicationContext, "Could not start the floating assistant service", Toast.LENGTH_SHORT).show() } catch (_: Throwable) { }; return false }
    }
}
