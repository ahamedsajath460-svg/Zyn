package com.a2z.ai

import android.Manifest
import android.animation.ValueAnimator
import android.app.Service
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Point
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.util.Base64
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.WindowManager
import android.view.WindowManager.LayoutParams
import android.view.inputmethod.InputMethodManager
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * THE single floating UI coordinator of Zyn Ai: ONE overlay window (bubble <-> panel) hosting the HTML design in assets/zyn_float_panel.html.
 * Everything the page does goes through [Bridge] into the real backends:
 *   chat            -> FloatAi / FloatStore (providers, keys, history are the app's own, nothing is re-entered)
 *   agent           -> AgentRunner / AgentController / AgentPolicy / AgentHistory / AgentActions (via AgentRunner)
 *   screen + vision -> FrameStore / ScreenCaptureService / ScreenOcr / AgentVision / HighlightOverlay (no second capture service)
 *   voice           -> NativeSpeech / NativeTts
 * Owned by [FloatingAssistantService]; there is at most one instance, so at most one bubble and one panel can exist.
 */
class FloatingPanelController(private val svc: Service) {
    class Confirm(val title: String, val lines: List<String>, val cb: (Boolean) -> Unit)
    private class Att(val id: String, val kind: String, val name: String, val bytes: ByteArray)
    private class Req { @Volatile var cancelled = false; var ai = FloatAi(); var image = false }

    companion object {
        @Volatile var instance: FloatingPanelController? = null; private set
        /** A confirmation that arrived before the panel existed (agent started from the app). Shown as soon as the panel is up. */
        @Volatile var queued: Confirm? = null
        fun speakFallback(t: String) { instance?.speak(t) }
        private const val PAGE = "file:///android_asset/zyn_float_panel.html"
    }

    private val ctx: Context = svc.applicationContext
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val main = Handler(Looper.getMainLooper())
    private val prefs = ctx.getSharedPreferences("a2z_float_ui", Context.MODE_PRIVATE)
    private var worker: ExecutorService? = Executors.newSingleThreadExecutor()

    // ---- window state ----
    private var host: Host? = null
    private var web: WebView? = null
    private var lp: LayoutParams? = null
    private var attached = false
    private var mode = "bubble"                   // bubble | panel
    private var minimized = false; private var maximized = false; private var typing = false; private var hidden = false
    private var minH = 0
    private var dsx = 0; private var dsy = 0
    private var bx = 0; private var by = 0
    private var px = Int.MIN_VALUE; private var py = 0; private var pw = 0; private var ph = 0
    @Volatile private var lastUp = 0L
    private val unhideRun = Runnable { if (hidden) setHidden(false) }

    // ---- chat state ----
    private var req: Req? = null
    private var streamMsg: FMsg? = null
    private var retryImgs: List<String> = emptyList(); private var retryExtra = ""
    private val atts = ConcurrentHashMap<String, Att>()
    private val busy get() = req != null

    // ---- screen / vision state ----
    private var action: String? = null            // share | ask | capture : what to do once screen capture is running
    private var capturingNow = false
    private var previewOn = false; private var previewBusy = false; private var lastPrevRef: String? = null
    private var lastOcr: JSONObject? = null
    private var lastStatus = ""
    private var confirm: Confirm? = null

    // ---- voice ----
    private var speech: NativeSpeech? = null
    private var tts: NativeTts? = null

    private val agentListener: (String, String) -> Unit = { t, d -> main.post { onAgentEvent(t, d) } }
    private val tick = object : Runnable { override fun run() { onTick(); main.postDelayed(this, if (mode == "panel") 1000L else 2500L) } }

    // ================================================================ lifecycle
    fun show(): Boolean {
        if (host != null) return true                   // exactly one window, ever
        if (!FloatPerm.has(ctx)) { toast("Allow \"Display over other apps\" for Zyn Ai first"); return false }
        FloatStore.init(ctx)
        instance = this
        val s = screen()
        bx = prefs.getInt("bx", s.x - dp(56) - dp(4)); by = prefs.getInt("by", s.y / 3)
        pw = prefs.getInt("pw", dp(360)); ph = prefs.getInt("ph", dp(520))
        if (prefs.contains("px")) { px = prefs.getInt("px", 0); py = prefs.getInt("py", 0) }
        val h = Host(ctx)
        val w = WebView(ctx)
        w.setBackgroundColor(Color.TRANSPARENT)
        w.isVerticalScrollBarEnabled = false; w.isHorizontalScrollBarEnabled = false
        w.overScrollMode = android.view.View.OVER_SCROLL_NEVER
        val st = w.settings
        st.javaScriptEnabled = true; st.domStorageEnabled = true; st.allowContentAccess = false
        st.blockNetworkLoads = true                    // the panel page never talks to the network itself; FloatAi does
        w.addJavascriptInterface(Bridge(), "ZP")
        w.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean = true
        }
        h.addView(w, FrameLayout.LayoutParams(-1, -1))
        host = h; web = w
        val l = LayoutParams(dp(56), dp(56), LayoutParams.TYPE_APPLICATION_OVERLAY,
            LayoutParams.FLAG_NOT_TOUCH_MODAL or LayoutParams.FLAG_LAYOUT_IN_SCREEN or LayoutParams.FLAG_NOT_FOCUSABLE or LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; softInputMode = LayoutParams.SOFT_INPUT_ADJUST_PAN }
        lp = l
        layout(false)
        try { wm.addView(h, l); attached = true } catch (e: Exception) {
            host = null; web = null; lp = null; instance = null; toast("Android refused the overlay window (permission?)"); return false
        }
        w.loadUrl(PAGE)
        FrameStore.onState = { main.post { onCaptureState() } }
        FrameStore.onShot = { sh -> main.post { onShot(sh) } }
        FrameStore.onPermission = { ok -> main.post { onPermission(ok) } }
        AgentController.listeners.add(agentListener)
        main.postDelayed(tick, 1000)
        queued?.let { q -> queued = null; main.postDelayed({ showConfirm(q.title, q.lines, q.cb) }, 600) }
        return true
    }

    fun destroy() {
        main.removeCallbacksAndMessages(null)
        AgentController.listeners.remove(agentListener)
        FrameStore.onState = null; FrameStore.onShot = null; FrameStore.onPermission = null
        // Release screen capture only if THIS panel started it in manual mode (a share started from the app's own dialog is left alone).
        if (FrameStore.mode == ScreenCaptureService.MODE_MANUAL && FrameStore.state != "stopped") try { ctx.stopService(Intent(ctx, ScreenCaptureService::class.java)) } catch (_: Throwable) { }
        req?.let { it.cancelled = true; it.ai.cancel() }; req = null
        confirm?.let { try { it.cb(false) } catch (_: Throwable) { } }; confirm = null
        worker?.shutdownNow(); worker = null
        try { speech?.destroy() } catch (_: Throwable) { }; speech = null
        try { tts?.destroy() } catch (_: Throwable) { }; tts = null
        atts.clear()
        val h = host; val w = web
        if (attached && h != null) try { wm.removeViewImmediate(h) } catch (_: Throwable) { }
        attached = false
        try { w?.removeAllViews(); w?.destroy() } catch (_: Throwable) { }
        host = null; web = null; lp = null
        FloatStore.save()
        if (instance === this) instance = null
    }

    fun toggleFromNotification() { main.post { if (mode == "panel") closePanel() else openPanel() } }

    fun onConfigChanged(c: Configuration) {
        main.post { layout(true); ev("win", winJson()) }
    }

    // ================================================================ window management
    private inner class Host(c: Context) : FrameLayout(c) {
        override fun dispatchTouchEvent(e: MotionEvent): Boolean {
            if (e.actionMasked == MotionEvent.ACTION_UP) lastUp = SystemClock.uptimeMillis()
            return super.dispatchTouchEvent(e)
        }
        override fun dispatchKeyEvent(e: KeyEvent): Boolean {
            if (e.keyCode == KeyEvent.KEYCODE_BACK) { if (e.action == KeyEvent.ACTION_UP) ev("back", ""); return true }
            return super.dispatchKeyEvent(e)
        }
    }

    private fun dp(v: Int) = (v * ctx.resources.displayMetrics.density + 0.5f).toInt()
    private fun screen(): Point { val dm = DisplayMetrics(); @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(dm); return Point(dm.widthPixels, dm.heightPixels) }
    private fun statusBar(): Int { val id = ctx.resources.getIdentifier("status_bar_height", "dimen", "android"); return if (id > 0) ctx.resources.getDimensionPixelSize(id) else dp(24) }
    private fun toast(m: String) { main.post { try { Toast.makeText(ctx, m, Toast.LENGTH_SHORT).show() } catch (_: Throwable) { } } }
    private fun update() { val h = host ?: return; val l = lp ?: return; if (!attached) return; try { wm.updateViewLayout(h, l) } catch (_: Throwable) { } }
    private fun winJson() = JSONObject().put("mode", mode).put("max", maximized).put("min", minimized).put("typing", typing).toString()

    private fun layout(apply: Boolean) {
        val l = lp ?: return
        val s = screen(); val land = s.x > s.y; val m = dp(8)
        if (mode == "bubble") {
            val size = dp(56)
            l.width = size; l.height = size
            bx = bx.coerceIn(0, (s.x - size).coerceAtLeast(0)); by = by.coerceIn(0, (s.y - size).coerceAtLeast(0))
            l.x = bx; l.y = by
        } else if (maximized) {
            l.width = s.x; l.height = s.y - statusBar(); l.x = 0; l.y = statusBar()
            if (typing) l.height = minOf(l.height, (s.y * 0.55f).toInt())
        } else {
            val w = pw.coerceIn(minOf(dp(260), s.x - 2 * m), s.x - 2 * m)
            var h = if (minimized && minH > 0) minH else ph.coerceIn(minOf(dp(200), s.y - 2 * m), s.y - 2 * m)
            if (typing) h = minOf(h, (s.y * (if (land) 0.5f else 0.46f)).toInt())
            if (px == Int.MIN_VALUE) {   // first open: next to the bubble
                px = if (bx + dp(28) < s.x / 2) m else s.x - w - m
                py = if (by > s.y / 2) by - h - dp(10) else by + dp(56) + dp(10)
            }
            px = px.coerceIn(0, (s.x - w).coerceAtLeast(0)); py = py.coerceIn(0, (s.y - h).coerceAtLeast(0))
            l.width = w; l.height = h; l.x = px; l.y = if (typing) minOf(py, statusBar() + dp(4)) else py
        }
        if (apply) update()
    }

    private fun setFocusable(on: Boolean) {
        val l = lp ?: return
        l.flags = if (on) l.flags and LayoutParams.FLAG_NOT_FOCUSABLE.inv() else l.flags or LayoutParams.FLAG_NOT_FOCUSABLE
        update()
        if (on) web?.requestFocus()
    }

    private fun openPanel() {
        if (mode == "panel") return
        mode = "panel"; minimized = false
        ev("win", winJson()); layout(true)
    }

    private fun closePanel() {
        if (mode == "bubble") return
        setTyping(false)
        mode = "bubble"; minimized = false; maximized = false
        ev("win", winJson()); layout(true)
    }

    private fun setTyping(on: Boolean) {
        if (typing == on) return
        typing = on
        if (!on) try { (ctx.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(host?.windowToken, 0) } catch (_: Throwable) { }
        setFocusable(on); layout(true)
        if (on) main.postDelayed({
            try { web?.requestFocus(); (ctx.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(web, InputMethodManager.SHOW_IMPLICIT) } catch (_: Throwable) { }
        }, 160)
    }

    private fun savePanel() { prefs.edit().putInt("pw", pw).putInt("ph", ph).putInt("px", px).putInt("py", py).apply() }

    private fun snapBubble() {
        val l = lp ?: return
        val s = screen(); val size = dp(56)
        val target = if (bx + size / 2 < s.x / 2) dp(4) else s.x - size - dp(4)
        by = by.coerceIn(0, (s.y - size).coerceAtLeast(0))
        ValueAnimator.ofInt(bx, target).apply {
            duration = 180
            addUpdateListener { a -> bx = a.animatedValue as Int; if (mode == "bubble") { l.x = bx; l.y = by; update() } }
            start()
        }
        prefs.edit().putInt("bx", target).putInt("by", by).apply()
    }

    private fun setHidden(h: Boolean) {
        if (h == hidden) return
        main.removeCallbacks(unhideRun)
        val v = host ?: return
        if (h) {
            setTyping(false); hidden = true
            if (attached) { try { wm.removeViewImmediate(v) } catch (_: Throwable) { }; attached = false }
            main.postDelayed(unhideRun, 45000)          // safety net: never leave the user without the bubble
        } else {
            hidden = false
            if (!attached) { try { layout(false); wm.addView(v, lp); attached = true } catch (_: Throwable) { } }
        }
        ev("busyShot", if (h) "1" else "0")
    }

    // ================================================================ JS plumbing
    private fun js(code: String) { main.post { try { web?.evaluateJavascript(code, null) } catch (_: Throwable) { } } }
    private fun ev(type: String, json: String) { js("window.ZPN&&ZPN(" + JSONObject.quote(type) + "," + JSONObject.quote(json) + ")") }
    private fun jo(vararg kv: Pair<String, Any?>): String { val o = JSONObject(); for ((k, v) in kv) o.put(k, v ?: JSONObject.NULL); return o.toString() }

    // ================================================================ chat (FloatAi)
    private fun emptyHint(): String {
        val p = FloatStore.ordered().firstOrNull()
        return when {
            !FloatStore.synced -> "Open the Zyn Ai app once so your AI providers and keys can sync, then come back."
            p == null -> "No AI provider is ready. Open Zyn Ai > Settings > AI providers and add an API key."
            else -> ""
        }
    }

    private fun chatJson(): String {
        val a = JSONArray()
        for (m in FloatStore.snapshot(FloatStore.current())) a.put(JSONObject().put("r", if (m.role == "user") "u" else "a").put("x", m.text).put("v", m.via).put("ts", m.ts))
        return a.toString()
    }

    private fun chatListJson(): String {
        val a = JSONArray(); val cur = FloatStore.current().id
        for (c in FloatStore.list()) a.put(JSONObject().put("id", c.id).put("t", FloatStore.titleOf(c)).put("u", c.updated).put("pin", c.pinned).put("cur", c.id == cur))
        return a.toString()
    }

    private fun providersJson(): String {
        val a = JSONArray(); val cur = FloatStore.ordered().firstOrNull()
        for (p in FloatStore.providers) a.put(JSONObject().put("id", p.id).put("label", p.label).put("tag", FloatVision.tag(p)).put("sel", p === cur))
        return JSONObject().put("list", a).put("synced", FloatStore.synced).put("hint", emptyHint()).toString()
    }

    private fun systemPrompt(withImage: Boolean): String {
        val date = SimpleDateFormat("EEEE, d MMMM yyyy, HH:mm", Locale.ENGLISH).format(Date())
        return listOf(FloatStore.systemBase, "Current date and time: $date.",
            "Language rule: reply in the language and script of the user's latest message (for example English, Tamil, Sinhala, or Tamil typed in English letters).",
            "You are answering inside a small floating chat panel on a phone, so keep replies focused and concise unless the user asks for detail.",
            if (withImage) "The user attached image(s) (possibly a screenshot of their own Android screen) to their latest message. Describe and answer only from what is actually visible; if something is cut off, blank or unreadable, say so instead of guessing. Do not repeat sensitive details such as passwords, card numbers or one-time codes." else "")
            .filter { it.isNotBlank() }.joinToString("\n\n")
    }

    private fun buildTurns(c: FConv): List<Turn> {
        val out = ArrayList<Turn>(); var budget = 24000
        for (m in FloatStore.snapshot(c).asReversed()) {
            if (budget <= 0 || out.size >= 24) break
            budget -= m.text.length
            val role = if (m.role == "user") "user" else "assistant"
            if (out.isNotEmpty() && out.last().role == role) { val last = out.removeAt(out.size - 1); out.add(Turn(role, m.text + "\n\n" + last.text)) }
            else out.add(Turn(role, m.text))
        }
        out.reverse()
        while (out.isNotEmpty() && out.first().role != "user") out.removeAt(0)
        return out
    }

    private fun decorate(t: List<Turn>, extra: String, imgs: List<String>): List<Turn> {
        if (t.isEmpty() || t.last().role != "user" || (extra.isEmpty() && imgs.isEmpty())) return t
        return t.dropLast(1) + Turn("user", t.last().text + extra, imgs)
    }

    /** Called on a bridge thread. Returns JSON {ok, err, pick}. Nothing is consumed on failure, so the page keeps the text and attachments. */
    private fun sendChat(text0: String, ids: List<String>): String {
        val t = text0.trim()
        if (busy || capturingNow) return jo("ok" to false, "err" to "Wait for the current reply to finish.")
        val list = ids.mapNotNull { atts[it] }
        if (t.isEmpty() && list.isEmpty()) return jo("ok" to false, "err" to "")
        val prov = FloatStore.ordered()
        if (prov.isEmpty()) return jo("ok" to false, "err" to emptyHint().ifEmpty { "No AI provider is ready." })
        val images = list.filter { it.kind == "image" }
        if (images.isNotEmpty() && FloatVision.support(prov.first()) == FloatVision.S.NO)
            return jo("ok" to false, "pick" to true, "err" to "\"${prov.first().model}\" is a text-only model, so it can't read images. Choose a model marked [image]. Your text and attachments are kept.")
        ids.forEach { atts.remove(it) }
        val extra = StringBuilder()
        for (a in list) if (a.kind == "text") extra.append("\n\n--- Attached file: ").append(a.name).append(" ---\n").append(String(a.bytes, Charsets.UTF_8).take(20000))
        val label = StringBuilder()
        if (images.isNotEmpty()) label.append("[Image attached] ")
        list.filter { it.kind == "text" }.forEach { label.append("[File: ").append(it.name).append("] ") }
        val shown = if (t.isEmpty()) "Explain what is on my screen: the app or website, the visible text and buttons, any errors or warnings, and what I should do next." else t
        val c = FloatStore.current()
        FloatStore.addMsg(c, FMsg("user", label.toString() + (if (t.isEmpty() && images.isNotEmpty()) shown else t), System.currentTimeMillis()))
        val b64 = images.map { Base64.encodeToString(it.bytes, Base64.NO_WRAP) }
        main.post { startRequest(c, b64, extra.toString()) }
        return jo("ok" to true)
    }

    private fun startRequest(c: FConv, imgs: List<String>, extra: String) {
        val rq = Req(); rq.image = imgs.isNotEmpty(); req = rq; streamMsg = null; retryImgs = imgs; retryExtra = extra
        val providers = if (imgs.isNotEmpty()) FloatStore.ordered().take(1) else FloatStore.ordered()   // images go ONLY to the selected provider
        val sys = systemPrompt(imgs.isNotEmpty()); val turns = decorate(buildTurns(c), extra, imgs)
        ev("busy", "1")
        val ex = worker ?: return
        ex.execute {
            val errors = ArrayList<String>(); var used: FProvider? = null; var fellBack = false
            val sb = StringBuilder(); var lastPost = 0L; var lastErr: Throwable? = null
            for ((idx, p) in providers.withIndex()) {
                if (rq.cancelled) break
                rq.ai = FloatAi().also { if (rq.cancelled) it.cancel() }
                val via = p.label + if (idx > 0) " (fallback)" else ""
                try {
                    rq.ai.stream(p, sys, turns) { d ->
                        sb.append(d)
                        val now = System.currentTimeMillis()
                        if (now - lastPost >= 100) { lastPost = now; val s = sb.toString(); main.post { onText(rq, s, via) } }
                    }
                    used = p; fellBack = idx > 0; lastErr = null; break
                } catch (e: Throwable) {
                    if (rq.cancelled) break
                    lastErr = e; errors.add(p.name.ifBlank { p.type } + ": " + FloatAi.friendly(e))
                    if (sb.isNotEmpty()) break          // never switch provider in the middle of an answer
                }
            }
            val text = sb.toString(); val via = used?.let { it.label + if (fellBack) " (fallback)" else "" } ?: providers.firstOrNull()?.label ?: ""
            main.post { onDone(rq, text, via, used != null, errors, lastErr) }
        }
    }

    private fun onText(rq: Req, text: String, via: String) {
        if (rq !== req) return
        var m = streamMsg
        if (m == null) { m = FMsg("assistant", text, System.currentTimeMillis(), via); streamMsg = m; FloatStore.addMsg(FloatStore.current(), m) }
        else FloatStore.setText(m, text, via)
        ev("delta", jo("x" to text, "v" to via))
    }

    private fun onDone(rq: Req, text: String, via: String, ok: Boolean, errors: List<String>, err: Throwable?) {
        if (rq !== req) return
        req = null
        val c = FloatStore.current(); var m = streamMsg; streamMsg = null
        if (text.isNotEmpty()) {
            if (m == null) { m = FMsg("assistant", text, System.currentTimeMillis(), via); FloatStore.addMsg(c, m) }
            FloatStore.setText(m, text, if (ok) via else "$via · interrupted")
        }
        var error = ""; var pick = false
        if (!ok && !rq.cancelled && err != null) {
            error = if (errors.size > 1) errors.joinToString("\n") { "• $it" } else FloatAi.friendly(err)
            if (rq.image && err is FloatAi.ApiError && err.status in intArrayOf(400, 404, 415, 422)) {
                error = "This model did not accept the image, so it may not support image input. Choose a model marked [image], then tap Retry.\n" + FloatAi.friendly(err)
                pick = true
            }
        }
        worker?.execute { FloatStore.save() }
        ev("done", jo("x" to text, "v" to via, "ok" to ok, "stopped" to rq.cancelled, "err" to error, "pick" to pick))
    }

    private fun stopChat() {
        val rq = req ?: return
        rq.cancelled = true; rq.ai.cancel()
        onDone(rq, streamMsg?.text ?: "", streamMsg?.via ?: "", false, emptyList(), null)
    }

    private fun regenerate(): String {
        if (busy) return jo("ok" to false)
        val c = FloatStore.current()
        val msgs = FloatStore.snapshot(c)
        if (msgs.isNotEmpty() && msgs.last().role == "assistant") FloatStore.removeMsg(c, msgs.last())
        if (FloatStore.snapshot(c).lastOrNull()?.role != "user") return jo("ok" to false)
        if (FloatStore.ordered().isEmpty()) return jo("ok" to false, "err" to emptyHint())
        startRequest(c, retryImgs, retryExtra)
        return jo("ok" to true)
    }

    // ================================================================ attachments (picked through FloatPickActivity)
    fun onPicked(name: String, mime: String, bytes: ByteArray) {
        val w = worker ?: return
        w.execute {
            try {
                if (bytes.size > 25 * 1024 * 1024) { toast("$name is over 25 MB"); return@execute }
                val id = "a" + System.nanoTime().toString(36)
                if (mime.startsWith("image/")) {
                    val jpeg = downscale(bytes, 1280, 82) ?: run { toast("Could not read $name"); return@execute }
                    val thumb = downscale(bytes, 120, 60)
                    atts[id] = Att(id, "image", name, jpeg)
                    ev("att", jo("id" to id, "kind" to "image", "name" to name, "thumb" to (if (thumb != null) "data:image/jpeg;base64," + Base64.encodeToString(thumb, Base64.NO_WRAP) else "")))
                } else if (mime.startsWith("text/") || mime == "application/json" || mime == "application/xml" || name.matches(Regex("(?i).*\\.(txt|md|csv|json|xml|log|kt|java|js|ts|py|html|css|yml|yaml|ini|sql|sh)$"))) {
                    atts[id] = Att(id, "text", name, bytes)
                    ev("att", jo("id" to id, "kind" to "file", "name" to name, "thumb" to ""))
                } else toast("The AI can read images and text files. \"$name\" was not added.")
            } catch (_: Throwable) { toast("Could not add $name") }
        }
    }

    private fun downscale(b: ByteArray, maxSide: Int, q: Int): ByteArray? {
      return try {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(b, 0, b.size, o)
        if (o.outWidth <= 0) null else {
            var ss = 1; while (maxOf(o.outWidth, o.outHeight) / (ss * 2) >= maxSide) ss *= 2
            val bm = BitmapFactory.decodeByteArray(b, 0, b.size, BitmapFactory.Options().apply { inSampleSize = ss }) ?: return null
            val k = minOf(1f, maxSide.toFloat() / maxOf(bm.width, bm.height))
            val sc = if (k < 1f) Bitmap.createScaledBitmap(bm, (bm.width * k).toInt().coerceAtLeast(1), (bm.height * k).toInt().coerceAtLeast(1), true) else bm
            val out = ByteArrayOutputStream(); sc.compress(Bitmap.CompressFormat.JPEG, q, out)
            if (sc !== bm) bm.recycle(); sc.recycle()
            out.toByteArray()
        }
    } catch (_: Throwable) { null }
    }

    private fun pick(kind: String) {
        main.post {
            setHidden(false)
            try { ctx.startActivity(Intent(ctx, FloatPickActivity::class.java).putExtra("kind", kind).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            catch (_: Throwable) { toast("Could not open the picker") }
        }
    }

    // ================================================================ screen capture + vision (existing ScreenCaptureService / FrameStore)
    private fun capActive() = FrameStore.state != "stopped"

    private fun requestPermission(live: Boolean) {
        setHidden(true)       // keep our overlay off Android's consent dialog
        try {
            ctx.startActivity(Intent(ctx, CaptureRequestActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                .putExtra("mode", if (live) ScreenCaptureService.MODE_CONTINUOUS else ScreenCaptureService.MODE_MANUAL).putExtra("interval", 1000).putExtra("quality", 65).putExtra("keep", 3))
        } catch (_: Throwable) { action = null; setHidden(false); toast("Could not open Android's screen capture permission dialog.") }
    }

    private fun shareStart() {
        if (capActive()) { toast("Screen sharing is already on."); return }
        action = "share"; requestPermission(true)
    }

    private fun capture(ask: Boolean) {
        if (capturingNow) return
        action = if (ask) "ask" else "capture"
        if (!capActive()) requestPermission(false)
        else if (FrameStore.state == "paused") { action = null; toast("Screen capture is paused. Tap Resume first.") }
        else takeShot()
    }

    private fun onPermission(ok: Boolean) {
        if (ok) return           // ScreenCaptureService is starting; onCaptureState() continues when it is running
        action = null; setHidden(false); toast("Screen capture permission was declined. Nothing was captured.")
    }

    private fun onCaptureState() {
        if (FrameStore.state == "stopped") {
            action = null; capturingNow = false; lastPrevRef = null
            if (hidden) setHidden(false)
            ev("preview", jo("src" to ""))
            pushStatus(true); return
        }
        if (FrameStore.state == "running" && action != null && !capturingNow) {
            if (action == "share") { action = null; setHidden(false); toast("Screen sharing started"); if (mode == "bubble") openPanel() }
            else takeShot()
        }
        pushStatus(true)
    }

    /** Hide our own overlay first (so the panel is not in the screenshot), then ask the capture service for ONE frame. */
    private fun takeShot() {
        if (action == null) return
        capturingNow = true
        setHidden(true)
        main.postDelayed({
            if (!capturingNow) return@postDelayed
            try { ctx.startService(Intent(ctx, ScreenCaptureService::class.java).setAction(ScreenCaptureService.CAPTURE).putExtra(ScreenCaptureService.QUALITY, 70)) }
            catch (_: Throwable) { onShot(Shot(null, 0, 0, false, "Could not reach the screen capture service.")) }
        }, 320)
    }

    private fun onShot(sh: Shot) {
        if (!capturingNow) return
        val wasAsk = action == "ask"; action = null; capturingNow = false
        setHidden(false)
        val jpeg = sh.jpeg
        if (jpeg == null) { toast(sh.error ?: "Screenshot failed."); return }
        val id = "a" + System.nanoTime().toString(36)
        atts[id] = Att(id, "image", "Screen capture", jpeg)
        val th = downscale(jpeg, 120, 60)
        if (mode == "bubble") openPanel()
        ev("att", jo("id" to id, "kind" to "image", "name" to "Screen capture", "blank" to sh.blank, "ask" to wasAsk,
            "thumb" to (if (th != null) "data:image/jpeg;base64," + Base64.encodeToString(th, Base64.NO_WRAP) else "")))
    }

    private fun shareCmd(a: String) {
        if (!capActive()) return
        try { ctx.startService(Intent(ctx, ScreenCaptureService::class.java).setAction(a)) } catch (_: Throwable) { toast("Could not reach the screen capture service.") }
    }

    private fun shareStop() {
        action = null; capturingNow = false
        if (capActive()) try { ctx.stopService(Intent(ctx, ScreenCaptureService::class.java)) } catch (_: Throwable) { }
        FrameStore.state = "stopped"; FrameStore.clear()
        pushStatus(true)
    }

    private fun setPrivacy(on: Boolean) {
        FrameStore.privacy = on
        if (on) { shareCmd(ScreenCaptureService.PAUSE); FrameStore.clear(); HighlightOverlay.hide(); lastPrevRef = null; ev("preview", jo("src" to "")) }
        pushStatus(true)
    }

    /** On-device OCR of the newest frame (or, in manual mode, the last capture). Never sends anything to the network. */
    private fun runOcr() {
        val w = worker ?: return
        w.execute {
            val f = FrameStore.latest(1).lastOrNull()
            if (f == null) { ev("ocr", jo("ok" to false, "err" to "No frame yet. Start Live Screen Share, switch to another app for a moment, then come back.")); return@execute }
            try {
                ScreenOcr.changedSinceRead = false
                val r = JSONObject(ScreenOcr.analyze(f, "auto", true))
                lastOcr = r
                ev("ocr", jo("ok" to r.optBoolean("ok"), "text" to r.optString("text"), "err" to r.optString("error")))
            } catch (e: Throwable) { ev("ocr", jo("ok" to false, "err" to (e.message ?: "OCR failed"))) }
        }
    }

    private fun highlightOcr() {
        val r = lastOcr
        if (r == null || !r.optBoolean("ok")) { toast("Run Screen OCR first."); return }
        val regions = JSONArray()
        val bl = r.optJSONArray("blocks")
        if (bl != null) for (i in 0 until bl.length()) {
            val ls = bl.getJSONObject(i).optJSONArray("lines") ?: continue
            for (j in 0 until ls.length()) {
                val o = ls.getJSONObject(j); if (o.optBoolean("red")) continue
                val b = o.optJSONArray("box") ?: continue
                regions.put(JSONArray().put(b.optInt(0)).put(b.optInt(1)).put(b.optInt(2)).put(b.optInt(3)))
            }
        }
        val fw = r.optInt("w"); val fh = r.optInt("h")
        main.post { try { HighlightOverlay.show(ctx, regions.toString(), fw, fh) } catch (e: Exception) { toast("Highlight failed: " + (e.message ?: "")) } }
    }

    private fun pushPreview() {
        if (!previewOn || previewBusy || FrameStore.state != "running" || FrameStore.privacy) return
        val f = FrameStore.latest(1).lastOrNull() ?: return
        if (f === lastPrevRef) return
        previewBusy = true; lastPrevRef = f
        val w = worker ?: run { previewBusy = false; return }
        w.execute {
            try {
                val bytes = Base64.decode(f, Base64.NO_WRAP)
                val th = downscale(bytes, 360, 55)
                if (th != null) ev("preview", jo("src" to "data:image/jpeg;base64," + Base64.encodeToString(th, Base64.NO_WRAP)))
            } catch (_: Throwable) { } finally { previewBusy = false }
        }
    }

    // ================================================================ agent (AgentRunner / AgentController)
    private fun startAgent(task: String, explain: Boolean): String {
        val t = task.trim()
        val e = AgentRunner.start(ctx, t, explain)
        if (e != null) return e
        FloatStore.addMsg(FloatStore.current(), FMsg("user", (if (explain) "[Ask] " else "[Agent task] ") + t, System.currentTimeMillis()))
        worker?.execute { FloatStore.save() }
        pushStatus(true)
        return ""
    }

    private fun onAgentEvent(t: String, d: String) {
        if (t == "result") {
            try {
                val o = JSONObject(d)
                val txt = o.optString("text")
                if (txt.isNotBlank()) {
                    FloatStore.addMsg(FloatStore.current(), FMsg("assistant", txt, System.currentTimeMillis(), "Agent"))
                    worker?.execute { FloatStore.save() }
                    ev("agentResult", jo("x" to txt, "ok" to o.optBoolean("ok")))
                }
            } catch (_: Throwable) { }
        }
        pushStatus(true)
    }

    fun showConfirm(title: String, lines: List<String>, cb: (Boolean) -> Unit) {
        main.post {
            val old = confirm; confirm = Confirm(title, lines, cb)
            if (old != null) try { old.cb(false) } catch (_: Throwable) { }
            if (hidden) setHidden(false)
            if (mode == "bubble") openPanel()
            minimized = false; layout(true)
            ev("confirm", jo("title" to title, "lines" to JSONArray(lines)))
        }
    }

    fun hideConfirm() {
        main.post {
            val p = confirm; confirm = null
            ev("confirmHide", "")
            if (p != null) try { p.cb(false) } catch (_: Throwable) { }
        }
    }

    private fun answerConfirm(ok: Boolean) {
        main.post {
            val p = confirm ?: return@post
            // Only a real finger tap on the panel can approve: the last touch must have ended a moment ago.
            if (ok && SystemClock.uptimeMillis() - lastUp > 2500) { toast("Tap Confirm with your finger."); return@post }
            confirm = null; ev("confirmHide", "")
            try { p.cb(ok) } catch (_: Throwable) { }
        }
    }

    fun pushStatus(force: Boolean) {
        if (web == null) return
        val s = statusJson()
        if (force || s != lastStatus) { lastStatus = s; ev("status", s) }
    }

    private fun statusJson(): String = try {
        val o = JSONObject(AgentController.status(ctx))
        o.put("paused", AgentController.paused).put("busy", busy).put("capBusy", capturingNow).put("shareMode", FrameStore.mode)
        o.put("privacy", FrameStore.privacy).put("auto", FrameStore.autoOcr).put("changed", ScreenOcr.changedSinceRead).put("protected", FrameStore.protectedHits)
        o.put("mic", ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
        o.put("confirm", confirm != null)
        val hist = JSONArray(AgentHistory.toJson()); val slim = JSONArray()
        for (i in 0 until minOf(hist.length(), 8)) {
            val h = hist.getJSONObject(i)
            slim.put(JSONObject().put("task", h.optString("task")).put("status", h.optString("status")).put("start", h.optLong("start")).put("result", h.optString("result"))
                .put("actions", h.optJSONArray("actions") ?: JSONArray()).put("errors", h.optJSONArray("errors") ?: JSONArray()))
        }
        o.put("history", slim)
        o.toString()
    } catch (e: Throwable) { "{}" }

    private fun onTick() {
        if (web == null) return
        val agentOn = AgentController.state != "idle"
        if (mode == "bubble" && !agentOn && !capActive() && confirm == null) return   // nothing visible to update: no work while only the bubble shows
        if (hidden) return
        pushStatus(false); if (mode == "panel") pushPreview()
    }

    // ================================================================ voice (NativeSpeech / NativeTts)
    private fun nt(): NativeTts = tts ?: NativeTts(ctx) { t, d -> ev("tts", jo("t" to t, "d" to d)) }.also { tts = it }
    private fun ns(): NativeSpeech = speech ?: NativeSpeech(ctx) { t, d -> ev("stt", jo("t" to t, "d" to d)) }.also { speech = it }
    fun speak(t: String) { main.post { try { nt().speak(t, AgentController.lang, 1f, 1f) } catch (_: Throwable) { } } }

    private fun micStart() {
        main.post {
            if (ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                toast("Allow Microphone for Zyn Ai in Android app settings."); openAppSettings(); return@post
            }
            try { if (!ns().available()) { toast("Speech recognition is not available on this device."); return@post }; ns().start(AgentController.lang) } catch (e: Throwable) { toast("Voice input failed.") }
        }
    }

    private fun openAppSettings() {
        try { ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Throwable) { }
    }

    private fun copy(t: String) {
        main.post { try { (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("Zyn Ai", t)) } catch (_: Throwable) { toast("Could not copy") } }
    }

    // ================================================================ boot state
    private fun bootJson(): String {
        val night = (ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        val theme = when (FloatStore.theme) { "light" -> "light"; "dark" -> "dark"; else -> if (night) "dark" else "light" }
        val acc = FloatStore.colors["acc"]?.let { String.format("#%06X", it and 0xFFFFFF) } ?: ""
        return JSONObject().put("theme", theme).put("acc", acc).put("chat", JSONArray(chatJson())).put("providers", JSONObject(providersJson()))
            .put("busy", busy).put("status", JSONObject(statusJson())).put("win", JSONObject(winJson())).put("density", ctx.resources.displayMetrics.density.toDouble())
            .put("blur", Build.VERSION.SDK_INT >= 31).toString()
    }

    // ================================================================ the bridge (page -> native)
    private inner class Bridge {
        // ---- boot / state
        @JavascriptInterface fun boot(): String = bootJson()
        @JavascriptInterface fun status(): String = statusJson()
        @JavascriptInterface fun providers(): String = providersJson()
        @JavascriptInterface fun chat(): String = chatJson()
        // ---- window
        @JavascriptInterface fun toggle() { main.post { if (mode == "panel") this@FloatingPanelController.closePanel() else openPanel() } }
        @JavascriptInterface fun open() { main.post { openPanel() } }
        @JavascriptInterface fun closePanel() { main.post { this@FloatingPanelController.closePanel() } }
        @JavascriptInterface fun quit() { main.post { toast("Floating assistant closed. Start it again from Zyn Ai."); svc.stopSelf() } }
        @JavascriptInterface fun drag(dx: Float, dy: Float) {
            main.post {
                val l = lp ?: return@post
                val d = ctx.resources.displayMetrics.density; val s = screen()
                if (mode == "bubble") { bx = (bx + (dx * d).toInt()).coerceIn(0, s.x - l.width); by = (by + (dy * d).toInt()).coerceIn(0, s.y - l.height); l.x = bx; l.y = by }
                else if (!maximized) { px = (px + (dx * d).toInt()).coerceIn(0, (s.x - l.width).coerceAtLeast(0)); py = (py + (dy * d).toInt()).coerceIn(0, (s.y - l.height).coerceAtLeast(0)); l.x = px; l.y = py }
                update()
            }
        }
        @JavascriptInterface fun dragStart() { main.post { dsx = if (mode == "bubble") bx else px; dsy = if (mode == "bubble") by else py } }
        @JavascriptInterface fun dragTo(dx: Float, dy: Float) {
            main.post {
                val l = lp ?: return@post
                val d = ctx.resources.displayMetrics.density; val s = screen()
                if (mode == "bubble") { bx = (dsx + (dx * d).toInt()).coerceIn(0, (s.x - l.width).coerceAtLeast(0)); by = (dsy + (dy * d).toInt()).coerceIn(0, (s.y - l.height).coerceAtLeast(0)); l.x = bx; l.y = by }
                else if (!maximized) { px = (dsx + (dx * d).toInt()).coerceIn(0, (s.x - l.width).coerceAtLeast(0)); py = (dsy + (dy * d).toInt()).coerceIn(0, (s.y - l.height).coerceAtLeast(0)); l.x = px; l.y = py }
                update()
            }
        }
        @JavascriptInterface fun resizeStart() { main.post { dsx = pw; dsy = ph } }
        @JavascriptInterface fun resizeTo(dx: Float, dy: Float) {
            main.post {
                if (mode != "panel" || maximized || minimized) return@post
                val d = ctx.resources.displayMetrics.density; val s = screen(); val m = dp(8)
                pw = (dsx + (dx * d).toInt()).coerceIn(minOf(dp(260), s.x - 2 * m), (s.x - px).coerceAtLeast(dp(120))); ph = (dsy + (dy * d).toInt()).coerceIn(minOf(dp(200), s.y - 2 * m), (s.y - py).coerceAtLeast(dp(120)))
                layout(true)
            }
        }
        @JavascriptInterface fun dragEnd() { main.post { if (mode == "bubble") snapBubble() else { savePanel() } } }
        @JavascriptInterface fun resize(dx: Float, dy: Float) {
            main.post {
                if (mode != "panel" || maximized || minimized) return@post
                val d = ctx.resources.displayMetrics.density; val s = screen(); val m = dp(8)
                pw = (pw + (dx * d).toInt()).coerceIn(minOf(dp(260), s.x - 2 * m), s.x - px - 0); ph = (ph + (dy * d).toInt()).coerceIn(minOf(dp(200), s.y - 2 * m), s.y - py)
                layout(true)
            }
        }
        @JavascriptInterface fun resizeEnd() { main.post { savePanel() } }
        @JavascriptInterface fun minimize(on: Boolean, cssH: Float) { main.post { minimized = on; if (on) { maximized = false; minH = (cssH * ctx.resources.displayMetrics.density).toInt() }; layout(true); ev("win", winJson()) } }
        @JavascriptInterface fun minHeight(cssH: Float) { main.post { minH = (cssH * ctx.resources.displayMetrics.density).toInt(); if (minimized) layout(true) } }
        @JavascriptInterface fun maximize(on: Boolean) { main.post { maximized = on; if (on) minimized = false; layout(true); ev("win", winJson()) } }
        @JavascriptInterface fun typing(on: Boolean) { main.post { setTyping(on) } }
        @JavascriptInterface fun resetGeometry() { main.post { px = Int.MIN_VALUE; pw = dp(360); ph = dp(520); maximized = false; minimized = false; prefs.edit().remove("px").remove("py").remove("pw").remove("ph").apply(); layout(true); ev("win", winJson()) } }
        @JavascriptInterface fun glassBlur(cssPx: Float) {
            main.post {
                if (Build.VERSION.SDK_INT < 31) return@post
                val l = lp ?: return@post
                try {
                    if (cssPx > 0f && wm.isCrossWindowBlurEnabled) { l.flags = l.flags or LayoutParams.FLAG_BLUR_BEHIND; l.blurBehindRadius = (cssPx * ctx.resources.displayMetrics.density).toInt() }
                    else { l.flags = l.flags and LayoutParams.FLAG_BLUR_BEHIND.inv(); l.blurBehindRadius = 0 }
                    update()
                } catch (_: Throwable) { }
            }
        }
        // ---- chat
        @JavascriptInterface fun send(text: String, ids: String): String = try {
            val a = JSONArray(ids.ifBlank { "[]" }); val l = ArrayList<String>(); for (i in 0 until a.length()) l.add(a.optString(i))
            sendChat(text, l)
        } catch (e: Throwable) { jo("ok" to false, "err" to (e.message ?: "Could not send")) }
        @JavascriptInterface fun stop() { main.post { stopChat() } }
        @JavascriptInterface fun regen(): String = regenerate()
        @JavascriptInterface fun newChat() { main.post { if (busy) stopChat(); FloatStore.newConv(); worker?.execute { FloatStore.save() }; ev("chat", chatJson()) } }
        @JavascriptInterface fun clearChat() { main.post { if (busy) stopChat(); val id = FloatStore.current().id; FloatStore.delete(setOf(id)); ev("chat", chatJson()) } }
        @JavascriptInterface fun chatList(): String = chatListJson()
        @JavascriptInterface fun openChat(id: String) { main.post { if (busy) stopChat(); FloatStore.open(id); ev("chat", chatJson()) } }
        @JavascriptInterface fun deleteChats(ids: String) { main.post { try { val a = JSONArray(ids); val s = HashSet<String>(); for (i in 0 until a.length()) s.add(a.optString(i)); if (busy) stopChat(); FloatStore.delete(s); ev("chat", chatJson()) } catch (_: Throwable) { } } }
        @JavascriptInterface fun renameChat(id: String, name: String) { FloatStore.rename(id, name) }
        @JavascriptInterface fun pinChat(id: String) { FloatStore.pin(id) }
        @JavascriptInterface fun selectProvider(id: String) { FloatStore.selectedId = id; ev("providers", providersJson()) }
        @JavascriptInterface fun copy(t: String) { this@FloatingPanelController.copy(t) }
        // ---- attachments
        @JavascriptInterface fun pick(kind: String) { this@FloatingPanelController.pick(kind) }
        @JavascriptInterface fun dropAtt(id: String) { atts.remove(id) }
        // ---- voice
        @JavascriptInterface fun speak(t: String) { this@FloatingPanelController.speak(t) }
        @JavascriptInterface fun speakStop() { main.post { try { tts?.stop() } catch (_: Throwable) { } } }
        @JavascriptInterface fun micStart() { this@FloatingPanelController.micStart() }
        @JavascriptInterface fun micStop() { main.post { try { speech?.stop() } catch (_: Throwable) { } } }
        // ---- agent
        @JavascriptInterface fun agentCfg(json: String) { try { AgentController.config(json) } catch (_: Throwable) { }; pushStatus(true) }
        @JavascriptInterface fun agentStart(task: String): String = startAgent(task, false)
        @JavascriptInterface fun agentAsk(task: String): String = startAgent(task, true)
        @JavascriptInterface fun agentExplain(): String = startAgent("Explain what is on this screen", true)
        @JavascriptInterface fun agentPause() { AgentController.pause(); pushStatus(true) }
        @JavascriptInterface fun agentResume() { AgentController.resume(); pushStatus(true) }
        @JavascriptInterface fun agentStop() { AgentController.hardStop("You pressed Stop."); pushStatus(true) }
        @JavascriptInterface fun agentClearHistory() { AgentHistory.clear(); pushStatus(true) }
        @JavascriptInterface fun confirm(ok: Boolean) { answerConfirm(ok) }
        @JavascriptInterface fun openAccessibility() { main.post { AgentController.openAccessibilitySettings(ctx) } }
        @JavascriptInterface fun openOverlaySettings() { main.post { try { ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Throwable) { } } }
        @JavascriptInterface fun openApp() { main.post { try { ctx.startActivity(Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)) } catch (_: Throwable) { toast("Open Zyn Ai from your launcher") } } }
        @JavascriptInterface fun openAppSettings() { main.post { this@FloatingPanelController.openAppSettings() } }
        // ---- screen share / vision
        @JavascriptInterface fun shareStart() { main.post { this@FloatingPanelController.shareStart() } }
        @JavascriptInterface fun shareStop() { main.post { this@FloatingPanelController.shareStop() } }
        @JavascriptInterface fun sharePause() { main.post { shareCmd(ScreenCaptureService.PAUSE) } }
        @JavascriptInterface fun shareResume() { main.post { if (!FrameStore.privacy) shareCmd(ScreenCaptureService.RESUME) else toast("Turn off Privacy Mode first.") } }
        @JavascriptInterface fun capture(ask: Boolean) { main.post { this@FloatingPanelController.capture(ask) } }
        @JavascriptInterface fun ocr() { runOcr() }
        @JavascriptInterface fun highlight() { highlightOcr() }
        @JavascriptInterface fun privacy(on: Boolean) { main.post { setPrivacy(on) } }
        @JavascriptInterface fun auto(on: Boolean) { FrameStore.autoOcr = on; pushStatus(true) }
        @JavascriptInterface fun preview(on: Boolean) { previewOn = on; if (on) lastPrevRef = null }
    }
}
