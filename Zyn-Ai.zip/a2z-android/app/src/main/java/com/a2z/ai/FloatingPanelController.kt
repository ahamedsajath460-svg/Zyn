package com.a2z.ai

import android.Manifest
import android.animation.ValueAnimator
import android.app.Service
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Point
import android.graphics.Rect
import android.graphics.RectF
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.util.Base64
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.WindowManager
import android.view.WindowManager.LayoutParams
import android.view.inputmethod.InputMethodManager
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * THE single floating UI coordinator of Zyn Ai: ONE overlay window (bubble <-> panel) hosting the HTML design in assets/zyn_float_panel.html.
 * Everything the page does goes through [Bridge] into the real backends:
 *   chat            -> FloatAi / FloatStore (providers, keys, history are the app's own, nothing is re-entered)
 *   agent           -> AgentRunner / AgentController / AgentPolicy / AgentHistory / AgentActions (via AgentRunner)
 *   screen + vision -> FrameStore / ScreenCaptureService / ScreenOcr / AgentVision / HighlightOverlay (no second capture service)
 *   voice           -> NativeSpeech / NativeTts
 * Owned by [FloatingAssistantService]; there is at most one instance, so at most one bubble and one panel can exist.
 */
class FloatingPanelController(private val svc: Service) {
    class Confirm(val title: String, val lines: List<String>, val cb: (Boolean) -> Unit)
    private class Att(val id: String, val kind: String, val name: String, val bytes: ByteArray)
    private class Req { @Volatile var cancelled = false; var ai = FloatAi(); var image = false }

    companion object {
        @Volatile var instance: FloatingPanelController? = null; private set
        /** A confirmation that arrived before the panel existed (agent started from the app). Shown as soon as the panel is up. */
        @Volatile var queued: Confirm? = null
        fun speakFallback(t: String) { instance?.speak(t) }
        private const val PAGE = "file:///android_asset/zyn_float_panel.html"
    }

    private val ctx: Context = svc.applicationContext
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val main = Handler(Looper.getMainLooper())
    private val prefs = ctx.getSharedPreferences("a2z_float_ui", Context.MODE_PRIVATE)
    private var worker: ExecutorService? = Executors.newSingleThreadExecutor()

    // ---- window state ----
    private var host: Host? = null
    private var web: WebView? = null
    private var lp: LayoutParams? = null
    private var attached = false
    private var mode = "bubble"                   // bubble | panel
    private var minimized = false; private var maximized = false; private var typing = false; private var selecting = false; private var hidden = false
    private var minH = 0
    private var dsx = 0; private var dsy = 0
    private var bx = 0; private var by = 0
    private var px = Int.MIN_VALUE; private var py = 0; private var pw = 0; private var ph = 0
    @Volatile private var lastUp = 0L
    private val unhideRun = Runnable { if (hidden) setHidden(false) }

    // ---- chat state ----
    private var req: Req? = null
    @Volatile private var srcActive = ""        // id of the website the Sources sheet is reading now (cancel = clear)
    private var streamMsg: FMsg? = null
    private var retryImgs: List<String> = emptyList(); private var retryExtra = ""
    private val atts = ConcurrentHashMap<String, Att>()
    private val busy get() = req != null

    // ---- screen / vision state ----
    private var action: String? = null            // share | ask | capture : what to do once screen capture is running
    private var capturingNow = false
    private var previewOn = false; private var previewBusy = false; private var lastPrevRef: String? = null
    private var lastOcr: JSONObject? = null
    private var lastStatus = ""
    private var confirm: Confirm? = null

    // ---- pencil: draw on the screen (Ask screen long-press), then ask about the marked area ----
    private var pencil: ScreenPencil? = null
    @Volatile private var penOn = false
    @Volatile private var penN = 0
    @Volatile private var markPending = false      // a marked-area question is being captured / prepared (blocks a second send)
    private var markText = ""
    private val markGuard = Runnable { if (markPending && req == null) markFail("The marked screenshot took too long. Try again.") }

    // ---- voice ----
    private var speech: NativeSpeech? = null
    private var tts: NativeTts? = null

    private val agentListener: (String, String) -> Unit = { t, d -> main.post { onAgentEvent(t, d) } }
    private val tick = object : Runnable { override fun run() { onTick(); main.postDelayed(this, if (mode == "panel") 1000L else 2500L) } }

    // ================================================================ lifecycle
    fun show(): Boolean {
        if (host != null) return true                   // exactly one window, ever
        if (!FloatPerm.has(ctx)) { toast("Allow \"Display over other apps\" for Zyn Ai first"); return false }
        FloatStore.init(ctx)
        instance = this
        val s = screen()
        bx = prefs.getInt("bx", s.x - dp(56) - dp(4)); by = prefs.getInt("by", s.y / 3)
        pw = prefs.getInt("pw", dp(360)); ph = prefs.getInt("ph", dp(520))
        if (prefs.contains("px")) { px = prefs.getInt("px", 0); py = prefs.getInt("py", 0) }
        val h = Host(ctx)
        val w = WebView(ctx)
        w.setBackgroundColor(Color.TRANSPARENT)
        w.isLongClickable = true; w.isFocusableInTouchMode = true; w.isHapticFeedbackEnabled = true
        w.isVerticalScrollBarEnabled = false; w.isHorizontalScrollBarEnabled = false
        w.overScrollMode = android.view.View.OVER_SCROLL_NEVER
        val st = w.settings
        st.javaScriptEnabled = true; st.domStorageEnabled = true; st.allowContentAccess = false
        st.blockNetworkLoads = true                    // the panel page never talks to the network itself; FloatAi does
        w.addJavascriptInterface(Bridge(), "ZP")
        w.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean = true
        }
        h.addView(w, FrameLayout.LayoutParams(-1, -1))
        host = h; web = w
        bubbleChrome(mode == "bubble")
        val l = LayoutParams(dp(56), dp(56), LayoutParams.TYPE_APPLICATION_OVERLAY,
            LayoutParams.FLAG_NOT_TOUCH_MODAL or LayoutParams.FLAG_LAYOUT_IN_SCREEN or LayoutParams.FLAG_NOT_FOCUSABLE or LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; softInputMode = LayoutParams.SOFT_INPUT_ADJUST_PAN; title = "ZynFloatPanel" }
        lp = l
        layout(false)
        addTarget()
        try { wm.addView(h, l); attached = true } catch (e: Exception) {
            host = null; web = null; lp = null; instance = null; toast("Android refused the overlay window (permission?)"); return false
        }
        w.loadUrl(PAGE)
        FrameStore.onState = { main.post { onCaptureState() } }
        FrameStore.onShot = { sh -> main.post { onShot(sh) } }
        FrameStore.onPermission = { ok -> main.post { onPermission(ok) } }
        AgentController.listeners.add(agentListener)
        main.postDelayed(tick, 1000)
        queued?.let { q -> queued = null; main.postDelayed({ showConfirm(q.title, q.lines, q.cb) }, 600) }
        return true
    }

    fun destroy() {
        main.removeCallbacksAndMessages(null)
        AgentController.listeners.remove(agentListener)
        FrameStore.onState = null; FrameStore.onShot = null; FrameStore.onPermission = null
        // Release screen capture only if THIS panel started it in manual mode (a share started from the app's own dialog is left alone).
        if (FrameStore.mode == ScreenCaptureService.MODE_MANUAL && FrameStore.state != "stopped") try { ctx.stopService(Intent(ctx, ScreenCaptureService::class.java)) } catch (_: Throwable) { }
        req?.let { it.cancelled = true; it.ai.cancel() }; req = null
        confirm?.let { try { it.cb(false) } catch (_: Throwable) { } }; confirm = null
        worker?.shutdownNow(); worker = null
        try { speech?.destroy() } catch (_: Throwable) { }; speech = null
        try { tts?.destroy() } catch (_: Throwable) { }; tts = null
        atts.clear()
        val h = host; val w = web
        if (attached && h != null) try { wm.removeViewImmediate(h) } catch (_: Throwable) { }
        xv?.let { try { wm.removeViewImmediate(it) } catch (_: Throwable) { } }; xv = null; xl = null
        try { pencil?.hide() } catch (_: Throwable) { }; pencil = null; penOn = false; penN = 0
        attached = false
        try { w?.removeAllViews(); w?.destroy() } catch (_: Throwable) { }
        host = null; web = null; lp = null
        FloatStore.save()
        if (instance === this) instance = null
    }

    fun toggleFromNotification() { main.post { if (mode == "panel") closePanel() else openPanel() } }

    fun onConfigChanged(c: Configuration) {
        main.post { layout(true); ev("win", winJson()) }
    }

    // ================================================================ window management
    private inner class Host(c: Context) : FrameLayout(c) {
        override fun dispatchTouchEvent(e: MotionEvent): Boolean {
            if (e.actionMasked == MotionEvent.ACTION_UP) lastUp = SystemClock.uptimeMillis()
            return super.dispatchTouchEvent(e)
        }
        override fun dispatchKeyEvent(e: KeyEvent): Boolean {
            if (e.keyCode == KeyEvent.KEYCODE_BACK) { if (e.action == KeyEvent.ACTION_UP) ev("back", ""); return true }
            return super.dispatchKeyEvent(e)
        }
    }

    private fun dp(v: Int) = (v * ctx.resources.displayMetrics.density + 0.5f).toInt()
    private fun screen(): Point { val dm = DisplayMetrics(); @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(dm); return Point(dm.widthPixels, dm.heightPixels) }
    private fun statusBar(): Int { val id = ctx.resources.getIdentifier("status_bar_height", "dimen", "android"); return if (id > 0) ctx.resources.getDimensionPixelSize(id) else dp(24) }
    private fun toast(m: String) { main.post { try { Toast.makeText(ctx, m, Toast.LENGTH_SHORT).show() } catch (_: Throwable) { } } }
    private fun update() { val h = host ?: return; val l = lp ?: return; if (!attached) return; try { wm.updateViewLayout(h, l) } catch (_: Throwable) { } }
    private fun winJson() = JSONObject().put("mode", mode).put("max", maximized).put("min", minimized).put("typing", typing).toString()

    private fun layout(apply: Boolean) {
        val l = lp ?: return
        val s = screen(); val land = s.x > s.y; val m = dp(8)
        if (mode == "bubble") {
            val size = dp(56)
            l.width = size; l.height = size
            bx = bx.coerceIn(0, (s.x - size).coerceAtLeast(0)); by = by.coerceIn(0, (s.y - size).coerceAtLeast(0))
            l.x = bx; l.y = by
        } else if (maximized) {
            l.width = s.x; l.height = s.y - statusBar(); l.x = 0; l.y = statusBar()
            if (typing) l.height = minOf(l.height, (s.y * 0.55f).toInt())
        } else {
            val w = pw.coerceIn(minOf(dp(260), s.x - 2 * m), s.x - 2 * m)
            var h = if (minimized && minH > 0) minH else ph.coerceIn(minOf(dp(200), s.y - 2 * m), s.y - 2 * m)
            if (typing) h = minOf(h, (s.y * (if (land) 0.5f else 0.46f)).toInt())
            if (px == Int.MIN_VALUE) {   // first open: next to the bubble
                px = if (bx + dp(28) < s.x / 2) m else s.x - w - m
                py = if (by > s.y / 2) by - h - dp(10) else by + dp(56) + dp(10)
            }
            px = px.coerceIn(0, (s.x - w).coerceAtLeast(0)); py = py.coerceIn(0, (s.y - h).coerceAtLeast(0))
            l.width = w; l.height = h; l.x = px; l.y = if (typing) minOf(py, statusBar() + dp(4)) else py
        }
        if (apply) update()
    }

    private fun setFocusable(on: Boolean) {
        val l = lp ?: return
        l.flags = if (on) l.flags and LayoutParams.FLAG_NOT_FOCUSABLE.inv() else l.flags or LayoutParams.FLAG_NOT_FOCUSABLE
        update()
        if (on) web?.requestFocus()
    }

    /**
     * Hides the overlay while the window changes size/position and the page switches between bubble and panel. Without this the
     * window already has its new size while the page still shows the old layout, so a half-switched frame (a stray Zyn logo square
     * flying to the bubble when closing) was visible. The page calls shown() once the new layout is painted; a timer is the fallback.
     */
    private var cloakRun: Runnable? = null
    private fun cloak() {
        val h = host ?: return
        cloakRun?.let { main.removeCallbacks(it) }
        h.animate().cancel(); h.alpha = 0f
        val r = Runnable { uncloak() }; cloakRun = r; main.postDelayed(r, 350)
    }
    private fun uncloak() {
        cloakRun?.let { main.removeCallbacks(it) }; cloakRun = null
        val h = host ?: return
        try { h.animate().cancel(); h.animate().alpha(1f).setDuration(90).start() } catch (_: Throwable) { h.alpha = 1f }
    }

    /**
     * The bubble's disc (fill + thin white ring) is painted by the window itself and clipped to a circle, not by the WebView.
     * Why: while the window is resized / re-shown the WebView can paint one wrong frame (stale or half-switched layout). Before, that
     * frame was a flat grey-blue SQUARE with no sparkle at the bubble's position (seen in the screen recording, for seconds). Now whatever
     * the WebView paints is clipped to the circle, so the worst case is a plain round bubble. In panel mode there is no chrome and no clip.
     */
    private fun bubbleChrome(on: Boolean) {
        val h = host ?: return
        if (on) {
            h.background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setColor(Color.argb(148, 38, 58, 100))                                 // same colour as the old CSS rgba(38,58,100,.58)
                setStroke(maxOf(1, (1.5f * ctx.resources.displayMetrics.density).toInt()), Color.argb(107, 255, 255, 255))
            }
            h.outlineProvider = android.view.ViewOutlineProvider.BACKGROUND
            h.clipToOutline = true
        } else {
            h.clipToOutline = false
            h.background = null
        }
    }

    private fun openPanel() {
        if (mode == "panel") return
        cloak()
        mode = "panel"; bubbleChrome(false); minimized = false
        layout(false)   // compute the panel position first, so the page can grow the panel out of the bubble
        val d = ctx.resources.displayMetrics.density; val l = lp
        val ox = if (l != null) ((bx + dp(28) - l.x) / d).coerceIn(0f, l.width / d) else 0f
        val oy = if (l != null) ((by + dp(28) - l.y) / d).coerceIn(0f, l.height / d) else 0f
        ev("win", JSONObject(winJson()).put("enter", true).put("ox", ox.toDouble()).put("oy", oy.toDouble()).toString()); update()
    }

    /** Long-press text selection needs window focus; the overlay is focusable only while text is selected (typing keeps its own handling). */
    private fun setSelecting(on: Boolean) {
        if (selecting == on) return
        selecting = on
        if (!typing) setFocusable(on)
    }

    private fun closePanel() {
        if (mode == "bubble") return
        setSelecting(false)
        setTyping(false)
        cloak()
        mode = "bubble"; bubbleChrome(true); minimized = false; maximized = false
        ev("win", winJson()); layout(true)
    }

    private fun setTyping(on: Boolean) {
        if (typing == on) return
        typing = on
        if (!on) try { (ctx.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(host?.windowToken, 0) } catch (_: Throwable) { }
        setFocusable(on || selecting); layout(true)
        if (on) main.postDelayed({
            try { web?.requestFocus(); (ctx.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(web, InputMethodManager.SHOW_IMPLICIT) } catch (_: Throwable) { }
        }, 160)
    }

    private fun savePanel() { prefs.edit().putInt("pw", pw).putInt("ph", ph).putInt("px", px).putInt("py", py).apply() }

    // ---- drag the bubble to the X target to close it ----
    private var xv: FrameLayout? = null; private var xl: LayoutParams? = null
    private var overX = false; private var dragOx = -1; private var dragOy = -1

    private fun addTarget() {
        if (xv != null) return
        try {
            val sz = dp(72)
            val v = FrameLayout(ctx)
            v.background = android.graphics.drawable.GradientDrawable().apply { shape = android.graphics.drawable.GradientDrawable.OVAL; setColor(Color.argb(235, 28, 30, 34)) }
            val t = android.widget.TextView(ctx).apply { text = "\u2715"; setTextColor(Color.WHITE); textSize = 26f; gravity = Gravity.CENTER }
            v.addView(t, FrameLayout.LayoutParams(-1, -1))
            v.visibility = android.view.View.GONE
            val l = LayoutParams(sz, sz, LayoutParams.TYPE_APPLICATION_OVERLAY,
                LayoutParams.FLAG_NOT_TOUCHABLE or LayoutParams.FLAG_NOT_FOCUSABLE or LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT)
                .apply { gravity = Gravity.TOP or Gravity.START; title = "ZynFloatX" }
            wm.addView(v, l); xv = v; xl = l          // added BEFORE the bubble window, so the bubble is drawn on top of it
        } catch (_: Throwable) { xv = null; xl = null }
    }

    private fun xShow(on: Boolean) {
        val v = xv ?: return; val l = xl ?: return
        if (on) {
            val s = screen(); val sz = dp(72)
            l.x = (s.x - sz) / 2; l.y = s.y - sz - dp(56)
            try { wm.updateViewLayout(v, l) } catch (_: Throwable) { }
            v.scaleX = 1f; v.scaleY = 1f; v.visibility = android.view.View.VISIBLE
        } else { v.visibility = android.view.View.GONE; overX = false }
    }

    /** Called while the bubble is dragged: shows the X after a real move, and grows it when the bubble is over it. */
    private fun xUpdate() {
        if (mode != "bubble" || xv == null || !FloatStore.feat("dragclose")) return
        val v = xv ?: return; val l = xl ?: return
        if (v.visibility != android.view.View.VISIBLE) {
            if (dragOx < 0) { dragOx = bx; dragOy = by }
            if (Math.abs(bx - dragOx) + Math.abs(by - dragOy) > dp(12)) xShow(true)
            return
        }
        val size = dp(56)
        val d = Math.hypot((bx + size / 2 - (l.x + dp(36))).toDouble(), (by + size / 2 - (l.y + dp(36))).toDouble())
        val over = d < dp(64)
        if (over != overX) {
            overX = over
            v.animate().scaleX(if (over) 1.25f else 1f).scaleY(if (over) 1.25f else 1f).setDuration(120).start()
            if (over) try { v.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY) } catch (_: Throwable) { }
        }
    }

    private fun endBubbleDrag() {
        val close = overX
        xShow(false); dragOx = -1; dragOy = -1
        if (close) { toast("Floating assistant closed. Start it again from Zyn Ai."); svc.stopSelf() } else snapBubble()
    }

    private fun snapBubble() {
        val l = lp ?: return
        val s = screen(); val size = dp(56)
        val target = if (bx + size / 2 < s.x / 2) dp(4) else s.x - size - dp(4)
        by = by.coerceIn(0, (s.y - size).coerceAtLeast(0))
        ValueAnimator.ofInt(bx, target).apply {
            duration = 180
            addUpdateListener { a -> bx = a.animatedValue as Int; if (mode == "bubble") { l.x = bx; l.y = by; update() } }
            start()
        }
        prefs.edit().putInt("bx", target).putInt("by", by).apply()
    }

    private fun setHidden(h: Boolean) {
        if (h == hidden) return
        main.removeCallbacks(unhideRun)
        val v = host ?: return
        if (h) {
            setTyping(false); hidden = true
            if (attached) { try { wm.removeViewImmediate(v) } catch (_: Throwable) { }; attached = false }
            main.postDelayed(unhideRun, 45000)          // safety net: never leave the user without the bubble
        } else {
            hidden = false
            if (!attached) { try { layout(false); wm.addView(v, lp); attached = true } catch (_: Throwable) { } }
        }
        ev("busyShot", if (h) "1" else "0")
    }

    // ================================================================ JS plumbing
    private fun js(code: String) { main.post { try { web?.evaluateJavascript(code, null) } catch (_: Throwable) { } } }
    private fun ev(type: String, json: String) { js("window.ZPN&&ZPN(" + JSONObject.quote(type) + "," + JSONObject.quote(json) + ")") }
    private fun jo(vararg kv: Pair<String, Any?>): String { val o = JSONObject(); for ((k, v) in kv) o.put(k, v ?: JSONObject.NULL); return o.toString() }

    // ================================================================ chat (FloatAi)
    private fun emptyHint(): String {
        val p = FloatStore.ordered().firstOrNull()
        return when {
            !FloatStore.synced -> "Open the Zyn Ai app once so your AI providers and keys can sync, then come back."
            p == null -> "No AI provider is ready. Open Zyn Ai > Settings > AI providers and add an API key."
            else -> ""
        }
    }

    private fun srcArr(j: String): JSONArray = try { if (j.isBlank()) JSONArray() else JSONArray(j) } catch (_: Throwable) { JSONArray() }
    /** Web search hits -> compact, de-duplicated [{"t","u"}] list (http/https only, max 8) shown as the "N sources" chip. */
    private fun srcJson(h: List<FloatSearch.Hit>): String {
        val a = JSONArray(); val seen = HashSet<String>()
        for (x in h) { val u = x.url.trim(); if (!(u.startsWith("http://") || u.startsWith("https://")) || !seen.add(u)) continue; a.put(JSONObject().put("t", x.title.trim().take(120)).put("u", u)); if (a.length() >= 8) break }
        return if (a.length() == 0) "" else a.toString()
    }

    private fun chatJson(): String {
        val a = JSONArray()
        for (m in FloatStore.snapshot(FloatStore.current())) a.put(JSONObject().put("r", if (m.role == "user") "u" else "a").put("x", m.text).put("v", m.via).put("ts", m.ts).put("src", srcArr(m.srcs)))
        return a.toString()
    }

    private fun chatListJson(): String {
        val a = JSONArray(); val cur = FloatStore.current().id
        for (c in FloatStore.list()) a.put(JSONObject().put("id", c.id).put("t", FloatStore.titleOf(c)).put("u", c.updated).put("pin", c.pinned).put("cur", c.id == cur))
        return a.toString()
    }

    private fun providersJson(): String {
        val a = JSONArray(); val cur = FloatStore.ordered().firstOrNull()
        for (p in FloatStore.providers) a.put(JSONObject().put("id", p.id).put("label", p.label).put("tag", FloatVision.tag(p)).put("sel", p === cur))
        return JSONObject().put("list", a).put("synced", FloatStore.synced).put("hint", emptyHint()).toString()
    }

    private fun systemPrompt(withImage: Boolean): String {
        val date = SimpleDateFormat("EEEE, d MMMM yyyy, HH:mm", Locale.ENGLISH).format(Date())
        return listOf(FloatStore.composeSystem(liveVoice), "Current date and time: $date.",
            if (liveVoice) "Voice conversation: the user is TALKING to you and your reply is read aloud. Answer like a person on a phone call: 1 to 3 short, natural sentences in plain words. No markdown, no lists, no emoji, no links, no code. Put the answer first, then stop. Ask at most one short question back, only when it really helps." else "",
            "Language rule: reply in the language and script of the user's latest message (for example English, Tamil, Sinhala, or Tamil typed in English letters).",
            "You are answering inside a small floating chat panel on a phone, so keep replies focused and concise unless the user asks for detail.",
            if (withImage) "The user attached image(s) (possibly a screenshot of their own Android screen) to their latest message. Describe and answer only from what is actually visible; if something is cut off, blank or unreadable, say so instead of guessing. Do not repeat sensitive details such as passwords, card numbers or one-time codes." else "")
            .filter { it.isNotBlank() }.joinToString("\n\n")
    }

    private fun buildTurns(c: FConv): List<Turn> {
        val out = ArrayList<Turn>(); var budget = 24000
        for (m in FloatStore.snapshot(c).asReversed()) {
            if (budget <= 0 || out.size >= 24) break
            budget -= m.text.length
            val role = if (m.role == "user") "user" else "assistant"
            if (out.isNotEmpty() && out.last().role == role) { val last = out.removeAt(out.size - 1); out.add(Turn(role, m.text + "\n\n" + last.text)) }
            else out.add(Turn(role, m.text))
        }
        out.reverse()
        while (out.isNotEmpty() && out.first().role != "user") out.removeAt(0)
        return out
    }

    private fun decorate(t: List<Turn>, extra: String, imgs: List<String>): List<Turn> {
        if (t.isEmpty() || t.last().role != "user" || (extra.isEmpty() && imgs.isEmpty())) return t
        return t.dropLast(1) + Turn("user", t.last().text + extra, imgs)
    }

    /** Called on a bridge thread. Returns JSON {ok, err, pick}. Nothing is consumed on failure, so the page keeps the text and attachments. */
    private fun sendChat(text0: String, ids: List<String>): String {
        val t = text0.trim()
        if (busy || capturingNow || markPending) return jo("ok" to false, "err" to "Wait for the current reply to finish.")
        val list = ids.mapNotNull { atts[it] }
        if (t.isEmpty() && list.isEmpty()) return jo("ok" to false, "err" to "")
        val prov = FloatStore.ordered()
        if (prov.isEmpty()) return jo("ok" to false, "err" to emptyHint().ifEmpty { "No AI provider is ready." })
        val images = list.filter { it.kind == "image" }
        if (images.isNotEmpty() && FloatVision.support(prov.first()) == FloatVision.S.NO)
            return jo("ok" to false, "pick" to true, "err" to "\"${prov.first().model}\" is a text-only model, so it can't read images. Choose a model marked [image]. Your text and attachments are kept.")
        ids.forEach { atts.remove(it) }
        val extra = StringBuilder()
        for (a in list) if (a.kind == "text") extra.append("\n\n--- Attached file: ").append(a.name).append(" ---\n").append(String(a.bytes, Charsets.UTF_8).take(20000))
        val label = StringBuilder()
        if (images.isNotEmpty()) label.append("[Image attached] ")
        list.filter { it.kind == "text" }.forEach { label.append("[File: ").append(it.name).append("] ") }
        val shown = if (t.isEmpty()) "Explain what is on my screen: the app or website, the visible text and buttons, any errors or warnings, and what I should do next." else t
        val c = FloatStore.current()
        FloatStore.addMsg(c, FMsg("user", label.toString() + (if (t.isEmpty() && images.isNotEmpty()) shown else t), System.currentTimeMillis()))
        val b64 = images.map { Base64.encodeToString(it.bytes, Base64.NO_WRAP) }
        main.post { startRequest(c, b64, extra.toString()) }
        return jo("ok" to true)
    }

    private fun startRequest(c: FConv, imgs: List<String>, extra: String) {
        val rq = Req(); rq.image = imgs.isNotEmpty(); req = rq; streamMsg = null; retryImgs = imgs; retryExtra = extra
        val providers = if (imgs.isNotEmpty() || !FloatStore.feat("fallback")) FloatStore.ordered().take(1) else FloatStore.ordered()   // images go ONLY to the selected provider
        val sys = systemPrompt(imgs.isNotEmpty()); var turns = decorate(buildTurns(c), extra, imgs)
        val askText = FloatStore.snapshot(c).lastOrNull { it.role == "user" }?.text ?: ""
        ev("busy", "1")
        val ex = worker ?: return
        ex.execute {
            val errors = ArrayList<String>(); var used: FProvider? = null; var fellBack = false; var srcs = ""
            if (imgs.isEmpty() && FloatSearch.wanted(askText)) {
                try { val h = FloatSearch.search(askText); if (h.isNotEmpty()) { turns = decorate(turns, "\n\n" + FloatSearch.block(h), imgs); srcs = srcJson(h) } } catch (_: Throwable) { }
            }
            val sb = StringBuilder(); var lastPost = 0L; var lastErr: Throwable? = null
            for ((idx, p) in providers.withIndex()) {
                if (rq.cancelled) break
                rq.ai = FloatAi().also { if (rq.cancelled) it.cancel() }
                val via = p.label + if (idx > 0) " (fallback)" else ""
                try {
                    rq.ai.stream(p, sys, turns) { d ->
                        sb.append(d)
                        val now = System.currentTimeMillis()
                        if (now - lastPost >= 100 && (FloatStore.feat("stream") || liveVoice)) { lastPost = now; val s = sb.toString(); main.post { onText(rq, s, via) } }
                    }
                    used = p; fellBack = idx > 0; lastErr = null; break
                } catch (e: Throwable) {
                    if (rq.cancelled) break
                    lastErr = e; errors.add(p.name.ifBlank { p.type } + ": " + FloatAi.friendly(e))
                    if (sb.isNotEmpty()) break          // never switch provider in the middle of an answer
                }
            }
            val text = sb.toString(); val via = used?.let { it.label + if (fellBack) " (fallback)" else "" } ?: providers.firstOrNull()?.label ?: ""
            main.post { onDone(rq, text, via, used != null, errors, lastErr, srcs) }
        }
    }

    private fun onText(rq: Req, text: String, via: String) {
        if (rq !== req) return
        var m = streamMsg
        if (m == null) { m = FMsg("assistant", text, System.currentTimeMillis(), via); streamMsg = m; FloatStore.addMsg(FloatStore.current(), m) }
        else FloatStore.setText(m, text, via)
        ev("delta", jo("x" to text, "v" to via))
    }

    private fun onDone(rq: Req, text: String, via: String, ok: Boolean, errors: List<String>, err: Throwable?, srcs: String = "") {
        if (rq !== req) return
        req = null
        val c = FloatStore.current(); var m = streamMsg; streamMsg = null
        if (text.isNotEmpty()) {
            if (m == null) { m = FMsg("assistant", text, System.currentTimeMillis(), via); FloatStore.addMsg(c, m) }
            FloatStore.setText(m, text, if (ok) via else "$via · interrupted")
            if (srcs.isNotEmpty() && ok) m.srcs = srcs
        }
        var error = ""; var pick = false
        if (!ok && !rq.cancelled && err != null) {
            error = if (errors.size > 1) errors.joinToString("\n") { "• $it" } else FloatAi.friendly(err)
            if (rq.image && err is FloatAi.ApiError && err.status in intArrayOf(400, 404, 415, 422)) {
                error = "This model did not accept the image, so it may not support image input. Choose a model marked [image], then tap Retry.\n" + FloatAi.friendly(err)
                pick = true
            }
        }
        worker?.execute { FloatStore.save() }
        ev("done", jo("x" to text, "v" to via, "ok" to ok, "stopped" to rq.cancelled, "err" to error, "pick" to pick, "src" to (if (ok) srcArr(srcs) else JSONArray())))
    }

    private fun stopChat() {
        val rq = req ?: run { if (markPending) markFail(""); return }      // Stop while a marked screenshot is still being prepared
        rq.cancelled = true; rq.ai.cancel()
        onDone(rq, streamMsg?.text ?: "", streamMsg?.via ?: "", false, emptyList(), null)
    }

    private fun regenerate(): String {
        if (busy) return jo("ok" to false)
        val c = FloatStore.current()
        val msgs = FloatStore.snapshot(c)
        if (msgs.isNotEmpty() && msgs.last().role == "assistant") FloatStore.removeMsg(c, msgs.last())
        if (FloatStore.snapshot(c).lastOrNull()?.role != "user") return jo("ok" to false)
        if (FloatStore.ordered().isEmpty()) return jo("ok" to false, "err" to emptyHint())
        startRequest(c, retryImgs, retryExtra)
        return jo("ok" to true)
    }

    // ================================================================ attachments (picked through FloatPickActivity)
    fun onPicked(name: String, mime: String, bytes: ByteArray) {
        val w = worker ?: return
        w.execute {
            try {
                if (bytes.size > 25 * 1024 * 1024) { toast("$name is over 25 MB"); return@execute }
                val id = "a" + System.nanoTime().toString(36)
                if (mime.startsWith("image/")) {
                    val jpeg = downscale(bytes, 1280, 82) ?: run { toast("Could not read $name"); return@execute }
                    val thumb = downscale(bytes, 120, 60)
                    atts[id] = Att(id, "image", name, jpeg)
                    ev("att", jo("id" to id, "kind" to "image", "name" to name, "thumb" to (if (thumb != null) "data:image/jpeg;base64," + Base64.encodeToString(thumb, Base64.NO_WRAP) else "")))
                } else if (mime.startsWith("text/") || mime == "application/json" || mime == "application/xml" || name.matches(Regex("(?i).*\\.(txt|md|csv|json|xml|log|kt|java|js|ts|py|html|css|yml|yaml|ini|sql|sh)$"))) {
                    atts[id] = Att(id, "text", name, bytes)
                    ev("att", jo("id" to id, "kind" to "file", "name" to name, "thumb" to ""))
                } else toast("The AI can read images and text files. \"$name\" was not added.")
            } catch (_: Throwable) { toast("Could not add $name") }
        }
    }

    private fun downscale(b: ByteArray, maxSide: Int, q: Int): ByteArray? {
        return try {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(b, 0, b.size, o)
            if (o.outWidth <= 0) return null
            var ss = 1; while (maxOf(o.outWidth, o.outHeight) / (ss * 2) >= maxSide) ss *= 2
            val bm = BitmapFactory.decodeByteArray(b, 0, b.size, BitmapFactory.Options().apply { inSampleSize = ss }) ?: return null
            val k = minOf(1f, maxSide.toFloat() / maxOf(bm.width, bm.height))
            val sc = if (k < 1f) Bitmap.createScaledBitmap(bm, (bm.width * k).toInt().coerceAtLeast(1), (bm.height * k).toInt().coerceAtLeast(1), true) else bm
            val out = ByteArrayOutputStream(); sc.compress(Bitmap.CompressFormat.JPEG, q, out)
            if (sc !== bm) bm.recycle(); sc.recycle()
            out.toByteArray()
        } catch (_: Throwable) { null }
    }

    private fun pick(kind: String) {
        main.post {
            setHidden(false)
            try { ctx.startActivity(Intent(ctx, FloatPickActivity::class.java).putExtra("kind", kind).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            catch (_: Throwable) { toast("Could not open the picker") }
        }
    }

    // ================================================================ screen capture + vision (existing ScreenCaptureService / FrameStore)
    private fun capActive() = FrameStore.state != "stopped"

    private fun requestPermission(live: Boolean) {
        setHidden(true)       // keep our overlay off Android's consent dialog
        try {
            ctx.startActivity(Intent(ctx, CaptureRequestActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                .putExtra("mode", if (live) ScreenCaptureService.MODE_CONTINUOUS else ScreenCaptureService.MODE_MANUAL).putExtra("interval", 1000).putExtra("quality", 65).putExtra("keep", 3))
        } catch (_: Throwable) { action = null; setHidden(false); toast("Could not open Android's screen capture permission dialog.") }
    }

    private fun shareStart() {
        if (capActive()) { toast("Screen sharing is already on."); return }
        action = "share"; requestPermission(true)
    }

    private fun capture(ask: Boolean) {
        if (capturingNow) return
        action = if (ask) "ask" else "capture"
        if (!capActive()) requestPermission(false)
        else if (FrameStore.state == "paused") { action = null; toast("Screen capture is paused. Tap Resume first.") }
        else takeShot()
    }

    private fun onPermission(ok: Boolean) {
        if (ok) return           // ScreenCaptureService is starting; onCaptureState() continues when it is running
        if (action == "mark") { markFail("Screen capture permission was declined. Nothing was captured."); return }
        action = null; setHidden(false); toast("Screen capture permission was declined. Nothing was captured.")
    }

    private fun onCaptureState() {
        if (FrameStore.state == "stopped") {
            if (action == "mark") markFail("Screen capture stopped.")
            action = null; capturingNow = false; lastPrevRef = null
            if (hidden) setHidden(false)
            ev("preview", jo("src" to ""))
            pushStatus(true); return
        }
        if (FrameStore.state == "running" && action != null && !capturingNow) {
            if (action == "share") { action = null; setHidden(false); toast("Screen sharing started"); if (mode == "bubble") openPanel() }
            else if (action == "pencil") { action = null; setHidden(false); activatePencil() }
            else takeShot()
        }
        pushStatus(true)
    }

    /** Hide our own overlay first (so the panel is not in the screenshot), then ask the capture service for ONE frame. */
    private fun takeShot() {
        if (action == null) return
        capturingNow = true
        setHidden(true)
        main.postDelayed({
            if (!capturingNow) return@postDelayed
            try { ctx.startService(Intent(ctx, ScreenCaptureService::class.java).setAction(ScreenCaptureService.CAPTURE).putExtra(ScreenCaptureService.QUALITY, 70)) }
            catch (_: Throwable) { onShot(Shot(null, 0, 0, false, "Could not reach the screen capture service.")) }
        }, 320)
    }

    private fun onShot(sh: Shot) {
        if (!capturingNow) return
        val act = action; val wasAsk = act == "ask"; action = null; capturingNow = false
        setHidden(false)
        if (act == "mark") { onMarkShot(sh); return }
        val jpeg = sh.jpeg
        if (jpeg == null) { toast(sh.error ?: "Screenshot failed."); return }
        val id = "a" + System.nanoTime().toString(36)
        atts[id] = Att(id, "image", "Screen capture", jpeg)
        val th = downscale(jpeg, 120, 60)
        if (mode == "bubble") openPanel()
        ev("att", jo("id" to id, "kind" to "image", "name" to "Screen capture", "blank" to sh.blank, "ask" to wasAsk,
            "thumb" to (if (th != null) "data:image/jpeg;base64," + Base64.encodeToString(th, Base64.NO_WRAP) else "")))
    }

    private fun shareCmd(a: String) {
        if (!capActive()) return
        try { ctx.startService(Intent(ctx, ScreenCaptureService::class.java).setAction(a)) } catch (_: Throwable) { toast("Could not reach the screen capture service.") }
    }

    private fun shareStop() {
        action = null; capturingNow = false
        if (capActive()) try { ctx.stopService(Intent(ctx, ScreenCaptureService::class.java)) } catch (_: Throwable) { }
        FrameStore.state = "stopped"; FrameStore.clear()
        pushStatus(true)
    }

    private fun setPrivacy(on: Boolean) {
        FrameStore.privacy = on
        if (on) { shareCmd(ScreenCaptureService.PAUSE); FrameStore.clear(); HighlightOverlay.hide(); lastPrevRef = null; ev("preview", jo("src" to "")) }
        pushStatus(true)
    }

    /** On-device OCR of the newest frame (or, in manual mode, the last capture). Never sends anything to the network. */
    private fun runOcr() {
        val w = worker ?: return
        w.execute {
            val f = FrameStore.latest(1).lastOrNull()
            if (f == null) { ev("ocr", jo("ok" to false, "err" to "No frame yet. Start Live Screen Share, switch to another app for a moment, then come back.")); return@execute }
            try {
                ScreenOcr.changedSinceRead = false
                val r = JSONObject(ScreenOcr.analyze(f, "auto", true))
                lastOcr = r
                ev("ocr", jo("ok" to r.optBoolean("ok"), "text" to r.optString("text"), "err" to r.optString("error")))
            } catch (e: Throwable) { ev("ocr", jo("ok" to false, "err" to (e.message ?: "OCR failed"))) }
        }
    }

    private fun highlightOcr() {
        val r = lastOcr
        if (r == null || !r.optBoolean("ok")) { toast("Run Screen OCR first."); return }
        val regions = JSONArray()
        val bl = r.optJSONArray("blocks")
        if (bl != null) for (i in 0 until bl.length()) {
            val ls = bl.getJSONObject(i).optJSONArray("lines") ?: continue
            for (j in 0 until ls.length()) {
                val o = ls.getJSONObject(j); if (o.optBoolean("red")) continue
                val b = o.optJSONArray("box") ?: continue
                regions.put(JSONArray().put(b.optInt(0)).put(b.optInt(1)).put(b.optInt(2)).put(b.optInt(3)))
            }
        }
        val fw = r.optInt("w"); val fh = r.optInt("h")
        main.post { try { HighlightOverlay.show(ctx, regions.toString(), fw, fh) } catch (e: Exception) { toast("Highlight failed: " + (e.message ?: "")) } }
    }

    private fun pushPreview() {
        if (!previewOn || previewBusy || FrameStore.state != "running" || FrameStore.privacy) return
        val f = FrameStore.latest(1).lastOrNull() ?: return
        if (f === lastPrevRef) return
        previewBusy = true; lastPrevRef = f
        val w = worker ?: run { previewBusy = false; return }
        w.execute {
            try {
                val bytes = Base64.decode(f, Base64.NO_WRAP)
                val th = downscale(bytes, 360, 55)
                if (th != null) ev("preview", jo("src" to "data:image/jpeg;base64," + Base64.encodeToString(th, Base64.NO_WRAP)))
            } catch (_: Throwable) { } finally { previewBusy = false }
        }
    }

    // ================================================================ pencil: draw on the screen, then ask about the marked area
    private fun pencilJson(open: Boolean = false) = jo("on" to penOn, "n" to penN, "tool" to (pencil?.tool ?: ScreenPencil.PEN), "open" to open)
    private fun pushPencil(open: Boolean = false) { ev("pencil", pencilJson(open)) }

    /** Long-press on "Ask screen". One screenshot is needed per question, so screen capture must be running (Android asks consent once). */
    private fun pencilStart() {
        if (penOn) { pushPencil(true); return }
        if (!capActive()) { action = "pencil"; requestPermission(false) } else activatePencil()
    }

    private fun activatePencil() {
        if (penOn) return
        val p = ScreenPencil(ctx, wm)
        try { p.show() } catch (e: Exception) { toast("Android refused the drawing layer (permission?)"); return }
        p.onChange = { penN = p.count; pushPencil() }
        pencil = p; penOn = true; penN = 0
        raiseHost()                 // the panel must stay ABOVE the drawing layer, otherwise its buttons could not be tapped
        pushPencil(true)
    }

    private fun pencilStop() {
        val p = pencil; pencil = null; penOn = false; penN = 0
        try { p?.hide() } catch (_: Throwable) { }
        pushPencil()
    }

    /** A window added later is drawn above older ones, so the panel window is re-added on top of the drawing layer. */
    private fun raiseHost() {
        val h = host ?: return
        if (!attached || hidden) return
        try { wm.removeViewImmediate(h) } catch (_: Throwable) { }
        try { wm.addView(h, lp); attached = true } catch (_: Throwable) { attached = false }
    }

    /** Called on a bridge thread when the user sends a question in Ask screen mode. used=false: nothing is marked, so the page asks the normal way. */
    private fun markedAsk(text0: String): String {
        if (!penOn || penN <= 0) return jo("ok" to true, "used" to false)
        if (busy || capturingNow || markPending) return jo("ok" to false, "err" to "Wait for the current reply to finish.")
        if (FloatStore.ordered().isEmpty()) return jo("ok" to false, "err" to emptyHint().ifEmpty { "No AI provider is ready." })
        markPending = true
        val t = text0.trim().ifEmpty { "What is this? Explain the marked part." }
        main.post { startMarkedCapture(t) }
        return jo("ok" to true, "used" to true)
    }

    private fun startMarkedCapture(t: String) {
        val p = pencil
        if (p == null || p.count == 0) { markFail("Mark something on the screen first."); return }
        markText = t; action = "mark"
        main.removeCallbacks(markGuard); main.postDelayed(markGuard, 25000)
        p.cloak(true)               // the strokes are drawn on afterwards, on top of a CLEAN screenshot
        if (!capActive()) requestPermission(false)
        else if (FrameStore.state == "paused") markFail("Screen capture is paused. Tap Resume first.")
        else takeShot()
    }

    /** Any failure before the request starts: undo the "busy" state the page already shows, and bring the drawing layer back. */
    private fun markFail(msg: String) {
        main.removeCallbacks(markGuard)
        markPending = false; capturingNow = false
        if (action == "mark") action = null
        pencil?.cloak(false)
        if (hidden) setHidden(false)
        if (msg.isNotBlank()) toast(msg)
        ev("done", jo("x" to "", "v" to "", "ok" to false, "stopped" to true, "err" to "", "pick" to false, "src" to JSONArray()))
    }

    private fun onMarkShot(sh: Shot) {
        pencil?.cloak(false)
        if (!markPending) return                      // cancelled (Stop) or timed out meanwhile
        val jpeg = sh.jpeg
        if (jpeg == null) { markFail(sh.error ?: "Screenshot failed."); return }
        if (sh.blank) { markFail("The screen looks black: this app blocks screenshots."); return }
        val marks = pencil?.snapshot()
        if (marks == null) { markFail("Nothing is marked."); return }
        val w = worker ?: run { markFail(""); return }
        val q = markText
        w.execute { try { sendMarked(jpeg, marks, q) } catch (e: Throwable) { main.post { markFail("Could not read the marked area.") } } }
    }

    /**
     * Worker thread. Builds what the AI needs to FOCUS on the marked area:
     *   image 1 = full screenshot with the user's strokes painted on it (where),
     *   image 2 = clean close-up of the marked area (readable small text),
     *   text    = where the marking is + on-device OCR of the lines under it (also lets text-only models answer).
     */
    private fun sendMarked(jpeg: ByteArray, m: ScreenPencil.Marks, question: String) {
        val src = BitmapFactory.decodeByteArray(jpeg, 0, jpeg.size) ?: throw IllegalStateException("decode")
        val real = screen()
        val sx = src.width.toFloat() / real.x.coerceAtLeast(1); val sy = src.height.toFloat() / real.y.coerceAtLeast(1)
        val vb = ScreenPencil.bounds(m.strokes) ?: throw IllegalStateException("empty")
        val box = RectF((vb.left + m.offX) * sx, (vb.top + m.offY) * sy, (vb.right + m.offX) * sx, (vb.bottom + m.offY) * sy)
        if (!box.intersect(0f, 0f, src.width.toFloat(), src.height.toFloat())) throw IllegalStateException("off screen")

        // 1) annotated full screenshot
        val ann = src.copy(Bitmap.Config.ARGB_8888, true)
        val cv = Canvas(ann); cv.scale(sx, sy); cv.translate(m.offX.toFloat(), m.offY.toFloat()); ScreenPencil.render(cv, m.strokes)
        val annOut = ByteArrayOutputStream(); ann.compress(Bitmap.CompressFormat.JPEG, 82, annOut); ann.recycle()

        // 2) clean close-up (skipped when the marking already covers most of the screen)
        val minSide = minOf(src.width, src.height).toFloat()
        val pad = maxOf(0.12f * maxOf(box.width(), box.height()), 0.04f * minSide)
        val hw = maxOf(box.width() / 2f + pad, minSide * 0.22f); val hh = maxOf(box.height() / 2f + pad, minSide * 0.16f)
        val crop = Rect(Math.floor((box.centerX() - hw).toDouble()).toInt(), Math.floor((box.centerY() - hh).toDouble()).toInt(),
            Math.ceil((box.centerX() + hw).toDouble()).toInt(), Math.ceil((box.centerY() + hh).toDouble()).toInt())
        crop.intersect(0, 0, src.width, src.height)
        var cropJpg: ByteArray? = null
        if (crop.width() > 8 && crop.height() > 8 && crop.width().toLong() * crop.height() < 0.62 * src.width * src.height) {
            var cb = Bitmap.createBitmap(src, crop.left, crop.top, crop.width(), crop.height())
            val longSide = maxOf(cb.width, cb.height); val k = if (longSide < 900) minOf(2.5f, 900f / longSide) else 1f
            if (k > 1.05f) { val sc = Bitmap.createScaledBitmap(cb, (cb.width * k).toInt(), (cb.height * k).toInt(), true); cb.recycle(); cb = sc }
            val o = ByteArrayOutputStream(); cb.compress(Bitmap.CompressFormat.JPEG, 86, o); cb.recycle(); cropJpg = o.toByteArray()
        }

        // 3) text under the marking (on-device OCR, sensitive lines are hidden by ScreenOcr)
        val ocrText = markedText(jpeg, box)
        val prov = FloatStore.ordered().firstOrNull()
        val vision = prov != null && FloatVision.support(prov) != FloatVision.S.NO
        if (!vision && ocrText.isBlank()) {
            src.recycle()
            main.post { markFail("\"${prov?.model ?: "This model"}\" can't read images, and no text was found under your marking. Choose a model marked [image], or mark some text.") }
            return
        }
        fun pc(v: Float, tot: Int) = Math.round(v * 100f / tot).coerceIn(0, 100)
        val where = "from ${pc(box.left, src.width)}% to ${pc(box.right, src.width)}% across and ${pc(box.top, src.height)}% to ${pc(box.bottom, src.height)}% down the screen"
        src.recycle()
        val sb = StringBuilder("\n\n[Marked screen]\nThe user drew on their own phone screen to point at something. Their question is about THAT marked area.\n")
        if (vision) {
            sb.append("Image 1: the full screenshot with the user's marking painted on it (coloured pen, box or highlighter).\n")
            if (cropJpg != null) sb.append("Image 2: a clean close-up of the marked area without the marking, for reading small text.\n")
        } else sb.append("You cannot see images, so none is attached. Work only from the text read from the marked area below.\n")
        sb.append("The marking covers about ").append(where).append(".\n")
        sb.append("Rules: answer about what is inside, under or touched by the marking. Use the rest of the screen only as context. Do not describe or summarise the whole screen. If the marked content is unreadable or the marking is unclear, say so and ask the user to mark it again.\n")
        if (ocrText.isNotBlank()) sb.append("Text read on-device from the marked area (may contain mistakes):\n\"\"\"\n").append(ocrText).append("\n\"\"\"\n")
        val extra = sb.toString()
        val imgs = if (vision) listOfNotNull(annOut.toByteArray(), cropJpg).map { Base64.encodeToString(it, Base64.NO_WRAP) } else emptyList()
        main.post {
            if (!markPending) return@post             // cancelled meanwhile: send nothing
            main.removeCallbacks(markGuard); markPending = false
            val c = FloatStore.current()
            FloatStore.addMsg(c, FMsg("user", "[Ask · marked area] $question", System.currentTimeMillis()))
            startRequest(c, imgs, extra)
        }
    }

    /** OCR lines of the clean screenshot that touch the marked rectangle (frame pixels). Empty string when nothing is found or OCR fails. */
    private fun markedText(jpeg: ByteArray, box: RectF): String = try {
        val r = JSONObject(ScreenOcr.analyze(Base64.encodeToString(jpeg, Base64.NO_WRAP), "auto", true))
        if (!r.optBoolean("ok")) "" else {
            val probe = RectF(box); probe.inset(-12f, -12f)
            val sb = StringBuilder()
            val bl = r.optJSONArray("blocks")
            if (bl != null) for (i in 0 until bl.length()) {
                val ls = bl.getJSONObject(i).optJSONArray("lines") ?: continue
                for (j in 0 until ls.length()) {
                    val o = ls.getJSONObject(j); if (o.optBoolean("red")) continue
                    val b = o.optJSONArray("box") ?: continue
                    val lr = RectF(b.optInt(0).toFloat(), b.optInt(1).toFloat(), b.optInt(2).toFloat(), b.optInt(3).toFloat())
                    if (RectF.intersects(lr, probe)) { if (sb.isNotEmpty()) sb.append('\n'); sb.append(o.optString("t")) }
                }
            }
            sb.toString().take(1500)
        }
    } catch (_: Throwable) { "" }

    // ================================================================ agent (AgentRunner / AgentController)
    private fun startAgent(task: String, explain: Boolean): String {
        val t = task.trim()
        if (!explain) main.post { if (penOn) pencilStop() }          // the drawing layer would swallow the agent's taps
        val e = AgentRunner.start(ctx, t, explain)
        if (e != null) return e
        FloatStore.addMsg(FloatStore.current(), FMsg("user", (if (explain) "[Ask] " else "[Agent task] ") + t, System.currentTimeMillis()))
        worker?.execute { FloatStore.save() }
        pushStatus(true)
        return ""
    }

    private fun onAgentEvent(t: String, d: String) {
        if (t == "result") {
            try {
                val o = JSONObject(d)
                val txt = o.optString("text")
                if (txt.isNotBlank()) {
                    FloatStore.addMsg(FloatStore.current(), FMsg("assistant", txt, System.currentTimeMillis(), "Agent"))
                    worker?.execute { FloatStore.save() }
                    ev("agentResult", jo("x" to txt, "ok" to o.optBoolean("ok")))
                }
            } catch (_: Throwable) { }
        }
        pushStatus(true)
    }

    fun showConfirm(title: String, lines: List<String>, cb: (Boolean) -> Unit) {
        main.post {
            val old = confirm; confirm = Confirm(title, lines, cb)
            if (old != null) try { old.cb(false) } catch (_: Throwable) { }
            if (hidden) setHidden(false)
            if (mode == "bubble") openPanel()
            minimized = false; layout(true)
            ev("confirm", jo("title" to title, "lines" to JSONArray(lines)))
        }
    }

    fun hideConfirm() {
        main.post {
            val p = confirm; confirm = null
            ev("confirmHide", "")
            if (p != null) try { p.cb(false) } catch (_: Throwable) { }
        }
    }

    private fun answerConfirm(ok: Boolean) {
        main.post {
            val p = confirm ?: return@post
            // Only a real finger tap on the panel can approve: the last touch must have ended a moment ago.
            if (ok && SystemClock.uptimeMillis() - lastUp > 2500) { toast("Tap Confirm with your finger."); return@post }
            confirm = null; ev("confirmHide", "")
            try { p.cb(ok) } catch (_: Throwable) { }
        }
    }

    fun pushStatus(force: Boolean) {
        if (web == null) return
        val s = statusJson()
        if (force || s != lastStatus) { lastStatus = s; ev("status", s) }
    }

    private fun statusJson(): String = try {
        val o = JSONObject(AgentController.status(ctx))
        o.put("paused", AgentController.paused).put("busy", busy).put("capBusy", capturingNow).put("shareMode", FrameStore.mode)
        o.put("privacy", FrameStore.privacy).put("auto", FrameStore.autoOcr).put("changed", ScreenOcr.changedSinceRead).put("protected", FrameStore.protectedHits)
        o.put("mic", ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
        o.put("confirm", confirm != null)
        val hist = JSONArray(AgentHistory.toJson()); val slim = JSONArray()
        for (i in 0 until minOf(hist.length(), 8)) {
            val h = hist.getJSONObject(i)
            slim.put(JSONObject().put("task", h.optString("task")).put("status", h.optString("status")).put("start", h.optLong("start")).put("result", h.optString("result"))
                .put("actions", h.optJSONArray("actions") ?: JSONArray()).put("errors", h.optJSONArray("errors") ?: JSONArray()))
        }
        o.put("history", slim)
        o.toString()
    } catch (e: Throwable) { "{}" }

    private fun onTick() {
        if (web == null) return
        val agentOn = AgentController.state != "idle"
        if (mode == "bubble" && !agentOn && !capActive() && confirm == null) return   // nothing visible to update: no work while only the bubble shows
        if (hidden) return
        pushStatus(false); if (mode == "panel") pushPreview()
    }

    // ================================================================ voice (NativeSpeech / NativeTts)
    private fun nt(): NativeTts = tts ?: NativeTts(ctx) { t, d -> ev("tts", jo("t" to t, "d" to d)) }.also { tts = it }
    private fun ns(): NativeSpeech = speech ?: NativeSpeech(ctx) { t, d -> ev("stt", jo("t" to t, "d" to d)) }.also { speech = it }
    fun speak(t: String) { main.post { try { nt().speak(t, AgentController.lang, 1f, 1f) } catch (_: Throwable) { } } }

    @Volatile private var liveVoice = false     // voice conversation is on: short spoken-style answers, spoken while they are still being written

    private fun micStart(fast: Boolean = false) {
        main.post {
            if (ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                toast("Allow Microphone for Zyn Ai in Android app settings."); openAppSettings(); return@post
            }
            try { if (!ns().available()) { toast("Speech recognition is not available on this device."); return@post }; ns().start(AgentController.lang, fast) } catch (e: Throwable) { toast("Voice input failed.") }
        }
    }

    private fun openAppSettings() {
        try { ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Throwable) { }
    }

    private fun copy(t: String) {
        main.post { try { (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("Zyn Ai", t)) } catch (_: Throwable) { toast("Could not copy") } }
    }

    // ================================================================ boot state
    private fun bootJson(): String {
        val night = (ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        val theme = when (FloatStore.theme) { "light" -> "light"; "dark" -> "dark"; else -> if (night) "dark" else "light" }
        val acc = FloatStore.colors["acc"]?.let { String.format("#%06X", it and 0xFFFFFF) } ?: ""
        return JSONObject().put("theme", theme).put("acc", acc).put("chat", JSONArray(chatJson())).put("providers", JSONObject(providersJson()))
            .put("busy", busy).put("status", JSONObject(statusJson())).put("win", JSONObject(winJson())).put("density", ctx.resources.displayMetrics.density.toDouble()).put("pencil", JSONObject(pencilJson()))
            .put("blur", Build.VERSION.SDK_INT >= 31).toString()
    }

    // ================================================================ the bridge (page -> native)
    private inner class Bridge {
        // ---- boot / state
        private fun off(k: String, what: String): String? = if (FloatStore.feat(k)) null else "$what is turned off. Turn it on in the panel menu > Panel features."
        @JavascriptInterface fun boot(): String = bootJson()
        @JavascriptInterface fun feat(): String = FloatStore.fpx.toString()
        @JavascriptInterface fun setFeat(k: String, v: Boolean) { FloatStore.setFeat(k, v) }
        @JavascriptInterface fun status(): String = statusJson()
        @JavascriptInterface fun providers(): String = providersJson()
        @JavascriptInterface fun chat(): String = chatJson()
        // ---- window
        @JavascriptInterface fun toggle() { main.post { if (mode == "panel") this@FloatingPanelController.closePanel() else openPanel() } }
        @JavascriptInterface fun open() { main.post { openPanel() } }
        @JavascriptInterface fun shown() { main.post { uncloak() } }
        @JavascriptInterface fun closePanel() { main.post { this@FloatingPanelController.closePanel() } }
        @JavascriptInterface fun quit() { main.post { toast("Floating assistant closed. Start it again from Zyn Ai."); svc.stopSelf() } }
        @JavascriptInterface fun drag(dx: Float, dy: Float) {
            main.post {
                val l = lp ?: return@post
                val d = ctx.resources.displayMetrics.density; val s = screen()
                if (mode == "bubble") { bx = (bx + (dx * d).toInt()).coerceIn(0, s.x - l.width); by = (by + (dy * d).toInt()).coerceIn(0, s.y - l.height); l.x = bx; l.y = by; xUpdate() }
                else if (!maximized) { px = (px + (dx * d).toInt()).coerceIn(0, (s.x - l.width).coerceAtLeast(0)); py = (py + (dy * d).toInt()).coerceIn(0, (s.y - l.height).coerceAtLeast(0)); l.x = px; l.y = py }
                update()
            }
        }
        @JavascriptInterface fun dragStart() { main.post { dsx = if (mode == "bubble") bx else px; dsy = if (mode == "bubble") by else py } }
        @JavascriptInterface fun dragTo(dx: Float, dy: Float) {
            main.post {
                val l = lp ?: return@post
                val d = ctx.resources.displayMetrics.density; val s = screen()
                if (mode == "bubble") { bx = (dsx + (dx * d).toInt()).coerceIn(0, (s.x - l.width).coerceAtLeast(0)); by = (dsy + (dy * d).toInt()).coerceIn(0, (s.y - l.height).coerceAtLeast(0)); l.x = bx; l.y = by; xUpdate() }
                else if (!maximized) { px = (dsx + (dx * d).toInt()).coerceIn(0, (s.x - l.width).coerceAtLeast(0)); py = (dsy + (dy * d).toInt()).coerceIn(0, (s.y - l.height).coerceAtLeast(0)); l.x = px; l.y = py }
                update()
            }
        }
        @JavascriptInterface fun resizeStart() { main.post { dsx = pw; dsy = ph } }
        @JavascriptInterface fun resizeTo(dx: Float, dy: Float) {
            main.post {
                if (mode != "panel" || maximized || minimized) return@post
                val d = ctx.resources.displayMetrics.density; val s = screen(); val m = dp(8)
                pw = (dsx + (dx * d).toInt()).coerceIn(minOf(dp(260), s.x - 2 * m), (s.x - px).coerceAtLeast(dp(120))); ph = (dsy + (dy * d).toInt()).coerceIn(minOf(dp(200), s.y - 2 * m), (s.y - py).coerceAtLeast(dp(120)))
                layout(true)
            }
        }
        @JavascriptInterface fun dragEnd() { main.post { if (mode == "bubble") endBubbleDrag() else { savePanel() } } }
        @JavascriptInterface fun resize(dx: Float, dy: Float) {
            main.post {
                if (mode != "panel" || maximized || minimized) return@post
                val d = ctx.resources.displayMetrics.density; val s = screen(); val m = dp(8)
                pw = (pw + (dx * d).toInt()).coerceIn(minOf(dp(260), s.x - 2 * m), s.x - px - 0); ph = (ph + (dy * d).toInt()).coerceIn(minOf(dp(200), s.y - 2 * m), s.y - py)
                layout(true)
            }
        }
        @JavascriptInterface fun resizeEnd() { main.post { savePanel() } }
        @JavascriptInterface fun minimize(on: Boolean, cssH: Float) { main.post { minimized = on; if (on) { maximized = false; minH = (cssH * ctx.resources.displayMetrics.density).toInt() }; layout(true); ev("win", winJson()) } }
        @JavascriptInterface fun minHeight(cssH: Float) { main.post { minH = (cssH * ctx.resources.displayMetrics.density).toInt(); if (minimized) layout(true) } }
        @JavascriptInterface fun maximize(on: Boolean) { main.post { maximized = on; if (on) minimized = false; layout(true); ev("win", winJson()) } }
        @JavascriptInterface fun typing(on: Boolean) { main.post { setTyping(on) } }
        @JavascriptInterface fun selecting(on: Boolean) { main.post { setSelecting(on) } }
        @JavascriptInterface fun resetGeometry() { main.post { px = Int.MIN_VALUE; pw = dp(360); ph = dp(520); maximized = false; minimized = false; prefs.edit().remove("px").remove("py").remove("pw").remove("ph").apply(); layout(true); ev("win", winJson()) } }
        @JavascriptInterface fun glassBlur(cssPx: Float) {
            main.post {
                if (Build.VERSION.SDK_INT < 31) return@post
                val l = lp ?: return@post
                try {
                    if (cssPx > 0f && wm.isCrossWindowBlurEnabled) { l.flags = l.flags or LayoutParams.FLAG_BLUR_BEHIND; l.blurBehindRadius = (cssPx * ctx.resources.displayMetrics.density).toInt() }
                    else { l.flags = l.flags and LayoutParams.FLAG_BLUR_BEHIND.inv(); l.blurBehindRadius = 0 }
                    update()
                } catch (_: Throwable) { }
            }
        }
        // ---- chat
        @JavascriptInterface fun send(text: String, ids: String): String = try {
            val a = JSONArray(ids.ifBlank { "[]" }); val l = ArrayList<String>(); for (i in 0 until a.length()) l.add(a.optString(i))
            val e = off("m_chat", "Chat")
            if (e != null) jo("ok" to false, "err" to e) else sendChat(text, l)
        } catch (e: Throwable) { jo("ok" to false, "err" to (e.message ?: "Could not send")) }
        @JavascriptInterface fun stop() { main.post { stopChat() } }
        @JavascriptInterface fun regen(): String = if (FloatStore.feat("regen")) regenerate() else jo("ok" to false, "err" to off("regen", "Retry"))
        @JavascriptInterface fun newChat() { main.post { if (busy) stopChat(); FloatStore.newConv(); worker?.execute { FloatStore.save() }; ev("chat", chatJson()) } }
        @JavascriptInterface fun clearChat() { main.post { if (busy) stopChat(); val id = FloatStore.current().id; FloatStore.delete(setOf(id)); ev("chat", chatJson()) } }
        @JavascriptInterface fun chatList(): String = chatListJson()
        @JavascriptInterface fun openChat(id: String) { main.post { if (busy) stopChat(); FloatStore.open(id); ev("chat", chatJson()) } }
        @JavascriptInterface fun deleteChats(ids: String) { main.post { try { val a = JSONArray(ids); val s = HashSet<String>(); for (i in 0 until a.length()) s.add(a.optString(i)); if (busy) stopChat(); FloatStore.delete(s); ev("chat", chatJson()) } catch (_: Throwable) { } } }
        @JavascriptInterface fun renameChat(id: String, name: String) { FloatStore.rename(id, name) }
        @JavascriptInterface fun pinChat(id: String) { FloatStore.pin(id) }
        @JavascriptInterface fun selectProvider(id: String) { FloatStore.selectedId = id; ev("providers", providersJson()) }
        @JavascriptInterface fun copy(t: String) { this@FloatingPanelController.copy(t) }
        // ---- attachments
        @JavascriptInterface fun pick(kind: String) { val e = off("attach", "Attachments"); if (e != null) main.post { toast(e) } else this@FloatingPanelController.pick(kind) }
        @JavascriptInterface fun dropAtt(id: String) { atts.remove(id) }
        // ---- voice
        @JavascriptInterface fun speak(t: String) { if (FloatStore.feat("speak")) this@FloatingPanelController.speak(t) }
        @JavascriptInterface fun liveSpeak(t: String) { if (FloatStore.feat("live")) this@FloatingPanelController.speak(t) }
        @JavascriptInterface fun liveSpeakPart(t: String) { if (FloatStore.feat("live")) main.post { try { nt().append(t, AgentController.lang, 1f, 1f) } catch (_: Throwable) { } } }
        @JavascriptInterface fun liveMode(on: Boolean) { liveVoice = on }
        @JavascriptInterface fun micStartLive() { val e = off("mic", "Voice input"); if (e != null) main.post { toast(e) } else this@FloatingPanelController.micStart(true) }
        @JavascriptInterface fun speakStop() { main.post { try { tts?.stop() } catch (_: Throwable) { } } }
        @JavascriptInterface fun micStart() { val e = off("mic", "Voice input"); if (e != null) main.post { toast(e) } else this@FloatingPanelController.micStart() }
        @JavascriptInterface fun micStop() { main.post { try { speech?.stop() } catch (_: Throwable) { } } }
        // ---- agent
        @JavascriptInterface fun agentCfg(json: String) { try { AgentController.config(json) } catch (_: Throwable) { }; pushStatus(true) }
        @JavascriptInterface fun agentStart(task: String): String = off("m_agent", "Agent") ?: startAgent(task, false)
        @JavascriptInterface fun agentAsk(task: String): String = off("m_ask", "Ask screen") ?: startAgent(task, true)
        @JavascriptInterface fun agentExplain(): String = off("m_explain", "Explain screen") ?: startAgent("Explain what is on this screen", true)
        @JavascriptInterface fun srcFav(h: String) { Thread({ FloatSources.favicon(h)?.let { d -> ev("srcFav", jo("h" to h, "d" to d)) } }, "zyn-fav").also { it.isDaemon = true }.start() }
        @JavascriptInterface fun srcRead(id: String, u: String, t: String) {
            if (!(u.startsWith("https://") || u.startsWith("http://"))) return
            srcActive = id
            Thread({ FloatSources.read(id, u, t, { srcActive == id }) { o -> ev("srcInfo", o.toString()) } }, "zyn-src").also { it.isDaemon = true }.start()
        }
        @JavascriptInterface fun srcCancel(id: String) { if (srcActive == id) srcActive = "" }
        @JavascriptInterface fun openUrl(u: String) { main.post { try { if (u.startsWith("https://") || u.startsWith("http://")) ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Throwable) { } } }
        @JavascriptInterface fun agentPause() { AgentController.pause(); pushStatus(true) }
        @JavascriptInterface fun agentResume() { AgentController.resume(); pushStatus(true) }
        @JavascriptInterface fun agentStop() { AgentController.hardStop("You pressed Stop."); pushStatus(true) }
        @JavascriptInterface fun agentClearHistory() { AgentHistory.clear(); pushStatus(true) }
        @JavascriptInterface fun confirm(ok: Boolean) { answerConfirm(ok) }
        @JavascriptInterface fun openAccessibility() { main.post { AgentController.openAccessibilitySettings(ctx) } }
        @JavascriptInterface fun openOverlaySettings() { main.post { try { ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Throwable) { } } }
        @JavascriptInterface fun openApp() { main.post { try { ctx.startActivity(Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)) } catch (_: Throwable) { toast("Open Zyn Ai from your launcher") } } }
        @JavascriptInterface fun openFeatures() { main.post { try { ctx.startActivity(Intent(ctx, MainActivity::class.java).putExtra("a2z_panel_features", true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)) } catch (_: Throwable) { toast("Open Zyn Ai > Settings > Floating panel > Panel features") } } }
        @JavascriptInterface fun openAppSettings() { main.post { this@FloatingPanelController.openAppSettings() } }
        // ---- pencil (Ask screen: long-press -> draw on the screen -> ask about the marked area)
        @JavascriptInterface fun pencilOn() { val e = off("m_ask", "Ask screen"); main.post { if (e != null) toast(e) else pencilStart() } }
        @JavascriptInterface fun pencilOff() { main.post { pencilStop() } }
        @JavascriptInterface fun pencilTool(tool: String, color: String) { main.post { val c = try { Color.parseColor(color) } catch (_: Throwable) { Color.RED }; pencil?.setTool(tool, c); pushPencil() } }
        @JavascriptInterface fun pencilUndo() { main.post { pencil?.undo() } }
        @JavascriptInterface fun pencilClear() { main.post { pencil?.clear() } }
        @JavascriptInterface fun pencilState(): String = pencilJson()
        @JavascriptInterface fun askMarked(text: String): String { val e = off("m_ask", "Ask screen"); return if (e != null) jo("ok" to false, "err" to e) else markedAsk(text) }
        // ---- screen share / vision
        @JavascriptInterface fun shareStart() { val e = off("share", "Screen share"); main.post { if (e != null) toast(e) else this@FloatingPanelController.shareStart() } }
        @JavascriptInterface fun shareStop() { main.post { this@FloatingPanelController.shareStop() } }
        @JavascriptInterface fun sharePause() { main.post { shareCmd(ScreenCaptureService.PAUSE) } }
        @JavascriptInterface fun shareResume() { main.post { if (!FrameStore.privacy) shareCmd(ScreenCaptureService.RESUME) else toast("Turn off Privacy Mode first.") } }
        @JavascriptInterface fun capture(ask: Boolean) { val e = off("share", "Screen share"); main.post { if (e != null) toast(e) else this@FloatingPanelController.capture(ask) } }
        @JavascriptInterface fun ocr() { runOcr() }
        @JavascriptInterface fun highlight() { highlightOcr() }
        @JavascriptInterface fun privacy(on: Boolean) { main.post { setPrivacy(on) } }
        @JavascriptInterface fun auto(on: Boolean) { FrameStore.autoOcr = on; pushStatus(true) }
        @JavascriptInterface fun preview(on: Boolean) { previewOn = on; if (on) lastPrevRef = null }
    }
}
