package com.a2z.ai
import java.util.concurrent.CopyOnWriteArrayList

/** Result of one on-demand screenshot taken by [ScreenCaptureService]. [jpeg] is null when [error] explains why. */
class Shot(val jpeg: ByteArray?, val width: Int, val height: Int, val blank: Boolean, val error: String?)

/** In-memory only. Cleared whenever sharing stops. Nothing is written to disk or sent anywhere by native code. */
object FrameStore {
    @Volatile var state = "stopped"          // stopped | running | paused
        set(v) { field = v; try { onState?.invoke() } catch (_: Throwable) { } }
    @Volatile var mode = "continuous"        // continuous (app's Share screen dialog) | manual (floating panel: one screenshot per tap)
    @Volatile var appForeground = true       // frames are only kept while ANOTHER app is on screen (continuous mode)
    @Volatile var maxFrames = 3
    @Volatile var privacy = false            // Privacy Mode: capture paused, nothing stored
    @Volatile var autoOcr = false            // automatic mode: on-device OCR of changed frames (no API request)
    @Volatile var lastAt = 0L                // time of the newest stored frame (lets the agent wait for a fresh screenshot after an action)
    @Volatile var protectedHits = 0          // frames Android blanked (FLAG_SECURE) and we therefore did not store

    // In-process callbacks used by the floating panel (may be invoked from any thread).
    @Volatile var onState: (() -> Unit)? = null
    @Volatile var onShot: ((Shot) -> Unit)? = null
    @Volatile var onPermission: ((Boolean) -> Unit)? = null

    private val frames = CopyOnWriteArrayList<String>()
    @Synchronized fun add(b64: String) { frames.add(b64); lastAt = System.currentTimeMillis(); while (frames.size > maxFrames) frames.removeAt(0) }
    fun latest(n: Int): List<String> = frames.toList().takeLast(n.coerceIn(1, maxFrames))
    fun count() = frames.size
    fun clear() { frames.clear(); protectedHits = 0; ScreenOcr.reset() }
}
