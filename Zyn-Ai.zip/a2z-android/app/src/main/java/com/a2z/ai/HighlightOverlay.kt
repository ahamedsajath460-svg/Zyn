package com.a2z.ai

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONArray

/**
 * Smart Screen Highlight: draws numbered boxes over text regions found by OCR. Main thread only.
 * Safe by design: the box layer is NOT touchable (taps pass through to the app below) unless the user switches on "Select";
 * a small always-touchable control strip offers Select and Close. It never simulates taps or touches other apps.
 * Needs the "Display over other apps" permission (checked by the caller).
 */
object HighlightOverlay {
    @Volatile var showing = false; private set
    var onSelect: ((Int) -> Unit)? = null
    private var wm: WindowManager? = null
    private var layer: Layer? = null
    private var bar: View? = null
    private var selecting = false

    private class Layer(c: Context, val regions: List<RectF>, val fw: Float, val fh: Float) : View(c) {
        var sel = -1
        private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 4f; color = Color.parseColor("#6750A4") }
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = Color.parseColor("#226750A4") }
        private val badge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = Color.parseColor("#6750A4") }
        private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 28f; textAlign = Paint.Align.CENTER; isFakeBoldText = true }
        override fun onDraw(c: Canvas) {
            val sx = width / fw; val sy = height / fh
            regions.forEachIndexed { i, r ->
                val b = RectF(r.left * sx, r.top * sy, r.right * sx, r.bottom * sy)
                if (i == sel) { fill.color = Color.parseColor("#556750A4"); stroke.strokeWidth = 7f } else { fill.color = Color.parseColor("#226750A4"); stroke.strokeWidth = 4f }
                c.drawRect(b, fill); c.drawRect(b, stroke)
                val cx = b.left.coerceAtLeast(22f); val cy = (b.top - 2f).coerceAtLeast(22f)
                c.drawCircle(cx, cy, 20f, badge); c.drawText((i + 1).toString(), cx, cy + 10f, txt)
            }
        }
        fun hit(x: Float, y: Float): Int {
            val sx = width / fw; val sy = height / fh; var best = -1; var area = Float.MAX_VALUE
            regions.forEachIndexed { i, r ->
                if (x >= r.left * sx && x <= r.right * sx && y >= r.top * sy && y <= r.bottom * sy) {
                    val a = (r.width() * r.height()); if (a < area) { area = a; best = i }
                }
            }
            return best
        }
        override fun onTouchEvent(e: MotionEvent): Boolean {
            if (e.action == MotionEvent.ACTION_UP) { val h = hit(e.x, e.y); if (h >= 0) { sel = h; invalidate(); onSelect?.invoke(h) } }
            return true
        }
    }

    private fun lp(touchable: Boolean) = WindowManager.LayoutParams(
        WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            (if (touchable) 0 else WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE), PixelFormat.TRANSLUCENT)

    /** [regionsJson]: [[l,t,r,b],...] in frame pixels of a frame fw x fh. */
    fun show(ctx: Context, regionsJson: String, fw: Int, fh: Int) {
        hide()
        val a = JSONArray(regionsJson); if (a.length() == 0 || fw <= 0 || fh <= 0) return
        val rs = ArrayList<RectF>()
        for (i in 0 until a.length()) { val b = a.getJSONArray(i); rs.add(RectF(b.getInt(0).toFloat(), b.getInt(1).toFloat(), b.getInt(2).toFloat(), b.getInt(3).toFloat())) }
        val w = ctx.applicationContext.getSystemService(Context.WINDOW_SERVICE) as WindowManager; wm = w
        val l = Layer(ctx.applicationContext, rs, fw.toFloat(), fh.toFloat()); layer = l; selecting = false
        w.addView(l, lp(false))
        val c = ctx.applicationContext
        val strip = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL; setBackgroundColor(Color.parseColor("#E61D1B20")); setPadding(8, 8, 8, 8) }
        fun chip(t: String, on: (TextView) -> Unit) = TextView(c).apply {
            text = t; setTextColor(Color.WHITE); textSize = 14f; setPadding(28, 18, 28, 18); contentDescription = t; setOnClickListener { on(this) }
        }
        strip.addView(chip("Select") { v -> selecting = !selecting; v.text = if (selecting) "Pass-through" else "Select"; layer?.let { w.updateViewLayout(it, lp(selecting)) } })
        strip.addView(chip("Close") { hide() })
        val p = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.END; y = 120 }
        bar = strip; w.addView(strip, p); showing = true
    }

    fun hide() {
        val w = wm
        try { layer?.let { w?.removeView(it) } } catch (_: Throwable) { }
        try { bar?.let { w?.removeView(it) } } catch (_: Throwable) { }
        layer = null; bar = null; showing = false
    }
}
