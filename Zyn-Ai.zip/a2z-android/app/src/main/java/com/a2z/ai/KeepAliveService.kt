package com.a2z.ai

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager

/**
 * Keeps the app process (and its WebView) alive while a tool is working, so the job also finishes when you
 * switch to another app or lock the screen. Started / stopped from JavaScript through Bridge.keepAlive(on).
 * Safety: it stops itself after 30 minutes even if JavaScript never turns it off.
 */
class KeepAliveService : Service() {
    private var wl: PowerManager.WakeLock? = null
    private val h = Handler(Looper.getMainLooper())
    private val stopper = Runnable { stopSelf() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel(CH, "Tools working", NotificationManager.IMPORTANCE_LOW))
            val pi = PendingIntent.getActivity(
                this, 0,
                Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NEW_TASK),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = Notification.Builder(this, CH)
                .setSmallIcon(android.R.drawable.stat_notify_sync)
                .setContentTitle("Zyn Ai is working")
                .setContentText("A tool is still running. Tap to open.")
                .setOngoing(true)
                .setContentIntent(pi)
                .build()
            if (Build.VERSION.SDK_INT >= 34) startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC) else startForeground(NID, n)
            if (wl == null) {
                val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
                wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "zyn:keepalive").apply { setReferenceCounted(false); acquire(30 * 60 * 1000L) }
            }
            h.removeCallbacks(stopper)
            h.postDelayed(stopper, 30 * 60 * 1000L)
            running = true
        } catch (_: Throwable) {
            stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        h.removeCallbacks(stopper)
        try { wl?.let { if (it.isHeld) it.release() } } catch (_: Throwable) { }
        wl = null
        running = false
        super.onDestroy()
    }

    companion object {
        private const val CH = "a2z_keepalive"
        private const val NID = 9
        @Volatile var running = false
    }
}
