package com.a2z.ai
import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.content.ActivityNotFoundException
import android.net.Uri
import android.provider.Settings
import android.provider.CalendarContract
import android.content.ContentValues
import androidx.appcompat.app.AlertDialog
import android.os.Build
import android.os.Bundle
import android.speech.SpeechRecognizer
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.ConnectionResult
import com.google.android.gms.common.GoogleApiAvailability
import com.google.android.gms.common.api.ApiException
import android.webkit.*
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.webkit.WebViewAssetLoader
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private var pendingInterval = 1000; private var pendingQuality = 75
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private var awaitingOverlay = false
    // ---- Google sign-in (additive): native account picker -> ID token -> Firebase JS Auth in the page ----
    private var gsc: GoogleSignInClient? = null
    private fun authEmit(type: String, data: String) {
        if (!::web.isInitialized) return
        web.post { web.evaluateJavascript("window.__fba&&window.__fba(" + JSONObject.quote(type) + "," + JSONObject.quote(data) + ")", null) }
    }
    private val signInLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        try {
            val t = GoogleSignIn.getSignedInAccountFromIntent(r.data).getResult(ApiException::class.java).idToken
            if (t.isNullOrEmpty()) authEmit("error", "Google did not return an ID token. Check the Web client ID in firebase-config.js.") else authEmit("token", t)
        } catch (e: ApiException) {
            when (e.statusCode) {
                12501 -> authEmit("cancelled", "")
                7 -> authEmit("error", "Network error during Google sign-in. Check your connection.")
                10 -> authEmit("error", "Developer error (code 10): the app's SHA-1/SHA-256 or the Web client ID in firebase-config.js does not match your Firebase project.")
                else -> authEmit("error", "Google sign-in failed (code ${e.statusCode}).")
            }
        } catch (e: Exception) { authEmit("error", "Google sign-in failed: ${e.message}") }
    }
    private fun googleClient(webClientId: String): GoogleSignInClient {
        val b = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN).requestEmail().requestProfile()
        if (webClientId.isNotBlank()) b.requestIdToken(webClientId)
        return GoogleSignIn.getClient(this, b.build()).also { gsc = it }
    }
    // ---- Native speech recognition (additive) ----
    private var speech: NativeSpeech? = null
    private var pendingSttLang = "en-US"
    private fun speechEmit(type: String, data: String) {
        if (!::web.isInitialized) return
        web.post { web.evaluateJavascript("window.__nsr&&window.__nsr(" + JSONObject.quote(type) + "," + JSONObject.quote(data) + ")", null) }
    }
    private fun ns(): NativeSpeech = speech ?: NativeSpeech(this) { t, d -> speechEmit(t, d) }.also { speech = it }
    private val micPermLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        permChanged()
        if (ok) ns().start(pendingSttLang)
        else speechEmit("perm_denied", if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.RECORD_AUDIO)) "ask" else "settings")
    }

    // ---- Native TextToSpeech + screen vision (additive) ----
    private var tts: NativeTts? = null
    private fun ttsEmit(type: String, data: String) {
        if (!::web.isInitialized) return
        web.post { web.evaluateJavascript("window.__ntts&&window.__ntts(" + JSONObject.quote(type) + "," + JSONObject.quote(data) + ")", null) }
    }
    private fun nt(): NativeTts = tts ?: NativeTts(this) { t, d -> ttsEmit(t, d) }.also { tts = it }

    private val projectionLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK && r.data != null) {
            ContextCompat.startForegroundService(this, Intent(this, ScreenCaptureService::class.java).apply {
                action = ScreenCaptureService.START
                putExtra(ScreenCaptureService.CODE, r.resultCode); putExtra(ScreenCaptureService.DATA, r.data)
                putExtra(ScreenCaptureService.INTERVAL, pendingInterval); putExtra(ScreenCaptureService.QUALITY, pendingQuality)
            })
        } else Toast.makeText(this, "Screen sharing permission was declined", Toast.LENGTH_SHORT).show()
    }
    private val fileLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data)); fileCb = null
    }

    // ---- Location (WebView geolocation) + Calendar (read/write through CalendarContract) ----
    private var geoCb: GeolocationPermissions.Callback? = null
    private var geoOrigin: String = ""
    private val locLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        val ok = r.values.any { it }
        try { geoCb?.invoke(geoOrigin, ok, false) } catch (_: Exception) { }
        geoCb = null
        permChanged()
    }
    private val calLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        val ok = r.isNotEmpty() && r.values.all { it }
        if (::web.isInitialized) web.post { web.evaluateJavascript("window.__calPerm&&window.__calPerm(" + ok + ")", null) }
        permChanged()
    }
    private fun permOk(p: String) = ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    // ---- Real permission state + requests: the ONLY source the Permissions page reads (nothing is assumed or faked) ----
    private val permPrefs by lazy { getSharedPreferences("a2z_perm", android.content.Context.MODE_PRIVATE) }
    private fun permAsked(k: String) = permPrefs.edit().putBoolean("asked_$k", true).apply()
    /** Tells the page that some permission changed, so every status on screen is re-read from Android. */
    private fun permChanged() { if (::web.isInitialized) web.post { web.evaluateJavascript("window.__permChanged&&window.__permChanged()", null) } }
    private fun permList(k: String): Array<String> = when (k) {
        "mic" -> arrayOf(Manifest.permission.RECORD_AUDIO)
        "cam" -> arrayOf(Manifest.permission.CAMERA)
        "loc" -> arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
        "calr" -> arrayOf(Manifest.permission.READ_CALENDAR)
        "calw" -> arrayOf(Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR)
        "notif" -> if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.POST_NOTIFICATIONS) else emptyArray()
        else -> emptyArray()
    }
    private fun permGranted(k: String): Boolean = when (k) {
        "mic" -> permOk(Manifest.permission.RECORD_AUDIO)
        "cam" -> permOk(Manifest.permission.CAMERA)
        "loc" -> permOk(Manifest.permission.ACCESS_FINE_LOCATION) || permOk(Manifest.permission.ACCESS_COARSE_LOCATION)
        "calr" -> permOk(Manifest.permission.READ_CALENDAR)
        "calw" -> permOk(Manifest.permission.READ_CALENDAR) && permOk(Manifest.permission.WRITE_CALENDAR)
        "notif" -> androidx.core.app.NotificationManagerCompat.from(this).areNotificationsEnabled()
        "overlay" -> FloatPerm.has(this)
        "acc" -> AIAccessibilityService.connected()
        else -> false
    }
    /** granted | ask (Android can still show its pop-up, or the user must switch it on in Settings) | blocked (only phone Settings can change it). */
    private fun permState(k: String): String {
        if (permGranted(k)) return "granted"
        if (k == "overlay" || k == "acc") return "ask"
        if (k == "notif" && (Build.VERSION.SDK_INT < 33 || permOk(Manifest.permission.POST_NOTIFICATIONS))) return "blocked"
        val canAsk = permList(k).any { ActivityCompat.shouldShowRequestPermissionRationale(this, it) }
        return if (!permPrefs.getBoolean("asked_$k", false) || canAsk) "ask" else "blocked"
    }
    private fun openAppSettings(k: String) {
        try {
            if (k == "notif" && Build.VERSION.SDK_INT >= 26) startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName))
            else startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        } catch (_: Exception) { try { startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (_: Exception) { } }
    }
    private val genPermLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { permChanged() }

    // WebView camera / microphone requests (getUserMedia): granted ONLY for what Android really allows
    private var webReq: PermissionRequest? = null
    private val webPermLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        val r = webReq; webReq = null
        if (r != null) answerWebReq(r)
        permChanged()
    }
    private fun answerWebReq(req: PermissionRequest) {
        val ok = req.resources.filter {
            when (it) {
                PermissionRequest.RESOURCE_AUDIO_CAPTURE -> permOk(Manifest.permission.RECORD_AUDIO)
                PermissionRequest.RESOURCE_VIDEO_CAPTURE -> permOk(Manifest.permission.CAMERA)
                else -> false
            }
        }.toTypedArray()
        try { if (ok.isEmpty()) req.deny() else req.grant(ok) } catch (_: Exception) { }
    }
    private fun calEventsJson(days: Int): String {
        val out = JSONArray()
        if (!permOk(Manifest.permission.READ_CALENDAR)) return out.toString()
        try {
            val now = System.currentTimeMillis()
            val end = now + days.coerceIn(1, 90) * 86400000L
            val proj = arrayOf(CalendarContract.Instances.TITLE, CalendarContract.Instances.BEGIN, CalendarContract.Instances.END, CalendarContract.Instances.EVENT_LOCATION, CalendarContract.Instances.ALL_DAY)
            val c = CalendarContract.Instances.query(contentResolver, proj, now, end)
            if (c != null) {
                try {
                    while (c.moveToNext() && out.length() < 40) {
                        out.put(JSONObject().put("title", c.getString(0) ?: "").put("start", c.getLong(1)).put("end", c.getLong(2)).put("loc", c.getString(3) ?: "").put("allDay", c.getInt(4) == 1))
                    }
                } finally { c.close() }
            }
        } catch (_: Exception) { }
        return out.toString()
    }
    private fun calAddEvent(title: String, startMs: Long, endMs: Long, desc: String, loc: String): String {
        if (!permOk(Manifest.permission.READ_CALENDAR) || !permOk(Manifest.permission.WRITE_CALENDAR)) return "Calendar permission is not allowed"
        try {
            var calId = -1L
            val c = contentResolver.query(CalendarContract.Calendars.CONTENT_URI, arrayOf(CalendarContract.Calendars._ID), CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL + " >= ?", arrayOf("500"), null)
            if (c != null) { try { if (c.moveToFirst()) calId = c.getLong(0) } finally { c.close() } }
            if (calId < 0) return "No calendar on this phone can save events"
            val v = ContentValues()
            v.put(CalendarContract.Events.DTSTART, startMs)
            v.put(CalendarContract.Events.DTEND, endMs)
            v.put(CalendarContract.Events.TITLE, title)
            v.put(CalendarContract.Events.DESCRIPTION, desc)
            v.put(CalendarContract.Events.EVENT_LOCATION, loc)
            v.put(CalendarContract.Events.CALENDAR_ID, calId)
            v.put(CalendarContract.Events.EVENT_TIMEZONE, java.util.TimeZone.getDefault().id)
            return if (contentResolver.insert(CalendarContract.Events.CONTENT_URI, v) != null) "ok" else "Could not save the event"
        } catch (e: Exception) { return "Calendar error: " + (e.message ?: "unknown") }
    }

    inner class Bridge {
        @JavascriptInterface fun calStatus(): String = if (permOk(Manifest.permission.READ_CALENDAR) && permOk(Manifest.permission.WRITE_CALENDAR)) "granted" else "denied"
        @JavascriptInterface fun calAsk() = runOnUiThread { permAsked("calw"); calLauncher.launch(arrayOf(Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR)) }
        @JavascriptInterface fun calEvents(days: Int): String = calEventsJson(days)
        @JavascriptInterface fun calAdd(title: String, startMs: String, endMs: String, desc: String, loc: String): String {
            val s = startMs.toLongOrNull() ?: return "Bad start time"
            val e = endMs.toLongOrNull() ?: (s + 3600000L)
            return calAddEvent(title, s, if (e > s) e else s + 3600000L, desc, loc)
        }
        @JavascriptInterface fun locStatus(): String = if (permOk(Manifest.permission.ACCESS_FINE_LOCATION) || permOk(Manifest.permission.ACCESS_COARSE_LOCATION)) "granted" else "denied"
        @JavascriptInterface fun available() = true
        @JavascriptInterface fun metered(): Boolean = NetInfo.metered(this@MainActivity)   // used by the Data saver (assets/datasave.js)
        // ---- real permission bridge ----
        /** JSON {mic,cam,notif,loc,calr,calw,overlay,acc}: each granted | ask | blocked, read live from Android. */
        @JavascriptInterface fun permStatus(): String {
            val o = JSONObject()
            for (k in arrayOf("mic", "cam", "notif", "loc", "calr", "calw", "overlay", "acc")) o.put(k, permState(k))
            return o.toString()
        }
        /** Asks Android for the permission (or opens the right Settings page when Android will no longer show a pop-up). */
        @JavascriptInterface fun permRequest(k: String) = runOnUiThread {
            when (k) {
                "overlay" -> overlayAsk()
                "acc" -> AgentController.openAccessibilitySettings(this@MainActivity)
                else -> {
                    if (permGranted(k)) { permChanged(); return@runOnUiThread }
                    val ps = permList(k)
                    if (ps.isEmpty() || permState(k) == "blocked") { openAppSettings(k); return@runOnUiThread }
                    permAsked(k)
                    genPermLauncher.launch(ps)
                }
            }
        }
        /** Opens an http(s) link in the phone's browser (used by the "Get API key" buttons). */
        @JavascriptInterface fun openUrl(u: String): Boolean = try {
            val uri = Uri.parse(u.trim())
            if (uri.scheme == "https" || uri.scheme == "http") { runOnUiThread { try { startActivity(Intent(Intent.ACTION_VIEW, uri)) } catch (_: Throwable) { } }; true } else false
        } catch (_: Throwable) { false }
        @JavascriptInterface fun appSettings(k: String) = runOnUiThread { openAppSettings(k) }
        /** Real state of one of our notification channels: on | off (silenced in Android) | new (not created yet, defaults apply). */
        @JavascriptInterface fun notifChannelState(id: String): String {
            if (Build.VERSION.SDK_INT < 26) return "on"
            return try {
                val ch = (getSystemService(NOTIFICATION_SERVICE) as android.app.NotificationManager).getNotificationChannel(id)
                if (ch == null) "new" else if (ch.importance == android.app.NotificationManager.IMPORTANCE_NONE) "off" else "on"
            } catch (_: Throwable) { "on" }
        }
        /** Opens Android's own settings page for one notification channel (created first so the page is never empty). */
        @JavascriptInterface fun notifChannel(id: String) = runOnUiThread {
            try {
                if (Build.VERSION.SDK_INT >= 26) {
                    val nm = getSystemService(NOTIFICATION_SERVICE) as android.app.NotificationManager
                    val name = when (id) { "a2z_reply" -> "Reply ready"; "a2z_share" -> "Screen sharing"; else -> "Floating assistant" }
                    val imp = if (id == "a2z_reply") android.app.NotificationManager.IMPORTANCE_DEFAULT else android.app.NotificationManager.IMPORTANCE_LOW
                    nm.createNotificationChannel(android.app.NotificationChannel(id, name, imp))
                    startActivity(Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName).putExtra(Settings.EXTRA_CHANNEL_ID, id))
                } else openAppSettings("notif")
            } catch (_: Exception) { openAppSettings("notif") }
        }
        /** Shows a real Android notification. Returns false (and shows nothing) unless notifications are allowed. */
        @JavascriptInterface fun notifShow(title: String, body: String): Boolean {
            if (!permGranted("notif")) return false
            return try {
                val nm = getSystemService(NOTIFICATION_SERVICE) as android.app.NotificationManager
                if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(android.app.NotificationChannel("a2z_reply", "Reply ready", android.app.NotificationManager.IMPORTANCE_DEFAULT))
                val pi = android.app.PendingIntent.getActivity(this@MainActivity, 0, Intent(this@MainActivity, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NEW_TASK), android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT)
                val n = android.app.Notification.Builder(this@MainActivity, "a2z_reply").setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title).setContentText(body).setContentIntent(pi).setAutoCancel(true).build()
                nm.notify(7101, n); true
            } catch (_: Throwable) { false }
        }
        /** Keeps the app alive while a tool is working (foreground service). JS calls keepAlive(true) when a tool starts and keepAlive(false) when all tools are idle. */
        @JavascriptInterface fun keepAlive(on: Boolean) = runOnUiThread {
            try {
                val i = Intent(this@MainActivity, KeepAliveService::class.java)
                if (on) ContextCompat.startForegroundService(this@MainActivity, i) else stopService(i)
            } catch (_: Throwable) { }
            Unit
        }
        @JavascriptInterface fun bootColor(c: String) { try { this@MainActivity.getSharedPreferences("a2z_boot", android.content.Context.MODE_PRIVATE).edit().putInt("bg", Color.parseColor(c.trim())).apply() } catch (_: Throwable) { } }
        @JavascriptInterface fun start(intervalMs: Int, quality: Int, keep: Int) = runOnUiThread {
            pendingInterval = intervalMs; pendingQuality = quality; FrameStore.maxFrames = keep.coerceIn(1, 3)
            if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
                { permAsked("notif"); ActivityCompat.requestPermissions(this@MainActivity, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1) }
            val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projectionLauncher.launch(mpm.createScreenCaptureIntent())   // system consent dialog
        }
        @JavascriptInterface fun pause() = cmd(ScreenCaptureService.PAUSE)
        @JavascriptInterface fun resume() = cmd(ScreenCaptureService.RESUME)
        @JavascriptInterface fun stop() = cmd(ScreenCaptureService.STOP)
        @JavascriptInterface fun status() = FrameStore.state + "|" + FrameStore.count()
        @JavascriptInterface fun latestFrames(n: Int): String = JSONArray(FrameStore.latest(n)).toString()
        // ---- AI Agent bridge (additive) ----
        @JavascriptInterface fun agentStatus(): String = AgentController.status(this@MainActivity)
        @JavascriptInterface fun agentConfig(json: String) { try { AgentController.config(json) } catch (_: Exception) { } }
        /** Returns "" when started, otherwise the reason it did not start. */
        @JavascriptInterface fun agentStart(task: String): String = AgentRunner.start(this@MainActivity, task) ?: ""
        /** Voice command: a stop phrase (English or Tamil) stops the agent; anything else starts a task. */
        @JavascriptInterface fun agentVoice(text: String): String { val c = AgentController.voiceControl(text); if (c.isNotEmpty()) return c; return AgentRunner.start(this@MainActivity, text) ?: "" }
        /** "Ask about my screen" by voice or text: always an explanation, never a UI action. Stop / Pause / Resume phrases still work. */
        @JavascriptInterface fun agentAsk(text: String): String { val c = AgentController.voiceControl(text); if (c.isNotEmpty()) return c; return AgentRunner.start(this@MainActivity, text, true) ?: "" }
        /** Persistent agent history as JSON (newest first). Contains no screenshots, screen text or typed text. */
        @JavascriptInterface fun agentHistory(): String = AgentHistory.toJson()
        @JavascriptInterface fun agentPanel(on: Boolean) = runOnUiThread {
            if (on && (!FloatPerm.has(this@MainActivity) || !AgentController.enabled)) { Toast.makeText(this@MainActivity, "Turn on AI Agent and allow overlay first", Toast.LENGTH_LONG).show(); if (!FloatPerm.has(this@MainActivity)) overlayAsk(); return@runOnUiThread }
            AgentController.panel = on; if (on) AgentOverlay.showBar(applicationContext) else AgentOverlay.hideAll(false)
        }
        /** Floating panel page: which buttons, top/bottom, start minimized, opacity. Rebuilds the bar if it is showing. */
        @JavascriptInterface fun agentPanelConfig(json: String) { try { AgentOverlay.configure(json); AgentOverlay.reload(applicationContext) } catch (_: Exception) { } }
        @JavascriptInterface fun agentPause() { AgentController.pause() }
        @JavascriptInterface fun agentResume() { AgentController.resume() }
        @JavascriptInterface fun agentStop() { AgentController.hardStop("You pressed Stop.") }
        @JavascriptInterface fun agentClearHistory() { AgentHistory.clear() }
        @JavascriptInterface fun agentOpenAccessibility() = runOnUiThread { AgentController.openAccessibilitySettings(this@MainActivity) }
        /** Screen Share OFF: current accessible UI as JSON (read only, password fields blank). */
        @JavascriptInterface fun agentUiSnapshot(): String = AIAccessibilityService.instance?.snapshotJson() ?: JSONObject().put("ok", false).put("error", "Accessibility is not connected.").toString()
        // ---- Advanced Vision bridge (additive) ----
        /** JSON: state|frames|privacy|protectedHits|autoOcr|changed|overlay */
        @JavascriptInterface fun statusEx(): String = JSONObject().put("state", FrameStore.state).put("count", FrameStore.count()).put("privacy", FrameStore.privacy)
            .put("protected", FrameStore.protectedHits).put("auto", FrameStore.autoOcr).put("changed", ScreenOcr.changedSinceRead).put("overlay", HighlightOverlay.showing).toString()
        @JavascriptInterface fun setAuto(on: Boolean) { FrameStore.autoOcr = on }
        @JavascriptInterface fun setPrivacy(on: Boolean) = runOnUiThread {
            FrameStore.privacy = on
            if (on) { cmd(ScreenCaptureService.PAUSE); FrameStore.clear(); HighlightOverlay.hide() }   // never resumes by itself
        }
        /** Runs OCR on the newest stored frame (blocking, cached by frame hash). script: auto|latin|devanagari. Returns JSON. */
        @JavascriptInterface fun ocrLatest(script: String, redact: Boolean): String {
            val f = FrameStore.latest(1).lastOrNull() ?: return JSONObject().put("ok", false).put("error", "No frame yet. Switch to another app for a moment, then come back.").toString()
            ScreenOcr.changedSinceRead = false
            return ScreenOcr.analyze(f, script, redact)
        }
        /** Sync: [json frames] with sensitive lines blacked out (when redact) for the newest n frames. */
        @JavascriptInterface fun safeFrames(n: Int, redact: Boolean): String {
            val out = JSONArray()
            for (f in FrameStore.latest(n)) {
                if (!redact) { out.put(f); continue }
                val r = JSONObject(ScreenOcr.analyze(f, "auto", true)); out.put(if (r.has("jpeg")) r.getString("jpeg") else f)
            }
            return out.toString()
        }
        @JavascriptInterface fun visionSupport(type: String, model: String): String = FloatVision.support(FProvider("x", "x", type, "", model, "")).name
        @JavascriptInterface fun copyText(t: String) = runOnUiThread {
            (getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager).setPrimaryClip(android.content.ClipData.newPlainText("Zyn Ai", t)); Toast.makeText(this@MainActivity, "Copied", Toast.LENGTH_SHORT).show()
        }
        @JavascriptInterface fun shareText(t: String) = runOnUiThread {
            try { startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, t), "Share")) } catch (_: Exception) { }
        }
        // save a file (from base64) into Downloads/Zyn Ai so Download buttons really work inside the app
        @JavascriptInterface fun saveFile(name: String, mime: String, b64: String): String {
            return try {
                val bytes = android.util.Base64.decode(b64, android.util.Base64.DEFAULT)
                val safe = name.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().ifBlank { "file" }
                val where: String
                if (android.os.Build.VERSION.SDK_INT >= 29) {
                    val v = android.content.ContentValues().apply {
                        put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, safe)
                        put(android.provider.MediaStore.MediaColumns.MIME_TYPE, if (mime.isBlank()) "application/octet-stream" else mime)
                        put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, android.os.Environment.DIRECTORY_DOWNLOADS + "/Zyn Ai")
                    }
                    val uri = this@MainActivity.contentResolver.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, v) ?: return "error"
                    this@MainActivity.contentResolver.openOutputStream(uri)?.use { it.write(bytes) } ?: return "error"
                    where = "Downloads/Zyn Ai"
                } else {
                    val dir = this@MainActivity.getExternalFilesDir(android.os.Environment.DIRECTORY_DOWNLOADS) ?: this@MainActivity.filesDir
                    java.io.File(dir, safe).writeBytes(bytes)
                    where = dir.absolutePath
                }
                runOnUiThread { Toast.makeText(this@MainActivity, "Saved: $where/$safe", Toast.LENGTH_LONG).show() }
                "ok"
            } catch (e: Exception) { "error" }
        }
        // highlight overlay
        @JavascriptInterface fun overlayAllowed() = FloatPerm.has(this@MainActivity)
        @JavascriptInterface fun overlayAsk() = runOnUiThread {
            AlertDialog.Builder(this@MainActivity).setTitle("Allow display over other apps")
                .setMessage("The floating assistant, screen highlights and the agent status bar are drawn on top of other apps, and Android needs \"Display over other apps\" for that. This permission only lets Zyn Ai draw; it does not let it tap or control anything. Tap Open settings, switch Zyn Ai ON, then come back.")
                .setPositiveButton("Open settings") { _, _ -> try { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) } catch (_: Exception) { } }
                .setNegativeButton("Cancel", null).show()
        }
        @JavascriptInterface fun overlayShow(regionsJson: String, w: Int, h: Int) = runOnUiThread {
            if (!FloatPerm.has(this@MainActivity)) { overlayAsk(); return@runOnUiThread }
            HighlightOverlay.onSelect = { i -> web.post { web.evaluateJavascript("window.__hl&&window.__hl(" + i + ")", null) } }
            try { HighlightOverlay.show(applicationContext, regionsJson, w, h) } catch (e: Exception) { Toast.makeText(this@MainActivity, "Overlay failed: " + e.message, Toast.LENGTH_LONG).show() }
        }
        @JavascriptInterface fun overlayHide() = runOnUiThread { HighlightOverlay.hide() }
        // native TextToSpeech
        @JavascriptInterface fun ttsSpeak(text: String, lang: String, rate: Float, pitch: Float) = runOnUiThread { if (ns().active) ttsEmit("error", JSONObject().put("kind", "mic").put("msg", "Wait for voice input to finish.").toString()) else nt().speak(text, lang, rate, pitch) }
        // voice choice + installed voice list for the Voice settings page
        @JavascriptInterface fun ttsSpeakEx(text: String, lang: String, rate: Float, pitch: Float, voice: String) = runOnUiThread { if (ns().active) ttsEmit("error", JSONObject().put("kind", "mic").put("msg", "Wait for voice input to finish.").toString()) else nt().speak(text, lang, rate, pitch, voice) }
        @JavascriptInterface fun ttsVoices(lang: String) = runOnUiThread { nt().voices(lang) }
        // Privacy: block screenshots and hide the app preview in the recent-apps list (FLAG_SECURE); remembered across restarts
        @JavascriptInterface fun setSecureScreen(on: Boolean) = runOnUiThread {
            try { this@MainActivity.getSharedPreferences("a2z_priv", android.content.Context.MODE_PRIVATE).edit().putBoolean("secure", on).apply() } catch (_: Exception) { }
            applySecure(on)
        }
        @JavascriptInterface fun secureScreen(): Boolean = this@MainActivity.getSharedPreferences("a2z_priv", android.content.Context.MODE_PRIVATE).getBoolean("secure", false)
        @JavascriptInterface fun ttsPause() = runOnUiThread { nt().pause() }
        @JavascriptInterface fun ttsResume() = runOnUiThread { nt().resume() }
        @JavascriptInterface fun ttsStop() = runOnUiThread { tts?.stop(); Unit }
        @JavascriptInterface fun ttsMute(on: Boolean) = runOnUiThread { nt().mute(on) }
        @JavascriptInterface fun ttsInfo() = runOnUiThread { nt().info(listOf("en-US", "ta-IN", "si-LK", "hi-IN")) }
        @JavascriptInterface fun ttsSettings() = runOnUiThread {
            try { startActivity(Intent("com.android.settings.TTS_SETTINGS")) } catch (_: Exception) { try { startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (_: Exception) { } }
        }
        // ---- Floating assistant bridge (additive) ----
        @JavascriptInterface fun floatAvailable() = true
        @JavascriptInterface fun floatSync(json: String) = FloatStore.applySync(json)
        @JavascriptInterface fun floatStart() = runOnUiThread { startFloating() }
        @JavascriptInterface fun floatStop() = runOnUiThread { stopService(Intent(this@MainActivity, FloatingAssistantService::class.java)); Unit }
        @JavascriptInterface fun floatStatus() = (if (FloatingAssistantService.running) "running" else "stopped") + "|" + (if (FloatPerm.has(this@MainActivity)) "granted" else "denied")
        @JavascriptInterface fun floatPeekChats(): String = FloatStore.peekJson()
        @JavascriptInterface fun floatAckChats(json: String) = FloatStore.ackJson(json)
        // ---- Google sign-in bridge (additive) ----
        @JavascriptInterface fun authAvailable(): Boolean = try { GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(this@MainActivity) == ConnectionResult.SUCCESS } catch (_: Exception) { false }
        @JavascriptInterface fun authSignIn(webClientId: String) = runOnUiThread {
            try {
                val c = googleClient(webClientId)
                c.signOut().addOnCompleteListener { signInLauncher.launch(c.signInIntent) }   // sign out first so the account chooser always shows
            } catch (e: Exception) { authEmit("error", "Could not start Google sign-in: ${e.message}") }
        }
        @JavascriptInterface fun authSignOut() = runOnUiThread { try { (gsc ?: googleClient("")).signOut() } catch (_: Exception) {}; Unit }
        // ---- Native SpeechRecognizer bridge (additive) ----
        @JavascriptInterface fun sttAvailable(): Boolean = try { SpeechRecognizer.isRecognitionAvailable(this@MainActivity) } catch (_: Exception) { false }
        @JavascriptInterface fun sttStart(lang: String) = runOnUiThread {
            if (ns().active) { speechEmit("error", JSONObject().put("kind", "busy").put("msg", "Voice input is already running.").toString()); return@runOnUiThread }
            pendingSttLang = lang; tts?.stop()   // never listen while speaking
            if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) ns().start(lang)
            else { permAsked("mic"); micPermLauncher.launch(Manifest.permission.RECORD_AUDIO) }
        }
        @JavascriptInterface fun sttStop() = runOnUiThread { speech?.stop(); Unit }
        @JavascriptInterface fun sttCancel() = runOnUiThread { speech?.cancel(); Unit }
        @JavascriptInterface fun sttSettings() = runOnUiThread {
            try { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) } catch (_: Exception) {}
        }
        private fun cmd(a: String) = startService(Intent(this@MainActivity, ScreenCaptureService::class.java).setAction(a)).let { }
    }

    private fun applySecure(on: Boolean) {
        try {
            if (on) window.setFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE, android.view.WindowManager.LayoutParams.FLAG_SECURE)
            else window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)
        } catch (_: Exception) { }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        applySecure(getSharedPreferences("a2z_priv", android.content.Context.MODE_PRIVATE).getBoolean("secure", false))
        FloatStore.init(applicationContext)
        AgentHistory.init(applicationContext)
        AgentController.onSpeak = { t -> runOnUiThread { try { if (!ns().active) nt().speak(t, AgentController.lang, 1f, 1f) } catch (_: Throwable) { } } }
        AgentController.onSpeakStop = { runOnUiThread { try { tts?.stop() } catch (_: Throwable) { } } }
        AgentController.onEvent = { t, d -> if (::web.isInitialized) web.post { web.evaluateJavascript("window.__agent&&window.__agent(" + JSONObject.quote(t) + "," + JSONObject.quote(d) + ")", null) } }
        val loader = WebViewAssetLoader.Builder().addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this)).build()
        val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        val bootBg = getSharedPreferences("a2z_boot", android.content.Context.MODE_PRIVATE).getInt("bg", if (night) 0xFF05061A.toInt() else 0xFFF7F5FF.toInt())
        window.setBackgroundDrawable(ColorDrawable(bootBg))
        web = WebView(this); web.setBackgroundColor(bootBg); setContentView(web)
        web.settings.apply { javaScriptEnabled = true; domStorageEnabled = true; mediaPlaybackRequiresUserGesture = false; allowFileAccess = false }
        web.addJavascriptInterface(Bridge(), "A2ZNative")
        watchKeyboard()
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest) = loader.shouldInterceptRequest(r.url)
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                if (r.url.host == "appassets.androidplatform.net") return false
                startActivity(Intent(Intent.ACTION_VIEW, r.url)); return true
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onGeolocationPermissionsShowPrompt(origin: String?, callback: GeolocationPermissions.Callback?) {
                val o = origin ?: ""
                if (permOk(Manifest.permission.ACCESS_FINE_LOCATION) || permOk(Manifest.permission.ACCESS_COARSE_LOCATION)) { callback?.invoke(o, true, false); return }
                geoCb = callback; geoOrigin = o; permAsked("loc")
                locLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
            }
            override fun onPermissionRequest(req: PermissionRequest) {
                runOnUiThread {
                    // Never grant blindly: ask Android first, then pass on ONLY what the user really allowed.
                    val need = ArrayList<String>()
                    for (r in req.resources) {
                        if (r == PermissionRequest.RESOURCE_AUDIO_CAPTURE && !permOk(Manifest.permission.RECORD_AUDIO)) { need.add(Manifest.permission.RECORD_AUDIO); permAsked("mic") }
                        if (r == PermissionRequest.RESOURCE_VIDEO_CAPTURE && !permOk(Manifest.permission.CAMERA)) { need.add(Manifest.permission.CAMERA); permAsked("cam") }
                    }
                    if (need.isEmpty()) { answerWebReq(req); return@runOnUiThread }
                    webReq?.let { try { it.deny() } catch (_: Exception) { } }
                    webReq = req
                    webPermLauncher.launch(need.toTypedArray())
                }
            }
            override fun onShowFileChooser(v: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
                fileCb?.onReceiveValue(null); fileCb = cb
                fileLauncher.launch(p.createIntent()); return true
            }
        }
        web.loadUrl("https://appassets.androidplatform.net/assets/a2z.html")
    }

    // ---------------- Floating assistant: permission flow ----------------
    private fun startFloating() {
        if (FloatPerm.has(this)) { launchFloating(); return }
        AlertDialog.Builder(this)
            .setTitle("Allow display over other apps")
            .setMessage("The floating assistant draws a chat bubble and panel on top of other apps. Android needs the \"Display over other apps\" permission for that.\n\nTap Open settings, switch Zyn Ai ON, then press Back to return here. This permission is only used to show the bubble and panel.")
            .setPositiveButton("Open settings") { _, _ -> openOverlaySettings() }
            .setNegativeButton("Cancel", null).show()
    }
    private fun openOverlaySettings() {
        awaitingOverlay = true
        try { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }
        catch (e: ActivityNotFoundException) {
            try { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) }
            catch (_: Exception) { awaitingOverlay = false; showOverlayDenied() }
        }
    }
    private fun showOverlayDenied() {
        AlertDialog.Builder(this)
            .setTitle("Permission is still off")
            .setMessage("The floating assistant cannot appear without \"Display over other apps\". To turn it on:\n\n1. Open Android Settings > Apps (\"Apps & notifications\" on Android 8).\n2. Open Zyn Ai > Advanced > Display over other apps, and switch it ON.\n\nHuawei / EMUI: Settings > Apps > Apps > tap the gear icon (top right) > Special access > Draw over other apps > Zyn Ai > ON.\n\nThen come back and tap Start again.")
            .setPositiveButton("Open settings") { _, _ -> openOverlaySettings() }
            .setNegativeButton("Close", null).show()
    }
    private fun launchFloating() {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        ContextCompat.startForegroundService(this, Intent(this, FloatingAssistantService::class.java).setAction(FloatingAssistantService.ACT_START))
        Toast.makeText(this, "Floating assistant started. Switch to any app to use the bubble.", Toast.LENGTH_LONG).show()
    }
    private var kbShown = false
    /** Tells the page when the on-screen keyboard is really open, so the chat box is compact whenever the keyboard is closed. */
    private fun watchKeyboard() {
        val root = window.decorView
        root.viewTreeObserver.addOnGlobalLayoutListener {
            try {
                val r = android.graphics.Rect()
                root.getWindowVisibleDisplayFrame(r)
                val total = root.rootView.height
                val open = total > 0 && (total - r.bottom) > total * 0.15
                if (open != kbShown) {
                    kbShown = open
                    if (::web.isInitialized) web.post { web.evaluateJavascript("window.__zynKb&&window.__zynKb(" + open + ")", null) }
                }
            } catch (_: Throwable) { }
        }
    }
    override fun onResume() {
        super.onResume(); agentVoiceIntent(); permChanged()
        if (awaitingOverlay) { awaitingOverlay = false; if (FloatPerm.has(this)) launchFloating() else showOverlayDenied() }
    }
    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); setIntent(intent) }
    private fun agentVoiceIntent() {
        val ix = intent ?: return
        val js = when {
            ix.getBooleanExtra("a2z_agent_voice", false) -> { ix.removeExtra("a2z_agent_voice"); "window.A2ZAgent&&A2ZAgent.listen()" }
            ix.getBooleanExtra("a2z_agent_ask", false) -> { ix.removeExtra("a2z_agent_ask"); "window.A2ZAgent&&A2ZAgent.listen(true)" }
            ix.getBooleanExtra("a2z_agent_open", false) -> { ix.removeExtra("a2z_agent_open"); "window.A2ZAgent&&A2ZAgent.open()" }
            else -> return
        }
        if (::web.isInitialized) web.postDelayed({ web.evaluateJavascript(js, null) }, 400)
    }
    override fun onStart() { super.onStart(); FrameStore.appForeground = true }
    override fun onStop() { FrameStore.appForeground = false; tts?.stop(); speech?.interrupted(); super.onStop() }
    override fun onDestroy() { try { stopService(Intent(this, KeepAliveService::class.java)) } catch (_: Throwable) { }; AgentController.onEvent = null; AgentController.onSpeak = null; AgentController.onSpeakStop = null; speech?.destroy(); speech = null; tts?.destroy(); tts = null; super.onDestroy() }
    @Deprecated("") override fun onBackPressed() { if (web.canGoBack()) web.goBack() else @Suppress("DEPRECATION") super.onBackPressed() }
}
