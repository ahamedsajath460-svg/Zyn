package com.a2z.ai

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import org.json.JSONObject

/**
 * Wraps android.speech.SpeechRecognizer. All methods MUST be called on the main thread.
 * Guarantees: at most one recognizer instance alive, late callbacks from old sessions are ignored,
 * and the recognizer is destroyed after every session and in destroy().
 * Events are sent to JS through [emit] as (type, data):
 *   ready, begin, partial(text), final(text), error(json), cancelled, interrupted(text), end
 */
class NativeSpeech(private val act: Activity, private val emit: (String, String) -> Unit) {
    private val main = Handler(Looper.getMainLooper())
    private var sr: SpeechRecognizer? = null
    private var token = 0
    private var lastPartial = ""
    var active = false; private set

    fun available(): Boolean = try { SpeechRecognizer.isRecognitionAvailable(act) } catch (_: Exception) { false }

    fun start(lang: String) {
        if (active) { emit("error", err("busy", "Voice input is already running.")); return }
        if (!available()) {
            emit("error", err("unavailable", "Speech recognition is not available on this device. Install or enable the Google app (voice typing) or another speech service, then try again."))
            return
        }
        release()
        val my = ++token
        val r = try { SpeechRecognizer.createSpeechRecognizer(act) } catch (_: Exception) { null }
        if (r == null) { emit("error", err("unavailable", "Could not start the speech recognition service.")); return }
        sr = r; active = true; lastPartial = ""
        r.setRecognitionListener(Listener(my))
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, lang)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, act.packageName)
        }
        try { r.startListening(i) } catch (e: Exception) {
            token++; active = false; release()
            emit("error", err("recognition", "Could not start listening: ${e.message ?: "unknown error"}"))
        }
    }

    /** Ask the recognizer to finish; the final result still arrives (with a safety timeout). */
    fun stop() {
        if (!active) return
        val my = token
        try { sr?.stopListening() } catch (_: Exception) {}
        main.postDelayed({ if (active && token == my) finishWithPartial() }, 4000)
    }

    /** Abort: discard the current session. The JS side restores the previous text. */
    fun cancel() { if (active) { abort(); emit("cancelled", "") } }

    /** App left the foreground: abort but keep what was heard so far. */
    fun interrupted() { if (active) { val t = lastPartial; abort(); emit("interrupted", t) } }

    fun destroy() { token++; active = false; release() }

    private fun abort() { token++; active = false; try { sr?.cancel() } catch (_: Exception) {}; release() }

    private fun release() {
        val r = sr ?: return
        sr = null
        try { r.setRecognitionListener(null) } catch (_: Exception) {}
        try { r.destroy() } catch (_: Exception) {}
    }

    private fun finishWithPartial() {
        val t = lastPartial; token++; active = false; release()
        if (t.isNotBlank()) emit("final", t) else emit("error", err("nomatch", "I didn't catch that. Tap the mic and try again."))
        emit("end", "")
    }

    private fun err(kind: String, msg: String) = JSONObject().put("kind", kind).put("msg", msg).toString()

    private fun mapError(code: Int): String = when (code) {
        SpeechRecognizer.ERROR_NETWORK_TIMEOUT, SpeechRecognizer.ERROR_NETWORK ->
            err("network", "Network problem. Voice recognition on this device needs an internet connection (or an offline language pack). Check your connection and try again.")
        SpeechRecognizer.ERROR_AUDIO -> err("audio", "Microphone audio error. Make sure no other app is using the microphone.")
        SpeechRecognizer.ERROR_SERVER, 11 -> err("server", "The speech service had a problem. Please try again in a moment.")
        SpeechRecognizer.ERROR_CLIENT -> err("client", "Voice input was interrupted. Please try again.")
        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> err("nomatch", "No speech heard. Tap the mic and speak when you see Listening.")
        SpeechRecognizer.ERROR_NO_MATCH -> err("nomatch", "I couldn't understand that. Please try again.")
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> err("busy", "The speech service is busy. Wait a moment and try again.")
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> err("permission", "Microphone permission is required for voice input.")
        10 -> err("busy", "Too many voice requests. Wait a moment and try again.")
        12, 13 -> err("language", "This language is not supported or not downloaded by the installed speech service. Pick another language, or install it in Android settings (Google app > Voice / Offline speech recognition).")
        else -> err("recognition", "Speech recognition failed (code $code).")
    }

    private inner class Listener(private val my: Int) : RecognitionListener {
        private fun live() = my == token && active
        override fun onReadyForSpeech(p: Bundle?) { if (live()) emit("ready", "") }
        override fun onBeginningOfSpeech() { if (live()) emit("begin", "") }
        private var lastRms = 0L
        override fun onRmsChanged(v: Float) {
            if (!live()) return
            val now = android.os.SystemClock.uptimeMillis()
            if (now - lastRms < 60) return
            lastRms = now
            emit("rms", v.toString())
        }
        override fun onBufferReceived(b: ByteArray?) {}
        override fun onEndOfSpeech() { if (live()) emit("processing", "") }
        override fun onEvent(t: Int, p: Bundle?) {}
        override fun onPartialResults(b: Bundle?) {
            if (!live()) return
            val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
            if (t.isNotBlank()) { lastPartial = t; emit("partial", t) }
        }
        override fun onResults(b: Bundle?) {
            if (!live()) return
            val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty().ifBlank { lastPartial }
            token++; active = false; release()
            if (t.isNotBlank()) emit("final", t) else emit("error", err("nomatch", "I couldn't understand that. Please try again."))
            emit("end", "")
        }
        override fun onError(code: Int) {
            if (!live()) return
            val keep = lastPartial
            token++; active = false; release()
            // Silence / no-match after partial text: keep what we heard instead of failing.
            if ((code == SpeechRecognizer.ERROR_SPEECH_TIMEOUT || code == SpeechRecognizer.ERROR_NO_MATCH) && keep.isNotBlank()) emit("final", keep)
            else emit("error", mapError(code))
            emit("end", "")
        }
    }
}
