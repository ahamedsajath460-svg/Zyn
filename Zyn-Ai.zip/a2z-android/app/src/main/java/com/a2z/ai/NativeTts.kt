package com.a2z.ai

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/**
 * Native Android TextToSpeech (never the browser's speechSynthesis). All public methods MUST be called on the main thread.
 * Text is split into sentence chunks so Pause / Resume work (the Android engine has no real pause: Pause stops at the current
 * chunk and Resume continues from the start of that chunk). Only one utterance chain exists at a time: every new speak() flushes the old one,
 * and a generation token makes late callbacks from a flushed chain harmless, so speech can never overlap.
 * Events to JS through [emit]: state(json {state: idle|speaking|paused, muted, i, n}), error(json {kind,msg}), info(json).
 */
class NativeTts(private val ctx: Context, private val emit: (String, String) -> Unit) {
    private val main = Handler(Looper.getMainLooper())
    private val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var tts: TextToSpeech? = null
    private var ready = false
    private var initializing = false
    private val waiting = ArrayList<() -> Unit>()
    private var chunks: List<String> = emptyList()
    private var idx = 0
    private var gen = 0
    private var state = "idle"
    var muted = false; private set
    private var lang = "en-US"; private var rate = 1f; private var pitch = 1f
    private var voiceName = ""
    private var focus: AudioFocusRequest? = null

    private fun sendState() = emit("state", JSONObject().put("state", state).put("muted", muted).put("i", idx).put("n", chunks.size).toString())
    private fun err(kind: String, msg: String) = emit("error", JSONObject().put("kind", kind).put("msg", msg).toString())

    private fun whenReady(run: () -> Unit) {
        if (ready) { run(); return }
        waiting.add(run)
        if (initializing) return
        initializing = true
        try {
            tts = TextToSpeech(ctx.applicationContext) { status ->
                main.post {
                    initializing = false
                    if (status == TextToSpeech.SUCCESS && tts != null) {
                        ready = true
                        tts!!.setAudioAttributes(AudioAttributes.Builder().setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).setUsage(AudioAttributes.USAGE_MEDIA).build())
                        tts!!.setOnUtteranceProgressListener(listener)
                        val w = ArrayList(waiting); waiting.clear(); w.forEach { it() }
                    } else {
                        waiting.clear(); try { tts?.shutdown() } catch (_: Throwable) { }; tts = null
                        err("init", "Text-to-speech is not available. Install or enable a speech engine (for example Speech Services by Google) in Android Settings, then try again.")
                    }
                }
            }
        } catch (e: Throwable) { initializing = false; waiting.clear(); err("init", "Could not start text-to-speech: ${e.message ?: "unknown error"}") }
    }

    /** Languages for the settings UI: ok | missing (voice data not installed) | unsupported. Delivered as an "info" event. */
    fun info(tags: List<String>) = whenReady {
        val t = tts ?: return@whenReady
        val o = JSONObject()
        tags.forEach { tag ->
            o.put(tag, try {
                when (t.isLanguageAvailable(Locale.forLanguageTag(tag))) {
                    TextToSpeech.LANG_MISSING_DATA -> "missing"
                    TextToSpeech.LANG_NOT_SUPPORTED -> "unsupported"
                    else -> "ok"
                }
            } catch (_: Throwable) { "unsupported" })
        }
        emit("info", o.toString())
    }

    /** Installed voices for a language, delivered as a "voices" event: {lang, voices:[{n,l,q,net}]}. Never throws. */
    fun voices(langTag: String) = whenReady {
        val t = tts ?: return@whenReady
        val arr = JSONArray()
        try {
            val want = Locale.forLanguageTag(langTag).language
            (t.voices ?: emptySet()).filter { v ->
                v.locale.language == want && !v.features.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED)
            }.sortedWith(compareByDescending<android.speech.tts.Voice> { it.quality }.thenBy { it.name }).take(60).forEach { v ->
                arr.put(JSONObject().put("n", v.name).put("l", v.locale.toLanguageTag()).put("q", v.quality).put("net", v.isNetworkConnectionRequired))
            }
        } catch (_: Throwable) { }
        emit("voices", JSONObject().put("lang", langTag).put("voices", arr).toString())
    }

    fun speak(text: String, langTag: String, rate: Float, pitch: Float, voice: String = "") {
        if (muted) { err("muted", "Voice is muted. Tap Unmute to hear answers."); return }
        val parts = split(clean(text))
        if (parts.isEmpty()) return
        halt()                                   // flush whatever is playing: no overlap, ever
        chunks = parts; idx = 0; lang = langTag; voiceName = voice; this.rate = rate.coerceIn(0.4f, 2.5f); this.pitch = pitch.coerceIn(0.5f, 2f)
        val my = ++gen
        whenReady { if (my == gen) begin() }
    }

    /**
     * Adds text to what is being spoken, without flushing: a streamed answer can be spoken sentence by sentence while it is still being
     * written. While speaking the text joins the queue; when idle a fresh chain starts WITHOUT the flush (so no extra "idle" event fires).
     */
    fun append(text: String, langTag: String, rate: Float, pitch: Float, voice: String = "") {
        if (muted) { err("muted", "Voice is muted. Tap Unmute to hear answers."); return }
        val parts = split(clean(text))
        if (parts.isEmpty()) return
        when (state) {
            "speaking" -> chunks = chunks + parts
            "idle" -> {
                chunks = parts; idx = 0; lang = langTag; voiceName = voice; this.rate = rate.coerceIn(0.4f, 2.5f); this.pitch = pitch.coerceIn(0.5f, 2f)
                val my = ++gen
                whenReady { if (my == gen) begin() }
            }
            else -> speak(text, langTag, rate, pitch, voice)
        }
    }

    private fun begin() {
        val t = tts ?: return
        val r = try { t.setLanguage(Locale.forLanguageTag(lang)) } catch (_: Throwable) { TextToSpeech.LANG_NOT_SUPPORTED }
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            chunks = emptyList(); state = "idle"; sendState()
            err("language", if (r == TextToSpeech.LANG_MISSING_DATA) "The voice data for this language is not installed. Open Text-to-speech settings and download it." else "This language is not supported by the installed speech engine. Pick another language or install another engine.")
            return
        }
        if (voiceName.isNotBlank()) {
            // A chosen voice only applies when it still exists and matches the language; otherwise the engine default is kept.
            try {
                val want = Locale.forLanguageTag(lang).language
                t.voices?.firstOrNull { it.name == voiceName && it.locale.language == want }?.let { t.voice = it }
            } catch (_: Throwable) { }
        }
        t.setSpeechRate(rate); t.setPitch(pitch)
        requestFocus(); speakChunk()
    }

    private fun speakChunk() {
        val t = tts ?: return
        if (idx >= chunks.size) { finish(); return }
        state = "speaking"
        val id = "a2z-$gen-$idx"
        val rc = t.speak(chunks[idx], TextToSpeech.QUEUE_FLUSH, Bundle(), id)
        if (rc != TextToSpeech.SUCCESS) { halt(); err("speak", "The speech engine could not start speaking.") } else sendState()
    }

    private val listener = object : UtteranceProgressListener() {
        override fun onStart(id: String?) {}
        override fun onDone(id: String?) {
            val p = id?.split("-") ?: return; if (p.size != 3) return
            val g = p[1].toIntOrNull() ?: return; val i = p[2].toIntOrNull() ?: return
            main.post { if (g == gen && i == idx && state == "speaking") { idx++; speakChunk() } }
        }
        @Deprecated("Deprecated in Java") override fun onError(id: String?) { onError(id, -1) }
        override fun onError(id: String?, code: Int) {
            val g = id?.split("-")?.getOrNull(1)?.toIntOrNull() ?: return
            main.post { if (g == gen) { halt(); err("speak", "Speech failed (engine error $code). Check Text-to-speech settings.") } }
        }
    }

    fun pause() { if (state != "speaking") return; gen++; try { tts?.stop() } catch (_: Throwable) { }; state = "paused"; sendState() }
    fun resume() {
        if (state != "paused" || muted) return
        val my = ++gen; whenReady { if (my == gen) { requestFocus(); speakChunk() } }
    }
    fun stop() { halt() }
    /** Muting stops current speech and blocks new speech until unmuted. It does not resume by itself. */
    fun mute(on: Boolean) { muted = on; if (on) halt() else sendState() }

    private fun halt() {
        gen++; try { tts?.stop() } catch (_: Throwable) { }
        val was = state != "idle"
        chunks = emptyList(); idx = 0; state = "idle"; abandonFocus()
        if (was || true) sendState()
    }
    private fun finish() { chunks = emptyList(); idx = 0; state = "idle"; abandonFocus(); sendState() }

    private fun requestFocus() {
        try {
            val r = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                .setAudioAttributes(AudioAttributes.Builder().setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).setUsage(AudioAttributes.USAGE_MEDIA).build()).build()
            focus = r; am.requestAudioFocus(r)
        } catch (_: Throwable) { }
    }
    private fun abandonFocus() { try { focus?.let { am.abandonAudioFocusRequest(it) } } catch (_: Throwable) { }; focus = null }

    fun destroy() { gen++; abandonFocus(); try { tts?.stop(); tts?.shutdown() } catch (_: Throwable) { }; tts = null; ready = false; initializing = false; waiting.clear(); chunks = emptyList(); state = "idle" }

    // ---- text preparation ----
    private fun clean(t: String): String = t
        .replace(Regex("```[\\s\\S]*?```"), " ")
        .replace(Regex("!?\\[([^\\]]*)]\\([^)]*\\)"), "$1")
        .replace(Regex("[*_`#>|~]+"), " ")
        .replace(Regex("[ \\t]+"), " ").trim().take(12000)

    private fun split(t: String): List<String> {
        if (t.isBlank()) return emptyList()
        val out = ArrayList<String>(); val cur = StringBuilder()
        for (s in t.split(Regex("(?<=[.!?।。])\\s+|\\n+"))) {
            val p = s.trim(); if (p.isEmpty()) continue
            if (cur.length + p.length + 1 > 350 && cur.isNotEmpty()) { out.add(cur.toString()); cur.setLength(0) }
            if (p.length > 350) { p.chunked(350).forEach { out.add(it) } } else { if (cur.isNotEmpty()) cur.append(' '); cur.append(p) }
        }
        if (cur.isNotEmpty()) out.add(cur.toString())
        return out
    }
}
