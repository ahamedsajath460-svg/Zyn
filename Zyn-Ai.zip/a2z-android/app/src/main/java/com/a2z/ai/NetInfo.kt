package com.a2z.ai

import android.content.Context
import android.net.ConnectivityManager

/** Data-saver helper: true when the current connection is metered (mobile data, or Wi-Fi marked as metered). */
object NetInfo {
    @Volatile private var lastAt = 0L
    @Volatile private var lastVal = true

    fun metered(ctx: Context): Boolean {
        val now = System.currentTimeMillis()
        if (now - lastAt < 3000L) return lastVal            // cheap: one system call every few seconds at most
        val v = try {
            val cm = ctx.applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            cm.isActiveNetworkMetered
        } catch (_: Throwable) { true }                       // unknown: be careful with data
        lastVal = v; lastAt = now
        return v
    }
}
