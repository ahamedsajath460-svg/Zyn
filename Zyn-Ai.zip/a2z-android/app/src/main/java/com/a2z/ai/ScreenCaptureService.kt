package com.a2z.ai
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.util.Base64
import android.util.DisplayMetrics
import android.view.WindowManager
import java.io.ByteArrayOutputStream
import kotlin.math.min

/**
 * The single MediaProjection service of the app.
 * - continuous mode (original behaviour, started from the app's "Share screen" dialog): buffers frames while another app is on screen.
 * - manual mode (started from the floating panel): the virtual display is PAUSED between screenshots; a frame is produced only on CAPTURE.
 */
class ScreenCaptureService : Service() {
    companion object {
        const val START = "a2z.start"; const val PAUSE = "a2z.pause"; const val RESUME = "a2z.resume"; const val STOP = "a2z.stop"
        const val CAPTURE = "a2z.capture"
        const val CODE = "code"; const val DATA = "data"; const val INTERVAL = "interval"; const val QUALITY = "quality"; const val MODE = "mode"
        const val MODE_MANUAL = "manual"; const val MODE_CONTINUOUS = "continuous"
        private const val CH = "a2z_share"; private const val NID = 7
    }
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private var intervalMs = 1000L; private var quality = 75; private var last = 0L
    private var rw = 0; private var rh = 0
    private var wantShot = false; private var attempts = 0; private var shotQuality = 70
    private val timeoutRun = Runnable { onShotTimeout() }

    override fun onBind(i: Intent?) = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val ii = i ?: return START_NOT_STICKY
        when (ii.action) {
            START -> start(ii)
            PAUSE -> { FrameStore.state = "paused"; notifyNow() }
            RESUME -> { FrameStore.state = "running"; notifyNow() }
            STOP -> stopSelf()
            CAPTURE -> capture(ii.getIntExtra(QUALITY, 70))
        }
        return START_NOT_STICKY
    }

    private fun start(i: Intent) {
        FrameStore.mode = if (i.getStringExtra(MODE) == MODE_MANUAL) MODE_MANUAL else MODE_CONTINUOUS
        intervalMs = i.getIntExtra(INTERVAL, 1000).toLong().coerceIn(250, 60000)
        quality = i.getIntExtra(QUALITY, 75).coerceIn(30, 95)
        createChannel()
        val n = notif()
        // Must be foreground BEFORE obtaining the projection (required on Android 10+/14).
        if (Build.VERSION.SDK_INT >= 29) startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION) else startForeground(NID, n)
        if (projection != null) { applyMode(); notifyNow(); return }   // already capturing: only switch mode, never a second projection
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra(DATA, Intent::class.java) else @Suppress("DEPRECATION") i.getParcelableExtra(DATA)
        if (data == null) { stopSelf(); return }
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        thread = HandlerThread("a2z-capture").also { it.start() }
        val h = Handler(thread!!.looper); handler = h
        projection = mpm.getMediaProjection(i.getIntExtra(CODE, Activity.RESULT_CANCELED), data)
        projection!!.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stopSelf() } }, h)

        val dm = DisplayMetrics()
        @Suppress("DEPRECATION") (getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(dm)
        // Cap at 720p-class: short side <= 720 and long side <= 1280 (Nova 2i 1080x2160 -> 640x1280)
        // On mobile data (metered) use a smaller frame: ~35% fewer pixels, so less upload and faster AI answers.
        val mShort = if (NetInfo.metered(this)) 576f else 720f; val mLong = if (NetInfo.metered(this)) 1024f else 1280f
        val s = min(1f, min(mShort / min(dm.widthPixels, dm.heightPixels), mLong / maxOf(dm.widthPixels, dm.heightPixels)))
        rw = (dm.widthPixels * s).toInt().coerceAtLeast(2) and 1.inv()
        rh = (dm.heightPixels * s).toInt().coerceAtLeast(2) and 1.inv()
        reader = ImageReader.newInstance(rw, rh, PixelFormat.RGBA_8888, 2)
        display = projection!!.createVirtualDisplay("a2z-share", rw, rh, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, h)
        reader!!.setOnImageAvailableListener({ r -> onImage(r) }, h)
        applyMode()
        FrameStore.state = "running"; notifyNow()
    }

    /** Manual mode: virtual display paused (no surface) = no GPU/CPU work between screenshots. Continuous mode: always rendering. */
    private fun applyMode() {
        val d = display ?: return; val r = reader ?: return
        try { d.setSurface(if (FrameStore.mode == MODE_MANUAL) null else r.surface) } catch (_: Throwable) { }
    }

    private fun onImage(r: ImageReader) {
        val img = r.acquireLatestImage() ?: return
        try {
            if (wantShot) {
                wantShot = false; handler?.removeCallbacks(timeoutRun)
                val (bytes, blank) = encode(img, shotQuality)
                if (FrameStore.mode == MODE_MANUAL) applyMode()
                FrameStore.onShot?.invoke(Shot(bytes, rw, rh, blank, null))
                return
            }
            if (FrameStore.mode == MODE_MANUAL) return
            val now = SystemClock.elapsedRealtime()
            if (FrameStore.state != "running" || FrameStore.appForeground || now - last < intervalMs) return
            last = now
            if (FrameStore.privacy) return
            val (jb, blank) = encode(img, quality)
            if (blank) { FrameStore.protectedHits++; return }   // protected (FLAG_SECURE) or black screen: never stored, never bypassed
            val b64 = Base64.encodeToString(jb, Base64.NO_WRAP)
            FrameStore.add(b64)
            if (FrameStore.autoOcr) ScreenOcr.submit(b64)
        } catch (_: Throwable) { } finally { img.close() }
    }

    private fun encode(img: Image, q: Int): Pair<ByteArray, Boolean> {
        val p = img.planes[0]; val pad = p.rowStride - p.pixelStride * rw
        val full = Bitmap.createBitmap(rw + pad / p.pixelStride, rh, Bitmap.Config.ARGB_8888)
        full.copyPixelsFromBuffer(p.buffer)
        val crop = Bitmap.createBitmap(full, 0, 0, rw, rh)
        val blank = looksBlank(crop)
        val out = ByteArrayOutputStream(128 * 1024)
        crop.compress(Bitmap.CompressFormat.JPEG, if (NetInfo.metered(this)) min(q, 62) else q, out)
        if (crop !== full) crop.recycle(); full.recycle()
        return out.toByteArray() to blank
    }

    /** A fully black frame usually means a protected (FLAG_SECURE / DRM) window. Android blanks those on purpose; we never try to bypass it. */
    private fun looksBlank(b: Bitmap): Boolean {
        val sx = (b.width / 24).coerceAtLeast(1); val sy = (b.height / 24).coerceAtLeast(1)
        var y = 0
        while (y < b.height) {
            var x = 0
            while (x < b.width) {
                val c = b.getPixel(x, y)
                if (((c shr 16) and 0xFF) > 12 || ((c shr 8) and 0xFF) > 12 || (c and 0xFF) > 12) return false
                x += sx
            }
            y += sy
        }
        return true
    }

    // ---------------- one-shot capture (floating panel) ----------------
    private fun fail(msg: String) { FrameStore.onShot?.invoke(Shot(null, 0, 0, false, msg)) }

    private fun capture(q: Int) {
        val h = handler
        if (h == null || display == null || projection == null) { fail("Screen capture is not active. Tap Capture Screen to start it."); return }
        if (FrameStore.state == "paused") { fail("Screen capture is paused. Tap Resume first."); return }
        shotQuality = q.coerceIn(40, 90)
        h.post { if (wantShot) return@post; attempts = 0; requestFrame() }
    }

    private fun requestFrame() {
        val h = handler ?: return; val d = display ?: return; val r = reader ?: return
        wantShot = true
        try {
            d.setSurface(null)                                         // detach, drop any stale buffered frame, re-attach => one fresh frame
            while (true) { val old = r.acquireLatestImage() ?: break; old.close() }
            d.setSurface(r.surface)
        } catch (e: Throwable) { wantShot = false; applyMode(); fail("Could not take the screenshot: " + (e.message ?: "unknown error")); return }
        h.postDelayed(timeoutRun, 1500)
    }

    private fun onShotTimeout() {
        if (!wantShot) return
        if (++attempts < 2) { requestFrame(); return }
        wantShot = false
        if (FrameStore.mode == MODE_MANUAL) applyMode()
        fail("No screen image was received from Android. Try again.")
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
            .createNotificationChannel(NotificationChannel(CH, "Screen sharing", NotificationManager.IMPORTANCE_LOW))
    }
    private fun act(a: String, label: String): Notification.Action {
        val pi = PendingIntent.getService(this, a.hashCode(), Intent(this, ScreenCaptureService::class.java).setAction(a),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return Notification.Action.Builder(null, label, pi).build()
    }
    private fun notif(): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), PendingIntent.FLAG_IMMUTABLE)
        val paused = FrameStore.state == "paused"
        val manual = FrameStore.mode == MODE_MANUAL
        return Notification.Builder(this, CH).setSmallIcon(android.R.drawable.presence_video_online)
            .setContentTitle(if (paused) "Screen sharing paused" else if (manual) "Zyn Ai screen capture is on" else "Zyn Ai is sharing your screen")
            .setContentText(if (manual) "A screenshot is taken only when you tap Capture in the panel." else "Frames stay on this device until you ask a question.")
            .setOngoing(true).setContentIntent(open)
            .addAction(if (paused) act(RESUME, "Resume") else act(PAUSE, "Pause")).addAction(act(STOP, "Stop")).build()
    }
    private fun notifyNow() = (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(NID, notif())

    override fun onDestroy() {
        val pending = wantShot; wantShot = false
        handler?.removeCallbacksAndMessages(null)
        if (pending) fail("Screen capture was stopped.")
        FrameStore.state = "stopped"; FrameStore.clear(); FrameStore.mode = MODE_CONTINUOUS; FrameStore.privacy = false; FrameStore.autoOcr = false
        Handler(Looper.getMainLooper()).post { HighlightOverlay.hide() }
        runCatching { reader?.setOnImageAvailableListener(null, null) }
        runCatching { display?.release() }; runCatching { reader?.close() }
        runCatching { projection?.stop() }; thread?.quitSafely()
        projection = null; display = null; reader = null; handler = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }
}
