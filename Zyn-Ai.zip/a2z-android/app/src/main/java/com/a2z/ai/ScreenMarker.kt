package com.a2z.ai

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import kotlin.math.max
import kotlin.math.sin

/**
 * "Circle it for me": draws a pulsing ring around one place on the screen for a few seconds so the user can SEE where something is
 * (the agent's `highlight` action, e.g. "screen la WhatsApp enga irukku circle pottu kaattu").
 *
 * It only draws. The window is a TYPE_ACCESSIBILITY_OVERLAY owned by the accessibility service (no extra permission), FLAG_NOT_TOUCHABLE and
 * not important for accessibility, so it never receives or blocks a touch, never changes the app below and is never part of the UI the
 * agent reads. It removes itself after [SHOW_MS]. Same window approach as [TouchIndicator].
 */
object ScreenMarker {
    const val SHOW_MS = 6000L
    private val main = Handler(Looper.getMainLooper())
    private var wm: WindowManager? = null
    private var view: MarkView? = null
    private val removeTask = Runnable { removeNow() }

    /** Any thread. Shows a ring around [target] (real screen pixels). Returns false when the overlay window could not be added. */
    fun show(s: AccessibilityService, target: Rect): Boolean {
        if (target.width() <= 0 || target.height() <= 0) return false
        val ok = BooleanArray(1)
        val latch = java.util.concurrent.CountDownLatch(1)
        main.post {
            try {
                main.removeCallbacks(removeTask)
                val v = ensure(s)
                if (v != null) { v.begin(RectF(target)); ok[0] = true; main.postDelayed(removeTask, SHOW_MS) }
            } catch (_: Throwable) { ok[0] = false } finally { latch.countDown() }
        }
        try { latch.await(1500, java.util.concurrent.TimeUnit.MILLISECONDS) } catch (_: InterruptedException) { Thread.currentThread().interrupt() }
        return ok[0]
    }

    /** Any thread. Removes the ring at once (Stop, accessibility turned off). */
    fun hide() { main.post { main.removeCallbacks(removeTask); removeNow() } }

    private fun removeNow() {
        val v = view ?: return
        try { wm?.removeView(v) } catch (_: Throwable) { }
        view = null
    }

    private fun ensure(s: AccessibilityService): MarkView? {
        view?.let { return it }
        val w = s.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val v = MarkView(s)
        v.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED, PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            if (Build.VERSION.SDK_INT >= 28) layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            title = "ZynScreenMarker"
        }
        return try { w.addView(v, p); wm = w; view = v; v } catch (_: Throwable) { null }
    }

    /** Ring geometry for a target box: an oval that clearly encloses the box, never thinner than a fingertip. */
    fun ringFor(target: RectF, density: Float): RectF {
        val pad = 10f * density
        val w = max(target.width() + 2 * pad, 56f * density)
        val h = max(target.height() + 2 * pad, 56f * density)
        // an oval through the corners of the box needs sqrt(2) times the half-size, so the ring really goes AROUND the target
        val rx = w / 2f * 1.2f; val ry = h / 2f * 1.2f
        return RectF(target.centerX() - rx, target.centerY() - ry, target.centerX() + rx, target.centerY() + ry)
    }

    private class MarkView(c: Context) : View(c) {
        private val d = c.resources.displayMetrics.density
        private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        private val loc = IntArray(2)
        private var ring: RectF? = null
        private var t0 = 0L

        fun begin(target: RectF) { ring = ringFor(target, d); t0 = SystemClock.uptimeMillis(); invalidate() }

        override fun onDraw(c: Canvas) {
            val r = ring ?: return
            val now = SystemClock.uptimeMillis(); val age = now - t0
            if (age > SHOW_MS) { ring = null; return }
            // fade in over 200 ms, fade out over the last 500 ms
            val a = minOf(age / 200f, (SHOW_MS - age) / 500f, 1f).coerceIn(0f, 1f)
            getLocationOnScreen(loc); c.save(); c.translate(-loc[0].toFloat(), -loc[1].toFloat())       // draw in true screen pixels
            val pulse = 1f + 0.06f * sin(age / 160f)
            val cx = r.centerX(); val cy = r.centerY()
            val rr = RectF(cx - r.width() / 2 * pulse, cy - r.height() / 2 * pulse, cx + r.width() / 2 * pulse, cy + r.height() / 2 * pulse)
            fill.color = Color.argb((40 * a).toInt(), 255, 64, 64); c.drawOval(rr, fill)
            line.color = Color.argb((255 * a).toInt(), 255, 255, 255); line.strokeWidth = 9f * d; c.drawOval(rr, line)     // white edge for contrast on any background
            line.color = Color.argb((255 * a).toInt(), 229, 57, 53); line.strokeWidth = 5f * d; c.drawOval(rr, line)
            c.restore()
            postInvalidateOnAnimation()
        }
    }
}
