package com.a2z.ai

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.util.Base64
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.Executors

/**
 * On-device OCR (Google ML Kit, bundled models: no network, no API request) + change detection + privacy redaction.
 * Everything here is in memory only. [reset] wipes all of it and is called whenever screen sharing stops.
 *
 * ML Kit's on-device recognizers cover Latin and Devanagari (Hindi). Tamil and Sinhala are NOT supported on-device;
 * for those the UI offers an explicit "AI read" using the user's own vision model, and says so.
 */
object ScreenOcr {
    private val exec = Executors.newSingleThreadExecutor { r -> Thread(r, "a2z-ocr").also { it.isDaemon = true } }
    @Volatile private var busy = false
    private var latin: TextRecognizer? = null
    private var deva: TextRecognizer? = null

    // frame change detection
    private var prevHash: LongArray? = null
    private var prevTokens: Set<String> = emptySet()
    private val cache = object : LinkedHashMap<String, String>(8, 0.75f, true) { override fun removeEldestEntry(e: MutableMap.MutableEntry<String, String>?) = size > 4 }
    @Volatile var latest: String? = null; private set          // last result JSON (used by the highlight overlay and the auto mode)
    @Volatile var changedSinceRead = false                       // set by auto mode when the screen changed meaningfully

    private fun rec(deva: Boolean): TextRecognizer = synchronized(this) {
        if (deva) this.deva ?: TextRecognition.getClient(DevanagariTextRecognizerOptions.Builder().build()).also { this.deva = it }
        else this.latin ?: TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).also { this.latin = it }
    }

    /** 16x16 average hash (256 bits). Hamming distance <= 8 bits = "same screen". */
    private fun aHash(b: Bitmap): LongArray {
        val s = Bitmap.createScaledBitmap(b, 16, 16, true)
        val g = IntArray(256); var sum = 0
        for (i in 0 until 256) { val c = s.getPixel(i % 16, i / 16); g[i] = (Color.red(c) * 3 + Color.green(c) * 6 + Color.blue(c)) / 10; sum += g[i] }
        if (s !== b) s.recycle()
        val avg = sum / 256; val h = LongArray(4)
        for (i in 0 until 256) if (g[i] > avg) h[i / 64] = h[i / 64] or (1L shl (i % 64))
        return h
    }
    private fun dist(a: LongArray, b: LongArray): Int { var d = 0; for (i in 0 until 4) d += java.lang.Long.bitCount(a[i] xor b[i]); return d }
    private fun hex(h: LongArray) = h.joinToString("") { java.lang.Long.toHexString(it) }

    // ---------------- privacy: what counts as sensitive ----------------
    private val kwOtp = Regex("(?i)\\b(otp|one[- ]?time|verification code|security code|auth(entication)? code|passcode|pin|cvv|cvc)\\b")
    private val kwPwd = Regex("(?i)\\b(password|passwd|pwd|secret|api[ _-]?key|access token|recovery phrase|seed phrase|private key)\\b")
    private val masked = Regex("^[\\s•●*·∙x]{4,}$")
    private val token = Regex("[A-Za-z0-9_\\-]{32,}")
    private val email = Regex("[A-Za-z0-9._%+\\-]+@[A-Za-z0-9.\\-]+\\.[A-Za-z]{2,}")
    private val phone = Regex("\\+?\\d[\\d\\s\\-()]{8,}\\d")
    private val codeOnly = Regex("^\\s*\\d{4,8}\\s*$")

    private fun luhn(d: String): Boolean {
        var sum = 0; var alt = false
        for (i in d.length - 1 downTo 0) { var n = d[i] - '0'; if (alt) { n *= 2; if (n > 9) n -= 9 }; sum += n; alt = !alt }
        return sum % 10 == 0
    }
    private fun cardLike(t: String): Boolean {
        val m = Regex("(?:\\d[ -]?){13,19}").findAll(t)
        for (x in m) { val d = x.value.filter { it.isDigit() }; if (d.length in 13..19 && luhn(d)) return true }
        return false
    }

    /** Indices of lines that must not leave the device: card numbers, OTP/PIN codes, passwords and their values, tokens, emails, phone numbers. */
    private fun sensitiveLines(lines: List<String>): Set<Int> {
        val out = HashSet<Int>()
        for (i in lines.indices) {
            val t = lines[i]
            val digits = t.count { it.isDigit() }
            val hit = cardLike(t) || masked.matches(t.trim()) || token.containsMatchIn(t) || email.containsMatchIn(t) ||
                (phone.containsMatchIn(t) && digits >= 9) ||
                (kwOtp.containsMatchIn(t) && digits >= 4) || kwPwd.containsMatchIn(t)
            if (hit) {
                out.add(i)
                // the value of "Password:" / "Enter OTP" is often on the next line
                if ((kwPwd.containsMatchIn(t) || kwOtp.containsMatchIn(t)) && i + 1 < lines.size && lines[i + 1].length <= 40) out.add(i + 1)
            }
            if (codeOnly.matches(t) && i > 0 && kwOtp.containsMatchIn(lines[i - 1])) out.add(i)
        }
        return out
    }

    private fun box(r: Rect?): JSONArray = JSONArray().apply { if (r == null) { put(0); put(0); put(0); put(0) } else { put(r.left); put(r.top); put(r.right); put(r.bottom) } }

    private fun scriptOf(t: String): String {
        var ta = 0; var si = 0; var de = 0; var la = 0
        for (c in t) when (c.code) { in 0x0B80..0x0BFF -> ta++; in 0x0D80..0x0DFF -> si++; in 0x0900..0x097F -> de++; in 0x41..0x7A -> la++ }
        val m = maxOf(ta, si, de, la); if (m == 0) return "none"
        return when (m) { de -> "devanagari"; ta -> "tamil"; si -> "sinhala"; else -> "latin" }
    }

    /**
     * Blocking: call from a worker thread (JavascriptInterface threads and [exec] qualify), never the main thread.
     * [script]: "auto" | "latin" | "devanagari". [redact]: black out and strip sensitive lines.
     */
    @Synchronized fun analyze(b64: String, script: String, redact: Boolean): String {
        val bytes = Base64.decode(b64, Base64.NO_WRAP)
        val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return JSONObject().put("ok", false).put("error", "Could not read the captured frame.").toString()
        try {
            val h = aHash(bmp); val key = hex(h) + "|" + script + "|" + redact
            cache[key]?.let { c -> val j = JSONObject(c).put("cached", true).put("changed", false).put("textChanged", false).toString(); latest = j; return j }
            val img = InputImage.fromBitmap(bmp, 0)
            var res: Text = Tasks.await(rec(script == "devanagari").process(img))
            var used = if (script == "devanagari") "devanagari" else "latin"
            if (script == "auto" && res.text.trim().length < 8) {
                val r2 = Tasks.await(rec(true).process(img))
                if (r2.text.trim().length > res.text.trim().length) { res = r2; used = "devanagari" }
            }
            // flatten: blocks -> lines (ML Kit already returns reading order; lines inside a block are sorted top to bottom)
            class L(val t: String, val r: Rect?, val b: Int)
            val all = ArrayList<L>()
            res.textBlocks.forEachIndexed { bi, b -> b.lines.sortedBy { it.boundingBox?.top ?: 0 }.forEach { all.add(L(it.text, it.boundingBox, bi)) } }
            val sens = if (redact) sensitiveLines(all.map { it.t }) else emptySet()
            val safeBmp: Bitmap? = if (sens.isNotEmpty()) bmp.copy(Bitmap.Config.ARGB_8888, true) else null
            if (safeBmp != null) {
                val c = Canvas(safeBmp); val p = Paint().apply { color = Color.BLACK; style = Paint.Style.FILL }
                sens.forEach { i -> all[i].r?.let { r -> c.drawRect(Rect(r.left - 6, r.top - 6, r.right + 6, r.bottom + 6), p) } }
            }
            val blocks = JSONArray(); val text = StringBuilder(); val safe = StringBuilder()
            var i = 0
            res.textBlocks.forEachIndexed { bi, b ->
                val lines = JSONArray(); val bt = StringBuilder(); val bs = StringBuilder()
                while (i < all.size && all[i].b == bi) {
                    val l = all[i]; val red = i in sens
                    lines.put(JSONObject().put("t", if (red) "[hidden]" else l.t).put("box", box(l.r)).put("red", red))
                    if (bt.isNotEmpty()) bt.append('\n'); bt.append(l.t)
                    if (!red) { if (bs.isNotEmpty()) bs.append('\n'); bs.append(l.t) }
                    i++
                }
                blocks.put(JSONObject().put("t", if (bs.isEmpty() && bt.isNotEmpty()) "[hidden]" else bs.toString()).put("box", box(b.boundingBox)).put("lines", lines))
                if (text.isNotEmpty()) text.append("\n\n"); text.append(bt)
                if (bs.isNotEmpty()) { if (safe.isNotEmpty()) safe.append("\n\n"); safe.append(bs) }
            }
            val toks = safe.toString().lowercase().split(Regex("\\W+")).filter { it.length > 2 }.toSet()
            val un = (toks union prevTokens).size.coerceAtLeast(1)
            val textSim = (toks intersect prevTokens).size.toDouble() / un
            val ph = prevHash
            val changed = ph == null || dist(ph, h) > 8
            val textChanged = ph == null || textSim < 0.9
            prevHash = h; prevTokens = toks
            val o = JSONObject().put("ok", true).put("hash", hex(h)).put("cached", false).put("changed", changed).put("textChanged", textChanged)
                .put("w", bmp.width).put("h", bmp.height).put("engine", used).put("lang", scriptOf(text.toString()))
                .put("blocks", blocks).put("text", if (redact) safe.toString() else text.toString()).put("safeText", safe.toString())
                .put("redacted", sens.size)
            if (safeBmp != null) {
                val out = ByteArrayOutputStream(96 * 1024); safeBmp.compress(Bitmap.CompressFormat.JPEG, 70, out); safeBmp.recycle()
                o.put("jpeg", Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP))
            }
            if (text.isBlank()) o.put("note", "No text was recognised on this screen. If it is Tamil or Sinhala, on-device OCR does not support those scripts: use \"AI read\" with a vision model instead.")
            val s = o.toString()
            cache[key] = s; latest = s
            return s
        } catch (e: Throwable) {
            return JSONObject().put("ok", false).put("error", "OCR failed: " + (e.message ?: e.javaClass.simpleName)).toString()
        } finally { bmp.recycle() }
    }

    /** Auto mode: called for every stored frame; runs at most one OCR at a time and skips frames that arrive meanwhile. */
    fun submit(b64: String) {
        if (busy) return
        busy = true
        exec.execute {
            try { val r = JSONObject(analyze(b64, "auto", true)); if (r.optBoolean("ok") && !r.optBoolean("cached") && r.optBoolean("textChanged")) changedSinceRead = true }
            catch (_: Throwable) { } finally { busy = false }
        }
    }

    /** Wipes every OCR result, hash and cache. Called when sharing stops. */
    @Synchronized fun reset() {
        cache.clear(); latest = null; prevHash = null; prevTokens = emptySet(); changedSinceRead = false
        try { latin?.close() } catch (_: Throwable) { }; try { deva?.close() } catch (_: Throwable) { }
        latin = null; deva = null
    }
}
