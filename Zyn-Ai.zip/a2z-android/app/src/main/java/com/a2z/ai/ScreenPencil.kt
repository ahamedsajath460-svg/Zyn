package com.a2z.ai

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * "Pencil" for Ask screen: a full-screen, transparent overlay the user draws on (pen, marker, highlighter, box, eraser) to point at
 * something on their own screen. The strokes are kept as vectors, so they can be erased / undone, drawn again on top of a clean
 * screenshot, and turned into a bounding box that tells the AI WHAT to focus on.
 *
 * Main thread only (except the immutable [Stroke] / [Marks] values, which are safe to hand to a worker thread).
 * The window sits below the floating panel (the controller raises the panel after [show]). It never reads or clicks other apps.
 */
class ScreenPencil(private val ctx: Context, private val wm: WindowManager) {
    class Stroke(val tool: String, val color: Int, val width: Float, val pts: FloatArray)
    /** Immutable copy of everything drawn, plus where the overlay sits on the screen (px) so strokes can be mapped onto a screenshot. */
    class Marks(val strokes: List<Stroke>, val offX: Int, val offY: Int, val w: Int, val h: Int)

    companion object {
        const val PEN = "pen"; const val MARKER = "marker"; const val HL = "hl"; const val BOX = "box"; const val ERASER = "eraser"
        val TOOLS = setOf(PEN, MARKER, HL, BOX, ERASER)

        /** Paint for one stroke. [px] converts dp to px of the surface it is drawn on. */
        private fun paintFor(s: Stroke, fill: Boolean): Paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
            if (fill) { style = Paint.Style.FILL; color = (s.color and 0xFFFFFF) or (0x2E shl 24) }
            else {
                style = Paint.Style.STROKE; strokeWidth = s.width
                color = if (s.tool == HL) (s.color and 0xFFFFFF) or (0x78 shl 24) else (s.color or (0xFF shl 24))
            }
        }

        fun render(c: Canvas, strokes: List<Stroke>) {
            for (s in strokes) {
                val p = s.pts; if (p.size < 2) continue
                if (s.tool == BOX) {
                    if (p.size < 4) continue
                    val r = RectF(min(p[0], p[2]), min(p[1], p[3]), max(p[0], p[2]), max(p[1], p[3]))
                    c.drawRoundRect(r, s.width * 1.5f, s.width * 1.5f, paintFor(s, true))
                    c.drawRoundRect(r, s.width * 1.5f, s.width * 1.5f, paintFor(s, false))
                    continue
                }
                if (p.size == 2) { c.drawCircle(p[0], p[1], s.width / 2f, Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = paintFor(s, false).color }); continue }
                val path = Path(); path.moveTo(p[0], p[1])
                var i = 2
                while (i + 1 < p.size) {
                    val px = p[i - 2]; val py = p[i - 1]; val x = p[i]; val y = p[i + 1]
                    path.quadTo(px, py, (px + x) / 2f, (py + y) / 2f); i += 2
                }
                path.lineTo(p[p.size - 2], p[p.size - 1])
                c.drawPath(path, paintFor(s, false))
            }
        }

        /** Union of all strokes in the overlay's own pixel space (stroke thickness included), or null when nothing is drawn. */
        fun bounds(strokes: List<Stroke>): RectF? {
            var r: RectF? = null
            for (s in strokes) {
                val p = s.pts; var i = 0
                val h = s.width / 2f
                while (i + 1 < p.size) {
                    val b = RectF(p[i] - h, p[i + 1] - h, p[i] + h, p[i + 1] + h)
                    if (r == null) r = RectF(b) else r.union(b)
                    i += 2
                }
            }
            return r
        }
    }

    var tool: String = PEN; private set
    var color: Int = Color.parseColor("#FF3B30"); private set
    var onChange: (() -> Unit)? = null
    val count: Int get() = strokes.size
    val showing: Boolean get() = layer != null

    private val d = ctx.resources.displayMetrics.density
    private val strokes = ArrayList<Stroke>()
    private val history = ArrayList<List<Stroke>>()
    private var layer: Layer? = null
    private val ui = Handler(Looper.getMainLooper())

    private fun widthOf(t: String) = when (t) { HL -> 20f * d; MARKER -> 9f * d; BOX -> 3.5f * d; else -> 3.5f * d }

    fun show() {
        if (layer != null) return
        val l = Layer()
        val lp = WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START; title = "ZynPencil"
            if (Build.VERSION.SDK_INT >= 28) layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        wm.addView(l, lp); layer = l
        l.hint = true; ui.postDelayed({ layer?.let { it.hint = false; it.invalidate() } }, 2600)
    }

    fun hide() {
        ui.removeCallbacksAndMessages(null)
        val l = layer ?: return
        layer = null
        try { wm.removeViewImmediate(l) } catch (_: Throwable) { }
        strokes.clear(); history.clear()
    }

    fun setTool(t: String, c: Int) { if (t in TOOLS) tool = t; color = c; layer?.invalidate() }

    fun undo() {
        if (history.isEmpty()) return
        strokes.clear(); strokes.addAll(history.removeAt(history.size - 1)); changed()
    }

    fun clear() {
        if (strokes.isEmpty()) return
        push(); strokes.clear(); changed()
    }

    /** Strokes must not appear in the clean screenshot: the window is made invisible for the shot and shown again afterwards. */
    fun cloak(on: Boolean) { layer?.visibility = if (on) View.INVISIBLE else View.VISIBLE }

    fun snapshot(): Marks? {
        val l = layer ?: return null
        if (strokes.isEmpty()) return null
        val loc = IntArray(2); l.getLocationOnScreen(loc)
        return Marks(ArrayList(strokes), loc[0], loc[1], l.width, l.height)
    }

    private fun push() { history.add(ArrayList(strokes)); while (history.size > 40) history.removeAt(0) }
    private fun changed() { layer?.invalidate(); try { onChange?.invoke() } catch (_: Throwable) { } }

    private inner class Layer : View(ctx) {
        var hint = false
        private val cur = ArrayList<Float>()
        private var curTool = PEN; private var curColor = Color.RED
        private var active = false; private var activeId = -1
        private var erased = false; private var snap: List<Stroke>? = null
        private var ex = 0f; private var ey = 0f; private var eraserOn = false
        private val eraserR = 16f * d
        private val border = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 3f * d; color = Color.argb(150, 124, 77, 255) }
        private val pill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = Color.argb(215, 30, 30, 40) }
        private val pillTx = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 13f * d; textAlign = Paint.Align.CENTER }
        private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1.5f * d; color = Color.argb(220, 255, 255, 255) }

        override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
            super.onSizeChanged(w, h, ow, oh)
            if (ow > 0 && oh > 0 && (ow != w || oh != h) && strokes.isNotEmpty()) { strokes.clear(); history.clear(); changed() }   // rotated: old strokes no longer line up
        }

        override fun onDraw(c: Canvas) {
            val b = border.strokeWidth / 2f
            c.drawRect(b, b, width - b, height - b, border)
            render(c, strokes)
            if (active && curTool != ERASER && cur.size >= 2) render(c, listOf(Stroke(curTool, curColor, widthOf(curTool), cur.toFloatArray())))
            if (eraserOn) c.drawCircle(ex, ey, eraserR, ring)
            if (hint) {
                val tx = "✏  Pencil on: mark the screen, then ask"
                val w = pillTx.measureText(tx) + 28f * d; val h = 34f * d; val top = 70f * d
                c.drawRoundRect(width / 2f - w / 2f, top, width / 2f + w / 2f, top + h, h / 2f, h / 2f, pill)
                c.drawText(tx, width / 2f, top + h / 2f + 4.5f * d, pillTx)
            }
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    activeId = e.getPointerId(0); active = true; hint = false
                    curTool = tool; curColor = color; cur.clear(); erased = false
                    val x = e.x; val y = e.y
                    if (curTool == ERASER) { snap = ArrayList(strokes); ex = x; ey = y; eraserOn = true; eraseAlong(x, y, x, y) }
                    else { cur.add(x); cur.add(y); if (curTool == BOX) { cur.add(x); cur.add(y) } }
                    invalidate()
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!active) return true
                    val i = e.findPointerIndex(activeId); if (i < 0) return true
                    for (h in 0 until e.historySize) move(e.getHistoricalX(i, h), e.getHistoricalY(i, h))
                    move(e.getX(i), e.getY(i))
                    invalidate()
                }
                MotionEvent.ACTION_POINTER_UP -> { /* a second finger is ignored */ }
                MotionEvent.ACTION_UP -> { if (active) { finish(true) } }
                MotionEvent.ACTION_CANCEL -> { if (active) finish(false) }
            }
            return true
        }

        private fun move(x: Float, y: Float) {
            if (curTool == ERASER) { eraseAlong(ex, ey, x, y); ex = x; ey = y; return }
            if (curTool == BOX) { cur[2] = x; cur[3] = y; return }
            val n = cur.size
            if (n >= 2 && abs(cur[n - 2] - x) < 1.2f && abs(cur[n - 1] - y) < 1.2f) return
            cur.add(x); cur.add(y)
        }

        private fun finish(commit: Boolean) {
            active = false; eraserOn = false
            if (curTool == ERASER) {
                if (commit && erased) { snap?.let { history.add(it); while (history.size > 40) history.removeAt(0) }; changed() }
                snap = null; invalidate(); return
            }
            if (commit && cur.size >= 2) {
                val keep = if (curTool == BOX) (abs(cur[2] - cur[0]) > 8f * d || abs(cur[3] - cur[1]) > 8f * d) else true
                if (keep) { push(); strokes.add(Stroke(curTool, curColor, widthOf(curTool), cur.toFloatArray())); changed() }
            }
            cur.clear(); invalidate()
        }

        /** Removes every stroke the eraser touches while it moves from (ax,ay) to (bx,by). */
        private fun eraseAlong(ax: Float, ay: Float, bx: Float, by: Float) {
            val steps = max(1, ceil(hypot(bx - ax, by - ay) / (eraserR / 2f)).toInt())
            val it = strokes.iterator()
            while (it.hasNext()) {
                val s = it.next(); var hit = false
                for (k in 0..steps) {
                    val t = k.toFloat() / steps
                    if (touches(s, ax + (bx - ax) * t, ay + (by - ay) * t)) { hit = true; break }
                }
                if (hit) { it.remove(); erased = true }
            }
        }

        private fun touches(s: Stroke, x: Float, y: Float): Boolean {
            val p = s.pts; val reach = eraserR + s.width / 2f
            if (s.tool == BOX && p.size >= 4) {
                val l = min(p[0], p[2]) - eraserR; val r = max(p[0], p[2]) + eraserR; val t = min(p[1], p[3]) - eraserR; val b = max(p[1], p[3]) + eraserR
                return x in l..r && y in t..b
            }
            if (p.size == 2) return hypot(x - p[0], y - p[1]) <= reach
            var i = 0
            while (i + 3 < p.size) { if (segDist(x, y, p[i], p[i + 1], p[i + 2], p[i + 3]) <= reach) return true; i += 2 }
            return false
        }

        private fun segDist(px: Float, py: Float, ax: Float, ay: Float, bx: Float, by: Float): Float {
            val dx = bx - ax; val dy = by - ay; val len2 = dx * dx + dy * dy
            if (len2 == 0f) return hypot(px - ax, py - ay)
            val t = (((px - ax) * dx + (py - ay) * dy) / len2).coerceIn(0f, 1f)
            return hypot(px - (ax + t * dx), py - (ay + t * dy))
        }
    }
}
