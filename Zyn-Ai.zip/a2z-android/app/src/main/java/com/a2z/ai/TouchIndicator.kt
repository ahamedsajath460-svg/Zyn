package com.a2z.ai

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import kotlin.math.sin

/**
 * One phase of a REAL gesture, described with exactly the numbers handed to dispatchGesture(), so the indicator draws what Android is
 * really doing: same screen pixels, same duration, same path. [first]/[last] split a two-part gesture (drag = hold, then move).
 */
class TouchSpec(
    val kind: String,                 // tap | double_tap | long_press | swipe | drag
    val x1: Int, val y1: Int,
    val x2: Int = x1, val y2: Int = y1,
    val durationMs: Long,             // same as the stroke duration
    val bounds: Rect? = null,         // element touched at the start (highlighted)
    val bounds2: Rect? = null,        // element under the end point (drag target, highlighted when the finger arrives)
    val first: Boolean = true,        // the finger arrives (cursor flies in) before this phase
    val last: Boolean = true,         // the finger lifts after this phase
    val moving: Boolean = false       // this phase moves from (x1,y1) to (x2,y2)
)

/**
 * Visible real-time touch indicator: an animated finger cursor with a coloured circular ripple at the exact screen coordinates of
 * every tap, double-tap, long-press, swipe and drag the AI performs. The cursor travels along swipe/drag paths in step with the
 * gesture, the touched element is briefly highlighted, and a failed or cancelled gesture is shown in red.
 *
 * Synchronisation: [prepare] runs before dispatchGesture() (the finger arrives first), [fire] runs immediately before it, and
 * [finish] is called from the GestureResultCallback (onCompleted / onCancelled), so the picture ends when Android says it ended.
 *
 * It is drawn in a TYPE_ACCESSIBILITY_OVERLAY window owned by the accessibility service (no extra permission). The window is
 * FLAG_NOT_TOUCHABLE and not important for accessibility: it never receives or blocks touches and is never part of the UI the
 * agent reads. It exists only while something is being shown and is removed shortly afterwards. Switch: Agent Control -> Touch indicator.
 */
object TouchIndicator {
    /** Time the finger needs to fly to the target before the real gesture starts. */
    const val PRE_MS = 220L
    @Volatile var enabled = true

    private val main = Handler(Looper.getMainLooper())
    private var wm: WindowManager? = null
    private var view: TouchView? = null
    private val removeTask = Runnable { removeNow() }

    /** Any thread. Shows the cursor flying to the start point; returns how long the caller should wait before dispatching. */
    fun prepare(s: AccessibilityService, t: TouchSpec): Long {
        if (!enabled) return 0L
        main.post { try { main.removeCallbacks(removeTask); ensure(s)?.begin(t) } catch (_: Throwable) { } }
        return if (t.first) PRE_MS else 0L
    }

    /** Any thread. Call immediately before dispatchGesture(): starts the press / path animation of this phase. */
    fun fire(t: TouchSpec) { if (enabled) main.post { try { view?.fire(t) } catch (_: Throwable) { } } }

    /** Any thread. Call from the gesture callback (or with the real result of a node action). Safe to call more than once. */
    fun finish(t: TouchSpec, ok: Boolean) {
        main.post {
            try { view?.finish(t, ok) } catch (_: Throwable) { }
            if (t.last || !ok) { main.removeCallbacks(removeTask); main.postDelayed(removeTask, 1600L) }
        }
    }

    /** Any thread. Removes the overlay at once (Stop, accessibility turned off, indicator switched off). */
    fun hide() { main.post { main.removeCallbacks(removeTask); removeNow() } }

    private fun removeNow() {
        val v = view ?: return
        try { wm?.removeView(v) } catch (_: Throwable) { }
        view = null
    }

    private fun ensure(s: AccessibilityService): TouchView? {
        view?.let { return it }
        val w = s.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val v = TouchView(s)
        v.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED, PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            if (Build.VERSION.SDK_INT >= 28) layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            title = "ZynTouchIndicator"
        }
        return try { w.addView(v, p); wm = w; view = v; v } catch (_: Throwable) { null }
    }

    // ------------------------------------------------------------------------------------------------------------------------

    private class Ripple(val x: Float, val y: Float, val t0: Long, val dur: Long, val color: Int, val maxR: Float)
    private class Hl(val r: RectF, val t0: Long, val color: Int) { var end = 0L }

    private val C_TAP = 0xFF7C4DFF.toInt()
    private val C_DOUBLE = 0xFF00BFA5.toInt()
    private val C_LONG = 0xFFFFB300.toInt()
    private val C_SWIPE = 0xFF29B6F6.toInt()
    private val C_DRAG = 0xFFFF6E40.toInt()
    private val C_FAIL = 0xFFE53935.toInt()
    private fun colorFor(kind: String) = when (kind) { "double_tap" -> C_DOUBLE; "long_press" -> C_LONG; "swipe" -> C_SWIPE; "drag" -> C_DRAG; else -> C_TAP }

    private class TouchView(c: Context) : View(c) {
        private val d = c.resources.displayMetrics.density
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
        private val loc = IntArray(2)

        private var vis = false; private var beginT = 0L; private var color = C_TAP
        private var flyX = 0f; private var flyY = 0f; private var flyT0 = 0L; private var flyEnd = 0L; private var restX = 0f; private var restY = 0f
        private var mvT0 = 0L; private var mvDur = 0L; private var mvX1 = 0f; private var mvY1 = 0f; private var mvX2 = 0f; private var mvY2 = 0f
        private var trail = false; private var trX = 0f; private var trY = 0f
        private var ringT0 = 0L; private var ringDur = 0L; private var ringColor = C_LONG
        private var fadeT0 = 0L
        private var px = 0f; private var py = 0f
        private val wins = ArrayList<LongArray>()      // pressed windows [start, end]; end 0 = still pressed
        private val ripples = ArrayList<Ripple>()
        private val hls = ArrayList<Hl>()

        // Finger cursor, drawn in dp units with the touch point at the origin (the fingertip). Outline pass first, then white fill pass.
        private val hand = listOf(
            RectF(-6.5f, -5f, 6.5f, 30f) to 6.5f, RectF(5f, 14f, 17f, 34f) to 6f, RectF(13f, 18f, 24f, 36f) to 5.5f,
            RectF(-17f, 22f, 19f, 56f) to 13f, RectF(-27f, 28f, -12f, 46f) to 7.5f
        )

        private fun ca(col: Int, a: Float) = (col and 0x00FFFFFF) or ((Color.alpha(col) * a.coerceIn(0f, 1f)).toInt() shl 24)
        private fun ease(p: Float) = 1f - (1f - p) * (1f - p) * (1f - p)

        private fun reset() {
            wins.clear(); ripples.clear(); hls.clear(); mvT0 = 0L; trail = false; ringT0 = 0L; fadeT0 = 0L
        }

        fun begin(t: TouchSpec) {
            val now = SystemClock.uptimeMillis()
            reset(); vis = true; beginT = now; color = colorFor(t.kind)
            restX = t.x1.toFloat(); restY = t.y1.toFloat()
            flyX = restX + 36f * d; flyY = restY + 120f * d; flyT0 = now; flyEnd = now + PRE_MS
            t.bounds?.let { if (it.width() > 0 && it.height() > 0) hls.add(Hl(RectF(it), now, color)) }
            invalidate()
        }

        private fun press(now: Long, open: Boolean, endAt: Long = 0L) { wins.add(longArrayOf(now, if (open) 0L else endAt)) }
        private fun ripple(x: Float, y: Float, t0: Long, dur: Long, col: Int, r: Float) { ripples.add(Ripple(x, y, t0, dur, col, r * d)) }

        fun fire(t: TouchSpec) {
            if (!vis) return
            val now = SystemClock.uptimeMillis()
            val x1 = t.x1.toFloat(); val y1 = t.y1.toFloat()
            when (t.kind) {
                "tap" -> { press(now, false, now + 60); ripple(x1, y1, now, 520, color, 58f) }
                "double_tap" -> {
                    press(now, false, now + 50); press(now + 150, false, now + 200)
                    ripple(x1, y1, now, 480, color, 54f); ripple(x1, y1, now + 150, 480, color, 62f)
                }
                "long_press" -> {
                    press(now, true); ringT0 = now; ringDur = t.durationMs; ringColor = color
                    ripple(x1, y1, now, 520, color, 50f); ripple(x1, y1, now + t.durationMs, 600, color, 78f)
                }
                "swipe" -> {
                    press(now, true); beginMove(t, now); ripple(x1, y1, now, 480, color, 46f)
                }
                "drag" -> {
                    if (!t.moving) { press(now, true); ringT0 = now; ringDur = t.durationMs; ringColor = color; ripple(x1, y1, now, 520, color, 52f) }
                    else {
                        if (wins.isEmpty()) press(now, true)
                        beginMove(t, now)
                        t.bounds2?.let { if (it.width() > 0 && it.height() > 0) hls.add(Hl(RectF(it), now + (t.durationMs * 0.7f).toLong(), color)) }
                    }
                }
                else -> { press(now, false, now + 60); ripple(x1, y1, now, 520, color, 58f) }
            }
            invalidate()
        }

        private fun beginMove(t: TouchSpec, now: Long) {
            mvT0 = now; mvDur = t.durationMs.coerceAtLeast(1L)
            mvX1 = t.x1.toFloat(); mvY1 = t.y1.toFloat(); mvX2 = t.x2.toFloat(); mvY2 = t.y2.toFloat()
            trail = true; trX = mvX1; trY = mvY1
        }

        fun finish(t: TouchSpec, ok: Boolean) {
            if (!vis) return
            val now = SystemClock.uptimeMillis()
            if (!ok) {
                ripples.removeAll { it.t0 > now }; computePos(now)
                for (w in wins) if (w[1] == 0L) w[1] = now
                ripple(px, py, now, 650, C_FAIL, 66f)
                fadeT0 = now + 450; hls.forEach { if (it.end == 0L) it.end = now + 150 }
                return
            }
            if (!t.last) return                       // drag: the finger is still down between hold and move
            for (w in wins) if (w[1] == 0L) w[1] = now
            ripples.removeAll { it.t0 > now + 1500 }
            if (t.kind == "swipe" || t.kind == "drag") { computePos(now); ripple(px, py, now, 480, color, 50f) }
            fadeT0 = now + 380; hls.forEach { if (it.end == 0L) it.end = now + 330 }
        }

        private fun computePos(now: Long) {
            if (mvT0 > 0L && now >= mvT0) {
                val p = ((now - mvT0) / mvDur.toFloat()).coerceIn(0f, 1f)
                px = mvX1 + (mvX2 - mvX1) * p; py = mvY1 + (mvY2 - mvY1) * p
            } else if (now < flyEnd) {
                val p = ease(((now - flyT0) / (flyEnd - flyT0).toFloat()).coerceIn(0f, 1f))
                px = flyX + (restX - flyX) * p; py = flyY + (restY - flyY) * p
            } else { px = restX; py = restY }
        }

        private fun pressed(now: Long): Boolean { for (w in wins) if (now >= w[0] && (w[1] == 0L || now < w[1])) return true; return false }

        override fun onDraw(c: Canvas) {
            if (!vis) return
            val now = SystemClock.uptimeMillis()
            if (now - beginT > 9000L) { vis = false; return }
            var fade = 1f
            if (fadeT0 > 0L && now >= fadeT0) { fade = 1f - (now - fadeT0) / 450f; if (fade <= 0f) { vis = false; return } }
            getLocationOnScreen(loc); c.save(); c.translate(-loc[0].toFloat(), -loc[1].toFloat())      // draw in true screen pixels
            computePos(now)

            // 1) touched-element highlight
            for (h in hls) {
                if (now < h.t0) continue
                var a = ((now - h.t0) / 140f).coerceIn(0f, 1f)
                if (h.end > 0L && now >= h.end) a *= (1f - (now - h.end) / 320f).coerceIn(0f, 1f)
                if (a <= 0f) continue
                val pulse = 1f + 0.5f * sin((now - h.t0) / 90f)
                val r = RectF(h.r); r.inset(-3f * d, -3f * d)
                fill.color = ca(h.color, 0.16f * a); c.drawRoundRect(r, 8f * d, 8f * d, fill)
                line.color = ca(h.color, 0.95f * a); line.strokeWidth = 3f * d * pulse; c.drawRoundRect(r, 8f * d, 8f * d, line)
            }
            // 2) swipe / drag trail, from the start point to where the finger is now
            if (trail) {
                line.color = ca(color, 0.55f * fade); line.strokeWidth = 8f * d; c.drawLine(trX, trY, px, py, line)
                fill.color = ca(color, 0.8f * fade); c.drawCircle(trX, trY, 5f * d, fill)
            }
            // 3) circular ripples
            val iter = ripples.iterator()
            while (iter.hasNext()) {
                val r = iter.next(); val p = (now - r.t0) / r.dur.toFloat()
                if (p < 0f) continue
                if (p > 1f) { iter.remove(); continue }
                val rad = r.maxR * (0.2f + 0.8f * ease(p)); val a = (1f - p) * fade
                fill.color = ca(r.color, 0.38f * a); c.drawCircle(r.x, r.y, rad, fill)
                line.color = ca(r.color, 0.95f * a); line.strokeWidth = 3.5f * d; c.drawCircle(r.x, r.y, rad, line)
            }
            // 4) long-press / drag-hold progress ring around the fingertip
            if (ringT0 > 0L && now >= ringT0 && now <= ringT0 + ringDur + 60) {
                val p = ((now - ringT0) / ringDur.toFloat()).coerceIn(0f, 1f)
                val rr = 34f * d; val box = RectF(px - rr, py - rr, px + rr, py + rr)
                line.color = ca(ringColor, 0.3f * fade); line.strokeWidth = 5f * d; c.drawCircle(px, py, rr, line)
                line.color = ca(ringColor, 0.95f * fade); c.drawArc(box, -90f, 360f * p, false, line)
            }
            // 5) contact dot while the finger is really down
            val down = pressed(now)
            if (down) {
                fill.color = ca(color, 0.5f * fade); c.drawCircle(px, py, 17f * d, fill)
                line.color = ca(Color.WHITE, 0.9f * fade); line.strokeWidth = 2f * d; c.drawCircle(px, py, 17f * d, line)
            }
            // 6) finger cursor, fingertip exactly on (px, py)
            val inA = ((now - flyT0) / 150f).coerceIn(0f, 1f) * fade
            val sc = (if (down) 0.86f else 1f) * d
            c.save(); c.translate(px, py); c.rotate(-18f); c.scale(sc, sc)
            fill.color = ca(Color.BLACK, 0.28f * inA)
            c.save(); c.translate(2f, 3.5f); for ((rc, rx) in hand) c.drawRoundRect(rc, rx, rx, fill); c.restore()
            line.color = ca(0xFF1D1B20.toInt(), inA); line.strokeWidth = 3.4f
            for ((rc, rx) in hand) c.drawRoundRect(rc, rx, rx, line)
            fill.color = ca(Color.WHITE, inA)
            for ((rc, rx) in hand) c.drawRoundRect(rc, rx, rx, fill)
            c.restore()
            c.restore()
            postInvalidateOnAnimation()
        }
    }
}
