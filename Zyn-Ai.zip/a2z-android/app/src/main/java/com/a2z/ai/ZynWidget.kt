package com.a2z.ai

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import java.util.Calendar

/**
 * Home-screen widget: a glass-gradient card with a greeting, an "Ask Zyn anything" pill and four round actions
 * (New chat, Voice, Agent, Floating bubble). The bubble button and the status chip always show the real state of the
 * floating assistant; [refresh] is called by [FloatingAssistantService] whenever it starts or stops.
 */
class ZynWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val v = build(context)
        for (id in ids) manager.updateAppWidget(id, v)
    }

    companion object {
        private const val FLAGS = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT

        fun refresh(ctx: Context) {
            try {
                val m = AppWidgetManager.getInstance(ctx)
                val ids = m.getAppWidgetIds(ComponentName(ctx, ZynWidget::class.java))
                if (ids.isNotEmpty()) m.updateAppWidget(ids, build(ctx))
            } catch (_: Throwable) { }
        }

        /** Opens the app; [mode] tells MainActivity which screen / action to start (see MainActivity.agentVoiceIntent). */
        private fun openApp(ctx: Context, code: Int, mode: String): PendingIntent {
            val i = Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP).putExtra("a2z_widget", mode)
            return PendingIntent.getActivity(ctx, code, i, FLAGS)
        }

        private fun bubbleIntent(ctx: Context, on: Boolean): PendingIntent {
            if (on) return PendingIntent.getService(ctx, 5, Intent(ctx, FloatingAssistantService::class.java).setAction(FloatingAssistantService.ACT_STOP), FLAGS)
            if (!FloatPerm.has(ctx)) {
                val i = Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP).putExtra("a2z_float_start", true)
                return PendingIntent.getActivity(ctx, 6, i, FLAGS)
            }
            return PendingIntent.getForegroundService(ctx, 7, Intent(ctx, FloatingAssistantService::class.java).setAction(FloatingAssistantService.ACT_START), FLAGS)
        }

        fun build(ctx: Context): RemoteViews {
            val v = RemoteViews(ctx.packageName, R.layout.zyn_widget)
            val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
            v.setTextViewText(R.id.zwGreet, when { h in 5..11 -> "Good morning"; h in 12..16 -> "Good afternoon"; h in 17..20 -> "Good evening"; else -> "Hello, night owl" })
            val on = FloatingAssistantService.running
            v.setTextViewText(R.id.zwChip, if (on) "● Bubble on" else "○ Bubble off")
            v.setInt(R.id.zwChip, "setBackgroundResource", if (on) R.drawable.zw_chip_on else R.drawable.zw_chip_off)
            v.setTextViewText(R.id.zwBubbleLabel, if (on) "Hide" else "Bubble")
            val bubble = bubbleIntent(ctx, on)
            v.setOnClickPendingIntent(R.id.zwAsk, openApp(ctx, 1, "ask"))
            v.setOnClickPendingIntent(R.id.zwNew, openApp(ctx, 2, "new"))
            v.setOnClickPendingIntent(R.id.zwVoice, openApp(ctx, 3, "voice"))
            v.setOnClickPendingIntent(R.id.zwAgent, openApp(ctx, 4, "agent"))
            v.setOnClickPendingIntent(R.id.zwBubble, bubble)
            v.setOnClickPendingIntent(R.id.zwChip, bubble)
            return v
        }
    }
}
