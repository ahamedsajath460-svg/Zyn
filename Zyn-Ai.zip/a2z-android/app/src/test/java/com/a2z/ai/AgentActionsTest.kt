package com.a2z.ai

import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

/** Pure JVM tests (no device). NOT RUN in the authoring environment: no Kotlin compiler / Android SDK was available. Run: ./gradlew testDebugUnitTest */
class AgentActionsTest {
    @Test fun nestedActionWithFence() {
        val r = AgentActions.parse("Sure!\n```json\n{\"explain\":\"open\",\"action\":{\"type\":\"click\",\"id\":\"#4\"}}\n```")!!
        assertEquals("click", r.getJSONObject("action").getString("type")); assertEquals(4, r.getJSONObject("action").getInt("id"))
    }
    @Test fun flatAndAlias() {
        val a = AgentActions.parse("{\"type\":\"type\",\"id\":2,\"value\":\"hi\"}")!!.getJSONObject("action")
        assertEquals("set_text", a.getString("type")); assertEquals("hi", a.getString("text"))
    }
    @Test fun openAiToolCallShape() {
        val a = AgentActions.parse("{\"tool_calls\":[{\"function\":{\"name\":\"long_press\",\"arguments\":\"{\\\"id\\\":7}\"}}]}")!!.getJSONObject("action")
        assertEquals("long_press", a.getString("type")); assertEquals(7, a.getInt("id"))
    }
    @Test fun scrollDownAlias() {
        val a = AgentActions.parse("{\"action\":\"scroll_down\"}")!!.getJSONObject("action")
        assertEquals("scroll", a.getString("type")); assertEquals("down", a.getString("dir"))
    }
    @Test fun garbageIsRejected() { assertNull(AgentActions.parse("no json here")); assertNull(AgentActions.parse("{\"action\":{\"type\":\"format_disk\"}}")) }
}

class AgentPolicyGestureTest {
    private fun v(s: String, img: Boolean) = AgentPolicy.validate(JSONObject(s), null, img)
    @Test fun coordinatesNeedScreenshot() { assertNotNull(v("{\"type\":\"tap\",\"x\":500,\"y\":500}", false)); assertNull(v("{\"type\":\"tap\",\"x\":500,\"y\":500}", true)) }
    @Test fun coordinatesMustBeInRange() { assertNotNull(v("{\"type\":\"tap\",\"x\":1500,\"y\":5}", true)) }
    @Test fun swipeByDirection() { assertNull(v("{\"type\":\"swipe\",\"dir\":\"down\"}", false)); assertNotNull(v("{\"type\":\"swipe\",\"dir\":\"sideways\"}", false)) }
    @Test fun unknownTypeRejected() { assertNotNull(v("{\"type\":\"install_apk\"}", true)) }
}

/** Vision link: pure logic of [AgentVision] and the tap_text action. NOT RUN in the authoring environment (no Kotlin compiler / Android SDK). */
class AgentVisionTest {
    private val lines = listOf(VLine("Wi-Fi", 100, 200, 300, 260), VLine("Wi-Fi calling", 100, 400, 500, 460), VLine("Bluetooth", 100, 600, 400, 660))
    @Test fun exactMatchWins() { assertEquals("Wi-Fi", AgentVision.findText(lines, "wi-fi")!!.text) }
    @Test fun containsPicksShortestLine() { assertEquals("Wi-Fi calling", AgentVision.findText(lines, "calling")!!.text) }
    @Test fun missingTextIsNull() { assertNull(AgentVision.findText(lines, "NFC")); assertNull(AgentVision.findText(lines, "  ")) }
    @Test fun centreScalesToScreenPixels() { assertEquals(400 to 460, AgentVision.toScreen(lines[0], 540, 1200, 1080, 2400)) }
    @Test fun positionedUsesThousandGrid() { assertTrue(AgentVision.positioned(lines, 1000, 2000).startsWith("[100,100,300,130] Wi-Fi")) }
    @Test fun expectNeedsHalfOfTheWords() {
        assertTrue(AgentVision.expectMet("Wi-Fi settings page shown with Bluetooth", "Settings Bluetooth Wi-Fi"))
        assertFalse(AgentVision.expectMet("Battery usage graph", "Settings Bluetooth"))
        assertFalse(AgentVision.expectMet("", "anything"))
    }
    @Test fun recoveryHintsChangeWithTheFailure() {
        assertTrue(AgentVision.recoveryHint("click", false, "not clickable", null, true, 0).contains("tap_text"))
        assertFalse(AgentVision.recoveryHint("click", false, "not clickable", null, false, 0).contains("tap_text"))
        assertTrue(AgentVision.recoveryHint("click", true, "no change", "com.other.app", true, 0).contains("com.other.app"))
        assertTrue(AgentVision.recoveryHint("click", true, "no change", null, true, 2).contains("two actions"))
    }
    @Test fun tapTextParsesAndValidates() {
        val a = AgentActions.parse("{\"action\":{\"type\":\"tap_text\",\"text\":\"Wi-Fi\"}}")!!.getJSONObject("action")
        assertEquals("tap_text", a.getString("type")); assertEquals("Wi-Fi", a.getString("text"))
        assertNotNull(AgentPolicy.validate(a, null, false, false))   // needs live OCR
        assertNull(AgentPolicy.validate(a, null, false, true))
        assertNotNull(AgentPolicy.validate(JSONObject("{\"type\":\"tap_text\"}"), null, false, true))   // needs text
    }
}
