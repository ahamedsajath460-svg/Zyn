package com.a2z.ai

import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

/** Pure JVM tests (no device). NOT RUN in the authoring environment: no Kotlin compiler / Android SDK was available. Run: ./gradlew testDebugUnitTest */
class AgentActionsTest {
    @Test fun nestedActionWithFence() {
        val r = AgentActions.parse("Sure!\n```json\n{\"explain\":\"open\",\"action\":{\"type\":\"click\",\"id\":\"#4\"}}\n```")!!
        assertEquals("click", r.getJSONObject("action").getString("type")); assertEquals(4, r.getJSONObject("action").getInt("id"))
    }
    @Test fun flatAndAlias() {
        val a = AgentActions.parse("{\"type\":\"type\",\"id\":2,\"value\":\"hi\"}")!!.getJSONObject("action")
        assertEquals("set_text", a.getString("type")); assertEquals("hi", a.getString("text"))
    }
    @Test fun openAiToolCallShape() {
        val a = AgentActions.parse("{\"tool_calls\":[{\"function\":{\"name\":\"long_press\",\"arguments\":\"{\\\"id\\\":7}\"}}]}")!!.getJSONObject("action")
        assertEquals("long_press", a.getString("type")); assertEquals(7, a.getInt("id"))
    }
    @Test fun scrollDownAlias() {
        val a = AgentActions.parse("{\"action\":\"scroll_down\"}")!!.getJSONObject("action")
        assertEquals("scroll", a.getString("type")); assertEquals("down", a.getString("dir"))
    }
    @Test fun garbageIsRejected() { assertNull(AgentActions.parse("no json here")); assertNull(AgentActions.parse("{\"action\":{\"type\":\"format_disk\"}}")) }
}

class AgentPolicyGestureTest {
    private fun v(s: String, img: Boolean) = AgentPolicy.validate(JSONObject(s), null, img)
    @Test fun coordinatesNeedScreenshot() { assertNotNull(v("{\"type\":\"tap\",\"x\":500,\"y\":500}", false)); assertNull(v("{\"type\":\"tap\",\"x\":500,\"y\":500}", true)) }
    @Test fun coordinatesMustBeInRange() { assertNotNull(v("{\"type\":\"tap\",\"x\":1500,\"y\":5}", true)) }
    @Test fun swipeByDirection() { assertNull(v("{\"type\":\"swipe\",\"dir\":\"down\"}", false)); assertNotNull(v("{\"type\":\"swipe\",\"dir\":\"sideways\"}", false)) }
    @Test fun unknownTypeRejected() { assertNotNull(v("{\"type\":\"install_apk\"}", true)) }
}
